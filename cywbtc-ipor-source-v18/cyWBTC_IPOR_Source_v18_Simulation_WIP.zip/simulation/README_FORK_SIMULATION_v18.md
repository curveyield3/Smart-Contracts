# cyWBTC Ethereum mainnet-fork functional simulation — v18

## Scope and execution boundary

`simulation/run_ethereum_fork_v18.py` extends the existing **real Yearn v19 deployment/configuration script** (`script/DeployFXUSDYearnV19.s.sol`) into a local-fork function-execution and state-reporting workflow. The original deployment contract transactions and ordered configuration are unchanged; only local-console address markers were added to the deployment script.

The simulation runs transactions on **a fresh, isolated Anvil process bound to `127.0.0.1`** and connects Forge only to that process. Its upstream `ETHEREUM_FORK_RPC_URL` is read by Anvil solely for mainnet state; it is never given to Forge, cast, or an `eth_sendTransaction` call. The script verifies `anvil_nodeInfo`, chain ID 1, and code at known mainnet addresses before any write. It funds simulation actors through **local-fork impersonation** of *actual* token holders, not by minting synthetic collateral. It never signs or broadcasts real Ethereum transactions.

**This is a simulation runner, not a full IPOR deployment implementation.** The v17 archive has not finished the official IPOR factory clone/configuration sequence. For that reason, the IPOR portion deliberately reports `BLOCKED` until actual deployed fork IPOR vault/fuse addresses and authorized actors are supplied. `PASS` cannot be reached by omitting IPOR scenarios. Source-zip packaging compliance remains incomplete until the underlying deployment and oracle wiring are finished.

## What is exercised

- Yearn deployment: factory creation; master, Pool 32, Pool 37, FXN reward child, router, Accountant; allocation 55/45; reward allocation 8%; auto-allocation queue; keeper/role settings; structural readback.
- Yearn public flow: real fxUSD funding on fork, ERC20 approval, deposit, verification that vault shares and both child exposures increase, partial native Yearn V3 loss-aware redemption at 25 bps, harvest, reward-engine harvest, vault `process_report`.
- Yearn governance: reject invalid allocations; set temporary 60/40 and restore; reject reward allocation above 20%; temporarily set 20% and restore.
- Yearn cooldown: request with real vault shares, claim/share fee, read actual unlock timestamp, move fork time, settle fxBASE cooldown, claim fxUSD at a 25 bps maximum accepted loss, check payout.
- IPOR readback: WBTC vault asset, fxMINT manager and market IDs, oracle price for fxUSD, **exactly one** instant withdrawal provider (LTV manager), registered owned position.
- IPOR active flow: fund WBTC from real on-chain holder (on fork), approve/deposit, atomic fxMINT NFT open plus adapter registration, borrow/reinvest via rebalance-up and validate increasing debt/Yearn shares, lower target then repay via rebalance-down and validate debt decrease, restore target and slippage, execute vault `withdraw` (LTV-guarded) and check collateral/debt/LTV.
- Negative authorization/configuration: direct LTV manager invocation must revert, invalid slippage and out-of-range Yearn allocations must revert without changing state.

Every write produces: transaction hash **on the local Anvil fork**, status, block, gas used, effective gas price, receipt log count, before/after state read using fresh `eth_call`, and raw error if failed. Snapshots include WBTC/fxUSD balances, vault shares, child shares, NAV, idle/debt, fxMINT collateral, debt, oracle exchange price, and LTV where applicable. Final state is queried again **after all fork transactions**, independent of Foundry's dry-run trace. JSON and readable Markdown are generated under `simulation-output/` (not included as audit inputs).

When no available reward accrual exists, a successful harvest proves the harvest *call pathway* but **not** yield conversion under nonzero reward input. Similarly, a skipped cooldown for insufficient liquidity is a BLOCKED case, never PASS. Failing transactions and invariants are never silently ignored.

## Requirements

Python 3.10+, the genuine Foundry `anvil`, `forge`, and `cast` binaries, accessible mainnet archive/full-state HTTPS RPC, enough local resources for an Ethereum fork, and genuine deployed protocol code at the pinned Ethereum mainnet fork height. A fresh fork may be pinned with `SIM_FORK_BLOCK_NUMBER`.

The script inherits the real Yearn V19 deployer's environment inputs exactly as defined in `script/DeployFXUSDYearnV19.s.sol`: `FXUSD`, `FXN`, `WETH`, `USDC`, `YEARN_V3_FACTORY` (optional), `YEARN_TOKENIZED_STRATEGY_IMPL` (optional), `CONVEX_FX_BOOSTER`, `CONVEX_FX_POOL_REGISTRY`, `CONVEX_FX_GAUGE_32`, `CONVEX_FX_GAUGE_37`, `CONVEX_FX_GAUGE_8`, `SDFXN`, `CURVE_SDFXN_FXN_POOL` (optional), `BOOSTHUB`, `BOOSTHUB_SDFXN_PID` (optional), `FXBASE_POOL`, `CURVE_USDC_FXUSD_POOL`, `CURVE_FXN_WETH_POOL`, `CURVE_WETH_USDC_POOL`, `VAULT_OWNER`, `HARVEST_KEEPER`, `VAULT_FEE_RECIPIENT` (optional), and Yearn fee/deposit-cap inputs. **Do not supply production private keys**: use a disposable Anvil-only key as `SIM_DEPLOYER_PRIVATE_KEY`. The wrapper copies it into the deployment script's `DEPLOYER_PRIVATE_KEY` variable **only for local Anvil**. The key is not written to disk or to reports.

Simulation-specific inputs:

| Variable | Use |
|---|---|
| `ETHEREUM_FORK_RPC_URL` | Upstream Ethereum mainnet state reads by Anvil (never transaction endpoint) |
| `SIM_DEPLOYER_PRIVATE_KEY` | Dedicated disposable local-fork deployment signer |
| `SIM_DEPOSITOR` | Ethereum address impersonated only on local fork for deposit/withdraw scenarios |
| `SIM_FXUSD_FUNDER` | Actual fork-state fxUSD holder providing simulation tokens; never real transfer |
| `SIM_WBTC_FUNDER` | Actual fork-state WBTC holder providing simulation collateral; never real transfer |
| `SIM_YEARN_DEPOSIT_RAW` | fxUSD raw amount to deposit (default 100 × 10¹⁸) |
| `SIM_WBTC_DEPOSIT_RAW` | WBTC raw amount to deposit (default 100000 = 0.001 WBTC) |
| `SIM_IPOR_WITHDRAW_RAW` | WBTC raw amount to withdraw from IPOR vault (default 10% of initial deposit) |
| `SIM_IPOR_VAULT` | **Existing fully configured IPOR fork clone**; current v17 cannot deploy it |
| `SIM_LTV_MANAGER` | Actual deployed fxMINT LTV manager |
| `SIM_FXMINT_COLLATERAL_FUSE` | Actual deployed collateral fuse |
| `SIM_FXMINT_ACCOUNTING_ADAPTER` | Actual deployed NFT accounting adapter |
| `SIM_IPOR_ALPHA` | Authorized IPOR ALPHA role holder, impersonated on local fork |
| `SIM_LTV_MANAGER_OWNER` | Exact LTV manager owner, impersonated on local fork |
| `SIM_PRICE_MIDDLEWARE` | Exact IPOR middleware with a live valid fxUSD/USD feed |

To use an **already deployed Yearn fork stack** instead of deploying it during the run, set `SIM_SKIP_YEARN_DEPLOY=1` and supply `SIM_YEARN_VAULT`, `SIM_YEARN_MASTER`, `SIM_YEARN_CHILD_32`, and `SIM_YEARN_CHILD_37`. This is particularly useful for a combined IPOR deployment script that creates both stacks. This bypass only changes deployment preparation, **not the functional cases**.

Start from the unzipped project root, with your configuration stored outside the ZIP and exported into the shell:

```bash
python3 simulation/run_ethereum_fork_v18.py
```

No public RPC, private key, credential or secret is included in this ZIP. The runner does not open a public listening port; it terminates Anvil after the run. Its exit status is **0 only if every required case passed**, 2 if any case is blocked or failed. It writes:

- `simulation-output/simulation-report-v18.json` — detailed machine-readable receipts and state history.
- `simulation-output/simulation-report-v18.md` — function-by-function human-readable summary and full snapshots.

**Current real status (2026-11-12): NOT FORK-VERIFIED.** This environment has no `forge`, `anvil`, `cast` or Ethereum RPC credential, so no actual fork execution occurred. The v17 IPOR deployer, genuine configured fxUSD oracle and final mainnet deployment inputs also remain incomplete. The runner's local source/Python syntax was inspected; this is not evidence of smart-contract behavior. A complete run on a real fork is still required before stating that deployment or functions work.
