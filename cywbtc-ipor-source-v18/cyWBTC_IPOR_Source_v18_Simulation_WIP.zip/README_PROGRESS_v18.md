# cyWBTC IPOR Ethereum Source — v18 simulation extension

**Status: work-in-progress (WIP); Ethereum mainnet-fork runner implemented, but NOT fork-executed, NOT mainnet-deployed, and NOT a complete Lite-Solo source-audit package.**

## Change from v17

- Kept all v17 `contracts/` and `lib/` Solidity files **byte-identical**; neither audited business logic nor pinned official imports were changed.
- Added `simulation/run_ethereum_fork_v18.py`: an isolated Ethereum mainnet-fork runner that invokes the existing Yearn v19 deployment/configuration script, performs actual contract function transactions, captures receipts, snapshots state after each operation, checks key invariants, and emits JSON plus Markdown reports.
- Added machine-readable simulation status and operator instructions under `simulation/`.
- Added strictly informational local-console deployed-address markers to `script/DeployFXUSDYearnV19.s.sol` so the runner can automatically discover Yearn master, vault, child, reward router and accountant after real deployment transactions. Deployment ordering, constructors and original owner/configuration calls remain unchanged.

## Required deployment completion work (unchanged from v17)

The official IPOR Fusion factory clone/configuration script, remaining IPOR execution dependencies, mainnet fxUSD/USD oracle source, role handoffs and full deployment profile are still unfinished. The existing Yearn v19 deployment script does not deploy or configure the IPOR PlasmaVault. The simulation checks the Yearn layer and **blocks the IPOR transaction suite** until the genuine configured IPOR vault, relevant fuses and alpha/owner actor addresses exist on the fork. No fake address, mock vault, dummy deployment, or in-scope code substitution is included.

The expected Lite Solo `audit-deployment.json` remains **absent**, intentionally, until the mandatory real complete deployment is available. Do not submit this WIP ZIP as a successful Lite Solo initializer package.

## Execution evidence

Static inspection: local Python syntax compilation succeeded; 67 Solidity sources (including script and locally vendored imports) have no unresolved import paths. **No Solidity compilation or Ethereum fork simulation was executed** in this environment, because `anvil`, `forge`, `cast` and a user-authenticated Ethereum RPC endpoint are not available. The simulation is not proof that any new contracts or function paths work. See `simulation/README_FORK_SIMULATION_v18.md` for the commands, dependencies, required configuration, exact scenario coverage and report output.
