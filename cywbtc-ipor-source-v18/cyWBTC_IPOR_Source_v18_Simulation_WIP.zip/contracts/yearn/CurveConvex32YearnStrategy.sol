// SPDX-License-Identifier: AGPL-3.0
pragma solidity ^0.8.30;
import {FXNYearnChildBase} from "./FXNYearnChildBase.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ITokenizedStrategy} from "@tokenized-strategy/interfaces/ITokenizedStrategy.sol";

interface ICurveFxUSDPoolY {
    function coins(uint256) external view returns (address);
    function add_liquidity(uint256[2] calldata, uint256 minLp) external returns (uint256);
    function calc_token_amount(uint256[2] calldata amounts, bool isDeposit) external view returns (uint256);
    function calc_withdraw_one_coin(uint256 lp, int128 i) external view returns (uint256);
    function get_virtual_price() external view returns (uint256);
    function remove_liquidity_one_coin(uint256 lp, int128 i, uint256 minOut) external returns (uint256);
}

/** @notice Yearn fxUSD child: fxUSD -> Curve USDC/fxUSD LP -> Convex f(x) pool 32. */
contract CurveConvex32YearnStrategy is FXNYearnChildBase {
    using SafeERC20 for IERC20;
    ICurveFxUSDPoolY public immutable CURVE;
    // Preserves the V13 virtual-price single-sided fxUSD exit guard: 0.20%
    // default, owner configurable from 0.05% to 0.55%.
    uint16 public curveExitToleranceBps = 20;
    // Exact rational Yearn share price at the most recent completed report.
    // Starts at the native 1:1 initial Yearn tokenized-strategy exchange rate.
    uint256 public reportedPpsAssets = 1;
    uint256 public reportedPpsShares = 1;
    uint256 public reportedPpsTimestamp;
    event CurveExitToleranceSet(uint16 bps);
    event ReportPricePerShareCheckpoint(uint256 assets, uint256 shares, uint256 timestamp);
    event NavFloorWithdrawal(uint256 grossAssets, uint256 netAssets, uint256 loss,
        uint256 remainingNAV, uint256 remainingShares);

    function setCurveExitToleranceBps(uint16 bps) external onlyGovernance {
        if (bps < 5 || bps > 55) revert BadConfiguration();
        curveExitToleranceBps = bps;
        emit CurveExitToleranceSet(bps);
    }

    /// @notice Unlike the plain delegatecall fallback, this wrapper captures
    /// the exact share-price baseline AFTER Yearn finishes a report, including
    /// its fee/share accounting. All standard Yearn keeper permissions still
    /// apply because the delegated report retains the original msg.sender.
    function report() external returns (uint256 profit, uint256 loss) {
        (profit, loss) = abi.decode(
            _delegateCall(abi.encodeCall(ITokenizedStrategy.report, ())),
            (uint256, uint256)
        );
        uint256 shares = ITokenizedStrategy(address(this)).totalSupply();
        if (shares == 0) {
            reportedPpsAssets = 1;
            reportedPpsShares = 1;
        } else {
            reportedPpsAssets = ITokenizedStrategy(address(this)).lastTotalAssets();
            reportedPpsShares = shares;
        }
        reportedPpsTimestamp = block.timestamp;
        emit ReportPricePerShareCheckpoint(
            reportedPpsAssets, reportedPpsShares, block.timestamp
        );
    }

    constructor(address fxusd, address fxn, address master, address governance,
        address booster, address registry, address gauge, address curvePool, address tokenizedStrategy)
        FXNYearnChildBase(fxusd, fxn, master, governance, booster, registry, 32,
            gauge, curvePool, tokenizedStrategy, "Yearn fxUSD Curve Convex32") {
        CURVE = ICurveFxUSDPoolY(curvePool);
        if (CURVE.coins(1) != fxusd) revert BadConfiguration();
    }

    function _deployFunds(uint256 amount) internal override {
        if (amount == 0) return;
        uint256[2] memory a;
        a[1] = amount;
        uint256 quote = CURVE.calc_token_amount(a, true);
        uint256 minLp = Math.mulDiv(quote, 10_000 - joinExitSlippageBps, 10_000);
        FXUSD.forceApprove(address(CURVE), amount);
        uint256 beforeLp = STAKING_TOKEN.balanceOf(address(this));
        CURVE.add_liquidity(a, minLp);
        FXUSD.forceApprove(address(CURVE), 0);
        uint256 minted = STAKING_TOKEN.balanceOf(address(this)) - beforeLp;
        if (minted < minLp || minted == 0) revert Slippage();
        _stake(minted);
    }

    /// @notice Native Yearn loss-aware withdrawal. A withdrawal never lowers
    /// the remaining holders' position NAV per share below the last completed
    /// report checkpoint. Accrued LP virtual-price gains since that checkpoint
    /// absorb exit costs first; any uncovered cost is reflected as lower fxUSD
    /// delivered by Yearn's own redeem() loss mechanism.
    /// @dev The master MUST use redeem(..., maxLoss) instead of
    /// withdraw(..., maxLoss=0), and MUST pass the realized loss through to
    /// the withdrawing master/vault shares instead of socializing it.
    function _freeFunds(uint256 fxusdNeeded) internal override {
        if (fxusdNeeded == 0) return;
        uint256 startingIdle = FXUSD.balanceOf(address(this));
        // Yearn's callback parameter already excludes idle balance.
        uint256 grossAssets = startingIdle + fxusdNeeded;
        uint256 shareSupply = ITokenizedStrategy(address(this)).totalSupply();
        uint256 nominalShares = ITokenizedStrategy(address(this)).previewWithdraw(grossAssets);
        if (nominalShares > shareSupply) nominalShares = shareSupply;
        if (nominalShares == 0 || shareSupply == 0) revert NoLiquidity();
        uint256 remainingShares = shareSupply - nominalShares;
        uint256 reportedFloor = Math.mulDiv(
            reportedPpsAssets, remainingShares, reportedPpsShares, Math.Rounding.Up
        );
        uint256 navBefore = positionAssets();
        // If a market loss already reduced PPS below the last report, no
        // withdrawal tax can restore that historical loss for all holders.
        // Protect current pro-rata NAV instead of blocking all withdrawals.
        uint256 currentFloor = Math.mulDiv(
            navBefore, remainingShares, shareSupply, Math.Rounding.Up
        );
        uint256 remainingFloor = Math.min(reportedFloor, currentFloor);

        // Remove no more LP NAV than remaining holders can safely absorb.
        uint256 allowedLpDebit = navBefore - remainingFloor;
        if (allowedLpDebit > startingIdle) {
            _unwindLpWithinNavBudget(fxusdNeeded, allowedLpDebit - startingIdle);
        }

        uint256 payout = Math.min(grossAssets, FXUSD.balanceOf(address(this)));
        uint256 loss = grossAssets - payout;
        uint256 navAfterUnwind = positionAssets();
        // Check executable final NAV, not only pre-exit virtual-price math.
        // This catches virtual-price changes and unexpected curve rounding.
        if (navAfterUnwind < payout || navAfterUnwind - payout < remainingFloor)
            revert Slippage();
        emit NavFloorWithdrawal(grossAssets, payout, loss,
            navAfterUnwind - payout, remainingShares);
        // Intentionally DO NOT revert if payout < grossAssets. The official
        // Yearn TokenizedStrategy._withdraw() passes this loss to the redeemer.
    }

    /// @dev Cap the virtual-price value of burned LP, not the amount of fxUSD
    /// returned by the one-coin exit. This is what protects remaining PPS.
    function _unwindLpWithinNavBudget(uint256 fxusdNeeded, uint256 budget) internal {
        uint256 idleLp = STAKING_TOKEN.balanceOf(address(this));
        uint256 totalLp = idleLp + _gaugeStaked();
        if (totalLp == 0) return;
        uint256 virtualPrice = CURVE.get_virtual_price();
        if (virtualPrice == 0) revert Slippage();
        uint256 maxLpBurn = Math.min(
            totalLp, Math.mulDiv(budget, 1e18, virtualPrice)
        );
        if (maxLpBurn == 0) return;
        uint256 fullQuote = CURVE.calc_withdraw_one_coin(totalLp, 1);
        uint256 desiredLp = fullQuote < fxusdNeeded
            ? totalLp : _sharesForFxUSD(totalLp, fxusdNeeded);
        uint256 lpToBurn = Math.min(desiredLp, maxLpBurn);
        if (lpToBurn > idleLp) _unstake(lpToBurn - idleLp);
        uint256 minOut = Math.mulDiv(
            Math.mulDiv(lpToBurn, virtualPrice, 1e18),
            10_000 - curveExitToleranceBps, 10_000
        );
        STAKING_TOKEN.forceApprove(address(CURVE), lpToBurn);
        CURVE.remove_liquidity_one_coin(lpToBurn, 1, minOut);
        STAKING_TOKEN.forceApprove(address(CURVE), 0);
    }

    /// @dev Emergency withdrawal merely unstakes liquidity within the child;
    /// it does not burn shares or transfer funds out, so no share tax applies.
    function _emergencyWithdraw(uint256 amount) internal override {
        if (amount == 0) return;
        uint256 initialFxUSD = FXUSD.balanceOf(address(this));
        uint256 idleLp = STAKING_TOKEN.balanceOf(address(this));
        uint256 totalLp = idleLp + _gaugeStaked();
        if (totalLp == 0) revert NoLiquidity();
        uint256 lpToBurn = _sharesForFxUSD(totalLp, amount);
        if (lpToBurn > idleLp) _unstake(lpToBurn - idleLp);
        uint256 virtualPrice = CURVE.get_virtual_price();
        uint256 minOut = Math.mulDiv(
            Math.mulDiv(lpToBurn, virtualPrice, 1e18),
            10_000 - curveExitToleranceBps, 10_000
        );
        STAKING_TOKEN.forceApprove(address(CURVE), lpToBurn);
        CURVE.remove_liquidity_one_coin(lpToBurn, 1, minOut);
        STAKING_TOKEN.forceApprove(address(CURVE), 0);
        if (FXUSD.balanceOf(address(this)) - initialFxUSD < amount) revert NoLiquidity();
    }

    function _sharesForFxUSD(uint256 maxShares, uint256 amount) internal view returns (uint256) {
        // Bounded proportional search: normally one/two quotes, maximum seven.
        // Conservatively fall back to a full unwind instead of exhausting transaction gas.
        uint256 fullQuote = CURVE.calc_withdraw_one_coin(maxShares, 1);
        if (fullQuote < amount || fullQuote == 0) revert NoLiquidity();
        uint256 shares = Math.mulDiv(maxShares, amount, fullQuote, Math.Rounding.Up);
        if (shares == 0) shares = 1;
        for (uint256 i; i < 6; ++i) {
            uint256 quote = CURVE.calc_withdraw_one_coin(shares, 1);
            if (quote >= amount) return shares;
            uint256 extra = Math.mulDiv(maxShares, amount - quote, fullQuote, Math.Rounding.Up) + 1;
            if (extra >= maxShares - shares) return maxShares;
            shares += extra;
        }
        return maxShares;
    }

    /// @notice Virtual-price valuation of both idle Curve LP and Convex-staked LP.
    /// @dev Curve StableSwap-NG exposes get_virtual_price() scaled by 1e18.
    ///      Its growth reflects fees retained by Curve liquidity providers.
    ///      The virtual price is an invariant-based LP NAV, NOT a guarantee of
    ///      executable one-coin fxUSD exit proceeds. Exits still use the
    ///      independent one-coin quote and the existing slippage guard.
    function curveLpValuation()
        public view returns (uint256 lpUnits, uint256 virtualPrice, uint256 fxusdValue)
    {
        lpUnits = STAKING_TOKEN.balanceOf(address(this)) + _gaugeStaked();
        if (lpUnits == 0) return (0, 0, 0);
        virtualPrice = CURVE.get_virtual_price();
        if (virtualPrice == 0) revert BadConfiguration();
        fxusdValue = Math.mulDiv(lpUnits, virtualPrice, 1e18);
    }

    function _positionValueFxUSD() internal view override returns (uint256) {
        (,, uint256 fxusdValue) = curveLpValuation();
        return fxusdValue;
    }
}
