// SPDX-License-Identifier: AGPL-3.0
pragma solidity ^0.8.30;

// Pin and vendor the OFFICIAL deployed Yearn V3 BaseStrategy release before compilation.
// The upstream `master` BaseStrategy's tokenizedStrategyAddress is a TEST PLACEHOLDER.
import {BaseStrategy} from "./YearnBaseStrategyFXUSD_v1.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

interface IConvexFxBoosterY { function createVault(uint256 pid) external returns (address); }
interface IConvexFxRegistryY {
    function vaultMap(uint256 pid, address owner) external view returns (address);
    function poolInfo(uint256 pid) external view returns (address, address gauge, address token, address rewards, uint8 active);
}
interface IConvexFxProxyY {
    function owner() external view returns (address);
    function gaugeAddress() external view returns (address);
    function stakingToken() external view returns (address);
    function deposit(uint256 amount) external;
    function withdraw(uint256 amount) external;
    function getReward() external;
}
interface ICurveFxUSDSwapY {
    function coins(uint256 index) external view returns (address);
    function get_dy(int128 i, int128 j, uint256 dx) external view returns (uint256);
    function price_oracle(uint256 k) external view returns (uint256);
    function exchange(int128 i, int128 j, uint256 dx, uint256 minDy) external returns (uint256);
}

/**
 * @notice Shared Yearn V3 FXN-earning child. Each strategy owns ONE Convex personal proxy.
 * @dev No IPOR delegatecalls, no custody outside strategy/proxy; master owns harvest routing.
 *      First-party Yearn ERC4626 functions, reporting, and profit locking come from BaseStrategy.
 */
abstract contract FXNYearnChildBase is BaseStrategy {
    using SafeERC20 for IERC20;

    IERC20 public immutable FXUSD;
    IERC20 public immutable FXN;
    address public immutable MASTER;
    address public immutable GOVERNANCE;
    IConvexFxBoosterY public immutable BOOSTER;
    IConvexFxRegistryY public immutable REGISTRY;
    uint256 public immutable POOL_ID;
    address public immutable GAUGE;
    IERC20 public immutable STAKING_TOKEN;

    uint256 private _entered;
    // Manual capital allocation: no APR samples, ranking, or capital-flow
    // checkpoint ledger. Yearn reports still value the whole underlying position.
    uint256 public joinExitSlippageBps = 100; // 1%, mutable by governance; not harvest-swap slippage
    event FxNClaimed(uint256 amount);
    event Compounded(uint256 fxusd);
    event JoinExitSlippageSet(uint256 bps);
    error Unauthorized();
    error BadConfiguration();
    error InvalidProxy();
    error NoLiquidity();
    error Slippage();
    error Reentrant();

    modifier onlyMaster() { if (msg.sender != MASTER) revert Unauthorized(); _; }
    modifier onlyGovernance() { if (msg.sender != GOVERNANCE) revert Unauthorized(); _; }
    modifier guarded() {
        if (_entered != 0) revert Reentrant();
        _entered = 1;
        _;
        _entered = 0;
    }

    constructor(
        address fxusd, address fxn, address master, address governance,
        address booster, address registry, uint256 poolId, address gauge,
        address stakingToken, address tokenizedStrategy, string memory strategyName
    ) BaseStrategy(fxusd, strategyName, tokenizedStrategy) {
        if (fxusd == address(0) || fxn == address(0) || master == address(0) || governance == address(0)
            || booster == address(0) || registry == address(0) || gauge == address(0) || stakingToken == address(0))
            revert BadConfiguration();
        FXUSD = IERC20(fxusd);
        FXN = IERC20(fxn);
        MASTER = master;
        GOVERNANCE = governance;
        BOOSTER = IConvexFxBoosterY(booster);
        REGISTRY = IConvexFxRegistryY(registry);
        POOL_ID = poolId;
        GAUGE = gauge;
        STAKING_TOKEN = IERC20(stakingToken);
        _checkPool();
    }

    // Yearn V3 master owns all newly minted strategy shares. Prevent strangers
    // from minting a competing stake in either child.
    function availableDepositLimit(address receiver) public view override returns (uint256) {
        return receiver == MASTER ? type(uint256).max : 0;
    }

    function setJoinExitSlippageBps(uint256 bps) external onlyGovernance {
        if (bps > 1_000) revert BadConfiguration();
        joinExitSlippageBps = bps;
        emit JoinExitSlippageSet(bps);
    }

    /// @dev The master measures actual FXN balance deltas from each child to fairly attribute output.
    function claimFxNToMaster() external onlyMaster guarded returns (uint256 amount) {
        address proxy = _personalVault(false);
        if (proxy != address(0)) IConvexFxProxyY(proxy).getReward();
        amount = FXN.balanceOf(address(this));
        if (amount != 0) FXN.safeTransfer(MASTER, amount);
        emit FxNClaimed(amount);
    }

    /// @notice Master transfers fxUSD before calling. The transfer is separate but in ONE atomic tx.
    function compoundFromMaster(uint256 amount) external onlyMaster guarded {
        if (amount == 0 || FXUSD.balanceOf(address(this)) < amount) revert BadConfiguration();
        _deployFunds(amount);
        emit Compounded(amount);
    }

    function availableWithdrawLimit(address) public view virtual override returns (uint256) {
        return positionAssets();
    }

    // The official Yearn emergencyWithdraw callback must be able to recover the
    // underlying investment after shutdown. Keep the normal liquidity guards;
    // management can retry with a smaller amount when pool liquidity changes.
    function _emergencyWithdraw(uint256 amount) internal virtual override {
        if (amount != 0) _freeFunds(amount);
    }

    // Yearn reports full position NAV, including underlying appreciation
    // and converted FXN, with no APR-driven allocation or double counting.
    function _harvestAndReport() internal override returns (uint256) {
        return positionAssets();
    }

    // Keep Yearn report-boundary accounting: BaseStrategy's default is
    // lastTotalAssets. Current position value is exclusively used in reports.
    function positionAssets() public view returns (uint256) {
        return FXUSD.balanceOf(address(this)) + _positionValueFxUSD();
    }

    function _checkPool() internal view {
        (, address gauge, address stakingToken, , ) = REGISTRY.poolInfo(POOL_ID);
        if (gauge != GAUGE || stakingToken != address(STAKING_TOKEN)) revert BadConfiguration();
    }

    function _personalVault(bool create) internal returns (address p) {
        p = REGISTRY.vaultMap(POOL_ID, address(this));
        if (p == address(0) && create) {
            p = BOOSTER.createVault(POOL_ID);
            if (REGISTRY.vaultMap(POOL_ID, address(this)) != p) revert InvalidProxy();
        }
        if (p != address(0)) _checkPersonal(p);
    }

    function _personalVaultView() internal view returns (address p) {
        p = REGISTRY.vaultMap(POOL_ID, address(this));
        if (p != address(0)) _checkPersonal(p);
    }

    function _checkPersonal(address p) internal view {
        if (IConvexFxProxyY(p).owner() != address(this)
            || IConvexFxProxyY(p).gaugeAddress() != GAUGE
            || IConvexFxProxyY(p).stakingToken() != address(STAKING_TOKEN)) revert InvalidProxy();
    }

    function _gaugeStaked() internal view returns (uint256) {
        address p = _personalVaultView();
        return p == address(0) ? 0 : IERC20(GAUGE).balanceOf(p);
    }

    function _stake(uint256 amount) internal {
        if (amount == 0) return;
        _checkPool();
        address p = _personalVault(true);
        uint256 beforeStake = IERC20(GAUGE).balanceOf(p);
        STAKING_TOKEN.forceApprove(p, amount);
        IConvexFxProxyY(p).deposit(amount);
        STAKING_TOKEN.forceApprove(p, 0);
        if (IERC20(GAUGE).balanceOf(p) - beforeStake < amount) revert Slippage();
    }

    function _unstake(uint256 amount) internal {
        if (amount == 0) return;
        address p = _personalVault(false);
        if (p == address(0) || IERC20(GAUGE).balanceOf(p) < amount) revert NoLiquidity();
        uint256 beforeToken = STAKING_TOKEN.balanceOf(address(this));
        IConvexFxProxyY(p).withdraw(amount);
        if (STAKING_TOKEN.balanceOf(address(this)) - beforeToken < amount) revert Slippage();
    }

    function _positionValueFxUSD() internal view virtual returns (uint256);
}
