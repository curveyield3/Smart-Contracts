// SPDX-License-Identifier: AGPL-3.0
pragma solidity ^0.8.30;
import {FXNYearnChildBase, ICurveFxUSDSwapY} from "./FXNYearnChildBase.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ITokenizedStrategy} from "@tokenized-strategy/interfaces/ITokenizedStrategy.sol";

interface IFXBasePoolY {
    function yieldToken() external view returns (address);
    function stableToken() external view returns (address);
    function previewRedeem(uint256 shares) external view returns (uint256 fxusdOut, uint256 usdcOut);
    function previewDeposit(address tokenIn, uint256 amount) external view returns (uint256 sharesOut);
    function instantRedeemFeeRatio() external view returns (uint256);
    function redeemCoolDownPeriod() external view returns (uint256);
    function redeemRequests(address account) external view returns (uint128 amount, uint128 unlockAt);
    function requestRedeem(uint256 shares) external;
    function redeem(address receiver, uint256 shares) external returns (uint256 fxusdOut, uint256 usdcOut);
    function deposit(address receiver, address tokenIn, uint256 amount, uint256 minSharesOut)
        external returns (uint256);
    function instantRedeem(address receiver, uint256 shares) external returns (uint256 fxusdOut, uint256 usdcOut);
}

/** @notice Yearn fxUSD child: fxUSD -> fxBASE fxSP -> Convex f(x) pool 37. */
contract FxBaseConvex37YearnStrategy is FXNYearnChildBase {
    using SafeERC20 for IERC20;
    IFXBasePoolY public immutable FXBASE;
    ICurveFxUSDSwapY public immutable CURVE_FXUSD_USDC;
    IERC20 public immutable USDC;
    uint256 public pendingMigrationShares;
    uint256 public pendingUserCooldownShares;
    uint256 public userCooldownUnlockAt;
    uint256 public nextCooldownRequestId;
    uint256 public pendingUserCooldownRequestId;
    struct CooldownClaim {
        address owner;
        uint256 vaultShares;
        uint256 unlockAt;
        uint256 reservedFxUSD;
        bool claimed;
    }
    mapping(uint256 => CooldownClaim) public cooldownClaims;
    bool public userSettlementActive;
    uint256 public cooldownUnlockAt;
    uint16 public constant USER_INSTANT_EXIT_TAX_BPS = 100; // 1%, on fxBASE-sourced principal only
    // Preserve Yearn last-reported PPS; user-paid instant exit costs must not
    // dilute the remaining child's shareholders.
    uint256 public reportedPpsAssets = 1;
    uint256 public reportedPpsShares = 1;
    uint256 public reportedPpsTimestamp;
    event ReportPricePerShareCheckpoint(uint256 assets, uint256 shares, uint256 timestamp);
    event InstantExitTax(uint256 nominal, uint256 net, uint256 loss, uint256 fxspRedeemed);
    event CooldownMigrationInitiated(uint256 shares, uint256 unlockAt);
    event CooldownMigrationCompleted(uint256 shares, uint256 fxusdReceived);
    event UserCooldownRequested(uint256 shares, uint256 unlockAt);
    event UserCooldownFinalized(uint256 shares, uint256 fxusdReceived);

    constructor(address fxusd, address usdc, address fxn, address master, address governance,
        address booster, address registry, address gauge, address fxbase, address curvePool, address tokenizedStrategy)
        FXNYearnChildBase(fxusd, fxn, master, governance, booster, registry, 37,
            gauge, fxbase, tokenizedStrategy, "Yearn fxUSD fxBASE Convex37") {
        FXBASE = IFXBasePoolY(fxbase);
        CURVE_FXUSD_USDC = ICurveFxUSDSwapY(curvePool);
        USDC = IERC20(usdc);
        if (FXBASE.yieldToken() != fxusd || FXBASE.stableToken() != usdc
            || CURVE_FXUSD_USDC.coins(0) != usdc || CURVE_FXUSD_USDC.coins(1) != fxusd)
            revert BadConfiguration();
    }

    function report() external returns (uint256 profit, uint256 loss) {
        (profit, loss) = abi.decode(
            _delegateCall(abi.encodeCall(ITokenizedStrategy.report, ())),
            (uint256, uint256)
        );
        uint256 shares = ITokenizedStrategy(address(this)).totalSupply();
        if (shares == 0) {
            reportedPpsAssets = 1;
            reportedPpsShares = 1;
        } else {
            reportedPpsAssets = ITokenizedStrategy(address(this)).lastTotalAssets();
            reportedPpsShares = shares;
        }
        reportedPpsTimestamp = block.timestamp;
        emit ReportPricePerShareCheckpoint(reportedPpsAssets, reportedPpsShares, block.timestamp);
    }

    function _deployFunds(uint256 amount) internal override {
        if (amount == 0) return;
        // The official fxBASE previewDeposit is the authoritative deposit quote.
        // Inverting a previewRedeem quote of one share diverges during mixed-basket
        // or fee-sensitive states, and is inaccurate for small deposits.
        uint256 expected = FXBASE.previewDeposit(address(FXUSD), amount);
        if (expected == 0) revert Slippage();
        uint256 minShares = Math.mulDiv(expected, 10_000 - joinExitSlippageBps, 10_000);
        FXUSD.forceApprove(address(FXBASE), amount);
        uint256 beforeShares = STAKING_TOKEN.balanceOf(address(this));
        FXBASE.deposit(address(this), address(FXUSD), amount, minShares);
        FXUSD.forceApprove(address(FXBASE), 0);
        uint256 shares = STAKING_TOKEN.balanceOf(address(this)) - beforeShares;
        if (shares < minShares || shares == 0) revert Slippage();
        _stake(shares);
    }

    /// @notice Normal user withdrawal: charge the 1% instant exit to the
    /// withdrawing Yearn shares via a smaller net fxUSD redemption. The
    /// protocol's own fee is included, never charged a second time.
    /// Additional realized USDC conversion losses also stay with the exit.
    /// Cooldown migrations use a different, fee-free code path.
    function _freeFunds(uint256 fxusdNeeded) internal override {
        // A finished cooldown is being redeemed through the child ERC4626
        // shares. It MUST NOT trigger any second (fee-bearing) fxSP exit.
        if (userSettlementActive || fxusdNeeded == 0) return;
        uint256 startingIdle = FXUSD.balanceOf(address(this));
        uint256 grossAssets = startingIdle + fxusdNeeded;
        uint256 supply = ITokenizedStrategy(address(this)).totalSupply();
        if (supply == 0) revert NoLiquidity();
        uint256 burned = ITokenizedStrategy(address(this)).previewWithdraw(grossAssets);
        if (burned > supply) burned = supply;
        if (burned == 0) revert NoLiquidity();
        uint256 remainder = supply - burned;
        uint256 lastFloor = Math.mulDiv(
            reportedPpsAssets, remainder, reportedPpsShares, Math.Rounding.Up
        );
        uint256 startingNAV = positionAssets();
        uint256 currentFloor = Math.mulDiv(startingNAV, remainder, supply, Math.Rounding.Up);
        uint256 floor = Math.min(lastFloor, currentFloor);
        uint256 maximumNavDebit = startingNAV - floor;

        if (maximumNavDebit > startingIdle) {
            _unwindInstantExit(fxusdNeeded, maximumNavDebit - startingIdle);
        }
        uint256 totalIdle = FXUSD.balanceOf(address(this));
        uint256 payout = Math.min(grossAssets, totalIdle);
        uint256 navAfter = positionAssets();
        if (navAfter < payout || navAfter - payout < floor) revert Slippage();
        // Do not require payout >= grossAssets. Yearn redeem(max_loss)
        // propagates the shortfall to the withdrawing holder.
    }

    /// @dev The 1% is an inclusive exit-cost target. Do not collect it again
    /// after fxBASE has already deducted its own instant redemption fee.
    function _unwindInstantExit(uint256 grossNeeded, uint256 availableNavBudget) internal {
        uint256 availableShares = _freeFxSPShares() + _gaugeStaked();
        if (availableShares == 0) return;
        uint256 noFeeValue = _estimateNoFeeFxUSDFromFxSP(availableShares);
        if (noFeeValue == 0) return;
        uint256 fee = FXBASE.instantRedeemFeeRatio();
        if (fee >= 1e18) revert BadConfiguration();
        uint256 targetNet = Math.mulDiv(
            grossNeeded, 10_000 - USER_INSTANT_EXIT_TAX_BPS, 10_000
        );
        uint256 targetGross = Math.mulDiv(targetNet, 1e18, 1e18 - fee);
        uint256 navToRedeem = Math.min(
            Math.min(grossNeeded, availableNavBudget), targetGross
        );
        uint256 shares = Math.mulDiv(availableShares, navToRedeem, noFeeValue);
        if (shares == 0) return;
        uint256 freeShares = _freeFxSPShares();
        if (shares > freeShares) _unstake(shares - freeShares);
        uint256 quoteNet = _estimateFxUSDFromFxSP(shares);
        uint256 beforeFxUSD = FXUSD.balanceOf(address(this));
        uint256 beforeUSDC = USDC.balanceOf(address(this));
        FXBASE.instantRedeem(address(this), shares);
        uint256 usdcReceived = USDC.balanceOf(address(this)) - beforeUSDC;
        if (usdcReceived != 0) _convertUSDC(usdcReceived);
        uint256 received = FXUSD.balanceOf(address(this)) - beforeFxUSD;
        if (received < Math.mulDiv(quoteNet, 10_000 - joinExitSlippageBps, 10_000))
            revert Slippage();
        emit InstantExitTax(
            grossNeeded, received, grossNeeded > received ? grossNeeded - received : 0, shares
        );
    }

    function _convertUSDC(uint256 usdcAmount) internal {
        // Separate child-specific stablecoin exit conversion, not part of the master FXN 3-hop swap.
        uint256 quote = CURVE_FXUSD_USDC.get_dy(0, 1, usdcAmount);
        uint256 oracle = CURVE_FXUSD_USDC.price_oracle(0);
        if (oracle == 0 || oracle > 2e18 || oracle < 5e17) revert Slippage();
        uint256 oracleExpected = Math.mulDiv(usdcAmount, 1e30, oracle);
        uint256 minOut = Math.mulDiv(oracleExpected, 10_000 - joinExitSlippageBps, 10_000);
        if (quote < minOut) revert Slippage();
        USDC.forceApprove(address(CURVE_FXUSD_USDC), usdcAmount);
        uint256 beforeOut = FXUSD.balanceOf(address(this));
        CURVE_FXUSD_USDC.exchange(0, 1, usdcAmount, minOut);
        USDC.forceApprove(address(CURVE_FXUSD_USDC), 0);
        if (FXUSD.balanceOf(address(this)) - beforeOut < minOut) revert Slippage();
    }

    function _freeFxSPShares() internal view returns (uint256) {
        (uint128 locked,) = FXBASE.redeemRequests(address(this));
        uint256 held = STAKING_TOKEN.balanceOf(address(this));
        if (uint256(locked) > held) revert BadConfiguration();
        return held - uint256(locked);
    }

    /// @notice The master requests an owner-authorized manual migration exit without paying the
    ///         instant-redemption fee. fxSP remains in this strategy's NAV.
    function requestMigrationExit(uint256 fxusdAmount)
        external onlyMaster guarded returns (uint256 shares, uint256 unlockAt)
    {
        if (fxusdAmount == 0 || pendingMigrationShares != 0 || pendingUserCooldownShares != 0) revert BadConfiguration();
        (uint128 already,) = FXBASE.redeemRequests(address(this));
        if (already != 0) revert BadConfiguration();
        uint256 available = _freeFxSPShares() + _gaugeStaked();
        uint256 value = _estimateNoFeeFxUSDFromFxSP(available);
        if (available == 0 || value == 0) revert NoLiquidity();
        shares = Math.mulDiv(available, fxusdAmount, value, Math.Rounding.Up);
        if (shares == 0) shares = 1;
        if (shares > available) shares = available;
        uint256 unstaked = _freeFxSPShares();
        if (shares > unstaked) _unstake(shares - unstaked);
        FXBASE.requestRedeem(shares);
        (uint128 registered, uint128 readyAt) = FXBASE.redeemRequests(address(this));
        if (uint256(registered) < shares || readyAt < block.timestamp) revert BadConfiguration();
        pendingMigrationShares = shares;
        cooldownUnlockAt = uint256(readyAt);
        unlockAt = cooldownUnlockAt;
        emit CooldownMigrationInitiated(shares, unlockAt);
    }

    function cooldownExitPending() external view returns (bool) {
        return pendingMigrationShares != 0;
    }

    /// @notice Stage 2, callable by the master after the on-chain cooldown.
    function finalizeMigrationExit() external onlyMaster guarded returns (uint256 fxusdReceived) {
        uint256 shares = pendingMigrationShares;
        if (shares == 0 || block.timestamp < cooldownUnlockAt) revert BadConfiguration();
        uint256 beforeFxUSD = FXUSD.balanceOf(address(this));
        uint256 beforeUSDC = USDC.balanceOf(address(this));
        uint256 referenceAmount = _estimateNoFeeFxUSDFromFxSP(shares);
        FXBASE.redeem(address(this), shares);
        uint256 deltaUSDC = USDC.balanceOf(address(this)) - beforeUSDC;
        if (deltaUSDC != 0) _convertUSDC(deltaUSDC);
        fxusdReceived = FXUSD.balanceOf(address(this)) - beforeFxUSD;
        if (fxusdReceived < Math.mulDiv(referenceAmount, 10_000 - joinExitSlippageBps, 10_000))
            revert Slippage();
        pendingMigrationShares = 0;
        cooldownUnlockAt = 0;
        emit CooldownMigrationCompleted(shares, fxusdReceived);
    }


    /// @notice Indicative fee-free cooldown capacity in fxUSD, not a promise
    ///         of exact future fxUSD proceeds (fxSP/Curve prices can change).
    function availableUserCooldownAssets() external view returns (uint256) {
        if (pendingMigrationShares != 0 || pendingUserCooldownRequestId != 0) return 0;
        (uint128 already,) = FXBASE.redeemRequests(address(this));
        if (already != 0) return 0;
        return _estimateNoFeeFxUSDFromFxSP(_freeFxSPShares() + _gaugeStaked());
    }

    /// @notice User-facing path, controlled by the master and backed by
    ///         escrowed *vault* shares. Only one fxBASE request per child may
    ///         be pending: fxBASE restarts the global unlockAt for its caller
    ///         if another request is added.
    /// @notice Called by master after it has escrowed the owner's net vault shares.
    /// @dev Pool 37 owns the request order and maturity state, preventing multiple
    ///      overlapping fxBASE redemptions from restarting earlier unlocks.
    function requestUserCooldownExit(address owner, uint256 vaultShares, uint256 fxusdAmount)
        external onlyMaster guarded returns (uint256 id, uint256 fxspShares, uint256 unlockAt)
    {
        if (owner == address(0) || vaultShares == 0 || fxusdAmount == 0 ||
            pendingMigrationShares != 0 || pendingUserCooldownShares != 0 ||
            pendingUserCooldownRequestId != 0) revert BadConfiguration();
        (uint128 already,) = FXBASE.redeemRequests(address(this));
        if (already != 0) revert BadConfiguration();
        uint256 availableShares = _freeFxSPShares() + _gaugeStaked();
        uint256 availableAssets = _estimateNoFeeFxUSDFromFxSP(availableShares);
        if (availableShares == 0 || fxusdAmount > availableAssets || availableAssets == 0)
            revert NoLiquidity();
        fxspShares = Math.mulDiv(availableShares, fxusdAmount, availableAssets, Math.Rounding.Up);
        if (fxspShares == 0 || fxspShares > availableShares || fxspShares > type(uint128).max)
            revert NoLiquidity();
        uint256 freeShares = _freeFxSPShares();
        if (fxspShares > freeShares) _unstake(fxspShares - freeShares);
        FXBASE.requestRedeem(fxspShares);
        (uint128 registered, uint128 readyAt) = FXBASE.redeemRequests(address(this));
        if (uint256(registered) != fxspShares || readyAt < block.timestamp)
            revert BadConfiguration();
        pendingUserCooldownShares = fxspShares;
        unlockAt = uint256(readyAt);
        userCooldownUnlockAt = unlockAt;
        id = ++nextCooldownRequestId;
        pendingUserCooldownRequestId = id;
        cooldownClaims[id] = CooldownClaim(owner, vaultShares, unlockAt, 0, false);
        emit UserCooldownRequested(fxspShares, unlockAt);
    }


    /// @notice Claim the external cooldown without the fxBASE instant fee;
    ///         the master immediately redeems the matching child shares and
    ///         moves the recovered fxUSD into its protected escrow.
    /// @notice Finish the mature request and convert all redeemed USDC to fxUSD.
    ///      The master subsequently burns child shares and reserves the proceeds.
    function finalizeUserCooldownExit(uint256 id)
        external onlyMaster guarded returns (uint256 fxusdReceived)
    {
        if (pendingUserCooldownRequestId != id || id == 0) revert BadConfiguration();
        uint256 shares = pendingUserCooldownShares;
        if (shares == 0 || block.timestamp < userCooldownUnlockAt) revert BadConfiguration();
        uint256 beforeFxUSD = FXUSD.balanceOf(address(this));
        uint256 beforeUSDC = USDC.balanceOf(address(this));
        uint256 quoted = _estimateNoFeeFxUSDFromFxSP(shares);
        FXBASE.redeem(address(this), shares);
        uint256 deltaUSDC = USDC.balanceOf(address(this)) - beforeUSDC;
        if (deltaUSDC != 0) _convertUSDC(deltaUSDC);
        fxusdReceived = FXUSD.balanceOf(address(this)) - beforeFxUSD;
        if (fxusdReceived == 0 || fxusdReceived <
            Math.mulDiv(quoted, 10_000 - joinExitSlippageBps, 10_000)) revert Slippage();
        pendingUserCooldownShares = 0;
        userCooldownUnlockAt = 0;
        pendingUserCooldownRequestId = 0;
        emit UserCooldownFinalized(shares, fxusdReceived);
    }

    /// @notice Credit the realized fxUSD that the master is now keeping in reserve.
    function recordUserCooldownSettlement(uint256 id, uint256 amount)
        external onlyMaster guarded
    {
        CooldownClaim storage req = cooldownClaims[id];
        if (req.owner == address(0) || req.claimed || req.reservedFxUSD != 0 ||
            pendingUserCooldownRequestId == id || amount == 0) revert BadConfiguration();
        req.reservedFxUSD = amount;
    }

    /// @notice Mark a claim consumed before the master's native Yearn burn.
    ///      Any failed downstream redemption reverts this mutation atomically.
    function consumeUserCooldownClaim(uint256 id, address claimant)
        external onlyMaster guarded returns (uint256 shares, uint256 reserved)
    {
        CooldownClaim storage req = cooldownClaims[id];
        if (claimant == address(0) || req.owner != claimant || req.claimed ||
            req.reservedFxUSD == 0 || pendingUserCooldownRequestId == id)
            revert BadConfiguration();
        shares = req.vaultShares;
        reserved = req.reservedFxUSD;
        req.reservedFxUSD = 0;
        req.claimed = true;
    }


    /// @dev Temporarily prevent any *additional* instant redemption while
    ///      the master redeems child ERC4626 shares for a finished cooldown.
    function setUserSettlementActive(bool enabled) external onlyMaster guarded {
        if (enabled && pendingUserCooldownShares != 0) revert BadConfiguration();
        userSettlementActive = enabled;
    }

    // Fee-inclusive *instant* exit quote used by normal user withdrawals.
    function _estimateFxUSDFromFxSP(uint256 shares) internal view returns (uint256) {
        if (shares == 0) return 0;
        (uint256 quotedFxUSD, uint256 quotedUSDC) = FXBASE.previewRedeem(shares);
        uint256 fee = FXBASE.instantRedeemFeeRatio();
        if (fee >= 1e18) revert BadConfiguration();
        quotedFxUSD = Math.mulDiv(quotedFxUSD, 1e18 - fee, 1e18);
        quotedUSDC = Math.mulDiv(quotedUSDC, 1e18 - fee, 1e18);
        return quotedFxUSD + (quotedUSDC == 0 ? 0 : CURVE_FXUSD_USDC.get_dy(0, 1, quotedUSDC));
    }

    function _estimateNoFeeFxUSDFromFxSP(uint256 shares) internal view returns (uint256) {
        if (shares == 0) return 0;
        (uint256 quotedFxUSD, uint256 quotedUSDC) = FXBASE.previewRedeem(shares);
        return quotedFxUSD + (quotedUSDC == 0 ? 0 : CURVE_FXUSD_USDC.get_dy(0, 1, quotedUSDC));
    }

    // NAV uses fee-free eventual redemption, not a hypothetical instant exit.
    // Real instant-exit fee losses are assigned to actual withdrawing users.
    function availableWithdrawLimit(address) public view override returns (uint256) {
        // Advertise nominal (fee-free) shares' liquidity: Yearn's
        // redeem(max_loss) must be able to burn those nominal shares and
        // deliver the actual smaller payout after the 1% instant exit.
        return FXUSD.balanceOf(address(this)) + _estimateNoFeeFxUSDFromFxSP(
            _freeFxSPShares() + _gaugeStaked()
        );
    }

    function _positionValueFxUSD() internal view override returns (uint256) {
        uint256 fxsp = STAKING_TOKEN.balanceOf(address(this)) + _gaugeStaked();
        uint256 freeUsdc = USDC.balanceOf(address(this));
        uint256 convertedUsdc = freeUsdc == 0 ? 0 : CURVE_FXUSD_USDC.get_dy(0, 1, freeUsdc);
        return _estimateNoFeeFxUSDFromFxSP(fxsp) + convertedUsdc;
    }
}
