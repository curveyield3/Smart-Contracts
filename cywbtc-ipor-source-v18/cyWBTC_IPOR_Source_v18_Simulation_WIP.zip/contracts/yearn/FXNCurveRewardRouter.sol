// SPDX-License-Identifier: AGPL-3.0
pragma solidity ^0.8.30;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

interface ICurveFXNWETHPool {
    function coins(uint256 i) external view returns (address);
    function price_oracle() external view returns (uint256);
    function exchange(uint256 i, uint256 j, uint256 dx, uint256 minDy) external returns (uint256);
}
interface ICurveWETHUSDCPool {
    function coins(uint256 i) external view returns (address);
    function price_oracle(uint256 k) external view returns (uint256);
    function exchange(uint256 i, uint256 j, uint256 dx, uint256 minDy) external returns (uint256);
}
interface ICurveUSDCFXUSDPool {
    function coins(uint256 i) external view returns (address);
    function price_oracle(uint256 k) external view returns (uint256);
    function exchange(int128 i, int128 j, uint256 dx, uint256 minDy) external returns (uint256);
}

/// @title FXN Curve Reward Router
/// @notice Master-only aggregated FXN->WETH->USDC->fxUSD route. Pools and
///         per-hop oracle slippage are configurable by the designated owner.
/// @dev No arbitrary target call capability; the route is restricted to
///      verified Curve pools with the expected token positions.
contract FXNCurveRewardRouter {
    using SafeERC20 for IERC20;
    uint256 private constant BPS = 10_000;
    IERC20 public immutable FXN;
    IERC20 public immutable WETH;
    IERC20 public immutable USDC;
    IERC20 public immutable FXUSD;
    address public owner;
    address public master;
    ICurveFXNWETHPool public curveFXNWETH;
    ICurveWETHUSDCPool public curveWETHUSDC;
    ICurveUSDCFXUSDPool public curveUSDCFXUSD;
    uint16[3] public swapSlippageBps = [250,250,30];
    uint8 public fxnPoolIndex;
    uint8 public triWethIndex;
    uint8 public stableUsdcIndex;
    bool private entered;

    event MasterBound(address indexed master);
    event OwnerTransferred(address indexed previousOwner, address indexed nextOwner);
    event SwapPoolsChanged(address indexed fxnWeth, address indexed wethUsdc, address indexed usdcFxusd);
    event SwapRouteIndicesChanged(uint8 fxnIndex, uint8 wethIndex, uint8 usdcIndex);
    event SwapSlippageChanged(uint16 fxnWeth, uint16 wethUsdc, uint16 usdcFxusd);
    event SwapCompleted(uint256 fxnSold, uint256 fxusdReturned);
    error Unauthorized();
    error BadConfiguration();
    error SwapOracleInvalid();
    error SwapInsufficientOutput();

    modifier onlyOwner() { if (msg.sender != owner) revert Unauthorized(); _; }
    modifier onlyMaster() { if (msg.sender != master) revert Unauthorized(); _; }
    modifier nonReentrant() {
        if (entered) revert Unauthorized();
        entered = true;
        _;
        entered = false;
    }
    constructor(
        address fxusd, address fxn, address weth, address usdc,
        address fxnWethPool, address wethUsdcPool, address usdcFxusdPool
    ) {
        if (fxusd == address(0) || fxn == address(0) || weth == address(0) || usdc == address(0))
            revert BadConfiguration();
        FXUSD = IERC20(fxusd);
        FXN = IERC20(fxn);
        WETH = IERC20(weth);
        USDC = IERC20(usdc);
        owner = msg.sender;
        _setCurvePools(fxnWethPool, wethUsdcPool, usdcFxusdPool);
    }

    function bindMaster(address newMaster) external onlyOwner {
        if (master != address(0) || newMaster.code.length == 0) revert BadConfiguration();
        master = newMaster;
        emit MasterBound(newMaster);
    }
    function transferOwnership(address nextOwner) external onlyOwner {
        if (nextOwner == address(0)) revert BadConfiguration();
        emit OwnerTransferred(owner,nextOwner);
        owner = nextOwner;
    }
    function setSwapSlippageBps(uint16 hop1, uint16 hop2, uint16 hop3) external onlyOwner {
        if (hop1 > 2_000 || hop2 > 2_000 || hop3 > 2_000) revert BadConfiguration();
        swapSlippageBps = [hop1,hop2,hop3];
        emit SwapSlippageChanged(hop1,hop2,hop3);
    }
    function setCurvePools(address a, address b, address c) external onlyOwner nonReentrant {
        _setCurvePools(a,b,c);
    }
    function _setCurvePools(address a, address b, address c) internal {
        if (a.code.length == 0 || b.code.length == 0 || c.code.length == 0) revert BadConfiguration();
        ICurveFXNWETHPool p1=ICurveFXNWETHPool(a);
        if (p1.coins(0) == address(FXN) && p1.coins(1) == address(WETH)) fxnPoolIndex=0;
        else if (p1.coins(0) == address(WETH) && p1.coins(1) == address(FXN)) fxnPoolIndex=1;
        else revert BadConfiguration();
        ICurveWETHUSDCPool p2=ICurveWETHUSDCPool(b);
        if (p2.coins(0) != address(USDC)) revert BadConfiguration();
        if (p2.coins(1) == address(WETH)) triWethIndex=1;
        else if (p2.coins(2) == address(WETH)) triWethIndex=2;
        else revert BadConfiguration();
        ICurveUSDCFXUSDPool p3=ICurveUSDCFXUSDPool(c);
        if (p3.coins(0) == address(USDC) && p3.coins(1) == address(FXUSD)) stableUsdcIndex=0;
        else if (p3.coins(0) == address(FXUSD) && p3.coins(1) == address(USDC)) stableUsdcIndex=1;
        else revert BadConfiguration();
        curveFXNWETH=p1;
        curveWETHUSDC=p2;
        curveUSDCFXUSD=p3;
        emit SwapPoolsChanged(a,b,c);
        emit SwapRouteIndicesChanged(fxnPoolIndex,triWethIndex,stableUsdcIndex);
    }

    /// @dev Amount is transferred from the master, not arbitrarily provided
    ///      by callers. No unsolicited balance is used or swept in a swap.
    function swapFXNToFXUSD(uint256 amount) external onlyMaster nonReentrant returns (uint256 fxusdOut) {
        if (amount == 0) revert BadConfiguration();
        uint256 previousFXN = FXN.balanceOf(address(this));
        FXN.safeTransferFrom(msg.sender, address(this), amount);
        if (FXN.balanceOf(address(this)) - previousFXN != amount) revert BadConfiguration();

        uint256 p1=curveFXNWETH.price_oracle();
        uint256 p2=curveWETHUSDC.price_oracle(uint256(triWethIndex-1));
        uint256 p3=curveUSDCFXUSD.price_oracle(0);
        if (p1 == 0 || p2 == 0 || p3 == 0) revert SwapOracleInvalid();
        uint256 expectedWETH = fxnPoolIndex == 1
            ? Math.mulDiv(amount,p1,1e18) : Math.mulDiv(amount,1e18,p1);
        uint256 minWETH = Math.mulDiv(expectedWETH,BPS-swapSlippageBps[0],BPS);
        if (minWETH == 0) revert SwapInsufficientOutput();
        FXN.forceApprove(address(curveFXNWETH),amount);
        uint256 priorWETH=WETH.balanceOf(address(this));
        curveFXNWETH.exchange(fxnPoolIndex,fxnPoolIndex==0?1:0,amount,minWETH);
        FXN.forceApprove(address(curveFXNWETH),0);
        uint256 receivedWETH=WETH.balanceOf(address(this))-priorWETH;
        if (receivedWETH < minWETH) revert SwapInsufficientOutput();

        uint256 expectedUSDC=Math.mulDiv(receivedWETH,p2,1e30);
        uint256 minUSDC=Math.mulDiv(expectedUSDC,BPS-swapSlippageBps[1],BPS);
        if (minUSDC == 0) revert SwapInsufficientOutput();
        WETH.forceApprove(address(curveWETHUSDC),receivedWETH);
        uint256 priorUSDC=USDC.balanceOf(address(this));
        curveWETHUSDC.exchange(triWethIndex,0,receivedWETH,minUSDC);
        WETH.forceApprove(address(curveWETHUSDC),0);
        uint256 receivedUSDC=USDC.balanceOf(address(this))-priorUSDC;
        if (receivedUSDC < minUSDC) revert SwapInsufficientOutput();

        uint256 expectedFXUSD=stableUsdcIndex==0
            ? Math.mulDiv(receivedUSDC,1e30,p3) : Math.mulDiv(receivedUSDC,p3,1e6);
        uint256 minFXUSD=Math.mulDiv(expectedFXUSD,BPS-swapSlippageBps[2],BPS);
        if (minFXUSD == 0) revert SwapInsufficientOutput();
        USDC.forceApprove(address(curveUSDCFXUSD),receivedUSDC);
        uint256 priorFXUSD=FXUSD.balanceOf(address(this));
        curveUSDCFXUSD.exchange(int128(uint128(stableUsdcIndex)),int128(uint128(1-stableUsdcIndex)),receivedUSDC,minFXUSD);
        USDC.forceApprove(address(curveUSDCFXUSD),0);
        fxusdOut=FXUSD.balanceOf(address(this))-priorFXUSD;
        if (fxusdOut < minFXUSD) revert SwapInsufficientOutput();
        FXUSD.safeTransfer(msg.sender,fxusdOut);
        emit SwapCompleted(amount,fxusdOut);
    }
}
