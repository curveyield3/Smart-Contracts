# cyWBTC IPOR source v19 — existing V7 Anvil compilation repair

The original cyWBTC v18 source is retained except for exactly five `Math.Rounding.Ceil` references replaced by `Math.Rounding.Up` inside `contracts/fuses/fxmint/FXMintLTVManager_v17.sol`.

These represent the same upward rounding semantics for the bundled OpenZeppelin math version. No Solidity function logic or numerical bounds were otherwise changed.

Initial GitHub V7 run: https://github.com/curveyield3/Contract-Automation/actions/runs/43206914133

**Status:** unverified until the exact v19 source is compiled and Ethereum fork simulation executed by the existing V7 workflow. The full IPOR deployment/configuration script and verified fxUSD/USD oracle wiring remain incomplete. No full-system PASS is claimed.
