# BoostHub Contract Stack v28 — Surgical Vyper Snapshot Rollback

Baseline: BoostHub Contract Stack v27. Date: 2026-11-14.

## Scope

Reverted **only** the v27 sparse/plateau historical snapshot mechanism in `contracts/BoostHubStaking.vy`:

1. Removed the `RewardPlateau` struct and both persistent plateau mappings.
2. Removed `_close_reward_plateau`, `_record_reward_plateau`, and `_historical_reward_integrals`.
3. Removed calls that created and closed plateaus, plus temporary flags used only for plateau-specific snapshot handling.
4. Restored direct writes to `activation_integral_at` and `activation_reward_q_at` at the existing snapshot boundaries; as in v25/v26, zero integral or zero moment entries are **not written**.
5. Restored direct historical mapping lookups during maturity checkpointing.

**Preserved:** v27 in-memory registration/harvest optimization, cached bucket-boundary index, ramp documentation, fee configuration, all router and Beefy changes, contracts and deployment configuration. No modifications to accounting formulas, reward stream selection, 90-day emergency recovery, reward distributor timelock, or interface selectors.

## Status

The rollback was checked by exact source comparison against v26's original snapshot read/write blocks, by absence of plateau identifiers, and by ZIP integrity. No compilation or runtime tests were executed.

`CHANGES_v27.md` remains included as historical documentation; its item #17 plateau implementation was reversed by this v28 change.
