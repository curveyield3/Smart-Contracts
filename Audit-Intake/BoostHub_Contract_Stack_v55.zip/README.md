**v55:** Only `emergencyWithdraw(uint256 shares, uint256 minAssetsOut)` remains as an emergency withdrawal entrypoint. The `emergencyWithdrawAll` convenience function from v54 was removed. See `CHANGES_v55.md`.

**v51:** Convex FXN/sdFXN external historical-oracle Curve guard tightened to 75 bps for deposits and withdrawals. See `CHANGES_v51.md` and `FORK_PROOF_v1.md`.

# v49 — external Curve LP bounds (100 bps) for sdFXN Convex pool 8
See CHANGES_v49.md. Prior v48 functionality preserved.

# BoostHub Contract Stack v46 — strategy-index migration selector

The sdFXN dual master strategy now accepts `migrate(uint8 fromStrategyIndex, uint256 sourceUnits)`:

- `0`: migrate **from BoostHub** to Convex, using staked sdFXN units.
- `1`: migrate **from Convex** to BoostHub, using staked Curve LP/gauge units.

Only `0` and `1` are valid; all migration cap, price, owner, and atomicity checks remain unchanged. The `ManualMigration` event reports the same numeric source index.

See `CHANGES_v46.md` for the exact changes. The contract ABI changes, so callers must use the numeric selector.

---

# v45: APR-first dual allocation caps (99% each by default) and owner-only sdFXN/Convex gauge LP migrations. See `CHANGES_v45.md`.

# BoostHub Contract Stack v43

**v43 deploy-script correction:** `script/DeployDualFXNPool8V42.s.sol` now predicts the new sdFXN vault at the broadcaster's initial nonce **+4**, accounting for `master.configureChildren()` between the three earlier creations and the vault creation. The source contracts, fee schedules, strategy rules, and existing deployments are unchanged. See `CHANGES_v43.md` for transaction order and verification scope. Not compiled, fork-tested, or deployed as part of this patch.

# BoostHub Contract Stack v42

**Current addendum:** See `CHANGES_v42.md` for the new **Ethereum sdFXN/FXN pool-8** dual-child master strategy. The user-requested sdFXS/FXS pairing cannot use Convex FXN/sdFXN pool 8, so the existing Fraxtal sdFXS implementation remains unchanged. v42 is an additive, uncompiled and undeployed source supplement that deploys a new vault, not a proxy upgrade. Prior v41 details below are historical and remain part of the stack.

# BoostHub Contract Stack v41

## v41 Ethereum custom staking/vault supplement

`CHANGES_v41.md` is the authoritative source for the v41 additions: matching `CurveYield` staking/vault names for sdCRV and sdFXN, 0.35%/0.45% custom-vault withdrawal fees, and preservation of the 10% caller share of the 3% performance fee. Use `script/DeployEthereumSupplementV41.s.sol` to add replacement Ethereum custom vault/strategy/staking pairs to an **existing** BoostHub/OmniRouter, with verified live addresses. The existing Fraxtal v40 supplement script remains available, unchanged. Historical sections below describe earlier package states. No v41 contracts have been deployed or compiled in this package.

## Historical implementation

This package combines the existing v29 Omni/Beefy-partner deployment package with the two-phase staking ramp approved in this conversation, then applies the approved custom-contract simplifications. Older versioned reports and changelogs are historical; this README and `CHANGES_v34.md` describe the current partner deployment integration (with v32 custom-system changes retained).

- Both custom and Beefy partner vault systems use the same chain-local `CurveYieldOmniRouter` deployed and configured by `script/DeployBoostHubStack.s.sol::run()`.
- The Ethereum reward converter and Fraxtal converter adapter are absent. No converter is imported, deployed, or required by the script.
- Ethereum: two custom vault/strategy pairs and two additional Beefy partner pairs, using sdCRV/sdFXN staking. Fraxtal: one of each pair, using sdFXS staking.
- The official Beefy V7 vault, vault factory, inherited base strategy, and BoostHub adapter remain unchanged. The pair-deployment helper is V4: the vault comes from Beefy’s existing V7 vault factory and the strategy is deployed independently; no claim of Beefy listing approval is made.
- The existing Omni implementation, route configuration, fee settings, timelocks, and reward registries are retained. SDT/3Crv have no configured routes; custom strategies defer failed conversions and the unchanged partner strategy excludes unsupported routes.

## Staking and custom-pair simplifications

- Deposits start at **10% reward weight immediately**, grow daily to **50% at day 33**, then **100% at day 45**. The existing daily-boundary convention and separate deposit ages remain.
- One internal harvest implementation serves standalone harvest() and harvest_and_claim(). The combined call now returns the complete registry already read during settlement, including external and disabled tokens. The custom strategy uses that returned list; the protected partner strategy continues its unchanged calls.
- Vyper immediate claims pay stored plus newly earned rewards from local variables. Hub claims now do the same for selected tokens through one shared reward-debt helper; principal changes still checkpoint every registered token. Omitted Hub tokens remain pending against their unchanged debt. No parallel ledger was added.
- The custom harvest receives the registered-token list from staking in its existing combined call, skips want, and checks each other token balance once. Staking registration excludes zero and its own address. Disabled-token leftovers remain convertible, zero balances are skipped, and unsupported/failed swaps remain deferred. The existing rewards()/rewardsLength() views still derive their list on demand; acceptedRewardTokens() still excludes disabled tokens.
- Performance/caller fees are calculated and rounded separately for each reward, accumulated in memory, and transferred once per recipient after conversions. Existing net-output checks and 72-hour profit locking remain.
- The custom vault no longer calls its permanently empty `beforeDeposit()` callback. The protected official vault and its callback path are unchanged.
- Hub approved locker-token enumeration uses the existing pool registry. Its global enumeration-only token array is removed; reward-registration authorization remains.

- Matured-user checkpoints no longer maintain an unused ramp cursor; new deposits initialize it. Withdrawals bypass ramp-removal processing when no ramp deposit weight remains. Maturity pruning clears individual buckets but subtracts their combined weight once.
- Custom strategy events use already-known action amounts, avoiding balance queries solely for logging.

## v32 targeted changes

- Staking lp_token, boost_hub, and pid are public immutables with the same getter selectors. Their constructor values are unchanged; their storage slots are removed. This package is source for fresh deployment, not a storage-compatible proxy upgrade.
- The custom strategy approves its fixed staking contract once for the maximum allowance at construction. Router approvals remain exact and failed swaps still clear their approval.
- Each daily ramp step reuses the two scheduled deltas already read for snapshot decisions and writes activation_rate once, after applying the old rate to inactive units.
- Every Vyper ERC-20 transfer, transferFrom, and approve asserts success. Empty return data uses the existing safe-call convention; explicit false reverts the transaction.
- Hub reward import uses reward_from_boosthub to skip already-imported tokens. New tokens and external-to-Hub promotions still pass through the existing registry, without a cache or parallel list.
- Custom vault shares use actual net tokens received after the deposit fee and the pre-deposit NAV; minting still follows successful staking. The final full-NAV recomputation is removed. This relies on the existing fixed, exact-value staking path and standard non-rebasing underlying transfers. A nonzero fee is followed by an actual vault-balance measurement, including when its fee receiver is the vault itself.
- Custom harvest carries the measured want balance between swaps and reuses the actual post-fee balance for restaking. Router output amounts remain independently measured, fee rounding remains per reward, and the post-fee measurement preserves self-directed fee behavior. This assumes standard tokens whose approvals do not alter want balances or invoke callbacks; unsupported rebasing/callback behavior is not accommodated.
- The daily user-bucket structure, automatic gauge discovery, preliminary router quote, and 10% immediate ramp are retained.

## Interfaces and observable differences

- Staking harvest_and_claim() now returns address[] without changing its input selector. Its custom Solidity interface/caller is updated together; this custom strategy requires the v32 staking return format. Standalone harvest()/claim_rewards() retain their prior external return behavior. Protected partner interfaces are unchanged.
- Removed custom-strategy `syncRewards()` and `beforeDeposit()`. The custom-only strategy interface no longer declares the unused callback.
- Custom-strategy `rewards(uint256)` and `rewardsLength()` retain their selectors but return the current derived list rather than a synchronized snapshot. These views now read staking; harvest avoids maintaining a second registry.
- Custom strategy `Deposit(uint256)` and `Withdraw(uint256)` retain their event signatures but their value is now the action amount, not TVL. `StratHarvest(address,uint256,uint256)` becomes `StratHarvest(address,uint256)`; its TVL field is removed. Event consumers must use the updated semantics/ABI. Protected partner events are unchanged.
- Custom reward enumeration now includes registered disabled tokens with zero balance; harvest skips them. `acceptedRewardTokens()` retains its prior semantics.
- Custom `ChargedFees` emits once per fee settlement with aggregate amounts instead of once per individual reward. Per-reward fee and caller-share rounding is unchanged.
- `approvedLockerRewardTokens()` now returns approved pairs in pool order; order may differ from earlier global reward-registration order.

## Build and deployment

The sole deployment entry point remains `script/DeployBoostHubStack.s.sol::run()`. The existing compile-only workflow, dependency declarations, remappings, source-bound Vyper artifact helper, and partner deployment preflights are retained. No additional workflow, runner, or deployment script was created.

Dependencies are declared in `dependencies/package.json`; they are not vendor-copied. The existing build path requires Vyper 0.4.3, Solidity 0.8.28, Forge, and the declared packages. Generated staking artifacts must be rebuilt from this source before a future deployment; no stale artifact is included.

This edit performed **no compilation, tests, simulations, gas benchmarks, broadcasts, or listing submissions**. Verification was limited to source review, byte comparisons, relative-import inspection, and package-content comparison. Runtime gas and bytecode size have not been measured.

## Historical v33 factory deployment and Vyper immutable verification (superseded by v34)

The first paragraph below records the **superseded v33** approach; it is NOT used by the current v34 deployment. The Vyper immutable-verification repair remains in v34.

The sole `run()` entrypoint now calls the existing Beefy V7 vault factory on each chain (Ethereum `0xC551dDCE8e5E657503Cd67A39713c06F2c0d2e97`, Fraxtal `0x91BB303E972995EbE5f593BCddBb6F5Ef49Dbcbd`). The updated `BoostHubPartnerPairDeployerV3` calls `StrategyFactory.createStrategy("BoostHubStaking")` instead of cloning an arbitrary strategy via the vault factory. It initializes both factory products atomically. **Both official Beefy strategy factories must already contain the reviewed `BoostHubStaking` implementation under that name before `run()` is called.** The deployment script checks existence and exact runtime hash before any broadcast. As of the last Ethereum on-chain check, this registration was absent, so the deployment is intentionally blocked until Beefy registers it.

Vyper 0.4.3 appends the public immutable `lp_token`, `boost_hub`, and `pid` to runtime bytecode. The deployment verification now checks exact compiler runtime bytes plus the 96-byte ordered immutable trailer, retaining the source-hash and compiler-pin verification. This resolves the invalid whole-codehash comparison from v32 without weakening evidence binding.

Beefy's active Ethereum default fee category supplies a nonzero actual caller reward (9.5% total fee; 5.26315789% caller split, equivalent to 0.5% of gross rewards). Strategy initialization links to this fee config; the unchanged informational `callReward()` getter stays zero. No fee settings were changed by v33.

The unified Omni routing, existing custom vault-strategy system, Hub, Vyper staking source, and official Beefy contracts are preserved. Fraxtal factory/pool registration and full compilation remain to be verified on a suitable environment before mainnet broadcast. No new tests or workflows were added.

## v34 partner deployment correction (current)

Both chains' Beefy partner vaults use their configured existing official V7 vault factories; Ethereum uses the verified `0xC551dDCE8e5E657503Cd67A39713c06F2c0d2e97`. The helper `BoostHubPartnerPairDeployerV4` calls `cloneVault()` then deploys `new StrategyConvexBoostHubPartnerV2()` **independently** on both chains, initializes each strategy and vault, validates bindings, and transfers ownership atomically in the same unified `run()` flow. Beefy's strategy factory is only a configuration source (native token, fee config, keeper, pause) and is not used to deploy/register strategies. No Beefy strategy-factory registration is required. See `CHANGES_v34.md` and `beefy-partner/README_v5.md`.

The existing Omni reward routes, the original three vaults/strategies, and the Vyper immutable-verification repair remain unchanged. This package has **not** been compiled or deployed. The required Fraxtal on-chain preflight, live-fork execution and formal Beefy SAFU/listing approval remain outstanding.


## v35 addition

Custom vaults deployed from `contracts/BeefyVaultV7FixedV2.sol` now export `getAPR()`, `aprReady()`, `rate()` and `checkpointAPR()` for trailing 15-day historical PPS APR; see `CHANGES_v35.md`. The official Beefy V7 factory-clone source is intentionally unchanged.


## APR v36 (replacing v35 behavior)

See `CHANGES_v36.md`. `rate()` now never reverts just because 15 days have not elapsed or daily checkpoints were omitted; it calculates using live PPS and the historical sample closest to 15 days ago. Until any usable baseline exists, rate is zero. A sparse sample window is necessarily a best-available annualized estimate, not an exact 15-day return.

## v44 sdFXN dual-strategy APR gate correction

See `CHANGES_v44.md`. Convex minimum-reserve top-ups now obey the same verified +4 percentage-point APR and >0.969 FXN per sdFXN price prerequisites as ordinary Convex deposits. The deployed OmniRouter's required sdFXN/FXN forward and reverse routes remain a mainnet configuration dependency.


## v50 note
See `CHANGES_v50.md` for post-deployment external Curve guard binding and 1% LP bounds.
