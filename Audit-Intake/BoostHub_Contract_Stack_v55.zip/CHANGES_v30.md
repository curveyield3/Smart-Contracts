# BoostHub v30 — Omni-only routing and custom-contract simplification

## Source basis

- Protected partner sources and the existing unified Omni deployment are recovered unchanged from `BoostHub_Contract_Stack_v29.zip`.
- The 10%-immediate / 50%-day-33 / 100%-day-45 staking ramp is retained from this conversation's `BoostHub_Contract_Stack_v29(1).zip`.
- All modifications below are to the custom contracts or shared Hub/staking implementation, not to the protected Beefy partner source tree.

## Approved changes

1. Remove converter implementations and use the existing unified Omni deployment for both vault systems. Converter-specific optimization is superseded by deletion.
2. Remove the custom strategy's stored reward array and synchronization machinery; retain live read selectors and deferred/disabled-balance handling.
3. Add a combined staking harvest/claim entry point using the same internal harvest and settlement functions. Keep the partner's existing standalone selectors.
4. Accumulate custom performance and caller fees in memory and transfer each recipient's total once.
5. Remove the Hub enumeration-only global token array; enumerate approved locker pairs from existing pools.
6. Settle immediate Vyper claims without storing then immediately clearing newly earned rewards, including selective claims.
7. Remove the custom vault's no-op deposit callback and its custom strategy/interface declaration.

## Accounting review (source only)

- For each gross reward g_i, fee_i = floor(g_i * performanceBps / 10000), caller_i = floor(fee_i * callerShareBps / 10000). New transfers are sum(caller_i) and sum(fee_i) - sum(caller_i), identical to summing the previous per-reward transfers. Fee calculation is not performed on the combined gross amount.
- Each swap still checks its own actual net want against minWantOutput. Fees never include pre-existing idle principal. Profit locking uses the actual post-fee balance increase.
- For stored claim C and new earnings E, immediate payment is C + E and the stored claim becomes zero. Nonselected/nonclaiming tokens store C + E. Existing integral and penalty calculations are unchanged.
- Combined harvest advances the old reward streams once before receiving/scheduling new rewards, then settles the caller. Standalone partner harvest/claim behavior remains available.
- The original ramp redistribution buffer, dormant nonzero historical snapshots, disabled-token handling, and separate deposit ages remain. No alternate reward or activation ledger is introduced.

## Verification and size

- Protected partner tree: 11 files compared, all byte-identical. OmniRouter source is also byte-identical.
- Relative Solidity imports resolve to supplied local source paths. Declared external dependencies were not installed or compiled for this edit.
- Relative to the complete partner v29 package with this conversation's ramp carried forward, Solidity/Vyper implementation source decreases from 263,143 to 238,900 bytes (24,243 fewer), and from 5,741 to 5,278 lines. These are source counts, not deployed bytecode measurements.
- Compared with the earlier minimal ZIP in this conversation, the protected partner tree and its existing deployment support are restored; that restoration is not new parallel custom infrastructure.
- No compilation, tests, simulation, deployment, or gas benchmark was run. Reduced storage maintenance, one fewer custom staking call/global checkpoint pass, and at most two custom fee transfers per harvest are structural changes; no numerical runtime-gas claim is made.

## Protected source digests

| File | SHA-256 |
| --- | --- |
| `beefy-partner/contracts/BIFI/interfaces/beefy/IBeefySwapper.sol` | `6e3c7c2861cb1877aceb3f32e87693fe0085f438c9e253e654b2e2d64462f073` |
| `beefy-partner/contracts/BIFI/interfaces/beefy/IStrategyFactory.sol` | `82c8a6a215da9c104943f11a5346dfa7a828c3b45ae310c3fdbcd04756477100` |
| `beefy-partner/contracts/BIFI/interfaces/beefy/IStrategyV7.sol` | `3af0866310038a77849257194cb6cee58ffdeac14afcfb4821b60e3b421eae48` |
| `beefy-partner/contracts/BIFI/interfaces/common/IFeeConfig.sol` | `8537e1455c5194fb2690c03a34871892932b5cb65a510d540ad7031aa0861de1` |
| `beefy-partner/contracts/BIFI/interfaces/common/IWrappedNative.sol` | `ee6887d84ce781dff76a3c3e31ac749e682061cdbc6e609f970010208a3af661` |
| `beefy-partner/contracts/BIFI/strategies/BoostHub/BoostHubPartnerPairDeployerV2.sol` | `6ebd37f002b8c46a9dd9a469c299c671ee06cf633e6849c05fc1cb8d5dde9acc` |
| `beefy-partner/contracts/BIFI/strategies/BoostHub/StrategyConvexBoostHubPartnerV2.sol` | `d2e58c9f16e5949f7aa52a1996f93bd85959f038fab5a6d10fa3361ce741eb3d` |
| `beefy-partner/contracts/BIFI/strategies/Common/BaseAllToNativeFactoryStrat.sol` | `a1f1b87def3bd1d32188ab2ae5d8b582ba53704079d92efd736029822d8d9b2a` |
| `beefy-partner/contracts/BIFI/vaults/BeefyVaultV7.sol` | `f4fc5aeedb4edce921a2678c038a26000071f060634877e3488308574729af12` |
| `beefy-partner/contracts/BIFI/vaults/BeefyVaultV7Factory.sol` | `a06f3d7d8add31ea2e80ae7511cf4f1ea633954e2cc7b884b85c9985183f14a1` |
