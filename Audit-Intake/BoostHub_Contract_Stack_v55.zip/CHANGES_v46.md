# BoostHub Contract Stack v46 — Numeric strategy indices for manual migration

## Exact API change

The owner-only master function changes from `migrate(bool fromConvex, uint256 sourceUnits)` to `migrate(uint8 fromStrategyIndex, uint256 sourceUnits)`.

- `migrate(0, sourceUnits)` — source **BoostHub**, destination **Convex**, `sourceUnits` is an 18-decimal amount of staked **sdFXN**.
- `migrate(1, sourceUnits)` — source **Convex**, destination **BoostHub**, `sourceUnits` is an 18-decimal amount of staked **Curve FXN/sdFXN LP/gauge tokens**.
- Any other `fromStrategyIndex` reverts with `INVALID_STRATEGY_INDEX`.

The `ManualMigration` event now emits `uint8 indexed fromStrategyIndex` in place of `bool indexed fromConvex`.

## Unchanged behavior

The migration is still owner-only, non-reentrant, and atomic; the destination allocation cap and post-migration cap check are preserved. BoostHub-to-Convex migration still requires a price quote strictly above 0.969 FXN per sdFXN. Both directions retain the same exact-unit source withdrawal and other accounting guards. Automatic APR-first capped allocation is unchanged, and no minimum-balance tiers are reintroduced.

This is an ABI-breaking selector/event change: owner scripts and interfaces must use `uint8` rather than `bool`.

## Verification

The change was made on top of the v45 source. Successful v45 compilation does not prove v46 compilation or deployment; consult the separate v46 GitHub build result for its status. No new or modified tests were created or executed.
