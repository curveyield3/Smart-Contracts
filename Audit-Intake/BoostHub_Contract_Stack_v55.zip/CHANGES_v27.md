# BoostHub Contract Stack v27 — Approved Source Changes

Date: 2026-11-14. Baseline: `BoostHub_Contract_Stack_v26.zip`.

## Completed, by approved finding number

| Finding | Source change |
|---|---|
| **6** | Added pinned `@uniswap/v4-core: 1.0.2` to the **existing** `dependencies/package.json`. No new workflow. |
| **7** | Renamed omni-router 3-argument `easyswap` to `swap`; added Beefy-compatible `getAmountOut` using the router's *same* historical-oracle net quote as `estimate_exact_output`. The explicit guarded input entry point remains `swapExactInput` because it was not named `swap`. No pool interface's `swap` signature changed. |
| **8** | Deployment constants now charge **300 BPS performance** and allocate **1000/10000 of the fee to the caller**, leaving **9000/10000** of the fee for the admin recipient. |
| **10** | Hub `_checkpoint` skips uninitialized zero reward indexes and avoids unnecessary position mapping reads; the original accRewardPerShare/rewardDebt model is unchanged. |
| **11** | Hub gauge enumeration returns the PID's known reward-token indices alongside token addresses, avoiding a second post-claim search when returning harvested amounts. |
| **12** | Original bounded full-pool fee-administration scan **retained unchanged**. |
| **17** | Vyper staking records sparse dormant reward-integral plateaus instead of rewriting identical nonzero day-boundary values. Historic lookups prefer original exact snapshots, then resolve earlier inactive plateaus; newly funded emissions delimit the previous plateau. No parallel reward accrual/debt ledger. |
| **18** | Cached each deposit bucket's boundary index in the maturity computation, eliminating repeated divisions inside its phase loop; existing maturity slopes and payout math retained. |
| **19** | Staking harvest derives the claim selection directly from tokens already returned by Hub.harvest, rather than rescanning its own reward registry. The local disabled flag still applies. |
| **20** | Staking reward imports cache registered token addresses in a single temporary fixed-size memory array instead of repeatedly scanning storage; updates the stored count only if changed. |
| **22** | Added comments explaining the accumulated integral and time-weighted integral invariants and four 45-day maturity segments; arithmetic remains unchanged. |
| **23–24** | The strategy's accepted-token view now performs one external staking-registry traversal instead of two. Its synchronizer retains v25's no-op early return on an unchanged reward registry. |
| **25–26** | The synchronizer's fresh in-memory token list is returned to the existing harvest path and reused for token conversion instead of reading the same persistent rewards array again. The strategy **continues to read actual token balances** because deferred/unconverted rewards can remain after a claim returns zero; dropping those balance reads would require additional state or a changed claim ABI. |
| **27** | Strategy `_approveExact` uses `SafeERC20.forceApprove()` without an upfront `allowance()` external read; exact-input standard swaps/strategies consume the allowance and failed swaps explicitly reset it. |
| **29** | Vault deposit caches its initial underlying balance and adds the strategy balance once; final asset accounting remains the original measured pool delta. |
| **31** | Removed unused Ethereum converter `_quoteRoute`, `ROUTE_RETENTION_BPS`, `RouteRateTooLow`, and dead `get_dy` interface declarations; live EMA oracle path preserved. |
| **35** | **Fraxtal adapter deliberately retained**: existing converter ABI is `previewConvert`/`convert`, not `getAmountOut`/`swap`. It is a narrow, fee-free compatibility adapter with immutable configured converter and route checks. |
| **36** | Removed the initial `approve(0)` for generic approved omni-router hops; the exact approval and final reset are preserved. |
| **41** | Reorganized the omni-router visually into labeled source sections and reformatted dense one-line statements, modifiers and function signatures. Formatting-only edits were checked to preserve non-whitespace source symbols prior to the separate API and allowance changes. |
| **43** | Corrected misleading deployment Merkle comment (the trusted distributor performs proof verification), trimmed unused local StakeDAO gauge/vlBoost interface declarations and unused BoostHubErrors declarations, and updated the README's current-version summary. |

## Explicitly unchanged and excluded

- Previously denied findings **2–5**: duplicate gauge slots, last-empty-PID attribution, reward capacity, and disabled reward reactivation.
- **Finding 14** from the earlier cleanup: no emergency-stop state-machine modification or change to the 90-day recovery/timelock mechanism.
- No new tests, test runners, workflows, reward ledgers, or converter contracts.
- No new persistent active/inactive token registry; the only additional staking state is sparse **historical integral lookup metadata**, not a separate earnings ledger.

## Deployment / review considerations

1. New router `swap` has the exact three-argument selector Beefy expects; any external caller using `easyswap` must update its selector.
2. Staking's sparse plateau storage is a **fresh-deployment layout change**, and the Vyper changes require Vyper `0.4.3` compilation and explicit audit of historical payout semantics before production use.
3. `@uniswap/v4-core@1.0.2` is pinned in the dependency manifest; package installation was not run locally.
4. Solidity/Vyper compilation, runtime execution, and gas profiling **have not been completed**. No tests were created or executed per instruction.
5. The deployment still uses the existing Ethereum converter and existing Fraxtal adapter. Selecting the omni-router as a strategy swapper additionally requires owner configuration of its token routes and oracle guards.
