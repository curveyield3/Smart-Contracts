# v52 — Curve StableSwap-NG ERC-4626 rate-reader compatibility

Surgical addition to `contracts/BeefyVaultV7FixedV2.sol` only:

- `asset() -> address` returns the existing immutable `underlying` (the strategy `want` token).
- `convertToAssets(uint256 shares) -> uint256` returns `shares * balance() / totalSupply()` (rounds down), or `shares` when there is no supply. It derives the same NAV/share ratio as the existing `getPricePerFullShare()`.

Curve StableSwap-NG asset type 3 calls `asset()` once during construction to obtain underlying decimals and `convertToAssets(10 ** shareDecimals)` during rate reads. ERC-20 `decimals()` already exists through OpenZeppelin ERC20 (18 decimals).

**Scope:** Curve rate-reader interoperability only, not full EIP-4626 transactional compliance; legacy `deposit(uint256)` and `withdraw(uint256)` semantics and fees are unchanged. The zero-supply conversion assumes the existing vault's 1:1 share/base-unit convention, appropriate for its current 18-decimal underlying assets. No storage layout, immutable, ownership, fee, APR, strategy, or deployment-script changes.

**Validation:** source-only inspection and narrow diff review. No tests created, modified, or executed. Compile/deployment status is reported separately; no on-chain deployment implied.
