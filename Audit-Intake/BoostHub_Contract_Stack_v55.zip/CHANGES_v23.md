# BoostHub v23 implementation record

Date: 2026-11-13. Source derived from `BoostHub_Contract_Stack_v22.zip`.

## Approved change mapping

1. Removed registered-token scan and automatic redistribution in every Hub harvest. `sweep` is owner-only and can move unreserved surplus only.
2. Staking collects all enabled Hub rewards in a single claim call per harvest.
3. Preserved original `_checkpoint` reward-index/debt semantics and collapsed deposit/withdraw bookkeeping into one loop; deleted `_syncRewardDebt`.
4. Avoided public result-array creation when internal harvest return values are ignored.
5. Combined gauge token discovery and claimability sampling; no second full gauge enumeration.
6. Avoided repeat token-source SSTOREs and a second staking reward synchronization in the common harvest path.
7. Allowed claims with zero PID stake; new receipts stay unreserved and owner-sweepable. Existing attributed claims stay protected.
8. Supported eight gauge rewards plus the principal token: Hub capacity 9; staking capacity 9 with unchanged constructor initial array length 8.
9. Skipped identical queued or active platform fee settings; removed pool-activity restriction tied to locked depositor allowlist.
10. Tracked pending-fee PIDs and iterated only queued entries for execution/clearing/views.
11. Removed redundant pending-fee exists flag; readyAt indicates a queued record.
12. Snapshotted only gauge-listed tokens before and after a gauge claim.
13. Removed duplicate local Merkle root/proof/claimed reads; preserved distributor validation, Hub token-balance deltas, and URD beneficiary validation.
14. Explicitly rejected: **not implemented**; emergency recovery code remains byte-for-byte identical.
15. Removed unused error/event declarations, packed Pool fields, reduced source-format noise.
Additional: removed user-supplied distributor address from both Merkle/URD claim functions; added owner-only `setRewardDistributor` with a fixed ten-day delay via existing `executeTransactions`, with pending state visible in `pendingTransactions`.

## Trust and behavior notes

- A claim from an empty PID no longer attributes to the empty pool. The actual receipt is unreserved surplus accessible via the owner-only `sweep` path.
- `sweep` subtracts all staker and owner reserves before transferring any token. It does not confiscate already attributed participant rewards.
- The `rewardDistributor` is mutable only after the ten-day pending configuration is executed by the authorized transaction executor. Public Merkle claims can no longer override it.
- `IBoostHub` claim function selectors and pending-transactions return shape changed. Existing external callers should be updated before using v23.
- No tests were created, modified, or executed. No chain deployments or GitHub workflows were run; compilation is outstanding.
