# BoostHub Contract Stack — v42 dual-strategy FXN/sdFXN supplement

## Scope and the asset/pool mismatch

The user requested an sdFXS/FXS gate and Convex f(x) pool ID 8. The real **Ethereum mainnet** Convex f(x) pool registry identifies PID 8 as the **FXN/sdFXN Curve LP**, not an FXS/sdFXS pool. Its underlying coins are FXN (coin 0) and sdFXN (coin 1); the corresponding BoostHub sdFXN deployment is on Ethereum, whereas the v41 sdFXS staking/vault is on Fraxtal. Those two chains and assets cannot be combined in an atomic single-token sdFXS vault. **v42 therefore adds a new sdFXN vault for the actual FXN/sdFXN Convex pool 8. It does not silently relabel pool 8 as an sdFXS pool or change the existing sdFXS vault.**

On-chain references observed November 16, 2026 (Ethereum):

- Convex f(x) Booster: `0xAffe966B27ba3E4Ebb8A0eC124C7b7019CC762f8`
- Convex pool registry: `0xdb95d646012bb87ac2e6cd63eab2c42323c1f5af`
- PID 8 Curve FXN/sdFXN LP: `0x28Ca243dc0aC075dD012fCf9375C25D18A844d96`
- FXN: `0x365AccFCa291e7D3914637ABf1F7635dB165Bb09`
- sdFXN: `0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD`
- PID 8 staking-proxy implementation: `0x2aa80139d3d6dfa90396547228d3875a8fdc0b04`
- PID 8 Curve gauge: `0x5b1d12365bec01b8b672ee45912d1bbc86305dba`
- PID 8 multi-reward pool: `0x729c84b794776f59f6acc38be1700fed2c2f6329`

These addresses are read-only observations, not proof that the v42 strategy is deployable or economically safe.

## Files added

- `contracts/StrategyDualFXNMasterV42.sol`: controls one BoostHub child and one Convex pool-8 child; communicates with the existing custom V7 vault interface.
- `contracts/StrategyBoostHubChildV42.sol`: reuses the v41 BoostHub staking implementation, with a child-specific capital-flow-neutral APR index.
- `contracts/StrategyConvexFXNPool8V42.sol`: minimal Convex f(x)-specific staking proxy adapter with single-sided sdFXN liquidity, rewards harvesting, bounded LP deposit/withdraw slippage, and independent APR.
- `contracts/ChildAPR15dV42.sol`: nontransferable internal performance units and vault-style rolling 15-day observations (16 daily / 5 four-hour samples).
- `script/DeployDualFXNPool8V42.s.sol`: Ethereum-only supplemental deployment, reusing an already-deployed BoostHub sdFXN staking pool and OmniRouter and creating a new custom vault. It cannot replace a deployed v41 vault's immutable strategy.

## Files updated

- `contracts/BaseAllToWantBoostHubV5.sol`: add optional APR hooks for child capital allocations and harvest. Harvest compounding does not mint internal capital-flow units.
- `contracts/BeefyVaultV7FixedV2.sol`: prefer the two-child capital-weighted APR when the master reports initialized observations; retain the existing PPS-based fallback. Mint new shares against *actual NAV increase* after investing in Curve LP, preventing minting from unrecovered single-sided LP slippage; reject strategy withdrawal shortfalls. On the last redemption all of that redemption's withdrawal fee goes to the administrator (there are no remaining shareholders to whom it could be retained). Other vaults can still deploy this source in single-strategy mode.
- `README.md`: v42 entry point and explicit integration limitations.

## Allocation rules

- New deposits route to **Convex** only when `OmniRouter.getAmountOut(sdFXN, FXN, 1e18) > 0.969e18` **and** the Convex child observed APR exceeds the BoostHub child observed APR by **at least 4 percentage points**. Otherwise they route to BoostHub. If APR observations are not ready, ordinary deposits route to BoostHub.
- New withdrawal capital comes from **BoostHub** first. It comes from **Convex** first instead if observed BoostHub APR exceeds Convex APR by **more than 6 percentage points**, or if withdrawing from BoostHub first would breach its remaining-capital floor. Once the preferred source is exhausted down to the floor, the other child is used.
- Each child is targeted to retain at least 1 sdFXN when total net managed assets >= 10 sdFXN, at least 0.1 when >=1, otherwise 0.01 until fully empty. For totals below 0.02, the target necessarily falls to half the remaining total so that full redemption remains possible.
- When the sdFXN/FXN price check is below threshold or unavailable, no new Convex LP exposure is added, even to top up its target floor. At startup a limited reserve-creation exception to the 4pp APR advantage rule is necessary to bootstrap measurement of both child APRs. Reserve upkeep can move allocations between children and incur Curve LP slippage. The price restriction deliberately takes priority over the requested uninterrupted 1-unit minimum when those rules conflict.
- Child APR uses a trailing PPS-like historical observation independent of allocations. The vault reports `(boostValue * boostAPR + convexValue * convexAPR) / (boostValue + convexValue)` once both children have valid observations, otherwise falls back to the pre-existing vault historical PPS APR. APR is backward-looking, not a forecast or an externally guaranteed return.

## Fees and names

- New v42 vault: `CurveYield sdFXN`, `cysdFXN`; 0.45% withdrawal fee, existing 30% administrator / 70% retained-for-shareholders allocation unless the last share is redeemed, in which case the full last-redemption fee goes to the administrator; existing 24-hour retained-profit unlock.
- BoostHub child strategy performance fee: **3%** of converted harvested rewards.
- Convex child strategy performance fee: **13% total** (the same 3% base plus an additional 10 percentage points).
- Caller receives **10% of each child performance fee**, not 10% of gross rewards. Effective caller fee: 0.3% of gross BoostHub harvest, 1.3% of gross Convex harvest; remaining fee portion goes to the original fee receiver.
- Existing sdFXS, sdCRV, sdFXN staking reward maturation and vault deployments are untouched by this additive supplement.

## Critical limitations and commissioning prerequisites

1. **Compilation, contract tests, fork simulations, pool deposits/withdrawals, and deployment have not been performed.** This package must not be assumed safe or deployment-ready. The v41 package declares Foundry, Solidity 0.8.28, and OpenZeppelin dependencies not installed in the local sandbox; no tests or workflows were added under the user's restrictions.
2. The Convex f(x) staking-proxy deployment flow, approval path, received FXN/reward token routing, Curve LP quotes and withdrawals must be compiled and verified on a mainnet fork with the exact current production contracts before broadcasting. The pool-specific adapter uses Convex's **f(x) Booster/createVault(PID)** and **PoolRegistry**, not the unrelated conventional Convex Booster deposit API.
3. The deploying wallet must already have v41 Ethereum sdFXN staking at BoostHub PID1 with suitable deposit/withdraw permissions; the deployment script validates staking linkage and initial approval. The script also checks OmniRouter sdFXN↔FXN quote routes. Appropriate FXN and other reward-token → sdFXN conversions are required for harvest.
4. Existing v41 custom vault strategy fields are immutable. The v42 script deploys a **new vault**, and does not migrate existing positions or replace an existing vault in place. Ownership is transferred to `0x47623C62f281807D615eeb4A2CEee9d97F9D3C49`.
5. An OmniRouter executable quote is used for the 0.969 allocation price guard; it is *not* an independent manipulation-resistant TWAP. The allocation rule inherits any trust and manipulation characteristics of the router's quote.
6. The user mentioned “Yearn” in the withdrawal comparison, but specified BoostHub and Convex as the **only two** children. The 6pp comparison therefore uses Convex APR; no Yearn strategy was created.
7. The source does not include a cross-chain sdFXS bridge, an sdFXS Convex pool, onchain replacement of previously deployed vaults, user deposits, or any live transaction.

