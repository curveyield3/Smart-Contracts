# BoostHub v31 — approved optimizations 1–4

## Scope

Source-only replacement of v30. Only BoostHub.sol, BoostHubStaking.vy, the custom BaseAllToWantBoostHubV5.sol, and the custom StrategyConvexBoostHubStakingV5.sol are modified. Protected partner sources, both vault source files, OmniRouter, interfaces, deployment configuration, and build infrastructure are unchanged. The conditional preliminary-quote optimization is not implemented.

## Implemented changes

1. Hub claims settle selected tokens directly. The existing checkpoint calculation is factored into one internal _checkpointReward helper, shared with deposit/withdraw checkpointing. Claims no longer checkpoint every reward into storage before payment. Only an existing stored claim is cleared; new earnings remain local. No storage field or public selector is added.
2. Custom strategy events emit known action amounts. Deposit and Withdraw retain their event signatures but report the deposited/withdrawn amount instead of TVL. StratHarvest drops its third TVL argument. This removes two balanceOf() calls during a profitable harvest with restaking, and one during an actual deposit or withdrawal. Each such call formerly queried the token and staking contracts. Accounting-related balance reads are retained.
3. Vyper skips unused cursor updates for users with no ramp deposit weight. The existing deposit path initializes the cursor on a fresh ramp. Ramp removal returns immediately when that weight is zero, including full matured exits. Multiple matured buckets are still cleared individually, but their aggregate weight is subtracted in one storage update.
4. Custom swap enumeration no longer queries reward_disabled or token balances. Its existing swap loop reads each candidate balance once. Disabled-token leftovers remain convertible; zero balances are skipped. The acceptedRewardTokens view is unchanged. The unused direct IERC20 import is removed.

## Source-level accounting review

- Let P be principal, I the accumulated reward index, D prior reward debt, and C stored claimable. Newly earned E is max(floor(P*I/ACC_PRECISION)-D, 0). Both old and new claims pay C+E; the new claim clears C only when nonzero, advances D to floor(P*I/ACC_PRECISION), and reduces token reserves by the payment. No fee or index formula changes.
- A deposit/withdraw settles against old P before replacing the debt using new principal, as before. All registered tokens are processed on principal changes. Never-funded zero-index tokens retain the existing early return.
- A partial claim leaves omitted tokens' C and D untouched. Their pending amount remains C+max(floor(P*I/ACC_PRECISION)-D,0); later claims or principal changes settle it. Repeating a selected token produces zero additional earnings after the first settlement. Invalid token or failed transfer still reverts the transaction.
- Maturity pruning subtracts the same sum of matured bucket amounts from ramp_deposit_weight and clears the same buckets. The zero-weight exit skips only nonexistent ramp positions. It does not use rounded inactive balance as its condition, preserving small remaining positions and their schedules.
- Ramp constants, schedules, reward integral/penalty arithmetic, fees, principal accounting, and the immediate 10% / day-33 50% / day-45 100% curve are unchanged. The prior redistribution buffer and historical snapshots remain.
- Event payload and reward enumeration differences are documented in README.md. No new cache, registry, ledger, callback system, or persistent state is introduced.

## Verification limits

Reviewed source diffs and references; compared protected files, router, deployment files, and vaults byte-for-byte; inspected local relative import targets and final archive contents. These are static checks, not runtime tests or an audit certification.

No compilation, tests, simulation, gas benchmarking, deployment, or listing submission was performed. Reduced executed work does not establish a measured gas or deployed-bytecode reduction. The shared helper and explicit fast paths add a small amount of source text while removing repeated storage work and external calls.
