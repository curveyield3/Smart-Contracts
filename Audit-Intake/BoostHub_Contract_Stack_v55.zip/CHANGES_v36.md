# BoostHub Contract Stack v36 — sparse-checkpoint APR

Changed only `contracts/BeefyVaultV7FixedV2.sol` from v35. Other contracts and the canonical Beefy partner vault remain identical to v35.

- Keep simple 15-day PPS-return annualization as the target, but use a live current PPS endpoint on every read. APR remains current even without `checkpointAPR()` calls.
- Find the stored PPS observation nearest 15 days before the current block; gaps in daily checkpointing no longer revert or invalidate the calculation.
- When less than 15 days of history is present, annualize the available positive-duration interval instead of requiring a full historical window. With sparse observations, this is a best-available approximation and not an exact trailing-15-day return.
- `rate()` returns zero, not a revert, when there is no usable recorded baseline. `aprReady()` now means *some measured historical baseline exists*, not 15 days complete. Euler must have a nonzero bootstrap/minimum borrow rate if used immediately after deployment.
- Preserve `checkpointAPR()` as optional, permissionless and rate-limited to once per 24 hours. Existing deposit/withdraw checkpoint hooks unchanged.
- No change to fees, harvest, staking, strategy, router, deployment code, or default calculations outside the APR getter.
- Source changes do not guarantee an accurate return for any period with no previous PPS observations. Exact 15-day returns require at least one observation near the 15-day boundary.
