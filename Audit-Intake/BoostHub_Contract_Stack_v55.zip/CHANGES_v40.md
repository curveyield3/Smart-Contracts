# BoostHub Contract Stack v40 — Fraxtal supplemental staking/vault deployment

Source: `BoostHub_Contract_Stack_v39.zip`. New stack reuses the deployed BoostHub and OmniRouter. Existing deployed contracts are NOT modified.

## Requested name and economics

- Staking `@title` and on-chain `name()` both: **CurveYield Boosthub sdFXS Staking**.
- Vault `name()` via constructor: **CurveYield sdFXS**; `symbol()` **cysdFXS**.
- Strategy total performance fee: **300 bps (3%)** of harvested profits.
- Caller share: **300 bps (3%)** of that performance fee, i.e. **9 bps (0.09%)** of harvested profits. Admin share is **9700 bps of the fee**.
- Vault withdrawal fee: **30 bps (0.30%)**; 30% of fee (0.09% of withdrawn assets) to admin; 70% (0.21%) retained in strategy's existing profit unlock.
- Strategy profit unlock: **86,400 seconds (24h)**. Staking's separate reward-stream smoothing stays **150 units = 15d**.
- All new contract administrative and fee roles: `0x47623C62f281807D615eeb4A2CEee9d97F9D3C49`.
- Existing BoostHub owner `0x064256591313eeb86a84a5cbcc4c6460791b96dd` is **not** altered; it must approve new depositor.

## Receiver changeability

- New vault `adminFeeReceiver`: **changeable after 7 days**, initiated and executed by current fee receiver.
- New staking `fee_receiver`: **changeable by `admin`**; `admin` can be transferred using commit/accept.
- Strategy `adminFeeReceiverAddress`: **immutable**. There is no strategy admin/owner; replacing its receiver requires replacement of the strategy and bound vault. This was disclosed before deployment.

## Changes

1. Vyper staking source: NatSpec title replaced; added read-only name() returning exact requested string. Existing sdFXS-only 45-day ramp maintained.
2. New `script/DeployFraxtalSupplementV40.s.sol`: chain-252-only create+configure, source-bound Vyper artifact, one allowlist append preserving old depositor, exact FeeSettings and nonce-coupled strategy/vault deployment; immutable governance/fees checked before output.
3. No existing Solidity contract financial logic was changed.

## Required execution and verification

Compile Vyper 0.4.3 `contracts/BoostHubStaking.vy` with existing `tooling/make_staking_artifact.py`; compile Solidity with existing `forge build`. Use the attached supplemental deployment script, **not** `DeployBoostHubStack.s.sol` (which would attempt to redeploy a full network stack). Existing Foundry flow must set `--sender` to the connected signer and be backed by an authorized signing provider. If signed via Blockchain Operations Hub rather than Forge, use its transaction executor in equivalent exact order, with CREATE nonces verified after each receipt. No deployment should be claimed before receipts and post-deployment state are read back.

**SAFETY:** New APR estimator v38 can legitimately return zero on PPS decline; Morpho borrowing-rate integration should impose a separately configured floor. New staking reward route must preserve pool 0's original depositor. No new test suite is included.
