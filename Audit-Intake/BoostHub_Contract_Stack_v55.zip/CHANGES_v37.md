# BoostHub v37 — minimal vault APR and withdrawal-tax unlock changes

Only the three Solidity sources listed below differ from v36. No contracts were deployed. No tests were created, changed, or run.

## Requested changes

1. Removed the APR-history reset on zero total supply and removed the final-withdrawal special fee diversion. Initialization checks needed before the first-ever mint remain intact. The intended deployment permanently burns a small amount of shares, so the final-share path is not expected to occur.
2. The existing PPS-APR algorithm still targets a 15-day observation but ignores samples older than 30 days, falling back to shorter available history. If no eligible sample exists, `getAPR()` returns zero and `aprReady()` is false.
3. APR checkpoints on deposit and withdraw are best-effort: bounded-gas external self-calls wrapped in try/catch, skipped when remaining gas is low. An APR observation revert/out-of-gas cannot propagate through the vault operation. Normal transaction gas must still be sufficient for the underlying deposit/withdraw process.
4. Withdrawal tax retains its 30% administrator and 70% shareholder split. The retained 70% is transferred into the strategy and added to the strategy's **existing** `totalLocked`/`lastHarvest` profit-unlocking mechanism. New vault-only `lockVaultProfit(uint256)` authorizes this addition; there is no second unlock system and no performance fee on this income.

## Changed files
- `contracts/BeefyVaultV7FixedV2.sol`
- `contracts/BaseAllToWantBoostHubV5.sol`
- `contracts/interfaces/IStrategyBoostHubV1.sol`

## Compatibility notes
- A nonzero-withdrawal-tax v37 vault must be paired with the updated strategy implementation containing `lockVaultProfit(uint256)`; an old strategy does not implement that method. A zero-tax vault never calls it.
- The original deployed Fraxtal vault at `0xa917af9c4a33fbf443fa74577e2365e9385a4021` is immutable and unchanged. It has a 0% withdrawal fee and no APR getters.
- APR is still an observational historical measurement; short windows may annualize very high yields. No unsolicited rate cap, averaging system, or extra governance controls were introduced.
- The strategy retains transferred withdrawal-tax tokens as idle `want` until a normal existing deposit/harvest operation invests them; they are included in its `balanceOf()` net of `lockedProfit()`.
