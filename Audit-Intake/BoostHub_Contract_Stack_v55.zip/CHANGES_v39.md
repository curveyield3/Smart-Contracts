# BoostHub Contract Stack v39 — targeted changes

Base: `BoostHub_Contract_Stack_v38.zip`. No contracts deployed and no on-chain state changed.

## CurveYield informational header

Copied the existing informational header verbatim from `contracts/BoostHub.sol` into:

- `contracts/BeefyVaultV7FixedV2.sol`
- `contracts/StrategyConvexBoostHubStakingV5.sol`
- `contracts/BaseAllToWantBoostHubV5.sol` (shared strategy base)

Their existing MIT SPDX identifiers and contract implementations are unchanged by these documentation additions. Added the same informational content in Vyper comment syntax at the top of `contracts/BoostHubStaking.vy`, retaining its existing Vyper pragma and module docstring.

## Staking ramp scope

In `BoostHubStaking.vy`:

- Only the `lp_token` reward (sdFXS for the Fraxtal pool) is affected by the existing 45-day 10%→50%→100% maturation ramp and its 35% administrator share of foregone rewards.
- `WFRAX` and all non-`lp_token` rewards receive immediate *pro-rata accrual* across all staked balances (subject to the existing reward-stream smoothing schedule). They do **not** pay ramp admin fees and do not redirect their issuance to mature depositors.
- Ramp-weighted user penalty arithmetic and boundary snapshots are calculated only for `lp_token`; the original principal ramp scheduling and sdFXS reward math are retained.
- Reward registry, staking/withdrawal flow, reward smoothing, harvest, claim, token support, ownership, fees outside the ramp and external interfaces remain unchanged.

**Note:** The ramp is keyed by immutable `lp_token`, *not* by a hard-coded sdFXS address. For the intended Fraxtal staking market, `lp_token` is sdFXS. Reusing this generic staking contract for another deposit asset would ramp that asset's reward instead.

## Verification and scope

This is a source-only package, not an on-chain deployment. No tests were created or run. Full compiler verification has not been performed. Changes are limited to the four contracts listed above plus this change record. Archive integrity and a diff-based scope review are performed at packaging.
