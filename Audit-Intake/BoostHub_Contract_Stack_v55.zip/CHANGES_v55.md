# BoostHub Contract Stack v55 — Single emergency withdrawal entrypoint

## Change from v54
- Removed only `BeefyVaultV7FixedV2.emergencyWithdrawAll(uint256 minAssetsOut)`.
- Retained `emergencyWithdraw(uint256 shares, uint256 minAssetsOut)` as the sole public emergency withdrawal entrypoint; withdrawing all shares is possible by passing `balanceOf(caller)` as `shares`.
- Retained the ordinary `withdraw(uint256 shares)` and `withdrawAll()` functions unchanged.
- Retained the vault → master → Convex emergency-withdraw path and its previously established guard-bypass behavior, minimum net payout check, exact-asset liability, existing fee accounting, non-reentrancy, and APY update hook.
- Did not change BoostHub, staking contracts, allocation behavior, deposit guards, normal withdrawal guards, or the existing APY tracker.

## Verification status
- Source diff and ZIP entry/integrity verified against v54; no test files changed.
- No tests created, modified, or executed; no Solidity compilation, deployment or on-chain operations claimed.
- v54 documentation is preserved as historical release notes; this v55 note supersedes v54's two-entrypoint description.
