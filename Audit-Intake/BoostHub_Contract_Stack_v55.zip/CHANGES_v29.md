# BoostHub v29 — Unified Omni + Official Beefy Partner Vaults

## Exact requested changes

1. Based **only** on the uploaded `BoostHub_Contract_Stack_v28(1).zip`; all Hub, Vyper staking, existing custom vault/strategy, Omni implementation, deployment factory, and deployed-converter source files remain byte-identical.
2. Deleted `contracts/BoostHubFraxtalConverterAdapter_v1.sol` entirely; removed its import, constructor, and any runtime deployment dependency.
3. `script/DeployBoostHubStack.s.sol::run()` is still the **sole** deployment entrypoint. On each supported chain its original Hub and staking deployment are followed by deploying a fresh chain-local `CurveYieldOmniRouter`, installing supported routes, deploying original custom vault/strategy pairs using that router, and deploying additional **official** Beefy V7 partner pairs using the same router and staking contracts. No second script, deployment invocation, or `runPartners` flow.
4. Additional partner pairs: Ethereum sdCRV (PID 0), Ethereum sdFXN (PID 1), and Fraxtal sdFXS (PID 0); **3 additional, original pairs all preserved**. Official Beefy V7 + original clone factory + upstream `BaseAllToNativeFactoryStrat` copied from v24 partner source, unchanged except the new minimal BoostHub-derived strategy adapter and deployment helper.
5. The partner strategy uses original Beefy fee logic, supports v28's **9** staking reward slots, adds the omitted `unirouter()` V7 interface alias, and uses existing Omni `routeLength` only to exclude tokens that lack configured swap routes. It never swaps or charges a reward fee on idle principal. Unsupported SDT/3Crv rewards stay in the strategy's custody and out of the route list.
6. No SDT or 3Crv routes were added. Their existing Hub/staking registry declarations were **not changed**, so this does not silently alter original yield eligibility. Original custom strategies defer unsupported reward conversions instead of reverting the whole harvest. New partner strategies do not add unsupported tokens to inherited Beefy reward conversion.
7. Swap routes use the *already-present* v28 Omni router (3-input `swap`, quote `getAmountOut`, 300s V3 native TWAP, per-hop Curve `price_oracle`). The Omni source itself is **unchanged**.
8. Partner pair creation uses a small atomic factory helper so the newly created upstream Beefy V7 vault clones cannot be initialized by another party between transactions; ownership is transferred to current BoostHub DAO owner until explicit Beefy handoff. Existing pair nonce-coupled creation remains unchanged.

## Route table

| Network | Token in | Token out | Hop list | Historical oracle direction |
| --- | --- | --- | --- | --- |
| Ethereum | CRV | sdCRV | CRV→sdCRV StableSwap | `price_oracle()` invert **yes** (coin0→1) |
| Ethereum | crvUSD | sdCRV | crvUSD→CRV Tricrypto→sdCRV StableSwap | `price_oracle(1)` invert yes; `price_oracle()` invert yes |
| Ethereum | wstETH | sdFXN | wstETH→WETH V3→FXN TwoCrypto→sdFXN StableSwap | V3 300s TWAP; TwoCrypto invert yes; StableSwap invert yes |
| Ethereum | CRV | WETH | CRV→WETH V3 | Native 300s TWAP |
| Ethereum | crvUSD | WETH | crvUSD→WETH Tricrypto | `price_oracle(0)` invert yes |
| Ethereum | wstETH | WETH | wstETH→WETH V3 | Native 300s TWAP |
| Ethereum | sdCRV | WETH | sdCRV→CRV StableSwap→WETH V3 | StableSwap invert **no**; V3 TWAP |
| Ethereum | WETH | sdCRV | WETH→CRV V3→sdCRV StableSwap | V3 TWAP; StableSwap invert yes |
| Ethereum | sdFXN | WETH | sdFXN→FXN StableSwap→WETH TwoCrypto | StableSwap invert no; TwoCrypto invert no |
| Ethereum | WETH | sdFXN | WETH→FXN TwoCrypto→sdFXN StableSwap | Both invert yes |
| Fraxtal | WFRAX | sdFXS | Same historical WFRAX/sdFXS Curve pool | Pool `price_oracle()` or `price_oracle(0)`; invert yes |
| Fraxtal | sdFXS | WFRAX | Reverse through same pool | Same EMA; invert no |

**Oracle evidence:** On Ethereum, live `get_dy` vs `price_oracle` comparisons: CRV→sdCRV 1.8805 vs inverse EMA 1.8851; sdCRV→CRV 0.5291 vs EMA 0.5305; crvUSD→CRV 4.4119 vs inverse indexed EMA 4.4173; crvUSD→WETH 0.00052212 vs inverse EMA 0.00052274; WETH→FXN 121.72 vs inverse EMA 122.85; FXN→sdFXN 0.99499 vs inverse EMA 0.9970. Each Curve rate is coin1/coin0 (or coin2/coin0 for indexed Tricrypto); code uses the inverse only for coin0→other directions. Native V3 TWAP computes orientation from token0/token1 automatically.

## Deployment safeguards and limitations

- Pre-broadcast dependency checks: correct Beefy strategy factory `native` token and fee config, global/strategy pause status, official Ethereum V7 factory implementation, live Ethereum Curve oracle methods including Tricrypto `(0)` and `(1)`, active liquidity for selected V3 pools, Fraxtal pool oracle and token ordering.
- The script configures routes and checks on-chain historical quotes after each route is set. These are **not** execution swaps or fork simulations.
- The existing source-bound Vyper artifact check remains mandatory. Creation of shared Hub with the same CREATE3 deployment ID and sender requires the existing unused address; `run()` is not a migration or an idempotent second-run pathway.
- Fraxtal live state could not be independently inspected from this session; the in-script live Fraxtal preflight is mandatory and will reject incorrect pool ordering/missing oracles.
- Fee category: Beefy's external fee configurator decides performance/caller shares; the script cannot set another owner's fee settings. It emits observed values for follow-up. The upstream `callReward()` remains the exact original zero-valued view as requested; approval under SAFU is still a separate Beefy decision.
- `@openzeppelin/contracts-upgradeable` (4.9.6) and `@openzeppelin-5/contracts` (5.4.0) are added to the declared build dependencies for official Beefy sources. The **existing compile-only workflow** receives one additional `beefy-partner/**` path trigger so future edits to the new strategy are compiled by the same pre-existing mechanism; no workflows or tests were created. `forge build` requires dependency installation and Vyper artifact generation; this environment did not have Forge/solc/Vyper installed.
- No tests, simulation, broadcast, ownership acceptance, listings, or contract publication were performed.
