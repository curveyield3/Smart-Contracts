// SPDX-License-Identifier: MIT
/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * dApp: https://curveyield.com & https://curveyield.org
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */
pragma solidity ^0.8.20;

import "@openzeppelin-4/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin-4/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "@openzeppelin-4/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin-4/contracts/access/Ownable.sol";
import "./interfaces/IBeefySwapperV2.sol";
import "./interfaces/IStrategyBoostHubV1.sol";

interface IYieldChildV42 is IStrategyBoostHubV1 {
    function harvest(address caller) external;
    function lockedProfit() external view returns (uint256);
}

interface IConvexGaugeMigrationV45 {
    function withdrawGaugeUnits(uint256 gaugeLpUnits) external returns (uint256 wantReceived);
}
interface IConvexEmergencyWithdrawalV54 {
    function emergencyWithdraw(uint256 amount) external;
}
interface IConvexCurveLiquidityGuardV50 {
    function setCurveLiquidityGuard(address newGuard) external;
    function curveLiquidityGuard() external view returns (address);
}

interface IVaultAPYUpdateV53 { function updateAPY() external; }

/// @notice Master strategy: one sdFXN vault -> direct BoostHub + Convex f(x) pool 8 children.
/// @dev Two-child architecture intentionally uses only existing vault.strategy() interface.
contract StrategyDualFXNMasterV42 is ReentrancyGuard, Ownable, IStrategyBoostHubV1 {
    using SafeERC20 for IERC20;

    address public immutable override vault;
    address public immutable override want;
    address public immutable swapper;
    address public immutable fxn;
    IYieldChildV42 public boostChild;
    IYieldChildV42 public convexChild;
    bool public initialized;

    uint256 public constant WAD = 1e18;
    uint256 public constant MAX_BPS = 10_000;
    // Existing owner caps also serve as normalized deposit/withdrawal target weights.
    // E.g. 5500/4500 => 55% BoostHub / 45% Convex; 9900/9900 => 50/50.
    uint16 public boostCapBps = 9_900;
    uint16 public convexCapBps = 9_900;
    uint256 public constant PEG_MIN_WAD = 969e15;         // strictly greater than 0.969 FXN / sdFXN
    uint256 public constant LOCK_DURATION = 1 days;
    uint256 public lastHarvest;
    uint256 public totalLocked;

    event ChildrenConfigured(address indexed boost, address indexed convex);
    event AllocationCapsUpdated(uint16 boostCapBps, uint16 convexCapBps);
    event Allocation(address indexed child, uint256 deposited);
    event Deallocation(address indexed child, uint256 withdrawn);
    event ManualMigration(uint8 indexed fromStrategyIndex, uint256 sourceUnits, uint256 transferredWant);
    event MasterHarvest(address indexed caller);

    constructor(address vault_, address want_, address fxn_, address swapper_) {
        require(block.chainid == 1, "ETHEREUM_ONLY_POOL8");
        require(vault_ != address(0) && want_.code.length > 0 && fxn_.code.length > 0
            && swapper_.code.length > 0, "INVALID_DEPENDENCY");
        require(IERC20Metadata(want_).decimals() == 18, "SD_FXN_DECIMALS");
        vault = vault_;
        want = want_;
        fxn = fxn_;
        swapper = swapper_;
    }

    function configureChildren(IYieldChildV42 boost, IYieldChildV42 convex) external onlyOwner {
        require(!initialized && address(boost).code.length > 0 && address(convex).code.length > 0
            && address(boost) != address(convex), "CHILD_INIT");
        require(boost.vault() == address(this) && convex.vault() == address(this)
            && boost.want() == want && convex.want() == want, "CHILD_MISMATCH");
        boostChild = boost;
        convexChild = convex;
        initialized = true;
        emit ChildrenConfigured(address(boost), address(convex));
    }

    /// @notice Configure or disable the external oracle guard after child deployment.
    /// @dev Requires the master owner's authority; no constructor-time guard dependency.
    function setConvexCurveLiquidityGuard(address guard) external onlyOwner {
        require(initialized, "CHILDREN_NOT_SET");
        IConvexCurveLiquidityGuardV50(address(convexChild)).setCurveLiquidityGuard(guard);
    }

    function _assets() internal view returns (uint256 boost, uint256 convex) {
        if (initialized) {
            boost = boostChild.balanceOf();
            convex = convexChild.balanceOf();
        }
    }

    function childBalances() external view returns (uint256 boost, uint256 convex) { return _assets(); }
    function lockedProfit() public view returns (uint256) {
        uint256 age = block.timestamp - lastHarvest;
        return age >= LOCK_DURATION ? 0 : totalLocked * (LOCK_DURATION - age) / LOCK_DURATION;
    }
    function balanceOf() public view override returns (uint256) {
        (uint256 b, uint256 c) = _assets();
        uint256 sum = IERC20(want).balanceOf(address(this)) + b + c;
        uint256 locked = lockedProfit();
        return sum > locked ? sum - locked : 0;
    }

    function sdFxnToFxnWad() public view returns (uint256) {
        try IBeefySwapperV2(swapper).getAmountOut(want, fxn, WAD) returns (uint256 amount) {
            return amount;
        } catch { return 0; }
    }
    /// @notice The original Convex price safeguard remains in force on new LP exposure.
    /// @dev Selection is driven exclusively by owner-defined percentages, not APRs.
    function convexEligible() public view returns (bool) {
        if (!initialized) return false;
        // A new Convex position requires the original separately configured
        // external liquidity guard; do not fail ordinary deposits while unset.
        try IConvexCurveLiquidityGuardV50(address(convexChild)).curveLiquidityGuard()
            returns (address guard) {
            if (guard.code.length == 0) return false;
        } catch { return false; }
        return sdFxnToFxnWad() > PEG_MIN_WAD;
    }

    function _targetBalances(uint256 grossAssets) private view returns (uint256 boost, uint256 convex) {
        uint256 weightSum = uint256(boostCapBps) + uint256(convexCapBps);
        boost = grossAssets * boostCapBps / weightSum;
        convex = grossAssets - boost;
    }

    /// @notice Normalized allocation targets inferred from the existing owner caps.
    function allocationTargets() external view returns (uint256 boostBps, uint256 convexBps) {
        uint256 denominator = uint256(boostCapBps) + uint256(convexCapBps);
        boostBps = uint256(boostCapBps) * MAX_BPS / denominator;
        convexBps = MAX_BPS - boostBps;
    }

    /// @notice Existing owner percentage control: upper caps AND normalized target weights.
    /// @dev Both values <=10000 and sum >=10000. 5500/4500 means 55%/45%,
    ///      while 9900/9900 normalizes to 50%/50%. No automatic position migration.
    function setAllocationCaps(uint16 boostBps, uint16 convexBps) external onlyOwner {
        require(boostBps <= MAX_BPS && convexBps <= MAX_BPS, "INVALID_CAP");
        require(uint256(boostBps) + convexBps >= MAX_BPS, "CAP_SUM_BELOW_100");
        boostCapBps = boostBps;
        convexCapBps = convexBps;
        emit AllocationCapsUpdated(boostBps, convexBps);
    }

    function _positionAssets(IYieldChildV42 child) private view returns (uint256) {
        // Child balanceOf() is net of its time-locked harvested profits, while
        // those underlying tokens are still invested in the child. Count both.
        return child.balanceOf() + child.lockedProfit();
    }

    function _grossAssets() private view returns (uint256 total) {
        // Idle balances include any master-level locked withdrawal fees already;
        // they must NOT be counted a second time via master.lockedProfit().
        total = IERC20(want).balanceOf(address(this)) + IERC20(want).balanceOf(vault);
        if (initialized) total += _positionAssets(boostChild) + _positionAssets(convexChild);
    }

    function _capacity(IYieldChildV42 child, uint256 grossAssets) private view returns (uint256) {
        uint256 maxPosition = grossAssets * (address(child) == address(convexChild) ? convexCapBps : boostCapBps)
            / MAX_BPS;
        uint256 position = _positionAssets(child);
        return maxPosition > position ? maxPosition - position : 0;
    }

    function allocationHeadroom() external view returns (uint256 boost, uint256 convex, uint256 grossAssets) {
        if (!initialized) return (0, 0, _grossAssets());
        grossAssets = _grossAssets();
        boost = _capacity(boostChild, grossAssets);
        convex = _capacity(convexChild, grossAssets);
    }

    function _invest(IYieldChildV42 child, uint256 amount) private {
        if (amount == 0) return;
        IERC20(want).safeTransfer(address(child), amount);
        child.deposit();
        emit Allocation(address(child), amount);
    }

    function _unlockedIdle() private view returns (uint256) {
        uint256 idle = IERC20(want).balanceOf(address(this));
        uint256 locked = lockedProfit();
        return idle > locked ? idle - locked : 0;
    }

    /// @dev Invest unlocked capital towards the owner-defined normalized targets,
    ///      never exceed existing absolute caps. Convex deposits still require the
    ///      existing peg safeguard; blocked target capital stays idle.
    function _allocateAvailable() private {
        uint256 free = _unlockedIdle();
        if (free == 0) return;
        uint256 gross = _grossAssets();
        (uint256 boostTarget, uint256 convexTarget) = _targetBalances(gross);
        uint256 boostPosition = _positionAssets(boostChild);
        uint256 convexPosition = _positionAssets(convexChild);
        uint256 boostDeficit = boostTarget > boostPosition ? boostTarget - boostPosition : 0;
        uint256 convexDeficit = convexTarget > convexPosition ? convexTarget - convexPosition : 0;
        uint256 boostCap = _capacity(boostChild, gross);
        uint256 convexCap = _capacity(convexChild, gross);
        if (boostDeficit > boostCap) boostDeficit = boostCap;
        if (convexDeficit > convexCap) convexDeficit = convexCap;
        if (!convexEligible()) convexDeficit = 0;

        // Invest the larger shortfall first, then the other; no APR decisions.
        if (convexDeficit > boostDeficit) {
            uint256 takeConvex = free < convexDeficit ? free : convexDeficit;
            _invest(convexChild, takeConvex);
            free -= takeConvex;
            uint256 takeBoost = free < boostDeficit ? free : boostDeficit;
            _invest(boostChild, takeBoost);
        } else {
            uint256 takeBoost = free < boostDeficit ? free : boostDeficit;
            _invest(boostChild, takeBoost);
            free -= takeBoost;
            uint256 takeConvex = free < convexDeficit ? free : convexDeficit;
            _invest(convexChild, takeConvex);
        }
    }

    function deposit() external override nonReentrant {
        require(initialized, "CHILDREN_NOT_SET");
        _allocateAvailable();
    }

    /// @notice Permissionless investment of previously idle, unlocked sdFXN.
    /// @dev Does not relocate existing positions; observes owner weights and existing caps.
    function rebalanceAllocations() external nonReentrant {
        require(initialized, "CHILDREN_NOT_SET");
        _allocateAvailable();
    }

    /// @notice Owner-directed migration from one child into the other.
    /// @param fromStrategyIndex 0 = BoostHub -> Convex (sourceUnits are staked
    ///        sdFXN base units); 1 = Convex -> BoostHub (sourceUnits are staked
    ///        Curve LP / gauge units). Both are 18-decimal raw integers.
    /// @dev Owner-directed position changes bypass automatic percentage targets,
    ///      but new Convex exposure still obeys the 0.969 price floor and the
    ///      destination cap. The operation is atomic.
    function migrate(uint8 fromStrategyIndex, uint256 sourceUnits) external onlyOwner nonReentrant {
        require(fromStrategyIndex <= 1, "INVALID_STRATEGY_INDEX");
        require(initialized && sourceUnits != 0, "INVALID_MIGRATION");
        uint256 beforeWant = IERC20(want).balanceOf(address(this));
        uint256 transferred;
        IYieldChildV42 destination;
        if (fromStrategyIndex == 1) {
            destination = boostChild;
            transferred = IConvexGaugeMigrationV45(address(convexChild)).withdrawGaugeUnits(sourceUnits);
            require(transferred > 0, "NO_MIGRATION_OUTPUT");
            require(IERC20(want).balanceOf(address(this)) - beforeWant == transferred,
                "MIGRATION_ASSET_MISMATCH");
        } else {
            require(sdFxnToFxnWad() > PEG_MIN_WAD, "CONVEX_PRICE_GATE");
            destination = convexChild;
            require(sourceUnits <= boostChild.balanceOf(), "BOOST_BALANCE_SHORTFALL");
            transferred = _take(boostChild, sourceUnits, false);
            require(transferred >= sourceUnits, "BOOST_EXIT_SHORTFALL");
        }
        // Cap is checked on the actual post-exit TVL, never a stale pre-swap
        // quote. Destination's deposit cannot exceed its remaining capacity.
        require(transferred <= _capacity(destination, _grossAssets()), "DESTINATION_CAP");
        _invest(destination, transferred);
        uint256 targetCapBps = fromStrategyIndex == 1 ? boostCapBps : convexCapBps;
        require(_positionAssets(destination) <= _grossAssets() * targetCapBps / MAX_BPS,
            "DESTINATION_OVER_CAP");
        emit ManualMigration(fromStrategyIndex, sourceUnits, transferred);
    }

    function _take(IYieldChildV42 child, uint256 need, bool emergency)
        private returns (uint256 received)
    {
        if (need == 0) return 0;
        uint256 balance = child.balanceOf();
        uint256 requested = need < balance ? need : balance;
        if (requested == 0) return 0;
        uint256 beforeValue = IERC20(want).balanceOf(address(this));
        if (emergency && address(child) == address(convexChild)) {
            IConvexEmergencyWithdrawalV54(address(child)).emergencyWithdraw(requested);
        } else {
            child.withdraw(requested);
        }
        received = IERC20(want).balanceOf(address(this)) - beforeValue;
        require(received >= requested, "CHILD_EXIT_SHORTFALL");
        emit Deallocation(address(child), received);
    }

    function withdraw(uint256 amount) external override nonReentrant {
        _withdrawForVault(amount, false);
    }

    /// @notice Vault-only exit that skips Convex's external Curve oracle output guard.
    /// @dev All withdrawal floors and exact-asset requirements are identical to withdraw().
    function emergencyWithdraw(uint256 amount) external nonReentrant {
        _withdrawForVault(amount, true);
    }

    function _withdrawForVault(uint256 amount, bool emergency) private {
        require(msg.sender == vault && initialized, "VAULT_ONLY");
        require(amount <= balanceOf(), "INSUFFICIENT_MASTER_VALUE");
        if (amount == 0) return;
        uint256 free = IERC20(want).balanceOf(address(this));
        uint256 locked = lockedProfit();
        free = free > locked ? free - locked : 0;
        uint256 need = amount > free ? amount - free : 0;

        if (need > 0) {
            // Reduce whichever child is most above its owner-defined target
            // for the post-withdrawal gross TVL; use the other if necessary.
            uint256 gross = _grossAssets();
            (uint256 bTarget, uint256 cTarget) = _targetBalances(gross > amount ? gross - amount : 0);
            uint256 bPosition = _positionAssets(boostChild);
            uint256 cPosition = _positionAssets(convexChild);
            uint256 bExcess = bPosition > bTarget ? bPosition - bTarget : 0;
            uint256 cExcess = cPosition > cTarget ? cPosition - cTarget : 0;
            bool convexFirst = cExcess > bExcess;
            IYieldChildV42 first = convexFirst ? convexChild : boostChild;
            IYieldChildV42 second = convexFirst ? boostChild : convexChild;
            uint256 got = _take(first, need, emergency);
            if (got < need) _take(second, need - got, emergency);
        }
        require(IERC20(want).balanceOf(address(this)) >= amount + lockedProfit(), "WITHDRAWAL_FLOOR_OR_LIQUIDITY");
        IERC20(want).safeTransfer(vault, amount);
    }

    function harvest() external nonReentrant { _harvest(msg.sender); }
    function harvest(address callFeeRecipient) external nonReentrant { _harvest(callFeeRecipient); }
    function _harvest(address recipient) internal {
        require(initialized && recipient != address(0), "INVALID_HARVEST");
        boostChild.harvest(recipient);
        convexChild.harvest(recipient);
        emit MasterHarvest(recipient);
        // Harvest happens outside the vault: keep the same best-effort APY check.
        if (gasleft() > 450_000) {
            try IVaultAPYUpdateV53(vault).updateAPY{gas: 300_000}() {} catch {}
        }
    }

    function lockVaultProfit(uint256 amount) external override {
        require(msg.sender == vault, "VAULT_ONLY");
        // The vault has already transferred 'amount' here before this call.
        require(IERC20(want).balanceOf(address(this)) >= amount + lockedProfit(), "LOCK_NOT_BACKED");
        totalLocked = lockedProfit() + amount;
        lastHarvest = block.timestamp;
    }

    /// @notice APY belongs solely to the share-issuing Beefy vault.
    /// @dev The master exposes no APR-based allocation or historical yield selectors.
}
