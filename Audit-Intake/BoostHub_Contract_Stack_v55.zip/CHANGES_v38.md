# BoostHub v38 — APR continuity and 4-hour observation spacing

Only `contracts/BeefyVaultV7FixedV2.sol` changes relative to v37.

1. Minimum 4 hours between stored readings, including automatic pre-deposit/pre-withdraw checkpoints and the permissionless keeper call.
2. Preserve up to 16 daily readings for the targeted 15-day APR, capped at a maximum 30-day *calculation* lookback. This prevents frequent 4-hour observations from evicting the useful long-term data.
3. Preserve the last five 4-hour readings separately. If the daily window has no eligible baseline, use the oldest of the five recent readings (or available readings during initial bootstrapping). For an already initialized APR, wait for all five fresh readings before switching from its last valid APR after a gap.
4. Cache the last computable APR on successful checkpoints. An outage with no readings within 30 days returns the cached APR instead of falling to zero; cache is only replaced by a new computable observation. A real PPS decline can still produce a zero measured APR, and APR cannot be initialized before any eligible PPS history exists. A stale cache is an availability fallback, not an estimate of current return.
5. Live `getPricePerFullShare()` is called through a bounded, catchable external self-call for APR getters; PPS failures fall back to the cached reading rather than reverting.
6. Deposit/withdraw APR checkpoints remain best-effort, run only after all principal accounting/transfers and skip entirely if 4 hours have not passed. The gas reserve means failure inside the capped APR self-call does not cause a normal asset operation to revert. Transactions must still be supplied with enough gas for their core functionality.

The v37 withdrawal fee / profit-unlock path and strategy are unchanged. No tests were created, modified or run. Compilation is not included.

**Operational note:** If Morpho must have a nonzero borrowing rate before five initial observations, its IRM must supply an independently configured fallback/floor. The vault cannot truthfully calculate historic gains before a history exists. The cached APR can be stale during a long outage; the market IRM should apply its own maximum rate/floor and monitoring.
