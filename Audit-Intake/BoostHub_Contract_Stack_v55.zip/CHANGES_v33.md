# BoostHub v33 — deployment runtime repair and official Beefy factory sequencing

## Scope

- Based on v32 without editing either legacy/custom vault-strategy implementation, Hub, Vyper staking source, Omni router or Beefy's official vault/base contracts.
- Correct the Vyper 0.4.3 three-immutable runtime verification in `DeployBoostHubStack.s.sol`: compare the exact compiler runtime prefix, check its required 96-byte trailer matches encoded `lp_token`, `boost_hub` and `pid`, then retain existing immutable getter checks. Do not weaken source artifact SHA-256/version binding.
- On BOTH chains, use Beefy's pre-existing official `BeefyVaultV7Factory.cloneVault()` and registered `StrategyFactory.createStrategy("BoostHubStaking")`. Remove generic arbitrary strategy clones and Fraxtal self-deployed vault factory.
- Keep `BoostHubPartnerPairDeployerV3` as the existing, same-transaction creation/initialization helper. Do not add another deployment entrypoint.
- Before starting broadcast, require the registered strategy beacon to exist and its implementation code hash to match this build's exact partner strategy runtime; require the on-chain vault factory and its template instance to exist.

## Required external dependency / deployment blocker

The official Ethereum Beefy strategy factory's `instances("BoostHubStaking")` was read on November 14, 2026 and returned the zero address. Factory owners/keepers must register the exact compiled `StrategyConvexBoostHubPartnerV2` implementation as `BoostHubStaking` before either chain's one-entrypoint deployment can proceed. The Fraxtal factory registration has not been independently read: Fraxtal RPC was unavailable in this session. The Fraxtal V7 factory address is `0x91BB303E972995EbE5f593BCddBb6F5Ef49Dbcbd`, sourced from Beefy's Fraxtal address book and corroborated by published Fraxscan code. The script checks it on-chain before use.

## Fees and SAFU

Beefy's live Ethereum default `BeefyFeeConfigurator.getFees(address(0))` returns an active fee category with total fee 9.5% and caller share 5.2631578947368421% of that fee, i.e. 0.5% of gross harvest. The initializer wires the strategy to that fee configurator, without requiring an explicit per-strategy category. This *actual caller payout* must not be confused with the unchanged inherited `callReward()` view, which always returns zero. This change does not modify the getter, reward logic, or the router.

## Validation / limitations

No new tests created or executed. No deploy or on-chain writes. Factory registration is a hard external prerequisite; this package is not immediately broadcastable while unregistered. Vyper immutables bytes are compared in source declaration order. Compilation/fork execution are not claimed; use the existing compilation workflow and planned SAFU validation after authorized registration.
