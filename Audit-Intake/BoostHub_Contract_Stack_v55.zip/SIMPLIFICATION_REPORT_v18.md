# BoostHub v18 — Staking simplification and compile-only report

## What changed

Rather than deleting the caches and reintroducing repeated ramp-phase work for each reward token, v18 **preserves the original v17 single shared depositor-bucket scan and the shared four-phase maturity calculation**. Each token retains its separately cached integral history and earned rewards. The improvements are narrowly focused on:

- Replacing two separately branched maturity functions (`_ramp_active_units`, `_ramp_slope`) with a single `_ramp_parameters` function that produces activation weight and slope together. It is called once when adjusting a deposit cohort, rather than evaluating the ramp phase twice.
- Reusing two small internal helpers for changes to the pending activation-increase and activation-decrease schedules, instead of repeating four copies of conditional storage-update code.
- Keeping **24-hour buckets (45 maximum)**, 45-day ramp milestones, proportional configured-duration reward smoothing, reward entitlements and bucket pruning unchanged.

For accuracy, no gas measurement is available; the source is smaller in compiled bytecode and avoids duplicated phase branching during cohort adjustments, but **gas savings are not benchmarked**. More aggressive memory-cache removal candidates were rejected because they would reintroduce repeated storage loads or phase calculations per token.

## GitHub compile-only verification

- Repository: `curveyield3/Smart-Contracts`, isolated branch `boosthub-staking-compile-v17`.
- Compiler: `vyper==0.4.3` (runtime and creation bytecode).
- Successful run: https://github.com/curveyield3/Smart-Contracts/actions/runs/43081438451
- v17 runtime: **18,616 bytes** (previous successful run 43076323379).
- v18 runtime: **18,479 bytes**, **137 bytes smaller**.
- v18 creation bytecode: **21,756 bytes**.
- EIP-170 runtime cap: **24,576 bytes**; headroom **6,097 bytes**.
- Historical v11 runtime (12-hour buckets, per-token scans): **18,113 bytes**; v18 retains **366 bytes** more than that older, less-shared implementation.
- Verified compiled source identity: Git blob `4b5db73e12a3e78868079fe78bdbbb2ebb4530a8` corresponds to `contracts/BoostHubStaking.vy` and the standalone `BoostHubStaking_Simplified_v13.vy`.

## Associated deployment cleanup

- CREATE3 factory retained, used only for the BoostHub address required to match on Ethereum and Fraxtal.
- Staking contracts deploy using normal CREATE, still checked against the exact Vyper runtime code hash and constructor bindings.
- The user-supplied BoostHub implementation revision v14 is unchanged; the deployment script sets its `automaticHarvestOnDeposit` option to `false` during initial configuration. Explicit harvest remains available.

## Unverified

No tests, fork simulations, actual deployments, or gas benchmarking were performed. The full Solidity/Foundry stack **has not been recompiled after the deployment-script changes**. The size result is an actual successful staking-source compile, not a security endorsement. Existing unresolved historical security findings are not implicitly repaired by this cleanup.
