# BoostHub v34 — independently deployed partner strategies with official Beefy V7 vaults

## Approved change

- Based on v33. Original custom vault/strategy sources, Vyper staking, Hub, chain-local Omni router, Oracle configurations, and official Beefy vault/base/fee interfaces remain byte-for-byte untouched.
- Maintain **one** `script/DeployBoostHubStack.s.sol::run()` entrypoint on each chain and the existing `BoostHubPartnerPairDeployer` helper (now V4); do not add a new standalone deployment flow.
- Ethereum's existing **official Beefy V7 vault factory** at `0xC551dDCE8e5E657503Cd67A39713c06F2c0d2e97` creates the standard vault clone using `cloneVault()`. Fraxtal retains its previously configured published V7 vault factory, subject to its original on-chain checks.
- On **both networks**, each partner strategy uses `new StrategyConvexBoostHubPartnerV2()` deployed independently and initialized immediately. It does **not** call `StrategyFactory.createStrategy()` or require `StrategyFactory.addStrategy()` / `instances("BoostHubStaking")`.
- Retain the existing Beefy StrategyFactory address **only** as the inherited strategy's native-token, keeper, fee recipient, fee configuration, and global/type pause provider. The preflight verifies those reads but no longer demands registered strategy beacon code.
- Preserve per-pair atomic vault clone + strategy creation + initialization + ownership transfer; vault's six-hour (21600-second) strategy-upgrade delay is unchanged.
- Preserve the v33 Vyper immutable-runtime repair, in-place main deployer, router routes, skip of SDT/3Crv routes, and original three custom vaults.

## On-chain precedent

Beefy Ethereum `cloneVault()` -> `createStrategy()` -> `vault.initialize()` -> ownership/configuration was observed for a vault launched 2026-11-10. The vault factory and strategy factory are independent contracts; the standard V7 vault accepts any conforming strategy, so the strategy-factory creation step is deliberately replaced by independent BoostHub strategy deployment. This is a protocol integration variation from the historical sequence, not a claim that Beefy currently accepts independent strategy deployment for listing.

## External status

- Requires existing published V7 vault factory, usable strategy factory config getters, nonpaused strategy type and token/oracle infrastructure on each chain.
- On Ethereum the standard vault-factory instance and default nonzero caller fee were read on-chain during prior review. This does not imply Beefy approval or that `callReward()` returns a nonzero quote: the upstream inherited getter is unchanged.
- Fraxtal factory availability and pools must pass the existing preflight on that chain.
- No compilation, simulation, test creation/execution, or chain deployment has been performed in this packaging change.
