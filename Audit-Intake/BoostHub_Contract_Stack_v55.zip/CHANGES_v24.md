# BoostHub Contract Stack v24 — Approved surgical cleanup

## Scope and authority

Based on the complete v23 package. Implements approved second-pass items **5, 6, 7, 8, 11, 12, 13 and 14**, and reverses the unnecessary pending-fee indexing mechanism raised in item **10**. Item **9** is satisfied by reusing Hub token enumeration via the existing harvest return and one shared staking importer. **Items 1–4 denied; no associated behavior changed.** Emergency migration remains unchanged (the earlier denied emergency item was not reinterpreted as the newer item 14).

## Changes by source

### `contracts/BoostHub.sol`
- Retains the *original* reward-index/debt checkpoint formula, now using `_checkpoint(pid, account, newPrincipal)` for claims and principal changes. Removes the v23-only `_checkpointPrincipalChange` duplicate. No extra reward state or secondary index was added.
- Removes the v23 pending-fee PID array, mapping and swap-and-pop code. `executeTransactions()`, `clearTransactions()` and `pendingTransactions()` use the original bounded pool loop and `PendingFeeConfig.readyAt` to identify pending fees. Unchanged fee configurations still avoid re-queuing.
- `NonRewardTokenSwept` event renamed to `UnreservedTokensSwept`; `PoolDepositorLocked(pid, depositor)` becomes `PoolDepositorAllowlistLocked(pid)`. External consumers filtering events must update their event signatures. Sweep and allowlist behavior remain unchanged.
- No changes to emergency-stop/migration, zero-staker reward rules, duplicate-gauge handling, reward slot limits, or disabled-reward behavior.

### `contracts/BoostHubStaking.vy`
- Adds `BoostHub.harvest()` to its typed interface; consumes the existing returned reward-token registry. The shared `_import_boosthub_rewards(tokens)` helper is the only import path for both the active harvest and explicit permissionless `update_reward_tokens()`. The zero-stake early return does not perform an unnecessary poolInfo read.
- Constructor fetches Hub poolInfo once and reuses the result for constructor reward validation and initial import.
- Removes the pre-harvest admin-fee transfer scan; retains one settlement at the end or before returning from the zero-stake branch.
- Removes the unused keeper role, keeper transfer functions/events and keeper constructor argument. Admin transfers are not removed.
- Shares fixed 45-day ramp phase boundaries and slopes via named compile-time constants. No change to the existing ramp formula or storage-backed integral accounting.
- Replaces the trivial `_total_reward_weight()` wrapper with its actual stored total. Keeps `MAX_BOOSTHUB_REWARDS = 8` only for the original constructor's eight-entry fixed array; the disable flow uses `MAX_REWARDS = 9` when building a claim array.

### `contracts/interfaces/IBoostHub.sol`
- Removes unused `pid` from `EthereumMerkleClaim` and `FraxtalUrdClaim`. Merkle recipient protections, distributor validation and PID attribution are otherwise unchanged.

### `script/DeployBoostHubStack.s.sol`
- Removes keeper selection and adjusts staking constructor ABI encoding accordingly. Still uses the original single deployment script and source-bound Vyper artifact check.

## Changed compatibility surfaces

- **Merkle/URD claim structs:** Two changed external tuple signatures; integrations must encode them without `pid`.
- **BoostHubStaking constructor:** Seven inputs instead of eight; rebuilt Vyper deployment artifact required.
- **Removed staking getters/actions:** `keeper`, `pending_keeper`, `initiate_keeper_transfer`, `accept_keeper`.
- **Events:** `UnreservedTokensSwept(address,address,uint256)` and `PoolDepositorAllowlistLocked(uint256)` replace the previous event signatures.
- **No modifications:** emergency migration entry points; Beefy vault/strategies; converters; gauges; router; user reward withdrawal semantics; reward capacity; external reward streams.

## Verification limits

The source diff has been reviewed for removed/replaced helper references and deployment ABI consistency. No tests were created or executed. Full compilation could not be run here because the pinned Vyper and Solidity/Foundry toolchains are unavailable in the local runtime and the attempted Vyper download failed. The existing GitHub compile-only workflow remains untouched. This package must **not** be represented as compiled or runtime-validated.
