// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;
import {IERC20} from "@openzeppelin-4/contracts/token/ERC20/IERC20.sol";
import {BaseAllToWantBoostHubV5} from "../contracts/BaseAllToWantBoostHubV5.sol";
import {StrategyConvexFXNPool8V42} from "../contracts/StrategyConvexFXNPool8V42.sol";
import {CurvePairOracleBoundsV6} from "../contracts/CurvePairOracleBounds_v6.sol";
interface VmV49 {
    function createSelectFork(string calldata) external returns (uint256);
    function envString(string calldata) external returns (string memory);
    function prank(address) external;
    function startPrank(address) external;
    function stopPrank() external;
    function load(address,bytes32) external view returns (bytes32);
    function store(address,bytes32,bytes32) external;
    function mockCall(address,bytes calldata,bytes calldata) external;
    function clearMockedCalls() external;
}
interface IFXStakingProxyV51Test { function withdraw(uint256) external; }
interface IRealCurveV49 {
    function get_dy(int128,int128,uint256) external view returns(uint256);
    function exchange(int128,int128,uint256,uint256) external returns(uint256);
    function price_oracle() external view returns(uint256);
    function calc_token_amount(uint256[2] calldata, bool) external view returns(uint256);
    function calc_withdraw_one_coin(uint256,int128) external view returns(uint256);
    function add_liquidity(uint256[2] calldata,uint256) external returns(uint256);
    function remove_liquidity_one_coin(uint256,int128,uint256) external returns(uint256);
}
contract CurveFXNGuardV51Fork {
    VmV49 constant vm=VmV49(address(uint160(uint256(keccak256("hevm cheat code")))));
    address constant SD=0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD;
    address constant FXN=0x365AccFCa291e7D3914637ABf1F7635dB165Bb09;
    address constant POOL=0x28Ca243dc0aC075dD012fCf9375C25D18A844d96;
    address constant ROUTER=0xA4a533025feF8d3446e7cB8A434824e1EE865b00;
    address constant BOOSTER=0xAffe966B27ba3E4Ebb8A0eC124C7b7019CC762f8;
    address constant SAFE=0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;
    address constant LIVE_GUARD=0x840fa8496e3B5Ac306281d5Bb5224fA08b5865F8;
    address constant WHALE=0xbcfE5c47129253C6B8a9A00565B3358b488D42E0;
    address constant FXN_WHALE=0x2290eeFEa24A6E43b26C27187742bD1FEDC10BDB;
    CurvePairOracleBoundsV6 internal bounds;
    StrategyConvexFXNPool8V42 internal child;
    IRealCurveV49 internal pool;
    event Shock(string direction,uint256 initialSpot,uint256 finalSpot,uint256 adverseBps);
    function setUp() public {
        vm.createSelectFork(vm.envString("ETH_RPC_URL"));
        require(POOL.code.length>0 && BOOSTER.code.length>0,"REAL_CONTRACTS_MISSING");
        pool=IRealCurveV49(POOL);
        require(LIVE_GUARD.codehash == 0xf019325f4f0bb9a1e27ab5a57aea9ea10331313cce1e8cf9cb8b71990a4c427f, "LIVE_GUARD_CODEHASH_MISMATCH");
        bounds=CurvePairOracleBoundsV6(LIVE_GUARD);
        child=new StrategyConvexFXNPool8V42(BOOSTER,POOL,FXN,
            BaseAllToWantBoostHubV5.Addresses(SD,address(this),ROUTER,SAFE),
            BaseAllToWantBoostHubV5.FeeSettings(1300,1000,9000),1 days,0);
        require(address(child.curveLiquidityGuard())==address(0),"GUARD_MUST_START_UNSET");
        child.setCurveLiquidityGuard(address(bounds));
        require(address(child.curveLiquidityGuard())==address(bounds),"GUARD_MISSING");
        require(child.CURVE_LP_SLIPPAGE_BPS()==75,"NOT_75_BPS");
    }
    function _fund(uint256 n) internal {vm.prank(WHALE);require(IERC20(SD).transfer(address(child),n),"FUND_FAILED");}
    function _stake(uint256 n) internal {_fund(n);child.deposit();require(child.lpBalance()>0,"STAKE_FAILED");}
    function _shockSdFXNLower() internal returns(uint256 bps) {
        uint256 base=pool.get_dy(1,0,1 ether);
        vm.startPrank(WHALE);IERC20(SD).approve(POOL,type(uint256).max);
        for(uint i;i<12;i++) {
            pool.exchange(1,0,100 ether,0);
            uint256 nowQuote=pool.get_dy(1,0,1 ether);
            bps=base>nowQuote?(base-nowQuote)*10000/base:0;
            if(bps>100){vm.stopPrank();emit Shock("sdFXN depegs from real swaps",base,nowQuote,bps);return bps;}
        }
        vm.stopPrank();revert("NO_ADVERSE_1_PERCENT_DEPOSIT_MOVE");
    }
    /// @dev Acquire real FXN from the real pool using funded sdFXN; no guessed ERC20 storage slots.
    function _forkFundFXN(uint256 n) internal {
        vm.prank(WHALE);
        require(IERC20(SD).transfer(address(this), n), "FXN_FUND_SD_SHORTFALL");
        IERC20(SD).approve(POOL, type(uint256).max);
        pool.exchange(1, 0, n, 0);
        require(IERC20(FXN).balanceOf(address(this)) >= 100 ether, "FXN_SWAP_TOO_SMALL");
    }
    function _shockSdFXNHigher() internal returns(uint256 bps) {
        _forkFundFXN(3000 ether);
        uint256 base=pool.get_dy(0,1,1 ether);
        IERC20(FXN).approve(POOL,type(uint256).max);
        for(uint i;i<12;i++) {
            pool.exchange(0,1,100 ether,0);
            uint256 nowQuote=pool.get_dy(0,1,1 ether);
            bps=base>nowQuote?(base-nowQuote)*10000/base:0;
            if(bps>100){emit Shock("sdFXN appreciates from real swaps",base,nowQuote,bps);return bps;}
        }
        revert("NO_ADVERSE_1_PERCENT_EXIT_MOVE");
    }
    function testLiveGuardQuote75Bps() public {
        (uint256 a,uint256 am)=bounds.quoteDeposit(POOL,1,1 ether,75);
        (uint256 b,uint256 bm)=bounds.quoteWithdraw(POOL,1,1 ether,75);
        require(a>0&&b>0&&am==a*9925/10000&&bm==b*9925/10000,"GUARD_QUOTES_INCORRECT");
    }
    function testBaselineRealPoolDepositAndWithdraw() public {
        _stake(20 ether);
        uint256 beforeLp=child.lpBalance();uint256 beforeWant=IERC20(SD).balanceOf(address(this));
        child.withdraw(2 ether);
        require(IERC20(SD).balanceOf(address(this))-beforeWant==2 ether,"SHORT_WITHDRAW");
        require(child.lpBalance()<beforeLp,"NO_LP_EXIT");
    }
    event GuardBreach(string direction, uint256 swaps, uint256 spotMoveBps, uint256 oracleMinOut, uint256 unguardedActual);

    /// @dev Dump sdFXN into the real Curve pool until the one-sided LP mint quote crosses the historical-oracle 75 bps floor.
    ///      Then prove that the same Curve call succeeds with minOut=0 and reverts through the actual strategy with guard minOut.
    function testRealLargeAdverseDepositCrosses75BpsFloorAndReverts() public {
        _fund(20 ether);
        uint256[2] memory a;
        a[1] = 20 ether;
        uint256 baselineSpot = pool.get_dy(1,0,1 ether);
        vm.startPrank(WHALE);
        IERC20(SD).approve(POOL,type(uint256).max);
        bool crossed;
        uint256 i;
        for (;i<80;i++) {
            pool.exchange(1,0,200 ether,0);
            (,uint256 floor)=bounds.quoteDeposit(POOL,1,20 ether,75);
            uint256 spotMint=pool.calc_token_amount(a,true);
            if (floor > spotMint && spotMint > 0) {crossed=true;break;}
        }
        vm.stopPrank();
        require(crossed,"DEPOSIT_BOUND_NEVER_BREACHED");
        (,uint256 guardMin)=bounds.quoteDeposit(POOL,1,20 ether,75);
        (bool ok,)=address(child).call(abi.encodeWithSignature("deposit()"));
        require(!ok,"GUARDED_DEPOSIT_SHOULD_REVERT");
        require(child.lpBalance()==0,"REVERT_DID_NOT_ROLLBACK_DEPOSIT");
        vm.prank(address(child));
        uint256 actual=pool.add_liquidity(a,0);
        uint256 nowSpot=pool.get_dy(1,0,1 ether);
        uint256 spotBps=baselineSpot>nowSpot?(baselineSpot-nowSpot)*10000/baselineSpot:0;
        require(actual > 0 && actual < guardMin,"UNGUARDED_DEPOSIT_NOT_BELOW_MIN");
        emit GuardBreach("deposit",i+1,spotBps,guardMin,actual);
    }

    /// @dev Shock with real FXN swaps, checking that a withdrawal with the deployed guard fails while a real Curve exit at zero minOut works.
    function _proveRealWithdrawBound(bool gaugeUnits) internal {
        _stake(100 ether);
        uint256 totalLp=child.lpBalance();
        require(totalLp>0,"NO_LP_STAKE");
        uint256 gaugeLp=totalLp/5;
        // Impersonate an independently funded real mainnet FXN holder. No reverse initial swap.
        vm.prank(FXN_WHALE);
        require(IERC20(FXN).transfer(address(this),8000 ether),"REAL_FXN_FUNDER_FAILED");
        uint256 baselineSpot=pool.get_dy(0,1,1 ether);
        IERC20(FXN).approve(POOL,type(uint256).max);
        bool crossed;
        uint256 i;
        for (;i<60;i++) {
            if (IERC20(FXN).balanceOf(address(this))<100 ether) break;
            pool.exchange(0,1,100 ether,0);
            (,uint256 minimum)=bounds.quoteWithdraw(POOL,1,gaugeLp,75);
            uint256 spot=pool.calc_withdraw_one_coin(gaugeLp,1);
            if (minimum>spot && spot>0){crossed=true;break;}
        }
        require(crossed,"WITHDRAW_BOUND_NEVER_BREACHED");
        (,uint256 guardMin)=bounds.quoteWithdraw(POOL,1,gaugeLp,75);
        (bool ok,)=address(child).call(abi.encodeWithSignature(
            gaugeUnits?"withdrawGaugeUnits(uint256)":"withdraw(uint256)",gaugeUnits?gaugeLp:10 ether
        ));
        require(!ok,"GUARDED_WITHDRAW_SHOULD_REVERT");
        require(child.lpBalance()==totalLp,"REVERT_DID_NOT_ROLLBACK_WITHDRAW");
        address personalProxy = address(child.convexVault());
        vm.prank(address(child));
        IFXStakingProxyV51Test(personalProxy).withdraw(gaugeLp);
        vm.prank(address(child));
        uint256 actual=pool.remove_liquidity_one_coin(gaugeLp,1,0);
        uint256 nowSpot=pool.get_dy(0,1,1 ether);
        uint256 bps=baselineSpot>nowSpot?(baselineSpot-nowSpot)*10000/baselineSpot:0;
        require(actual>0 && actual<guardMin,"UNGUARDED_WITHDRAW_NOT_BELOW_MIN");
        emit GuardBreach(gaugeUnits?"gauge exit":"withdraw",i+1,bps,guardMin,actual);
    }
    function testRealLargeAdverseGaugeExitCrosses75BpsFloorAndReverts() public {
        _proveRealWithdrawBound(true);
    }
    function testRealLargeAdverseStandardWithdrawCrosses75BpsFloorAndReverts() public {
        _proveRealWithdrawBound(false);
    }
    function testInvalidOracleFailsClosed() public {
        _fund(20 ether);
        vm.mockCall(POOL,abi.encodeWithSignature("price_oracle()"),abi.encode(uint256(0)));
        (bool ok,)=address(child).call(abi.encodeWithSignature("deposit()"));vm.clearMockedCalls();
        require(!ok,"BAD_ORACLE_ACCEPTED");require(child.lpBalance()==0,"BAD_ORACLE_STAKED");
    }
    function testOldQuoteIsNotUsedForLpMinimum() public {
        _fund(20 ether);uint256[2] memory amount;amount[1]=20 ether;
        vm.mockCall(POOL,abi.encodeWithSignature("calc_token_amount(uint256[2],bool)",amount,true),abi.encode(uint256(1)));
        (bool ok,)=address(child).call(abi.encodeWithSignature("deposit()"));vm.clearMockedCalls();
        require(ok,"STILL_USING_OLD_MINIMUM");require(child.lpBalance()>0,"NO_LP");
    }

    function testUnconfiguredGuardRevertsInsteadOfFallback() public {
        child.setCurveLiquidityGuard(address(0));
        _fund(20 ether);
        (bool ok,) = address(child).call(abi.encodeWithSignature("deposit()"));
        require(!ok,"GUARDLESS_DEPOSIT_DID_NOT_REVERT");
        require(child.lpBalance()==0 && IERC20(SD).balanceOf(address(child))==20 ether,
            "GUARDLESS_DEPOSIT_MUTATED_ASSETS");
    }
    function testGuardSetterRestrictedToMaster() public {
        vm.prank(WHALE);
        (bool ok,) = address(child).call(
            abi.encodeWithSignature("setCurveLiquidityGuard(address)",address(0))
        );
        require(!ok,"UNAUTHORIZED_GUARD_CHANGE");
        require(address(child.curveLiquidityGuard()) == address(bounds),"UNAUTHORIZED_GUARD_STATE");
    }
    function testGuardRequiredForWithdrawalAndGaugeMigration() public {
        _stake(50 ether);
        uint256 lpBefore=child.lpBalance();
        child.setCurveLiquidityGuard(address(0));
        (bool withdrawn,)=address(child).call(abi.encodeWithSignature("withdraw(uint256)",2 ether));
        (bool migrated,)=address(child).call(abi.encodeWithSignature("withdrawGaugeUnits(uint256)",lpBefore/5));
        require(!withdrawn && !migrated,"EXIT_BYPASSED_GUARD");
        require(child.lpBalance()==lpBefore,"UNGUARDED_EXIT_MUTATED_LP");
    }
}
