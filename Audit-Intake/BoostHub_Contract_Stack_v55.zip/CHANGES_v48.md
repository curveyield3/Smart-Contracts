# BoostHub Contract Stack v48 — CurveYield official dApp URLs

Documentation-only header correction from v47. The extended `CurveYield System Component` header now has a single dApp line, using the exact requested format:

`dApp: https://curveyield.com & https://curveyield.org`

Removed only the two obsolete `Documentation:` and `GitHub:` URL lines, and replaced `dApp: https://curveyield.online` with this one combined dApp line. All other description text and decentralized link references are preserved. The header was updated in the 10 first-party source files that already contained it:

- `contracts/BaseAllToWantBoostHubV5.sol`
- `contracts/BeefyVaultV7FixedV2.sol`
- `contracts/BoostHub.sol`
- `contracts/BoostHubStaking.vy`
- `contracts/ChildAPR15dV42.sol`
- `contracts/CurveYieldOmniRouter.sol`
- `contracts/StrategyBoostHubChildV42.sol`
- `contracts/StrategyConvexBoostHubStakingV5.sol`
- `contracts/StrategyConvexFXNPool8V42.sol`
- `contracts/StrategyDualFXNMasterV42.sol`

No files under `beefy-partner/` were edited. No operational Solidity or Vyper statements, imports, constructors, ABIs, storage, ownership conditions, allocation parameters, or economic logic were modified. Contract source file names were kept unchanged.
