# Compatibility review v1 — BoostHub v29 + Omni + official Beefy partner V7

## Source origin and boundaries

- Authoritative original archive: `BoostHub_Contract_Stack_v28(1).zip` supplied in this turn.
- Prior partner implementation source: v24 partner folder, now minimally revised as `StrategyConvexBoostHubPartnerV2.sol` and `BoostHubPartnerPairDeployerV2.sol`.
- Upstream Beefy V7/factory, fee, factory interface, and `BaseAllToNativeFactoryStrat.sol` remain otherwise unmodified, as represented in the partner folder.
- Original BoostHub Hub, Vyper staking, original custom vault, original custom strategy, Omni source, all reward accounting, and previously deployed converter source remain byte-identical to v28. Only the obsolete Fraxtal adapter source is deleted.

## Interface-level compatibility

| Component | Required interface | Exact present implementation | Finding |
| --- | --- | --- | --- |
| Beefy base -> Omni | `swap(address,address,uint256) returns (uint256)` | V28 `CurveYieldOmniRouter.swap` | Matches |
| Existing custom base -> Omni | `swap(address,address,uint256)` | Same V28 swap | Matches |
| Existing custom base -> Omni | `getAmountOut(address,address,uint256)` | V28 `getAmountOut` | Matches |
| Beefy base -> Omni | Approve underlying before `swap` | inherited `_swap` uses `forceApprove` | Matches `transferFrom` consumption |
| Official Beefy V7 -> strategy | `want`, `vault`, `balanceOf`, `beforeDeposit`, `deposit`, `withdraw`, `retireStrat` | inherited Beefy base plus BoostHub staking adapter | Matches |
| Beefy `IStrategyV7` compatibility | `unirouter()` | New V2 one-line getter returns inherited `swapper` | Matches |
| Partner strategy -> Vyper staking | `deposit(amount,address)`, `withdraw(amount)`, `harvest()`, `claim_rewards()`, `balanceOf(account)` | v28 `BoostHubStaking.vy` | Matches |
| Partner dynamic reward slots | `reward_count()` / `reward_tokens(index)` | v28 supports 9 (principal + 8) | V2 max upgraded from 8 to 9 |
| Partner unsupported rewards | `routeLength(token,native)` | v28 Omni `routeLength` | Excludes SDT/3Crv from inherited reward conversions; does not remove their Hub registration |
| Official V7 deployment | Vault clone + strategy clone + initializer | V2 helper `deployPair` | One helper transaction initializes both before control transfer |

## Ethereum mainnet on-chain observations (2026-11-14)

- Published Beefy V7 factory `0xC551dDCE8e5E657503Cd67A39713c06F2c0d2e97`: `instance()` -> `0xd2838c50e843aff1359011486b31697c2b1290dc` (implementation checked for code in deployment preflight).
- Published Beefy strategy factory `0x52941De3eDE234ae6B8608597440Ac3394C64Ae8`: `native()` -> WETH `0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2`; `beefyFeeConfig()` -> `0x3d38ba27974410679aff73abd096d7ba58870ead`; `globalPause()` -> false; `strategyPause("BoostHubStaking")` -> false; `keeper()` -> `0x4fed5491693007f0cd49f4614ffc38ab6a04b619`.
- Curve pool `0xCA0253A98D16e9C1e3614caFDA19318EE69772D0`: CRV->sdCRV `get_dy(0,1,1e18)` = 1.880464940477310531e18; EMA `price_oracle()` = 0.530465441563849103e18; reciprocal ~1.8851 sdCRV per CRV. Reverse spot `get_dy(1,0,1e18)` = 0.529126913751211596e18; EMA direct 0.530465... CRV/sdCRV. Hence 0→1 invert true, 1→0 invert false.
- Curve Tricrypto `0x4eBdF703948ddCEA3B11f675B4D1Fba9d2414A14`: crvUSD→CRV `get_dy(0,2,1e18)` = 4.411867663589385193e18; `price_oracle(1)` = 0.226384799212681602e18 (invert). crvUSD→WETH `get_dy(0,1,1e18)` = 0.000522123866066965e18; `price_oracle(0)` = 1913.010853161362311913e18 (invert).
- Curve TwoCrypto `0xC15F285679a1Ef2d25F53D4CbD0265E1D02F2A92`: WETH→FXN spot = 121.722092889501338716e18; EMA = 0.008139888347432664e18 (invert); FXN→WETH direct.
- FXN/sdFXN pool `0x28Ca243dc0aC075dD012fCf9375C25D18A844d96`: FXN→sdFXN spot = 0.994985492050558704e18; EMA 1.003021522430022806e18 (invert); reverse direct.
- For Uniswap V3, the exact v28 router's 300s historical tick quote handles token order automatically, so no manual oracle inversion is set. Selected CRV/WETH 0.3% and wstETH/WETH 0.05% pools had nonzero active liquidity in recent Ethereum queries.

## Deployment details and unresolved gates

1. The single script entrypoint `run()` supports chain ID 1 (Ethereum, 2 original pairs + 2 partner pairs) and chain ID 252 (Fraxtal, 1 original + 1 partner). It must be invoked on each chain, preserving the original same-sender Hub CREATE3 process. It does not make the two chains into a single on-chain transaction.
2. Fraxtal's `FRAX_BEEFY_STRATEGY_FACTORY.native`, fee-config and pause status, and historical Curve pool `0x3df1658e3E76d14eF3C4d410829EA7575bB83B9B` coin ordering/oracle were not independently read in this session, because no configured Fraxtal RPC was available. The deployment script makes these live read failures fatal **before** broadcast.
3. Beefy partner `callReward()` is deliberately unchanged (returns zero in official base). Nonzero caller-fee distribution must be set separately by authorized Beefy fee-config governance. The script records the fee category without claiming to set fees it does not control.
4. Omni source was not edited; existing native `swap` and quote methods are already present. Old converter/adapter are no longer involved in deployment, and no SDT/3Crv routes are created. Because the original reward registration is preserved, those unconfigured rewards will be deferred, not compounded.
5. All route adds use the existing `setRoute()` and `estimate_exact_output()` calls. Live fork swap and full Solidity compilation are still required before mainnet use. The environment did not provide a local Forge, Vyper or solc binary. No tests or deployments were run.
