# BoostHub Contract Stack v44 — enforce both Convex allocation gates for reserve top-ups

## Correction

The sdFXN two-child master strategy previously allowed an initial Convex minimum allocation whenever the price gate was satisfied, even if the child APR histories were not ready or Convex did not exceed BoostHub APR by 4 percentage points. This behavior violated the explicit *only deposit to Convex if both gates pass* condition and failed the real-deployed-contract Ethereum fork battle check.

In `contracts/StrategyDualFXNMasterV42.sol`, `_restoreMinima()` now computes `convexAllowed = convexEligible()` and only tops up the Convex minimum if that shared predicate is true. `convexEligible()` requires BOTH the historical-oracle price to exceed 0.969 FXN per sdFXN AND both child APRs to be ready AND Convex APR to exceed or equal BoostHub APR plus 4 percentage points.

No Convex deposits happen during initial APR bootstrap, when price is too low, or when APR advantage is below the threshold. In such states, new funds remain in the BoostHub child. Once both gates pass, Convex may be filled to the tier-specific reserve and receive the remaining deposits, as before. The minimum-per-child aspiration is subordinate to this strict eligibility condition.

Unchanged: withdrawal source preference at a >6pp BoostHub advantage, reserve floors of 1/0.1/0.01 sdFXN by TVL tier when eligible, the sdFXN vault withdrawal fee (0.45%), child performance fees (3%/13%), caller share (10% of fee), APR aggregation, seven-transaction deployment nonce fix, BoostHub and OmniRouter integration.

## Verification

- Source input: unmodified v43 `StrategyDualFXNMasterV42.sol` SHA256 `d23b728b02abe17695cd89abc759b1a3c6a4e4349a90983a6fc565d9be76a5c0`.
- v44 source SHA256: `e2108933e97fc16531ba77b98076d17e041ee77d84ff53585debb0c3ccd47347`.
- Existing adversarial fork tests have been updated to assert that the cold-start Convex reserve is zero; no production external integrations were changed.
- Real Ethereum contract addresses used by the fork runner: staking `0x55eb43C2112f7eD1127f7F313B17fF111F069217`, BoostHub `0x40f7085841034f752F17592875703EB5032f2B42`, OmniRouter `0xA4a533025feF8d3446e7cB8A434824e1EE865b00`, Curve `0x28Ca243dc0aC075dD012fCf9375C25D18A844d96`, Convex Booster `0xAffe966B27ba3E4Ebb8A0eC124C7b7019CC762f8`.

## Production deployment blocker still present

The live OmniRouter has no configured `sdFXN -> FXN` or `FXN -> sdFXN` route. Its existing contract functions and pool are suitable; the routes must be installed by the authorized owner on Ethereum mainnet and then independently read back. The fork tests configure them only in isolated fork state. The `sdFXS/FXS` routes are unrelated.

This correction does not resolve previously reported valuation, slippage, last-share fee accounting, or stale-APR edge-case risks. No production transactions were sent.
