# BoostHub v32 — eight approved source changes

## Approval mapping

| Recommendation | Implementation |
| --- | --- |
| Earlier round 1: fixed staking configuration | lp_token, boost_hub, and pid become public immutables; constructor ABI and getters remain. |
| Earlier round 2: standing staking allowance | Custom strategy approves the immutable staking contract at construction; per-deposit approval is removed. Router approvals remain exact. |
| Earlier round 3: one ramp-rate write | Daily checkpoint reads scheduled increase/decrease once and passes them into the existing step helper; rate assignment is combined. |
| Earlier round 4: ERC-20 success handling | All Vyper transfer/transferFrom/approve calls assert the result with default_return_value=True for missing-return tokens. Explicit false reverts. |
| Latest round 2: reward-list return | Existing user settlement returns its in-memory complete registry through harvest_and_claim(); custom harvest consumes it directly. |
| Latest round 3: import fast path | Existing reward_from_boosthub state skips registered Hub tokens. New/import-promoted tokens use the original registry membership helper. |
| Latest round 4: custom vault deposit accounting | Actual net incoming tokens determine new shares against pre-deposit NAV; successful staking still precedes minting. The post-staking full-NAV read is removed. |
| Latest round 5: harvest balance reuse | Swap processing carries the last measured want balance, and restaking consumes the actual post-fee balance already measured. |

## Scope and compatibility

Only the Vyper staking contract, custom strategy/base, custom vault, and custom staking interface change. No protected partner file, Hub implementation, OmniRouter, deployment script, dependency declaration, workflow, or build helper changes. No new implementation file or persistent reward/ramp ledger is added.

The public staking getter selectors remain. harvest_and_claim() retains its selector but now returns address[]; the v32 custom strategy must be deployed with this v32 staking ABI. The protected partner continues calling harvest() and claim_rewards(). The immutable conversion changes Vyper storage layout and is intended for fresh deployment, not an in-place proxy upgrade.

The latest round's sparse user-deposit list and manual gauge-refresh proposals are not implemented. The preliminary quote, exact router allowance, per-reward output minimum, original ramp snapshots/buffer, and separate deposit ages remain.

## Source-level accounting review

| Ledger or operation | Preserved invariant |
| --- | --- |
| Global ramp | Inactive units decrease by the old activation rate; new rate is old rate plus scheduled increase minus scheduled decrease, with the same checked arithmetic order. Snapshot and boundary ordering stay unchanged. |
| User reward settlement | Integral/Q baselines, maturity penalties, stored claims, and actual payment calculation are unchanged. Returning the registry introduces no additional accrual or transfer. |
| Reward imports | True Hub provenance implies an existing registry entry: every path setting it true registers or confirms the token first. Promotions retain the existing stream and disabled status. New registrations update count immediately so repeated inputs cannot add duplicate slots. |
| Token payment | Success retains the prior ledger transition; explicit false now rolls the entire transaction back rather than retaining unpaid claim/principal changes. |
| Custom vault | With an exact-value staking path, post-deposit NAV minus pre-deposit NAV equals the measured net receipt. Shares remain netReceipt for zero supply, otherwise floor(netReceipt * supply / preDepositNAV). Existing idle balances/donations enter the old NAV, not the incoming receipt. |
| Deposit fee | Net receipt is measured again after a nonzero fee transfer. Fees paid back to the vault therefore do not reduce credited receipt; fees sent elsewhere do. |
| Custom harvest | For each successful swap, output is actual ending want balance minus the previous measured balance. Each reward's fee and caller share retain separate floor rounding. A reverted swap rolls back its changes and leaves the balance baseline unchanged. |
| Fee payment and profit | Final want balance is measured after fee transfers, rather than inferred by subtracting nominal fees. This preserves a caller/admin receiver equal to the strategy. Only the actual increase above pre-claim idle want is profit-locked; the measured final balance is restaked. |

Custom vault receipt-based accounting relies on the fixed strategy/staking/Hub path crediting exact principal, and on standard non-rebasing underlying transfers. Harvest balance reuse likewise relies on standard tokens: approval/quote/failed-conversion paths do not independently change want. No protection or support for rebasing, transfer-tax, or callback-driven balance changes is claimed.

The returned registry includes all registered rewards, including external rewards and disabled tokens with deferred balances. It does not use only newly paid tokens. Zero and the staking contract's own address cannot be registered; the custom swap loop excludes want so principal is not converted. Existing reward views remain available without a stored strategy cache.

## Structural savings and validation limits

- One token approval call is removed per custom staking deposit/restake.
- The custom harvest no longer makes reward_count() plus N reward_tokens() calls to rediscover N registered tokens.
- The unchanged-registry import path avoids its local-registry copy and per-token membership searches. Several newly introduced rewards can incur more reward_count writes during their one-time import.
- One redundant rate assignment and repeated schedule reads are removed per processed daily boundary.
- Each attempted swap avoids its separate pre-swap want-balance read; successful swaps still measure actual received want. Profitable harvest restaking avoids another want-balance read.
- Custom deposit removes the final full-NAV query; nonzero deposit fees retain a simpler direct token-balance read for actual net-receipt accounting.
- The eight changes add no persistent cache. Returning the existing checkpoint token list does require a dynamic memory-array representation and return handling; net gas and bytecode effects have not been measured.

Review is limited to source diffs, call-site/ABI inspection, protected-file byte comparisons, relative import paths, and archive contents. No compilation, tests, simulations, gas benchmarks, deployment, or listing submission was performed. This review is not a runtime proof or independent audit certification.
