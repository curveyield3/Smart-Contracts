# Beefy partner system v4 — included in BoostHub unified deployment

No `runPartners` entrypoint. The only main entrypoint is `script/DeployBoostHubStack.s.sol::run()`; execute once on Ethereum and once on Fraxtal using the same sender/CREATE3 configuration as the existing deployment instructions.

Three supplemental Beefy V7 vaults are deployed under the existing staking contracts: Ethereum sdCRV/sdFXN and Fraxtal sdFXS. These are independent from, and do not replace, the three custom BoostHub vaults.

The strategy is derived from Beefy's `StrategyConvexStakingFraxtal.sol` and inherits the original `BaseAllToNativeFactoryStrat.sol`, using the exact BoostHub staking ABI. The original V7 vault and factory are unmodified. Atomic pair creation uses `BoostHubPartnerPairDeployerV4` as a helper contract called by the same main script. Each vault is cloned from Beefy's existing chain-specific on-chain V7 vault factory via `cloneVault()`. Each BoostHub partner strategy is deployed **independently** as `new StrategyConvexBoostHubPartnerV2()` and immediately initialized, on Ethereum and Fraxtal alike. No BeaconProxy registration or `createStrategy()` call is used, and no new vault/strategy factory is deployed. Beefy's existing strategy factory is retained as the provider of native token, keeper, fee configurator and global/type pause settings, not as a deployment dependency. The helper atomically creates and initializes each vault/strategy pair within the sole `run()` execution, and transfers administrative ownership only after both are initialized and bound.

The newly deployed `CurveYieldOmniRouter` is used for **both** vault systems. V28 Omni already implements Beefy's `swap(address,address,uint256)` and `getAmountOut(address,address,uint256)`, and its contract implementation was not edited. All supplied routes use historic same-pool Curve price oracles, with per-direction inversion, or 300-second V3 TWAPs. No SDT or 3Crv route is created. The original reward registrations remain in place and unsupported tokens are held/deferred.

The current BoostHub DAO owner receives initial ownership. Beefy's existing default fee category supplies a nonzero actual caller payout on Ethereum unless changed by the fee-config owner; an approved per-strategy category remains possible. The unchanged upstream `callReward()` view returns zero independently of live caller-fee configuration; this requires Beefy SAFU clarification. Our independently deployed partner strategies are not subject to Beefy's strategy beacon upgrades. Vault strategy replacements are still governed by the official V7 vault's owner-controlled `proposeStrat`/`upgradeStrat` and six-hour approval delay. DAO vault/strategy ownership may be handed to Beefy's official owners only after review and acceptance.

## To build (existing build process, no new tests)

```bash
npm install --prefix dependencies --no-audit --no-fund --ignore-scripts --package-lock=false
python -m pip install vyper==0.4.3
python tooling/make_staking_artifact.py
forge build --force
```

Verify the main deployment preflight and each route's historical-quote output before any production broadcast. On Fraxtal, confirm `0x3df1658e3E76d14eF3C4d410829EA7575bB83B9B` is actually WFRAX (coin0) and sdFXS (coin1); the deployment reverts before broadcasting if that assumption is false.
