// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IStrategyFactory {
    event ProxyCreated(string strategyName, address proxy);
    function createStrategy(string calldata _strategyName) external returns (address);
    function instances(string calldata _strategyName) external view returns (address);
    function getImplementation(string calldata _strategyName) external view returns (address);
    function native() external view returns (address);
    function keeper() external view returns (address);
    function beefyFeeRecipient() external view returns (address);
    function beefyFeeConfig() external view returns (address);
    function globalPause() external view returns (bool);
    function strategyPause(string calldata stratName) external view returns (bool);
}
