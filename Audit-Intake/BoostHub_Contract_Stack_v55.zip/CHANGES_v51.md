# v51 — External Curve guard: 75 bps

- Changed `CURVE_LP_SLIPPAGE_BPS` from 100 to **75**, for all three Convex child liquidity paths: LP deposit, exact-underlying withdrawal, and gauge-LP withdrawal/migration.
- The contract still uses the existing deployed `CurvePairOracleBoundsV6` guard via `quoteDeposit(...,75)` and `quoteWithdraw(...,75)`; the second return `minOut` is passed verbatim to Curve `add_liquidity` or `remove_liquidity_one_coin`.
- Guard remains configured after deployment by the master owner; no constructor guard address is required. Unconfigured guard fails closed.
- No changes to the original external guard, partner-protected Beefy files, master logic, APR/caps, or production dependencies.
- Updated the already authorized real Ethereum-fork test fixture to stress adverse pool swaps, verify rollback, and independently check that a zero-minimum direct Curve operation succeeds with less output than the live guard minimum.
- Guard tolerance is an LP/output-value bound, not a hard spot-price movement cap. Tests must demonstrate actual guard-minOut enforcement, not assert a specific fixed spot move always fails.

- **Verified:** GitHub Actions 43992532148 passed (10/10 mainnet-fork tests). Direct minOut comparisons at real-pool spot shifts of 1.95% deposit and 1.21% withdrawal/gauge exit caused reverts; minOut=0 comparator operations succeeded. Full numbers in `FORK_PROOF_v1.md`.
