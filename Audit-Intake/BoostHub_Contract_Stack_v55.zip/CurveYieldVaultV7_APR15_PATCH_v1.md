# Separate deployed CurveYieldVaultV7 source — 15-day APR patch (v1)

On-chain Ethereum CurveYieldVaultV7 (`0xdB6AA572243b9617C4b39FB20468843b2CB97bA5`) is NOT `BeefyVaultV7FixedV2.sol`. It has `estimatedTokenAprBps()` which delegates to its strategy and is not a 15-day realized return.

Apply the following changes to the original **unflattened** `contracts/src/CurveYieldVaultV7.sol` when redeploying that other implementation. Do NOT insert this as a replacement for the official Beefy V7 factory implementation; that would alter Beefy's independently maintained template.

1. In the `CurveYieldVaultV7` contract body, add the `APRSample`, `aprHistory`, `lastAPRCheckpoint`, `aprNext`, `aprCount`, `APR_WINDOW`, `APR_SNAPSHOT_INTERVAL`, and `APRNotReady()` declarations verbatim from `contracts/BeefyVaultV7FixedV2.sol`.
2. Add the five new functions `checkpointAPR`, `_checkpointAPR`, `getAPR`, `aprReady`, `rate`, and `_apr15d` verbatim from the modified custom vault, immediately following `getPricePerFullShare`.
3. In `deposit(uint256 amount)`, add `_checkpointAPR();` after the zero-amount guard and before `strategy.beforeDeposit()`, and again immediately following `_mint(msg.sender, shares);`.
4. In `withdraw(uint256 shares)`, call `_checkpointAPR();` after the zero-share guard and before computing the share redemption amount. After `want().safeTransfer(msg.sender, amount)`, reset `aprCount`, `aprNext`, and `lastAPRCheckpoint` to zero when `totalSupply() == 0`.
5. Keep `estimatedTokenAprBps()` untouched (it remains the strategy's estimate). `rate()` uses realized 15-day PPS growth instead.

This patch does NOT automatically modify an unavailable original source tree. Its applicability must be rechecked against the actual redeployment source, especially deployment constructor, strategy binding, and version. The attached local v34 package does not contain `CurveYieldVaultV7.sol`.
