# BoostHub Contract Stack v47 — Extended CurveYield description headers

Documentation-only change. Added the full unmodified extended CurveYield system description block (copied from `contracts/BoostHub.sol`) immediately after the SPDX line in the following four strategy-related source files:

- `contracts/StrategyDualFXNMasterV42.sol`
- `contracts/StrategyBoostHubChildV42.sol`
- `contracts/StrategyConvexFXNPool8V42.sol`
- `contracts/ChildAPR15dV42.sol` (shared APR-tracking strategy support)

All operational code, ABIs, storage layout, factory/deployment scripts, fee terms, staking contracts and vault contracts remain unchanged. No files under `beefy-partner/` were modified. Existing source file basenames and declared contract names are preserved.

Compilation verification: see accompanying GitHub Actions build record.
