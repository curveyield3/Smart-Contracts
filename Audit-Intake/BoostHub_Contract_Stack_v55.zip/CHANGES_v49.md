# v49 — External Curve oracle bounds, 1% tolerance

- The sdFXN Convex pool-8 child now takes **liquidityGuard** as the final constructor argument; the address MUST contain code. No silent fallback.
- All Curve LP deposits use `CurvePairOracleBoundsV6.quoteDeposit(pool, 1, sdFXNAmount, 100)` for `add_liquidity` minimum LP mint.
- All underlying and gauge-unit Curve exits use `CurvePairOracleBoundsV6.quoteWithdraw(pool, 1, lpAmount, 100)` for `remove_liquidity_one_coin` minimum sdFXN received.
- Removed the old 50-bps minimums derived from `calc_token_amount` and `calc_withdraw_one_coin`. The latter is still used only to size target LP redemption and account for held LP units.
- The guard source was supplied by the user and is preserved byte-for-byte (GPL-2.0-or-later). Its UniV3TickMath helper was not supplied; this package includes the narrow official Uniswap TickMath primitive with its GPL license.
- `script/DeployDualFXNPool8V42.s.sol::run` accepts a `liquidityGuard` address, checks guard code exists, and confirms a positive baseline historical-oracle LP quote before deploying the child.
- Foundry now autodetects solc for the 0.8.28 deployment script and 0.8.30 guard.
- Existing master APR/caps and BoostHub staking unchanged; Beefy partner contracts unchanged.

## Protection model
A **1% adverse deviation relative to the guard's historical-oracle LP estimate** causes the corresponding Curve min-output check to revert. This is not a symmetric guarantee that any absolute 1% price move in either direction reverts; favorable moves and oracle updates can still allow execution. The v6 guard advertises marginal estimates, not finite-trade execution simulations; large deposits can revert even when fair due to price impact. Verify mainnet-fork behavior before deploying the stack.
