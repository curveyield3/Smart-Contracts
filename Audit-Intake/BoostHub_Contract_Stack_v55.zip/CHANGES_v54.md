# CurveYield BoostHub Contract Stack v54 — Emergency sdFXN withdrawal

## Scope
- Added `emergencyWithdraw(uint256 shares, uint256 minAssetsOut)` and `emergencyWithdrawAll(uint256 minAssetsOut)` to `BeefyVaultV7FixedV2.sol`. These are permissionless for holders of the shares they burn. The caller sets an explicit minimum **net** sdFXN payout.
- Added vault-only `emergencyWithdraw(uint256 amount)` to `StrategyDualFXNMasterV42.sol`; it preserves the owner-weighted withdrawal order, unlocked-liquidity calculations, locked profit floor, and exact-asset liability. Only withdrawals routed through Convex use the alternate emergency child path.
- Added master-only `emergencyWithdraw(uint256 amount)` to `StrategyConvexFXNPool8V42.sol`. It deliberately bypasses `CurvePairOracleBoundsV6.quoteWithdraw()` and the corresponding oracle-based minimum output, using Curve's live `calc_withdraw_one_coin()` only to size LP redemption and `remove_liquidity_one_coin(..., 0)`.
- Kept the final exact amount requirement in Convex, master and vault, the usual vault withdrawal fee and 30/70 final-share fee distribution, ERC20 share burn and non-reentrancy protections, and APY update hook.
- Normal withdrawal, deposit, peg guard and guarded manual migration remain unchanged. No BoostHub or BoostHubStaking changes.

## Limitations and risk
- Emergency exit explicitly removes the oracle-derived minimum-output protection **only for the Convex sdFXN liquidity withdrawal**. Curve execution can occur at a worse rate, so a user should set `minAssetsOut`; however, this input checks the final user receipt, not maximum LP consumed. Exact requested underlying is still mandatory. An insolvent/illiquid pool or a failing Curve quote can still cause a revert.
- This release does not introduce a pro-rata loss-tolerant exit, a receipt-in-LP exit, or a global ability to bypass vault's other safeguards. These would be separate features and require separate review.
- Child and master contracts must be replaced in a coordinated deployment for the new selectors to be callable. Existing deployed contracts cannot acquire them without upgrading/redeploying.

## Verification
- Source edited from v53. Package contents/integrity inspected. No tests created, modified or executed (not authorized). Solidity compilation and deployment not performed or asserted.
