# CurveYield BoostHub Contract Stack v53 — Vault-only APY

## Scope
- **BeefyVaultV7FixedV2.sol**: Replace 16 daily + 5 recent historic APR samples with exactly 10 circular vault-level PPS samples. `updateAPY()` is permissionless, with a strict 12-hour minimum interval between stored observations. `getAPY()` reports compounded annualized share-price growth using the oldest retained sample and live PPS; its 1e18 output represents 100% APY. `apyReady()` and `apySample(index)` expose readiness and sample history. `rate()` remains for per-second integrations, and no public `getAPR()` exists. Observations are valid before all ten positions fill. Empty vault supply resets the usable history.
- Vault `deposit`, `withdraw`, and `earn` call best-effort `updateAPY()` checks after final accounting. `depositAll`/`withdrawAll` invoke those functions. Master `harvest` also attempts to invoke the vault updater so reward compounding is visible without requiring another vault transaction.
- **StrategyBoostHubChildV42.sol**, **StrategyConvexFXNPool8V42.sol**, **BaseAllToWantBoostHubV5.sol**: Remove child APR snapshot inheritance, internal APR units, and deposit/withdraw/harvest APR callbacks.
- **StrategyDualFXNMasterV42.sol**: Remove APR-based routing, child APR interface dependencies, and master APR selectors. Deposit allocations follow normalized weights from the existing owner-configured `setAllocationCaps` values, bounded by those same absolute caps; withdrawals prioritize whichever child exceeds its post-withdrawal target. Owner-directed migrations remain.
- **ChildAPR15dV42.sol**: Removed as obsolete.

## Unchanged execution safeguards
- New Convex deposits require the 0.969 FXN per sdFXN price gate and an existing external Curve oracle-liquidity guard; the price gate remains on owner-directed BoostHub->Convex migrations.
- Child Curve deposit and withdrawal execution retains the preexisting 75-bps minimum output haircut against the historic-oracle estimate, redemption headroom, and exact underlying withdrawal conditions.

## Review notes
- On-chain view functions cannot read historical state from arbitrary past blocks. This ring buffer relies on transactions invoking the update path; samples may be more than 12 hours apart, and missing observations cannot be synthesized.
- `getAPY()` clamps negative share-price growth to zero and saturates extraordinary positive APY at 1,000,000x 1e18. It is not a guaranteed future return.
- Zero-source or delayed valuation outcomes do not block vault actions: automatic update hooks are best effort and have gas checks. Manual `updateAPY()` uses the same timing gate.
- The original suite's legacy APR tests are **preserved untouched**. No tests were created, modified, or executed in this change. The new sources require normal compile/review before deployment.
