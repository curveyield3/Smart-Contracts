# BoostHub Contract Stack v35: 15-day realized vault APR

Based on uploaded v34. Modified only `contracts/BeefyVaultV7FixedV2.sol`; unchanged v34 deploy workflow, script, strategy, Vyper staking, Hub, Omni router, and protected official Beefy partner vault/strategy sources.

- Added a 16-entry ring of tightly packed timestamp/PPS observations, at most one per 24 hours.
- Permissionless `checkpointAPR()` plus opportunistic checkpoints on deposit/withdraw; the first deposit seeds a baseline; fully empty vault resets history.
- Added `getAPR()` (annualized simple historical 15-day PPS return, 1e18) and `rate()` (APR per second, 1e18, directly consumable by Euler IRM v2).
- Added `aprReady()`. `rate()` reverts until a sample 15 to 16 days before the last snapshot exists, and if the latest checkpoint is more than 2 days old. `getAPR()` returns 0 for unavailable data or nonpositive realized returns.
- Annualization uses actual elapsed time between observations, not assumed 15 days. No reward or price oracle changes.
- No new keeper workflow, offchain data service, ERC-4626 adapter, or fee modifications. Existing deployment path continues to create the custom vault.
- Full samples are taken at most once per day: maintain daily calls to checkpointAPR for uninterrupted live IRM rates, especially if deposits/withdrawals are sparse. No automatic checkpoint when strategy harvests externally.
- Extra source-bound note for different *already-deployed* `CurveYieldVaultV7` is supplied; it cannot be silently substituted for this local custom source.
- Official Beefy V7 clones from existing canonical factory do not gain this APR getter. They require a separate reader or a purpose-built customized implementation/factory, subject to listing compatibility approval.
- The first 15 days cannot provide a valid historical APR and must not be treated as zero collateral yield by the IRM.
- Security: share prices can change for non-yield reasons (fees, donations, accounting adjustments); historical return is not guaranteed future yield. Positive-only rate floors losses at zero.
- No compilation, simulation, or tests were executed in this packaging step.
