# BoostHub Contract Stack — Static Source Audit v26

**Baseline:** `BoostHub_Contract_Stack_v25.zip`  
**Result:** `BoostHub.sol` reorganized without changing executable code; all other contract/deployment sources retained from v25.  
**Assessment type:** Source-level code review, interaction analysis, gas-efficiency and maintainability review.  
**Not performed:** Compilation, tests, fuzzing, gas measurements, mainnet calls or deployment. Accordingly, no finding below is a claimed exploit reproduction or measured gas saving.

## Scope and change control

Sources reviewed:

- `contracts/BoostHub.sol` and `contracts/BoostHubStaking.vy`
- `contracts/BaseAllToWantBoostHubV5.sol`, `StrategyConvexBoostHubStakingV5.sol`, `BeefyVaultV7FixedV2.sol`
- `contracts/BoostHubEthereumRewardConverter_v4.sol`, `BoostHubFraxtalConverterAdapter_v1.sol`, `CurveYieldOmniRouter.sol`
- `contracts/BoostHubDeploymentFactory_v1.sol`, all six `contracts/interfaces/*.sol`, `contracts/libraries/BoostHubErrors.sol`
- vendored Solmate `CREATE3.sol`, `Bytes32AddressLib.sol`, the deployment script, dependencies manifest, Foundry config and Vyper artifact helper.

The approved work was **structural only** for `BoostHub.sol`: sections now follow imports/storage → events/errors → constructor/config → timelocks/fees → pools/allowlists → deposits/withdrawals → gauge harvesting → Merkle/URD claims → participant claims/sweep → governance/Snapshot → views → grouped internals. Declarations, storage field order and method bodies were preserved. In particular, **no change** was made to `emergencyStopRecoveryAndMigrate()`.

### Findings by severity and evidence standard

- **Confirmed:** The cited source implements the described behavior; no execution assumption is needed beyond standard EVM semantics.
- **Conditional:** The source creates the issue under stated conditions, e.g. a gauge with duplicate reward-token slots.
- **Integration/configuration:** Requires a selected router, deployed gauge, real oracle or runtime artifact to establish the operational consequence.
- **Optimization:** Candidate; gas reduction is not benchmarked, and its cost/complexity tradeoff must be considered.

## A. Highest-priority observations

### A1 — Locked-profit windfall to first new shareholder after supply reaches zero
**High · Confirmed accounting edge case**  
`BeefyVaultV7FixedV2.sol:71–93,108–131`; `BaseAllToWantBoostHubV5.sol:222–230`.

`strategy.balanceOf()` subtracts `lockedProfit()`, whereas the vault mints first shares using `shares = _amount` whenever `totalSupply() == 0`. If the previous last shareholder exits while locked profit remains, the visible asset balance may be zero although the strategy still holds locked underlying. The next depositor can mint at the 1:1 initial-share branch and, after lock expiry, benefit from the leftover rewards. This is not merely inefficient formatting. **Recommendation:** Agree an explicit final-shareholder/locked-profit ownership rule and correct the existing vault share-accounting path; do not add a second reward ledger.

### A2 — Gauge can be double-accounted if its reward-token slots repeat
**High when triggered · Conditional on gauge configuration**  
`BoostHub.sol:891–903,936–968,982–990`.

`_syncGaugeRewards` appends every nonzero `reward_tokens(i)` without deduplication. `_harvest` snapshots each array entry independently and attributes the same token balance delta once per slot. A gauge listing the same token twice can therefore inflate reserve liabilities and `accRewardPerShare`. **Recommendation:** Deduplicate reward tokens before measuring and attributing, if this condition must be supported. **Prior user decision:** this repair was previously denied; source was not modified.

### A3 — Empty-PID historical rewards can benefit the next staker
**High when triggered · Conditional, known design tradeoff**  
`BoostHub.sol:402–415,936–968`.

With auto-harvest disabled, an empty PID can retain gauge claimables. If a new staker deposits before those are claimed, the subsequent harvest attributes the old amount against the new `totalStaked`. The owner-sweep path applies only if rewards are actually claimed while staking is zero. **Prior user decision:** remediation was denied; unchanged.

### A4 — Nine-slot staking registry can exhaust and block future imports
**High to availability when triggered · Conditional configuration**  
`BoostHubStaking.vy:83–84,191–224,243–258,925–935,780–791`.

Hub reward imports, principal, and manually added external rewards use a common nine-slot registry. Once full, import of a newly discovered Hub reward reverts. The limit is bounded and documented; the blocking condition remains. **Prior user decision:** active repair was denied; unchanged.

### A5 — Irreversibly disabled Hub reward token may stop collection
**Medium–high · Confirmed state machine, contingent on later rewards**  
`BoostHubStaking.vy:960–973,793–812`.

`disable_reward` permanently sets `reward_disabled[token]` with no reactivation function. Harvesting excludes disabled tokens, but the Hub can receive them again. Historical user claims via staking still exist, but later Hub accrual is no longer pulled through normal staking harvesting. **Prior user decision:** repair was denied; unchanged.

### A6 — Omni-router cannot currently be built from the declared pinned dependencies
**Build blocker · Confirmed package configuration**  
`CurveYieldOmniRouter.sol:4`; `dependencies/package.json`; `foundry.toml`.

Router imports `@uniswap/v4-core/src/libraries/TickMath.sol`, but the ZIP does not include that source or declare/install `@uniswap/v4-core`; the existing remappings do not supply it. The full-stack Forge build has an unresolved import unless an unlisted external dependency happens to be installed. **Recommendation:** Add a pinned V4 Core dependency to the **existing** dependency manifest/build only; no new workflow.

### A7 — Configured omni-router is not `IBeefySwapperV2` compatible
**Integration blocker for that chosen converter · Confirmed selectors**  
`IBeefySwapperV2.sol:5–7`; `BaseAllToWantBoostHubV5.sol:173–185,195–202`; `CurveYieldOmniRouter.sol:350–390`.

Strategy calls `swap(address,address,uint256)` and, when the configured minimum is nonzero, `getAmountOut(address,address,uint256)`. The included omni-router exposes `easyswap(...)` and `estimate_exact_output(...)` instead. They are distinct selectors. **Deployment script currently uses the Ethereum converter/Fraxtal adapter**, so this issue is conditional on choosing the omni-router for a strategy. **Recommendation:** Implement the previously authorized compatibility adjustment only if/when that router is configured; do not assume these ABI names are interchangeable.

### A8 — Deployment economic settings are inconsistent with the previously requested 3%/5% performance fee
**Configuration discrepancy · Confirmed script constants**  
`script/DeployBoostHubStack.s.sol:90–98,299–305`.

`PERFORMANCE_FEE_BPS = 0`, `CALL_SHARE_BPS = 7000`, `ADMIN_SHARE_BPS = 3000`. These instantiate **zero** strategy performance fee and a **70% caller / 30% admin** split if later made nonzero, not a 3% performance fee with 5% of that fee to caller. The script labels them conservative audit-fork economics; this may be intentional for simulation. **Recommendation:** Confirm production economic parameters before using this script for a live deployment; avoid silently changing audit-fork settings.

### A9 — Ethereum strategy reward registry includes tokens with no default converter path
**Harvest-compounding limitation · Confirmed default route table**  
`script/DeployBoostHubStack.s.sol:354–363`; `BoostHubEthereumRewardConverter_v4.sol:96–102,445–460`.

The script lists rewards including `0x73968b9a...` and `0x6c3F90f0...`, while the four default converter routes cover only CRV, crvUSD, wstETH and crvUSD to specific destination tokens. Unrouted rewards are deferred by the strategy rather than compounded. **Recommendation:** Complete the route inventory for actual deployed rewards, or deliberately document which are excluded.

## B. BoostHub.sol — Gas, structure and accounting review

**B1 · Medium · Source optimization:** `BoostHub.sol:994–1007`. `_checkpoint` still traverses all registered tokens and reads per-user reward debt on each deposit, withdrawal and claim. This is the **single authoritative accumulator/debt model** and must be preserved. Zero-index early paths and caching may help, but an active-token bit alone is unsafe when the user's principal changes.

**B2 · Low–medium · Source optimization:** `BoostHub.sol:891–903,936–968`. Public `harvest` returns a full reward-token list; it performs a nested memory search to map gauge tokens to return indices. Up to eight gauge and nine total token slots means a bounded `8×9` comparison. Avoid introducing new mappings or persistent indexes to optimize this without measured benefit.

**B3 · Low · Expected, not an optimization request:** `BoostHub.sol:244–283` and `view pendingTransactions()`. Transaction execution scans configured pools to find pending fees; this is deliberately the **original simple scan** restored after the overcomplicated pending-PID registry was removed. It runs on infrequent administrator transactions. Do not reintroduce a second registry merely to remove this scan.

**B4 · Medium · Capacity edge:** `BoostHub.sol:852–891`. `addPoolsBatch` accepts up to nine supplied reward tokens, then appends the pool's deposit token if absent. Nine supplied non-asset tokens therefore exceed the nine-token combined limit and revert. This is not an exploitable overflow; it is a confusing boundary/API constraint. Preserve the user-approved nine-slot design unless capacity policy is revisited.

**B5 · Medium · Snapshot governance interface:** `BoostHub.sol:1083–1090`. `_snapshotSpaceId` copies the first 32 bytes of an arbitrary string without length validation. Overlong names sharing the first 32 bytes yield the same `spaceId`, and an empty string maps to zero. If actual Snapshot spaces are constrained to ≤32 bytes, this may be harmless, but the current function does not enforce that assumption. Consider a minimal length rule after verifying the registry's expected encoding.

**B6 · Low · Persistent authorization:** `BoostHub.sol` Snapshot approval/`isValidSignature` stores approved hashes permanently and has no revocation. That matches hash-based ERC-1271 authorization but can surprise reviewers. Document intended permanence or add a revocation policy only with explicit approval.

**B7 · Low · Source hygiene:** `BoostHub.sol` keeps some mixed terminology (`strategy` for any approved depositor, Merkle vs Stake DAO indexed claims, pool asset as reward). Readability was improved by section reordering, but names were **not** changed because public selectors and storage semantics were out of scope.

**B8 · Important preserved invariant:** `sweep()` computes `actualBalance − (stakerReserves + ownerReserves)` and may recover surplus *of the same ERC-20 contract* as an attributed reward. It does not permit sweeping the reserved quantity. `BoostHub.sol:576–587`. Changing this distinction would alter user-authorized behavior; no such edit was made.

**B9 · No action recommended:** The `MAX_REWARD_TOKENS` cap, tracked `_rewardTokenReserves`, `_ownerRewardReserves`, `approvedLockerRewardPidPlusOne` and per-user debt are not mutually redundant. They have different roles in reserve protection, direct claim attribution, and participant entitlements.

## C. BoostHubStaking.vy — Gas and code clarity

**C1 · Largest remaining gas candidate:** `BoostHubStaking.vy:488–516`. On an activation boundary requiring a snapshot, the contract iterates *all nine token slots* and writes nonzero cumulative `activation_integral_at` and `activation_reward_q_at`, even where several inactive tokens have the same plateau value as previous snapshots. This can generate repeated expensive storage operations. Eliminating nonzero plateau writes safely requires adapting historical lookup semantics. A simple active flag with no lookup change would underpay or miscalculate users who have not checkpointed. **Recommend design/measurement before implementation**, not a new parallel accounting system.

**C2 · Bounded but expensive:** `BoostHubStaking.vy:542–680`. User checkpoint walks 45 maturity buckets × four phases and, when necessary, historical values for each accrued token. v25 correctly narrows the expensive inner token loops to `accrued_indices`; retain it. Additional caching may help, but reward maturity formula integrity is more important than micro-optimizations.

**C3 · Medium gas:** `BoostHubStaking.vy:780–816`. Harvest imports all Hub reward tokens, selects eligible tokens, claims them in one transaction and schedules only nonzero outputs. This is significantly simpler than v22–v24 and uses trusted standard ERC-20 returned amounts. The initial full-token selection is still necessary to discover resumed tokens. Avoid owner-maintained active lists unless backed by a robust reactivation mechanism.

**C4 · Low gas:** `BoostHubStaking.vy:243–258,273–281`. Each newly imported Hub token uses a linear scan of the nine-slot local registry. Only occasional imports incur this cost, so a persistent membership mapping is unlikely to be an attractive trade-off without measurements.

**C5 · Low-to-medium safety review:** `BoostHubStaking.vy:679,699,883,904`. A few direct ERC-20 `transfer` and `transferFrom` calls ignore the returned `bool`; other transfers in the same contract assert success. The assumed certified-standard reward/principal tokens are expected to return true, so practical impact depends on the exact deployed tokens. Consistent success handling makes intent clearer and avoids false accounting with nonstandard tokens.

**C6 · Human readability:** The 45-day ramp slope and boundary constants are now named (good). `_mul_scale_down` is a specialized overflow-aware helper (retain); `_change_ramp_position` and `_checkpoint_user_current` are intricate but logically distinct. Add a worked accounting invariant/comment in a future documentation pass rather than creating competing calculators.

## D. Beefy strategy and vault contracts

**D1 · Medium gas:** `StrategyConvexBoostHubStakingV5.sol:78–106`. Every `_syncRewards()` call checks all staking tokens, disabled flags, and strategy balances for disabled tokens. It now skips rewriting the storage array if unchanged (good). The public `acceptedRewardTokens()` does two complete external-read passes (`:57–70`), which can be reduced to one pass if it becomes a frequent on-chain dependency; as a view it costs gas only for on-chain callers.

**D2 · Moderate gas / contract coupling:** `StrategyConvexBoostHubStakingV5.sol:46–52`. `_claim()` calls both `staking.harvest()` and `staking.claim_rewards()`, then refreshes the strategy's reward list. These are distinct required actions. If claiming already produces an authoritative array of newly paid tokens, it could reduce later token scanning, but the staking ABI currently does not expose that to the strategy; changing it would be more than formatting.

**D3 · Medium runtime gas:** `BaseAllToWantBoostHubV5.sol:152–191`. It reads the strategy's balance of every known reward token on harvest, even if most are dormant. A persistent active bit would require reliable reactivation. A transient per-harvest list or staking-return reuse would need an ABI redesign and benchmarking; no change made.

**D4 · Medium approval overhead:** `BaseAllToWantBoostHubV5.sol:214–218`. `_approveExact` reads `allowance` then conditionally zeroes and increases it. This is correct for the pinned OpenZeppelin 4 SafeERC20 line but costs an external read. Changing to persistent allowances would reduce gas but change spender trust. Avoid without explicit authorization.

**D5 · Low–medium:** `BaseAllToWantBoostHubV5.sol:111–150` has parallel `claim` and `_harvest` entry paths; both update profit locking, but only `_harvest` converts other reward tokens and reinvests. Their different purposes are material and should be documented. The permissionless `claim()` also uses `tx.origin` for fee recipient; this is an unusual composability convention, even if fees go to the origin EOA rather than the attacker by default.

**D6 · High · See A1:** `BeefyVaultV7FixedV2.sol` retains zero-supply locked-profit economics. In addition to accounting risk, `deposit` performs repeated `balance()` and `available()` calls around `earn` (`:79–93`), creating unavoidable external balance calls but some potential caching opportunities. Do not optimize away pre/post measurement needed for fee-on-transfer defenses without agreement.

**D7 · Low · Governance semantics:** `BeefyVaultV7FixedV2.sol:134–150` only lets the *current fee recipient*, rather than vault owner, propose/execute fee-recipient changes; an inaccessible fee-recipient wallet can lock rotation. This is a design choice, not inherently a defect.

## E. Reward converters

**E1 · Low · Dead code:** `BoostHubEthereumRewardConverter_v4.sol:317–336` contains `_quoteRoute()` using `get_dy()`, but active quote/protection paths invoke `_oracleQuoteRoute()`. The old routine appears unused. `ROUTE_RETENTION_BPS` and `RouteRateTooLow` also appear unused. Remove only after confirming no external tooling calls the selector (internal method is not externally callable).

**E2 · Medium · Owner misconfiguration:** `BoostHubEthereumRewardConverter_v4.sol:214–244` verifies route layout and indices but does **not** validate that each configured pool's indexed coin tokens match the claimed route sequence. Incorrect routes can produce wrong oracle conversions or swap failures. Add read-time/config-time validation only after checking Curve pool ABI variation; not every Curve pool exposes identical coin getters.

**E3 · Medium · Execution dependency:** `BoostHubEthereumRewardConverter_v4.sol:260–307` requires EMA `price_oracle()`/indexed support on each pool. The source does not establish that every supplied Ethereum mainnet pool currently offers those selectors. This is an availability/deployment-verification item, not a proven source exploit.

**E4 · Low gas:** The converter recomputes token decimals and per-hop EMA input/output values each quote (`:279–315`). A small in-memory cache for repeated intermediate tokens can cut external `decimals()` reads; avoid persistent decimals mappings until necessary.

**E5 · Fraxtal adapter expected overhead:** `BoostHubFraxtalConverterAdapter_v1.sol:60–85` makes two token transfers in each direction (strategy ↔ adapter ↔ converter), performs several balance checks and resets an allowance. This is deliberate ABI compatibility and exact-balance protection. The adapter supports only a single hardcoded route and a 0.2 WFRAX minimum; amounts below the threshold stay deferred until accumulation.

## F. Omni-router — Correctness and avoidable per-hop overhead

**F1 · High build priority:** The missing V4 Core `TickMath` import is described in A6.

**F2 · Medium gas:** `CurveYieldOmniRouter.sol:534–560` unconditionally executes `approve(spender,0)`, `approve(spender,amount)`, and `approve(spender,0)` for generic/Curve/Balancer/external hops. Given its zero-after-success policy, the first zero approval is normally redundant. Changing this should preserve the selected zero-allowance security policy and be reviewed for unusual token behavior.

**F3 · Medium gas:** `CurveYieldOmniRouter.sol:520–532` reads both input and output token balances before and after every hop. These four reads support fully-spent-input and positive-output invariants. Replace only where a supported standard token/pool gives equally trustworthy net settlement; do not globally discard checks for minimal gas savings.

**F4 · Conditional very high gas:** `CurveYieldOmniRouter.sol:588–598` makes a separate Balancer V2 Vault `swap()` per hop. Adjacent hops against the same Vault could be grouped with `batchSwap()` and net settlement, saving intermediate transfers; this would increase route-runner complexity and requires actual multi-Balancer routing demand.

**F5 · Medium availability:** `CurveYieldOmniRouter.sol:713–790` depends on owner-configured external historical oracles and pool fee assumptions. Unavailable, unsuitable or mis-decimalized oracles can revert valid swaps. An oracle's mere 18-decimal return is not proof that it measures the correct token pair. This is chiefly an owner-configured integration boundary.

**F6 · Medium feature constraint:** `CurveYieldOmniRouter.sol:402–465` checks both endpoint token contracts have code and forbids zero addresses, so native ETH cannot be an endpoint or intermediate route token. The router supports wrapped-token routes; do not describe it as fully native-ETH capable without changing this deliberate restriction.

**F7 · Low readability:** The router's compact no-space formatting, dense inline guards, and mixed pool-type setup and execution logic are harder to audit than the reorganized Hub. A separate formatting-only pass would improve readability; no router source was changed in v26.

## G. Deployment and supporting sources

**G1 · Deployment assumptions:** `script/DeployBoostHubStack.s.sol:288–316` predicts the vault address using broadcaster nonce + 1. The contract enforces a mismatch revert, which is useful, but the exact Forge broadcaster semantics require verification in the intended deployment environment. No live simulation was performed.

**G2 · Comments inconsistent with code:** Deployment script around `:188–191` says BoostHub handles proof verification; current BoostHub delegates proof validation to the configured distributor and measures the resulting token balance. Change the comment in the later documentation pass.

**G3 · Vendor libraries:** `BoostHubDeploymentFactory_v1.sol:8–13` is compact and reuses Solmate `CREATE3.deploy`/`getDeployed` with caller-scoped salts. `dependencies/solmate/src/utils/CREATE3.sol` and `Bytes32AddressLib.sol` have no local functional modifications requiring cleanup. Avoid editing vendored source without a demonstrated operational defect.

**G4 · Interface/library hygiene:** `IStakeDaoGauge.sol` and `IvlBoost.sol` declare methods not used by this stack; interface-only declarations do **not** produce recurring swap/harvest gas costs. `BoostHubErrors.sol` includes names whose references appear absent (`CheckpointFailed`, `CheckpointSelectorNotSet`, `NothingToClaim`, `InvalidSnapshotSpace`, `InvalidLockedCall`). These are low-risk readability cleanup candidates, not worthwhile runtime gas optimizations.

**G5 · Build:** The provided `.github/workflows/boosthub-build.yml` compiles but does not run tests. Buildability is unverified locally due to absent compiler toolchains and the V4 import dependency. No new workflow, test or infrastructure was created.

## Recommended next steps (not implemented)

| Priority | Target | Reason | Complexity |
|---|---|---|---|
| P0 | Missing V4 dependency | Full-stack compilation blocker | Low |
| P0 | Vault terminal-supply locked-profit ownership | Potential shareholder windfall | Medium, economic policy needed |
| P1 | Production fee constants | Deployed economics differ from requested settings | Low, deployment decision |
| P1 | Unrouted rewards | Deferred compounding/operational surprise | Configuration |
| P1 | Confirm router ABI before strategy integration | Different function selectors | Low interface edit, integration check |
| P2 | Dormant-token nonzero snapshot compression | Largest unaddressed staking write cost | High, historical lookup semantics |
| P2 | Router repeated approval/balance operations | Frequent per-hop gas overhead | Low–medium |
| P3 | Converter dead helpers / Vyper interface hygiene | Smaller bytecode, clearer review | Low |
| P3 | Router formatting-only pass | Human-review readability | Low |

**Prior restrictions respected:** Findings that were earlier explicitly rejected (empty-PID pre-harvest settlement, gauge-token deduplication, reward-capacity modification, re-enabling disabled rewards and emergency migration changes) were **not** implemented. This report records their present behavior for completeness without overriding those decisions.
