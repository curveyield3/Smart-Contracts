# BoostHub Contract Stack v45 — Owner migrations + APR-first allocation caps

## Scope

This is the direct successor to the previously fork-verified v44 source. The sdFXN dual master and the Convex pool-8 child are the only changed Solidity contracts. The original sdFXN staking system, OmniRouter, vault, economics, and existing Ethereum deployment scripts are retained.

## Two position caps

- Owner sets `setAllocationCaps(uint16 boostBps, uint16 convexBps)`, basis points (10,000 = 100%).
- Defaults: **9,900 (99%)** for BoostHub and **9,900 (99%)** for Convex.
- Each cap must be <= 10,000; combined caps must sum to **at least 10,000**.
- Set `(10000,10000)` to effectively remove position allocation restrictions, without disabling the APR/price qualification logic.
- Caps limit **additional allocations**, not existing positions when profits accrue or an owner tightens a cap; no compulsory forced unwind occurs.
- The percentage denominator is **gross sdFXN vault assets**, including both child strategies' time-locked profits, master idle sdFXN (including retained vault fees), and vault idle sdFXN; it does not double-count master locked profits. Each position's size also includes its own time-locked profits.
- Query `allocationHeadroom()` to see the available headroom in sdFXN base units for each child and the gross TVL used.

## APR-first deposits

1. The master calls the original `convexEligible()` condition: both APR histories ready, `sdFxnToFxnWad() > 0.969e18`, and `convexAPR >= boostAPR + 0.04e18`.
2. If qualified, invest new unlocked sdFXN into Convex **up to its cap**; place remaining unlocked sdFXN into BoostHub, up to its cap. The next deposit increases vault TVL and thus unlocks more position headroom if the cap allows.
3. If not qualified, invest unlocked sdFXN into BoostHub, up to its cap. **Never bypass the Convex APR/price qualification to fill Convex's cap.** If BoostHub is full, excess stays idle, fully accounted, and may be invested later with a new deposit or `rebalanceAllocations()`.
4. Removed all old 1/0.1/0.01 sdFXN child-minimum reserve requirements, automatic top-ups and the former `rebalanceMinima` API. No child is required to hold a nominal balance.
5. Withdrawals retain the prior +6-percentage-point BoostHub APR preference for selecting Convex as the first withdrawal source; the low-BoostHub-balance fallback now uses actual liquidity rather than a fictional minimum.

## Owner-controlled migration

`migrate(bool fromConvex, uint256 sourceUnits)` is owner-only, non-reentrant, atomic, and **moves exactly the requested source staking units** (no percent interpretation):

- `fromConvex = false`: `sourceUnits` is sdFXN staked in the BoostHub child, **18 decimals**. Withdraw from BoostHub and reinvest received sdFXN into the Convex pool-8 child. Requires the 0.969 FXN/sdFXN price floor and sufficient Convex allocation headroom.
- `fromConvex = true`: `sourceUnits` is **Curve FXN/sdFXN LP gauge token units**, **18 decimals**, staked by the actual Convex pool-8 proxy, **not** sdFXN units. The convex child calls `convexVault.withdraw(gaugeLpUnits)`, removes exactly those LP units from Curve through the single-coin sdFXN exit (0.5% slippage guard), and transfers only the newly received sdFXN to the master, which invests it in the BoostHub child. Requires sufficient BoostHub allocation headroom.
- Migration checks destination cap **before and after** reinvestment. All unstaked sdFXN in the master remains untouched by the migration. Underlying returned from a Curve single-sided LP exit may differ from input LP units due to pool accounting/fees.
- Manual owner migration intentionally bypasses the **automatic** APR selection preference, so the owner can seed the Convex child before it has the historical samples required to report a valid APR. This does **not** bypass the Convex price floor or either allocation cap. Automatic deposits always use the strict APR gate.
- Neither migration can withdraw locked profits through a child that lacks sufficient unlocked value. An exit failure or violated cap reverts atomically; no partial migration is committed.

## Compatibility / operational notes

- The existing `DeployDualFXNPool8V42.s.sol` creates the new v45 master and convex child using the same nonce sequence (no additional deployment transactions). The original contract filenames and names are retained to minimize changes to imports and the known deployment tooling.
- Owner of the master after deployment remains the configured fee receiver `0x47623C62f281807D615eeb4A2CEee9d97F9D3C49`.
- The master address is immutable inside the deployed children and vault; **v45 is a new deployment**, not an upgrade to already deployed v44 contracts.
- The live Ethereum OmniRouter still requires FXN <-> sdFXN routes. The prior mainnet fork simulated those routes without modifying production.

## Verification

The v45 master and Convex-child Solidity sources **compiled successfully** with Solc 0.8.28 and optimizer on the existing isolated Foundry build runner. Compilation was confirmed via source-hash checks against the exact delivered contracts and a successful GitHub Actions run: https://github.com/curveyield3/Audit-Controller/actions/runs/43975851865 . The runner compiled only production sources; it **did not create, edit, or execute tests**. The previously authorized v44 fork tests do not establish safety or correctness of the new v45 cap and migration behavior. No v45 fork simulation or mainnet deployment was performed.
