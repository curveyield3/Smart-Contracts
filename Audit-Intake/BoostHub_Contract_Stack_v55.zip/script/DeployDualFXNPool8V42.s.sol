// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

// Ethereum-only V42 deployment. Extends an existing v41 BoostHub staking
// instance; does not redeploy Hub, OmniRouter or alter old vault balances.
import {BaseAllToWantBoostHubV5} from "../contracts/BaseAllToWantBoostHubV5.sol";
import {StrategyBoostHubChildV42} from "../contracts/StrategyBoostHubChildV42.sol";
import {StrategyConvexFXNPool8V42} from "../contracts/StrategyConvexFXNPool8V42.sol";
import {StrategyDualFXNMasterV42, IYieldChildV42} from "../contracts/StrategyDualFXNMasterV42.sol";
import {BeefyVaultV7FixedV2} from "../contracts/BeefyVaultV7FixedV2.sol";
import {IStrategyBoostHubV1} from "../contracts/interfaces/IStrategyBoostHubV1.sol";

interface VmDualFXNV42 {
    function getNonce(address) external view returns (uint64);
    function computeCreateAddress(address,uint256) external pure returns (address);
    function startBroadcast() external;
    function stopBroadcast() external;
}
interface IBoostHubDualV42 {
    function isApprovedDepositor(uint256,address) external view returns (bool);
}
interface IStakingDualV42 {
    function lp_token() external view returns (address);
    function boost_hub() external view returns (address);
    function pid() external view returns (uint256);
}
interface ICurvePoolDualV42 {
    function coins(uint256) external view returns (address);
}

contract DeployDualFXNPool8V42 {
    VmDualFXNV42 private constant vm = VmDualFXNV42(address(uint160(uint256(keccak256("hevm cheat code")))));
    address private constant SDFXN = 0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD;
    address private constant FXN = 0x365AccFCa291e7D3914637ABf1F7635dB165Bb09;
    address private constant CURVE_FXN_SDFXN = 0x28Ca243dc0aC075dD012fCf9375C25D18A844d96;
    address private constant FX_CONVEX_BOOSTER = 0xAffe966B27ba3E4Ebb8A0eC124C7b7019CC762f8;
    address private constant FEE_RECEIVER = 0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;

    event NewDualVault(address indexed vault, address indexed master, address indexed boostChild, address convexChild);

    /// @param staking Existing v41 Ethereum sdFXN staking (BoostHub PID 1), authorized as depositor.
    /// @param hub The existing Ethereum BoostHub.
    /// @param router Existing OmniRouter with sdFXN->FXN and FXN->sdFXN routes.
    /// @param broadcaster EOA supplied as --sender, required for CREATE nonce prediction.
    /// @param liquidityGuard Optional already-deployed V6 guard (zero defers configuration).
    function run(address staking, address hub, address router, address broadcaster, address liquidityGuard)
        external returns (address master, address boostChild, address convexChild, address vault)
    {
        require(block.chainid == 1, "ETHEREUM_ONLY");
        require(staking.code.length > 0 && hub.code.length > 0 && router.code.length > 0, "MISSING_DEPLOYED_STACK");
        require(broadcaster != address(0), "INVALID_BROADCASTER");
        require(liquidityGuard == address(0) || liquidityGuard.code.length != 0, "INVALID_CURVE_GUARD");
        if (liquidityGuard != address(0)) {
            (, uint256 minLpOut) = ICurveLiquidityBoundsFXNV49Deploy(liquidityGuard).quoteDeposit(
                CURVE_FXN_SDFXN, 1, 1 ether, 100
            );
            require(minLpOut > 0, "CURVE_GUARD_NOT_READY");
        }
        require(IStakingDualV42(staking).lp_token() == SDFXN
            && IStakingDualV42(staking).boost_hub() == hub
            && IStakingDualV42(staking).pid() == 1, "WRONG_STAKING_POOL");
        require(IBoostHubDualV42(hub).isApprovedDepositor(1,staking), "STAKING_NOT_APPROVED");
        require(ICurvePoolDualV42(CURVE_FXN_SDFXN).coins(0) == FXN
            && ICurvePoolDualV42(CURVE_FXN_SDFXN).coins(1) == SDFXN, "WRONG_CURVE_POOL");
        require(StrategyDualFXNMasterV42Check.oracleRoutesReady(router, SDFXN, FXN), "OMNI_ROUTER_ROUTES_MISSING");

        // Before the vault: three broadcaster CREATE transactions (master, BoostHub child,
        // Convex child) plus one broadcaster CALL (master.configureChildren).
        // Thus the vault is created at broadcaster nonce + 4, not + 3.
        // The Convex booster.createVault() call occurs inside the Convex child's
        // constructor transaction and does not consume another broadcaster EOA nonce.
        address predictedVault = vm.computeCreateAddress(broadcaster, vm.getNonce(broadcaster) + 4);
        vm.startBroadcast();
        master = address(new StrategyDualFXNMasterV42(predictedVault, SDFXN, FXN, router));
        BaseAllToWantBoostHubV5.Addresses memory bindings = BaseAllToWantBoostHubV5.Addresses({
            want: SDFXN, vault: master, swapper: router, adminFeeReceiver: FEE_RECEIVER
        });
        BaseAllToWantBoostHubV5.FeeSettings memory boostFees = BaseAllToWantBoostHubV5.FeeSettings({
            totalPerformanceFeeBps: 300, callShareBps: 1000, adminShareBps: 9000
        });
        boostChild = address(new StrategyBoostHubChildV42(staking, bindings, boostFees, 1 days, 0));
        BaseAllToWantBoostHubV5.FeeSettings memory convexFees = BaseAllToWantBoostHubV5.FeeSettings({
            totalPerformanceFeeBps: 1300, callShareBps: 1000, adminShareBps: 9000
        });
        convexChild = address(new StrategyConvexFXNPool8V42(
            FX_CONVEX_BOOSTER, CURVE_FXN_SDFXN, FXN,
            bindings, convexFees, 1 days, 0
        ));
        StrategyDualFXNMasterV42(master).configureChildren(IYieldChildV42(boostChild), IYieldChildV42(convexChild));
        vault = address(new BeefyVaultV7FixedV2(
            IStrategyBoostHubV1(master), "CurveYield sdFXN", "cysdFXN", 45, FEE_RECEIVER
        ));
        require(vault == predictedVault, "VAULT_NONCE_MISMATCH");
        require(address(BeefyVaultV7FixedV2(vault).strategy()) == master, "VAULT_NOT_BOUND");
        require(StrategyDualFXNMasterV42(master).vault() == vault, "MASTER_NOT_BOUND");
        require(StrategyBoostHubChildV42(boostChild).vault() == master
            && StrategyConvexFXNPool8V42(convexChild).vault() == master, "CHILDREN_NOT_BOUND");
        require(StrategyConvexFXNPool8V42(convexChild).totalPerformanceFeeBps() == 1300, "CONVEX_FEE_WRONG");
        // Configure after deployment, before ownership handoff.  This CALL is
        // deliberately after the predicted vault CREATE, preserving its nonce.
        if (liquidityGuard != address(0)) {
            StrategyDualFXNMasterV42(master).setConvexCurveLiquidityGuard(liquidityGuard);
            require(address(StrategyConvexFXNPool8V42(convexChild).curveLiquidityGuard()) == liquidityGuard,
                "CURVE_GUARD_NOT_SET");
        }
        BeefyVaultV7FixedV2(vault).transferOwnership(FEE_RECEIVER);
        StrategyDualFXNMasterV42(master).transferOwnership(FEE_RECEIVER);
        emit NewDualVault(vault, master, boostChild, convexChild);
        vm.stopBroadcast();
    }
}

interface IDualRouterV42 {
    function getAmountOut(address from, address to, uint256 amount) external view returns (uint256);
}

library StrategyDualFXNMasterV42Check {
    function oracleRoutesReady(address router, address sdFxn, address fxn) internal view returns (bool) {
        try IDualRouterV42(router).getAmountOut(sdFxn, fxn, 1e18) returns (uint256 amount) {
            if (amount == 0) return false;
            try IDualRouterV42(router).getAmountOut(fxn, sdFxn, 1e18) returns (uint256 reverse) {
                return reverse != 0;
            } catch { return false; }
        } catch { return false; }
    }
}

interface ICurveLiquidityBoundsFXNV49Deploy {
    function quoteDeposit(address pool, uint8 coinIndex, uint256 amount, uint16 slippageBps)
        external view returns (uint256 estimate, uint256 minOut);
}
