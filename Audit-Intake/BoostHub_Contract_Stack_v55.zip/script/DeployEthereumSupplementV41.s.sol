// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

// Ethereum-only supplement for EXISTING BoostHub and OmniRouter installations.
// Fresh staking/strategy/vault instances are deployed; existing contracts and
// their pool accounting, depositor approvals, routes, and ownership are preserved.
import {IBoostHub} from "../contracts/interfaces/IBoostHub.sol";
import {BaseAllToWantBoostHubV5} from "../contracts/BaseAllToWantBoostHubV5.sol";
import {StrategyConvexBoostHubStakingV5} from "../contracts/StrategyConvexBoostHubStakingV5.sol";
import {BeefyVaultV7FixedV2} from "../contracts/BeefyVaultV7FixedV2.sol";
import {IStrategyBoostHubV1} from "../contracts/interfaces/IStrategyBoostHubV1.sol";

interface VmEthereumSupplementV41 {
    function readFile(string calldata path) external view returns (string memory);
    function parseJsonBytes(string calldata json, string calldata key) external pure returns (bytes memory);
    function parseJsonString(string calldata json, string calldata key) external pure returns (string memory);
    function parseJsonBytes32(string calldata json, string calldata key) external pure returns (bytes32);
    function getNonce(address account) external view returns (uint64);
    function computeCreateAddress(address deployer, uint256 nonce) external pure returns (address);
    function startBroadcast() external;
    function stopBroadcast() external;
}

interface IBoostHubOwnerSupplementV41 {
    function owner() external view returns (address);
    function isApprovedDepositor(uint256 pid, address depositor) external view returns (bool);
    function setApprovedDepositors(uint256 pid, address[] calldata depositors, bool[] calldata approvals, bool lockList) external;
}

interface IStakingSupplementV41 {
    function lp_token() external view returns (address);
    function boost_hub() external view returns (address);
    function pid() external view returns (uint256);
    function admin() external view returns (address);
    function fee_receiver() external view returns (address);
    function reward_smoothing_units() external view returns (uint256);
    function name() external view returns (string memory);
}

/// @notice Redeploys the two Ethereum custom staking/vault systems without touching the existing Hub/Router.
/// @dev Pass verified live hub/router addresses and broadcast with --sender equal to the Hub owner.
///      The same sender must sign all transactions in the broadcast; nonce-linked strategy/vault
///      deployments will revert if a different signer is used. No private key is embedded.
contract DeployEthereumSupplementV41 {
    VmEthereumSupplementV41 private constant vm =
        VmEthereumSupplementV41(address(uint160(uint256(keccak256("hevm cheat code")))));

    address private constant SDCRV = 0xD1b5651E55D4CeeD36251c61c50C889B36F6abB5;
    address private constant SDFXN = 0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD;
    address private constant ADMIN_AND_FEES = 0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;
    uint16 private constant PERFORMANCE_FEE_BPS = 300;
    uint16 private constant CALL_SHARE_BPS = 1000; // 10% of the 3% performance fee
    uint16 private constant ADMIN_SHARE_BPS = 9000;
    uint256 private constant SMOOTHING_UNITS = 150; // 15 days; distinct from vault profit unlock
    uint256 private constant PROFIT_UNLOCK = 1 days;

    event NewStaking(uint256 indexed pid, address indexed staking);
    event NewStrategyVault(uint256 indexed pid, address indexed strategy, address indexed vault);

    function run(address hub, address router) external returns (address[2] memory staking, address[2] memory strategies, address[2] memory vaults) {
        require(block.chainid == 1, "ETHEREUM_ONLY");
        require(hub.code.length != 0 && router.code.length != 0, "LIVE_HUB_ROUTER_REQUIRED");
        require(SDCRV.code.length != 0 && SDFXN.code.length != 0, "STAKING_ASSETS_MISSING");
        address broadcaster = msg.sender;
        require(IBoostHubOwnerSupplementV41(hub).owner() == broadcaster, "BROADCASTER_MUST_OWN_HUB");

        string memory artifact = vm.readFile("artifacts/staking.json");
        require(vm.parseJsonBytes32(artifact, ".sourceSha256") == sha256(bytes(vm.readFile("contracts/BoostHubStaking.vy"))), "STAKING_SOURCE_MISMATCH");
        require(keccak256(bytes(vm.parseJsonString(artifact, ".compilerVersion"))) == keccak256("0.4.3"), "STAKING_COMPILER_MISMATCH");
        bytes memory creation = vm.parseJsonBytes(artifact, ".bytecode");
        require(creation.length > 1000, "INVALID_STAKING_BYTECODE");

        address[2] memory assets = [SDCRV, SDFXN];
        string[2] memory stakingNames;
        stakingNames[0] = "CurveYield Boosthub sdCRV Staking";
        stakingNames[1] = "CurveYield Boosthub sdFXN Staking";
        string[2] memory vaultNames;
        vaultNames[0] = "CurveYield sdCRV";
        vaultNames[1] = "CurveYield sdFXN";
        string[2] memory vaultSymbols;
        vaultSymbols[0] = "cysdCRV";
        vaultSymbols[1] = "cysdFXN";
        uint256[2] memory withdrawalFees = [uint256(35), uint256(45)];

        // Verify both pool identities BEFORE broadcasting. Do not assume the PID order on an arbitrary Hub.
        IBoostHub.PoolView[2] memory pools;
        for (uint256 pid; pid < 2; ++pid) {
            pools[pid] = IBoostHub(hub).poolInfo(pid);
            require(pools[pid].asset == assets[pid] && pools[pid].active, "UNEXPECTED_HUB_POOL");
            require(!pools[pid].depositorLocked, "HUB_ALLOWLIST_PERMANENTLY_LOCKED");
        }

        vm.startBroadcast();
        for (uint256 pid; pid < 2; ++pid) {
            address[8] memory rewards;
            uint256 count;
            for (uint256 j; j < pools[pid].rewardTokens.length; ++j) {
                address reward = pools[pid].rewardTokens[j];
                if (reward == assets[pid]) continue;
                require(count < 8, "TOO_MANY_POOL_REWARDS");
                rewards[count++] = reward;
            }
            bytes memory initCode = abi.encodePacked(creation, abi.encode(
                assets[pid], hub, pid, ADMIN_AND_FEES, rewards, ADMIN_AND_FEES, SMOOTHING_UNITS
            ));
            address instance;
            assembly { instance := create(0, add(initCode, 32), mload(initCode)) }
            require(instance != address(0), "STAKING_CREATE_FAILED");
            IStakingSupplementV41 st = IStakingSupplementV41(instance);
            require(st.lp_token() == assets[pid] && st.boost_hub() == hub && st.pid() == pid, "STAKING_BINDING_MISMATCH");
            require(st.admin() == ADMIN_AND_FEES && st.fee_receiver() == ADMIN_AND_FEES, "STAKING_ADMIN_MISMATCH");
            require(st.reward_smoothing_units() == SMOOTHING_UNITS, "STAKING_SMOOTHING_MISMATCH");
            require(keccak256(bytes(st.name())) == keccak256(bytes(stakingNames[pid])), "STAKING_NAME_MISMATCH");
            staking[pid] = instance;
            emit NewStaking(pid, instance);
        }

        // Add one new depositor to each PID. The existing allowlists and pool settings remain unchanged.
        for (uint256 pid; pid < 2; ++pid) {
            address[] memory depositors = new address[](1);
            bool[] memory approvals = new bool[](1);
            depositors[0] = staking[pid];
            approvals[0] = true;
            IBoostHubOwnerSupplementV41(hub).setApprovedDepositors(pid, depositors, approvals, false);
            require(IBoostHubOwnerSupplementV41(hub).isApprovedDepositor(pid, staking[pid]), "STAKING_NOT_APPROVED");
        }

        for (uint256 pid; pid < 2; ++pid) {
            // The next TWO broadcast CREATEs must be consecutive for this pair.
            address predictedVault = vm.computeCreateAddress(broadcaster, vm.getNonce(broadcaster) + 1);
            BaseAllToWantBoostHubV5.Addresses memory addresses = BaseAllToWantBoostHubV5.Addresses({
                want: assets[pid], vault: predictedVault, swapper: router, adminFeeReceiver: ADMIN_AND_FEES
            });
            BaseAllToWantBoostHubV5.FeeSettings memory fees = BaseAllToWantBoostHubV5.FeeSettings({
                totalPerformanceFeeBps: PERFORMANCE_FEE_BPS,
                callShareBps: CALL_SHARE_BPS,
                adminShareBps: ADMIN_SHARE_BPS
            });
            address strategy = address(new StrategyConvexBoostHubStakingV5(staking[pid], addresses, fees, PROFIT_UNLOCK, 0));
            address vault = address(new BeefyVaultV7FixedV2(
                IStrategyBoostHubV1(strategy), vaultNames[pid], vaultSymbols[pid], withdrawalFees[pid], ADMIN_AND_FEES
            ));
            require(vault == predictedVault, "STRATEGY_VAULT_NONCE_MISMATCH");
            StrategyConvexBoostHubStakingV5 strat = StrategyConvexBoostHubStakingV5(strategy);
            BeefyVaultV7FixedV2 v = BeefyVaultV7FixedV2(vault);
            require(strat.vault() == vault && address(strat.staking()) == staking[pid], "STRATEGY_BINDING_MISMATCH");
            require(address(v.strategy()) == strategy && address(v.want()) == assets[pid], "VAULT_BINDING_MISMATCH");
            require(strat.adminFeeReceiverAddress() == ADMIN_AND_FEES, "FEE_RECEIVER_MISMATCH");
            require(strat.totalPerformanceFeeBps() == PERFORMANCE_FEE_BPS &&
                strat.callShareBps() == CALL_SHARE_BPS && strat.adminShareBps() == ADMIN_SHARE_BPS, "PERFORMANCE_FEES_MISMATCH");
            require(strat.lockDuration() == PROFIT_UNLOCK && v.withdrawalFeeBps() == withdrawalFees[pid], "VAULT_ECONOMICS_MISMATCH");
            require(keccak256(bytes(v.name())) == keccak256(bytes(vaultNames[pid])) &&
                keccak256(bytes(v.symbol())) == keccak256(bytes(vaultSymbols[pid])), "VAULT_METADATA_MISMATCH");
            v.transferOwnership(ADMIN_AND_FEES);
            require(v.owner() == ADMIN_AND_FEES, "VAULT_OWNER_MISMATCH");
            strategies[pid] = strategy;
            vaults[pid] = vault;
            emit NewStrategyVault(pid, strategy, vault);
        }
        vm.stopBroadcast();
    }
}
