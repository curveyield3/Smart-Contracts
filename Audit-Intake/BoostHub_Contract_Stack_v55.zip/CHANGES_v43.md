# BoostHub Contract Stack v43 — sdFXN dual-strategy deployment script fix

## Defect corrected

`script/DeployDualFXNPool8V42.s.sol` previously predicted the vault CREATE address with `vm.getNonce(broadcaster) + 3`, incorrectly counting only the three contract creations before the vault. `master.configureChildren()` is a separate EOA-broadcast CALL and consumes a nonce, so the vault's actual CREATE uses nonce `initial + 4`. The old prediction was embedded immutably in the master and caused the `VAULT_NONCE_MISMATCH` / `MASTER_NOT_BOUND` deployment checks to fail.

## Exact change

The prediction is now `vm.computeCreateAddress(broadcaster, vm.getNonce(broadcaster) + 4)`, with an accompanying explanatory comment.

| EOA nonce | Action | Type |
| --- | --- | --- |
| Initial + 0 | Deploy `StrategyDualFXNMasterV42` | CREATE |
| Initial + 1 | Deploy `StrategyBoostHubChildV42` | CREATE |
| Initial + 2 | Deploy `StrategyConvexFXNPool8V42` | CREATE |
| Initial + 3 | Call `master.configureChildren(...)` | CALL |
| Initial + 4 | Deploy `BeefyVaultV7FixedV2` | CREATE |

Convex Booster's `createVault(8)` is invoked internally from the Convex child's constructor, and does not use a separate broadcaster EOA nonce. The script retains the existing `vault == predictedVault`, `strategy == master`, and `master.vault() == vault` assertions after vault deployment.

**Requirements preserved:** The supplied `broadcaster` must be the actual Forge broadcast signer (`--sender`), must have sufficient gas, and must deploy with a nonce matching `vm.getNonce(broadcaster)` at simulation/broadcast time. Other transactions sent by the same EOA during the sequence can invalidate the prediction.

## Scope and limitations

Only the new dual-strategy deployment script and top-level documentation were modified. No deployed contracts, Solidity strategy code, fee settings, withdrawal routing, or allocation conditions were changed. This is a source-level correction, not a verified successful deployment. No compilation, tests, live-fork execution, or production broadcasts were performed. The other findings from the v42 audit remain unresolved.
