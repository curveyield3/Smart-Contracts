# v50 — Post-deploy Curve oracle-guard configuration; no old quote-based minimums

- Convex sdFXN child no longer requires or accepts the external guard address in its constructor.
- Added `setCurveLiquidityGuard(address)` on the child, restricted to its `vault` (the master), and `setConvexCurveLiquidityGuard(address)` on the master, restricted to the master's actual `Ownable` owner.
- Zero guard is permitted during deployment and may be used to disable LP operations later. **All liquidity deposits and withdrawals fail closed** until a contract guard is configured. There is no quote-based fallback.
- The guard remains `CurvePairOracleBoundsV6` and all LP deposits / single-coin withdrawals / gauge-unit redemptions use its `quoteDeposit`/`quoteWithdraw` at **100 bps** for *minOut*.
- Removed the unused Curve `calc_token_amount` interface call. LP sizing and gauge-unit exit checks now use the external guard estimate rather than Curve's spot withdrawal estimate.
- Curve's `calc_withdraw_one_coin` remains *solely* for vault NAV valuation (`balanceOfPool`), and is never used for swap/liquidity minimum outputs.
- Deployment script optionally accepts a guard address; when nonzero, it configures through the master after vault deployment and before master ownership transfer; a zero guard does not block deployment. No extra CREATE-nonce assumption is changed.
- Scoped changes to the child, master, optional deployment script, and **existing targeted user-authorized** Foundry fork tests. All partner-protected Beefy contracts and original guard source/dependency unchanged.
- v49 targeted fork suite extended with unconfigured/unauthorized guard tests; live GitHub compilation and fork test status reported separately.
