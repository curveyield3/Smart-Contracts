# BoostHub Contract Stack v20 — Deployment configuration change manifest

Base: `BoostHub_Contract_Stack_v19.zip`. This revision modifies **only** `script/DeployBoostHubStack.s.sol` as operational source. All Solidity and Vyper contract implementations, libraries, interfaces, fees, existing converter/adapter, and build configuration remain byte-identical to v19.

## Requested deployment changes

1. **Every newly deployed Beefy vault:** change the strategy constructor's `STRATEGY_LOCK_DURATION_SECONDS` from `0` to `72 hours` (= `259200` seconds). The vault uses the strategy's built-in locked-profit calculation; no new smoothing function is added. The lock duration is immutable for already-deployed strategy instances.
2. **Fraxtal sdFXS staking:** set constructor `reward_smoothing_units` from `0` to `150`. Since the staking source defines `REWARD_TIME_UNIT = 8640`, this equals **1,296,000 seconds, or 15 days**. Ethereum sdCRV and sdFXN remain at 150.
3. **Remove Ethereum sdYB from deployment:** `_ethereumPools()` changes from three pool slots to two and drops PID 2's asset/gauge/reward data; the loops that create staking and Beefy pairs now instantiate exactly PID 0 sdCRV and PID 1 sdFXN. Removed PID 2-specific keeper/checkpoint-selector logic and sdYB vault name/symbol references. Source contracts are retained for potential future reuse, not deployed in this entrypoint.

## Resulting layout

| Chain | Hub | Staking | Beefy strategy/vault pairs | Staking smoothing | Beefy profit lock |
|---|---:|---|---|---|---|
| Ethereum | 1 | sdCRV (PID 0), sdFXN (PID 1) | 2 | 15 days each | 72 hours each |
| Fraxtal | 1 | sdFXS (PID 0) | 1 | 15 days | 72 hours |

Only BoostHub requires CREATE3 address parity. Other deployments remain ordinary CREATE.

## Scope and verification

- The only changed operational source file is `script/DeployBoostHubStack.s.sol`. README and this v20 manifest were updated to describe configuration.
- One deployment script. All contracts still reside under `contracts/`; dependencies remain centralized.
- Checked the v19–v20 source diff, no remaining `sdYB`, `ASSET_2`, `GAUGE_2`, `rewards[2]` or `pid == 2` references in the script, and verified ZIP integrity.
- No compilation, tests, simulations or blockchain deployments were performed. The current Solidity stack compilation status is therefore unchanged from v19.
