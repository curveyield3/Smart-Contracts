# BoostHub Contract Stack v41 — Ethereum sdCRV / sdFXN custom staking + vault parity

Base: `BoostHub_Contract_Stack_v40(1).zip`. Source changes only; no Ethereum/Fraxtal transaction was signed or broadcast.

## Requested metadata and economics

| Parameter | Ethereum sdCRV (PID 0) | Ethereum sdFXN (PID 1) | Fraxtal sdFXS v40 supplement |
| --- | --- | --- | --- |
| Staking `name()` | `CurveYield Boosthub sdCRV Staking` | `CurveYield Boosthub sdFXN Staking` | `CurveYield Boosthub sdFXS Staking` (preserved) |
| Custom vault `name()` | `CurveYield sdCRV` | `CurveYield sdFXN` | `CurveYield sdFXS` (preserved) |
| Custom vault `symbol()` | `cysdCRV` | `cysdFXN` | `cysdFXS` (preserved) |
| Vault withdrawal fee | **35 bps (0.35%)** | **45 bps (0.45%)** | **30 bps (0.30%)** |
| Performance fee on harvested profits | 300 bps (3%) | 300 bps (3%) | 300 bps (3%) |
| Caller share of performance fee | **1,000 bps (10%)** | **1,000 bps (10%)** | **300 bps (3%)** |
| Admin share of performance fee | 9,000 bps (90%) | 9,000 bps (90%) | 9,700 bps (97%) |
| Strategy profit unlock | 24 hours | 24 hours | 24 hours |
| Staking reward smoothing | 150 units (15 days) | 150 units (15 days) | 150 units (15 days) |

Ethereum caller reward is therefore **0.30% of gross harvested profits** (10% x 3%), not 10% of total profits. Remaining administrator performance fee is **2.70% of gross profits**. Staking's **35% ramp penalty on foregone principal-token rewards** is separate from the 3% strategy performance fee and the vault withdrawal fee.

Withdrawal fee division is unchanged: 30% to the vault's `adminFeeReceiver` and 70% reinvested/locked for remaining shareholders using the existing strategy `lockVaultProfit()` mechanism. For sdCRV this is 0.105% admin / 0.245% shareholder-retained; for sdFXN this is 0.135% admin / 0.315% shareholder-retained (all expressed as fractions of withdrawn underlying). The Vyper staking contract itself continues to have **no principal withdrawal fee**; only custom ERC-20 vault share redemption incurs the above fee.

## Source changes

1. **`contracts/BoostHubStaking.vy`**: shared on-chain name getter selects the intended chain/PID-specific names. On Ethereum PID 0 is sdCRV and PID 1 sdFXN, and on Fraxtal PID 0 is sdFXS. Other chain/PID combinations return a generic name instead of mislabeling the token. Documentation describes the principal-token-only 45-day maturation policy generically. The staking reward, balance, maturity, and withdrawal algorithms are **unchanged**: principal-token rewards ramp 10% initially → 50% at day 33 → 100% at day 45. Forgone principal-token rewards allocate 65% to eligible weight and 35% to fee receiver. Non-principal rewards accrue pro rata without the ramp haircut. Vyper staking is not an ERC-20 receipt token and does not expose `symbol()`.
2. **`script/DeployBoostHubStack.s.sol`**: for **fresh full-stack Ethereum deployment only**, custom vault name/symbol, withdrawal fee, and 24-hour strategy unlock use the v41 settings. The original **10% caller share is preserved**, not reduced to the Fraxtal supplemental 3%. The historic full-stack Fraxtal path, partner Beefy vault names/fees, and all hub/router/other configuration remain unchanged. *Do not use the full-stack script to supplement an existing deployed hub; it creates another hub and router.*
3. **`script/DeployEthereumSupplementV41.s.sol`**: new Ethereum-only supplemental deployment, based on v40's existing Fraxtal supplement pattern. This is necessary because the existing Fraxtal supplement is strictly chain-252-only and the original full-stack script redeploys the hub/router. The supplemental script reuses caller-supplied, verified live Ethereum Hub and OmniRouter addresses, checks existing pool assets and depositor allowlist availability, deploys two new source-bound staking contracts, append-authorizes them without revoking old depositors, then deploys two nonce-linked strategy/vault pairs with the fees above. No new swaps, token accounting, or reward-maturation system is added. All new staking admin, vault owner, and fee-recipient roles follow v40's `0x47623C62f281807D615eeb4A2CEee9d97F9D3C49` convention. The **existing Hub owner** must be the broadcasting EOA for depositor authorization; ownership of the existing Hub is not altered.
4. `script/DeployFraxtalSupplementV40.s.sol` is **unchanged** and continues using its original v40 rates/name/role assignment when built with the updated shared staking source.

## Build, deployment, and limits

- **Do not broadcast before Vyper/Foundry compilation and review.** The bundled build workflow already installs Vyper 0.4.3 and Solidity 0.8.28 / Foundry; no new workflow or test infrastructure was introduced.
- Regenerate the bytecode artifact from the exact updated source: `python tooling/make_staking_artifact.py` after installing Vyper 0.4.3; then run the existing `forge build` with pinned dependencies. Source SHA-256 verification in both supplemental scripts prevents stale artifacts from being deployed.
- Existing Ethereum hub/router addresses are **not provided in v40's source package**, so they are **runtime parameters** rather than invented constants. Verify both contract addresses, hub owner, PID order, active pool status, router reward conversion routes, and remaining approvable depositor capacity before broadcast.
- Invocation shape: `forge script script/DeployEthereumSupplementV41.s.sol:DeployEthereumSupplementV41 --sig 'run(address,address)' <VERIFIED_ETH_HUB> <VERIFIED_ETH_OMNI_ROUTER> --rpc-url <ETHEREUM_RPC> --sender <HUB_OWNER_SIGNER> --broadcast` with an already configured/authorized signing provider. Sender must exactly match the active on-chain Hub owner. Strategy/vault CREATEs depend on that sender's nonce; no unrelated transactions may be interleaved.
- **No existing deployed staking or vault is mutable in place for its immutable metadata/fee settings.** The supplemental script deploys new instances and adds their depositor approvals while keeping existing positions untouched. Migration of any existing users' deposits to the new vaults is not automated; no forced withdrawals are attempted.
- Original independently deployed official Beefy partner vaults and their fee categories remain unchanged; these settings apply to **custom CurveYield vaults** only.
- Source review and archive comparison are performed; the environment available for v41 packaging does not have Vyper 0.4.3, Forge, or Solidity dependencies installed and cannot fetch them, so **no successful compilation or transaction simulation is claimed**. No tests have been added, modified, or run.
