# CurveYield sdFXN Convex Pool-8 — 75 bps Curve guard fork proof v1

## Source and environment

- Production package: `BoostHub_Contract_Stack_v51.zip`.
- Mainnet fork: Ethereum, block **26,431,343** (the GitHub run selects the live RPC at the time of execution).
- Curve pool: `0x28Ca243dc0aC075dD012fCf9375C25D18A844d96`, coin 1 = sdFXN.
- Existing verified deployed external guard: `0x840fa8496e3B5Ac306281d5Bb5224fA08b5865F8` (`CurvePairOracleBoundsV6`). The guard was **not redeployed**.
- Source change vs v50: `StrategyConvexFXNPool8V42.sol` changes the `CURVE_LP_SLIPPAGE_BPS` constant from **100** to **75** and clarifies that it is a bound on output relative to the historical-oracle quote, not a hard spot-price limit. No other production contract or protected partner contract code changed.
- The strategy calls guard `quoteDeposit(pool,1,amount,75)` or `quoteWithdraw(pool,1,lpUnits,75)` and passes the second tuple element `minOut` unchanged to Curve's `add_liquidity` or `remove_liquidity_one_coin`.

## GitHub verified results

[Full trace, compilation, and 10 passing tests](https://github.com/curveyield3/Audit-Controller/actions/runs/43992532148), commit `67701bd1a2cd7ed0283d4b7232da5009139087cb` on isolated branch `sdfxn-v51-75bps-curve-fork`.

Solidity/Foundry compilation **passed**, targeted Ethereum mainnet-fork suite **10 passed, 0 failed, 0 skipped**. The successful run was repeated with `-vvvv` to record actual swaps and guard minimum versus unguarded output.

| Operation | Real swaps | Adverse observed spot move | Deployed guard minOut | Unprotected actual Curve output | Result |
| --- | ---: | ---: | ---: | ---: | --- |
| Deposit 20 sdFXN → Curve LP | 7 | 1.95% | 19.190863581200404299 LP | 19.160595957313617004 LP | Guarded transaction **reverted**; zero-minimum Curve deposit **succeeded** |
| Withdraw Convex gauge-LP → sdFXN | 9 | 1.21% | 19.828524514716080466 sdFXN | 19.823543285464044984 sdFXN | Guarded transaction **reverted**; zero-minimum Curve withdrawal **succeeded** |
| Standard exact-asset strategy withdrawal | 9 | 1.21% | 19.828524514716080466 sdFXN (comparator LP units) | 19.823543285464044984 sdFXN (comparator LP units) | Guarded transaction **reverted**; zero-minimum same-LP Curve withdrawal **succeeded** |

The deposit failed because its actual output was **0.030267623886787295 LP below** the external guard minimum. Withdrawal failed because actual output was **0.004981229252035482 sdFXN below** the external guard minimum. The low-level strategy calls reverted and left the staked LP balances unchanged; deliberately removing the min-output constraint in the comparison executed successfully. This is a direct source-bound proof of the protection, not merely a test expecting an exception.

Additional passed cases: healthy real-pool deposit/withdraw; correct 75-bps haircut (`estimate * 9925 / 10000`) for both calls; unauthorized guard setter rejection; zero/unconfigured guard blocks liquidity operations; invalid oracle fails closed; old Curve-spot-based minOut is no longer used.

## Interpretation and limits

**75 bps is a guard-output haircut, not a guaranteed 0.75% spot-price-movement cutoff.** The live market needed larger spot moves (1.21%-1.95% in this fork state) before the finite-size Curve output fell below the 75-bps historical-oracle minimum. The strategy and guard were not changed to add a separate hard spot-rate-deviation limit.

Mainnet contracts were **not deployed or upgraded** and no real funds were moved by the tests. An older v50 Safe deployment batch or ABI artifact must be regenerated to contain this v51 runtime before signing or execution.
