# BoostHub Contract Stack v25 — Reward-processing gas optimization

## Scope

Surgical source updates to `BoostHubStaking.vy`, `BoostHub.sol`, `BaseAllToWantBoostHubV5.sol`, and `StrategyConvexBoostHubStakingV5.sol`. Based on v24. No new contract, storage registry, reward ledger, workflow, or test was added. Previously rejected changes (zero-staker ownership handling, duplicate-gauge handling, capacity policy redesign, disabled reward redesign, emergency-shutdown behavior) remain unchanged.

## Specific modifications

1. **Strategy 9-token compatibility:** `MAX_STAKING_REWARDS` changes from 8 to 9, matching the staking registry's maximum. The deploy constructor and its ABI remain unchanged.
2. **Only unsettled reward tokens receive 45-day per-user bucket/phase computation:** `_checkpoint_user_current` builds a *temporary in-memory* list of reward-token indices for which `reward_integral[token] > reward_integral_for[token][user]`. The expensive nested phase/penalty calculations use only that list; all historical positions, pending token claims, and token registrations remain accessible. Q-integral baseline reads and writes are skipped when integral is unchanged.
3. **Only unfinished streams or buffered redistributions require per-boundary work:** `_advance_reward_integrals` builds a temporary in-memory list based on existing `reward_remaining`, `reward_period_finish`, `reward_last_update`, and `active_reward_redistribution_buffer`. It processes only those token streams across daily boundaries and at the current timestamp. The ordinary same-day/no-active-ramp case retains the original single-pass implementation to avoid constructing an index list when there is no repeated boundary work to eliminate. Tokens are automatically selected again when a new reward stream is scheduled.
4. **Maintain historical snapshot correctness:** At relevant cohort phase boundaries, store `activation_integral_at` and `activation_reward_q_at` only when their values are nonzero. Nonzero plateau snapshots are still stored, even for dormant tokens: direct historical lookup depends on them. Compressing these plateau values safely would require a different historical lookup mechanism, which is deliberately not introduced.
5. **Conditional debt updates:** `BoostHub._checkpoint` writes `rewardDebt` only when its recalculated value differs from the existing value. Its authoritative accumulated-per-share/debt model is unchanged.
6. **Standard-token claim return accounting:** Staking's `harvest()` consumes the amounts returned by `BoostHub.claim()`, preserving the returned token ordering. Removed the two per-reward `balanceOf` passes. This relies on the approved assumption that every supported reward token is a standard non-fee-on-transfer, non-rebasing ERC-20; unusual or subsequently added nonstandard tokens would require reconsideration.
7. **Beefy reward sync:** `_syncRewards` compares its desired list against the stored list and returns without rewriting storage if equal. Removed a redundant synchronizing pass from `BaseAllToWantBoostHubV5.deposit()` and from internal harvest re-deposit: `_claim()` refreshes before reward conversions and `syncRewards()` remains available explicitly. Public `deposit()` still stakes all available want.
8. **Constructor:** Reused the already fetched BoostHub pool list to identify whether the principal token is itself a Hub reward; eliminates the separate initial `poolInfo` call.

## Accounting invariants preserved

- No reward token is deregistered or disabled by the new stream-activity optimization; nine slots remain registered.
- Discontinued tokens remain claimable and retain the original historical integral mappings.
- Tokens with new rewards automatically re-enter the active processing list, without an owner-set flag.
- The 45-day ramp phases, smoothing, per-user claim data, pending fees, reserve protections, principal accounting and external claim ABI remain unchanged.
- Owner sweeping, reward distributor authorization/timelock and 90-day emergency code are unchanged.

## Build and runtime verification status

Source deltas were reviewed against v24 for changed call paths and external ABI signatures. Vyper 0.4.3 was not installed and package retrieval failed because the environment could not resolve pypi.org. Forge/solc were also unavailable locally. **No compilation, tests, fork execution or measured gas benchmarking completed.** This source package is an uncompiled candidate and needs normal deployment-build verification before use. No new tests were created or run.
