# CurveYield cyvlSDT deployment package v64

Source-correction release based on the exact v63 archive (`CurveYield-cyvlSDT-Deployment-Package-v63(1).zip`, SHA-256 `ce3fe59c8745a78912f083b9df4467aa4cbecbfab4cd061d7f373e05da7251b9`).

## Changes relative to v63

- `contracts/VoteMarketSingleGaugeBribeAllocator.sol`: repair the USDC constant to the Solidity-accepted EIP-55 mixed-case checksum; address bytes unchanged.
- `contracts/CurveYieldRevenueStrategyV8.sol`: same USDC address checksum correction; address bytes unchanged.
- `contracts/CurveYieldVlSDTBoostMerchant.sol`: restore the missing fifth `bool amountAlreadyChecked` parameter to `_createMarketplaceListing` and its conditional `_checkLeaseAmount` guard. The direct public listing path passes `false` and performs the capacity/minimum check; `executeBestRoute` passes `true` because it already performed the identical check before entering the routing path. Both calls' original arguments are preserved.
- `package.json` / `package-lock.json`: synchronize release metadata at v64 and name the compilation script `compile:v64` (underlying command remains `hardhat compile`; dependencies and locks unchanged).

No existing ABI selectors, economic settings, storage variables, constructor arguments, events, or deployment scripts were intentionally changed. The internal helper parameter does not affect the external ABI.

## Build status

These fixes resolve the four source errors explicitly reported by the GitHub Phase 0 attempt for the original v63 ZIP. The original Hardhat config and lockfile remain unchanged. The environment also reported a separate offline-solc-0.8.30 downloader error; that toolchain-provisioning problem is not a source-code fault, and full production-profile compilation is **not yet verified**. No tests, forks, deployments, or transactions were executed for this repair.
