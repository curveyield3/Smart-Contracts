// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable, Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {IBoostMarketplace} from "./interfaces/IStakeDao.sol";
import {ICurveYieldvlSDTLocker} from "./interfaces/ICurveYield.sol";

/// @dev The Merchant owns the route policy and rate checks; Locker alone owns vlSDT voting power.
interface IAladdinRewardHistory {
    function weeklyRewards(uint256 week) external view returns (uint256);
    function historyBoosts(address user, uint256 week) external view returns (uint256);
    function lastSDTReward() external view returns (uint128 balance, uint128 timestamp);
}

contract CurveYieldVlSDTBoostMerchant is Ownable2Step, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 public constant WEEK = 7 days;
    uint256 public constant PRECISION = 1e18;
    uint256 public constant BPS = 10_000;
    uint256 public constant MIN_ALADDIN_PREMIUM_BPS = 11_000;
    uint256 public constant MAX_LEASE_SECONDS = 90 days;
    uint256 public constant MAX_MARKETPLACE_LISTING_WEEKS = 11;
    uint256 public constant MAX_REQUEST_WEEKS = 12;
    address public constant USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    uint256 public constant USDC_UNIT = 1e6;
    IAladdinRewardHistory public constant ALADDIN =
        IAladdinRewardHistory(0x322c76e1205dE5ee4146e40644563B482B1CDA43);

    // Owner-maintained prices: USDC base units per 1e18 vlBoost per week.
    // Conversion: SDT wei per 1 whole USDC; no external price oracle.
    enum Route { FillOffer, PostListing, DelegateAladdin }

    struct RouteParams {
        uint256 offerId;
        uint256 amount;
        uint256 minPayment;
        uint256 listingExpiry;
        uint256 minListingWeeks;
        uint256 maxListingWeeks;
        uint256 aladdinEndtime;
    }

    ICurveYieldvlSDTLocker public LOCKER;
    IBoostMarketplace public MARKETPLACE;

    uint96 public postPricePerWeek;
    uint96 public minimumFillPricePerWeek;
    uint256 public sdtWeiPerUsdc;
    mapping(address => bool) public isKeeper;
    mapping(uint256 => bool) public createdListings;
    uint256 public minimumLeaseBoost = 1e18;
    bool public postListingIfNoAcceptableOffer;

    error ZeroAddress();
    error ZeroAmount();
    error InvalidPriceRange();
    error UnsupportedPaymentToken();
    error InvalidDuration();
    error DeadlineExpired();
    error MaximumPaymentExceeded();
    error InsufficientBoostCapacity();
    error OfferBelowCurrentRate();
    error InvalidOffer();
    error NotOwnerOrKeeper();
    error BelowMinimumLease();
    error StaleAladdinEpoch();
    error NoAladdinDelegations();
    error BelowAladdinPremium();
    error InvalidConversion();

    event SaleRatesSet(uint256 postPricePerWeek, uint256 minimumFillPricePerWeek, uint256 sdtWeiPerUsdc);
    event DirectLease(address indexed buyer, address indexed recipient, address indexed paymentToken,
        uint256 boostAmount, uint256 pricePerWeek, uint256 payment, uint256 endtime);
    event MarketplaceListingCreated(uint256 indexed listingId, address indexed paymentToken, uint256 amount, uint256 price);
    event MarketplaceListingUpdated(uint256 indexed listingId, uint256 amount, uint256 price);
    event MarketplaceListingCancelled(uint256 indexed listingId);
    event MarketplaceOfferFilled(uint256 indexed offerId, uint256 fillAmount, uint256 pricePerWeek);
    event KeeperSet(address indexed keeper, bool allowed);
    event MinimumLeaseBoostSet(uint256 amount);
    event PostListingFallbackSet(bool enabled);
    event AladdinDelegationSelected(uint256 indexed commitmentId, uint256 amount, uint256 endtime);
    event AladdinRewardsForwarded(uint256 amount);
    event RouteSelected(Route indexed route, uint256 indexed referenceId, uint256 amount);
    event LockerRebound(address indexed previous,address indexed next);
    event MarketplaceRebound(address indexed previous,address indexed next);

    constructor(address initialOwner_, address locker_, address marketplace_)
        Ownable(initialOwner_)
    {
        if (initialOwner_ == address(0) || locker_ == address(0)
            || marketplace_ == address(0)) revert ZeroAddress();
        LOCKER = ICurveYieldvlSDTLocker(locker_);
        MARKETPLACE = IBoostMarketplace(marketplace_);
        // Locker takes the exact forwarded revenue amount, without recurring allowance writes.
        IERC20(USDC).forceApprove(locker_, type(uint256).max);
    }

    modifier onlyOwnerOrKeeper() {
        if (msg.sender != owner() && !isKeeper[msg.sender]) revert NotOwnerOrKeeper();
        _;
    }

    function setLocker(address next) external onlyOwner {
        if (next == address(0)) revert ZeroAddress();
        address previous = address(LOCKER);
        if (previous != next) {
            IERC20(USDC).forceApprove(previous, 0);
            IERC20(USDC).forceApprove(next, type(uint256).max);
        }
        emit LockerRebound(previous, next);
        LOCKER = ICurveYieldvlSDTLocker(next);
    }

    function setMarketplace(address next) external onlyOwner {
        emit MarketplaceRebound(address(MARKETPLACE), next);
        MARKETPLACE = IBoostMarketplace(next);
    }

    function setKeeper(address keeper, bool allowed) external onlyOwner {
        if (keeper == address(0)) revert ZeroAddress();
        isKeeper[keeper] = allowed;
        emit KeeperSet(keeper, allowed);
    }

    function setMinimumLeaseBoost(uint256 amount) external onlyOwner {
        if (amount == 0) revert ZeroAmount();
        minimumLeaseBoost = amount;
        emit MinimumLeaseBoostSet(amount);
    }

    function setPostListingIfNoAcceptableOffer(bool enabled) external onlyOwner {
        postListingIfNoAcceptableOffer = enabled;
        emit PostListingFallbackSet(enabled);
    }

    /// @notice Set USDC-only marketplace listing/direct-lease and offer-fill thresholds.
    /// @param postRate Price per 1e18 vlBoost per week, in USDC base units.
    /// @param fillRate Minimum acceptable buy-offer rate, in USDC base units.
    /// @param sdtPerUsdc SDT wei-equivalent value of one whole USDC (owner-maintained).
    function setSaleRates(uint256 postRate, uint256 fillRate, uint256 sdtPerUsdc) external onlyOwner {
        if (postRate == 0 || fillRate == 0
            || postRate > type(uint96).max || fillRate > type(uint96).max) revert InvalidPriceRange();
        if (sdtPerUsdc == 0) revert InvalidConversion();
        postPricePerWeek = uint96(postRate);
        minimumFillPricePerWeek = uint96(fillRate);
        sdtWeiPerUsdc = sdtPerUsdc;
        emit SaleRatesSet(postRate, fillRate, sdtPerUsdc);
    }

    /// @notice Last completed UNIX/Thursday week, priced in SDT wei per 1e18 vlBoost per week.
    /// @dev Fail closed if that week's rewards are not checkpointed or global power is missing.
    function aladdinLastEpochRate() public view returns (uint256 week, uint256 sdtWeiPerBoostWeek) {
        week = (block.timestamp / WEEK) * WEEK - WEEK;
        (, uint128 checkpointTime) = ALADDIN.lastSDTReward();
        if (checkpointTime < week + WEEK) revert StaleAladdinEpoch();
        uint256 totalPower = ALADDIN.historyBoosts(address(0), week);
        if (totalPower == 0) revert NoAladdinDelegations();
        sdtWeiPerBoostWeek = Math.mulDiv(ALADDIN.weeklyRewards(week), PRECISION, totalPower);
    }

    function aladdinMinimumPriceInSDT() public view returns (uint256) {
        (, uint256 rate) = aladdinLastEpochRate();
        return Math.mulDiv(rate, MIN_ALADDIN_PREMIUM_BPS, BPS, Math.Rounding.Ceil);
    }

    function aladdinLastEpochAprBps() external view returns (uint256) {
        (, uint256 rate) = aladdinLastEpochRate();
        return Math.mulDiv(rate, 365 days * BPS, PRECISION * WEEK);
    }

    /// @notice Arithmetic average of weekly annualized SDT-on-vlBoost rates.
    /// @dev Read-only historical indicator; sale guards use ONLY the last completed epoch.
    function aladdinAverageAprBps(uint256 weeksBack) external view returns (uint256) {
        if (weeksBack == 0 || weeksBack > 12) revert InvalidDuration();
        uint256 week = (block.timestamp / WEEK) * WEEK - WEEK;
        (, uint128 lastCheckpoint) = ALADDIN.lastSDTReward();
        if (lastCheckpoint < week + WEEK) revert StaleAladdinEpoch();
        uint256 sumRate;
        for (uint256 i; i < weeksBack; ++i) {
            uint256 totalPower = ALADDIN.historyBoosts(address(0), week);
            if (totalPower == 0) revert NoAladdinDelegations();
            sumRate += Math.mulDiv(ALADDIN.weeklyRewards(week), PRECISION, totalPower);
            week -= WEEK;
        }
        return Math.mulDiv(sumRate, 365 days * BPS, PRECISION * WEEK * weeksBack);
    }

    /// @notice SDT-equivalent value of USDC-denominated price per 1e18 boost per week.
    function priceInSDT(uint256 pricePerWeek) public view returns (uint256) {
        if (sdtWeiPerUsdc == 0) revert InvalidConversion();
        return Math.mulDiv(pricePerWeek, sdtWeiPerUsdc, USDC_UNIT);
    }

    function _checkPremium(uint256 pricePerWeek, bool marketplaceFee) internal view {
        uint256 equivalent = priceInSDT(pricePerWeek);
        if (marketplaceFee) {
            uint256 fee = MARKETPLACE.feeBps();
            if (fee >= BPS) revert BelowAladdinPremium();
            equivalent = Math.mulDiv(equivalent, BPS - fee, BPS);
        }
        if (equivalent < aladdinMinimumPriceInSDT()) revert BelowAladdinPremium();
    }

    function currentPricePerWeek() public view returns (uint256 price) {
        price = postPricePerWeek;
        if (price == 0) revert InvalidPriceRange();
        _checkPremium(price, true);
    }

    function acceptableFillPricePerWeek() public view returns (uint256 price) {
        price = minimumFillPricePerWeek;
        if (price == 0) revert InvalidPriceRange();
        _checkPremium(price, true);
    }

    function _checkLeaseAmount(uint256 amount) internal view {
        if (amount == 0) revert ZeroAmount();
        if (amount < minimumLeaseBoost) revert BelowMinimumLease();
        if (amount > LOCKER.merchantDelegableBoost()) revert InsufficientBoostCapacity();
    }

    function _alignedEndtime(uint256 durationWeeks) internal view returns (uint256 endtime) {
        if (durationWeeks == 0 || durationWeeks > MAX_REQUEST_WEEKS) revert InvalidDuration();
        endtime = Math.ceilDiv(block.timestamp + durationWeeks * WEEK, WEEK) * WEEK;
        _checkEndtime(endtime);
    }

    function _checkEndtime(uint256 endtime) internal view {
        if (endtime <= block.timestamp || endtime - block.timestamp > MAX_LEASE_SECONDS)
            revert InvalidDuration();
    }

    function quoteLease(uint256 boostAmount, uint256 durationWeeks)
        public view returns (uint256 pricePerWeek, uint256 endtime, uint256 totalPayment) {
        if (boostAmount == 0) revert ZeroAmount();
        if (boostAmount < minimumLeaseBoost) revert BelowMinimumLease();
        pricePerWeek = currentPricePerWeek();
        endtime = _alignedEndtime(durationWeeks);
        totalPayment = Math.mulDiv(boostAmount, pricePerWeek * (endtime - block.timestamp), WEEK * PRECISION);
    }

    function leaseBoost(uint256 boostAmount, uint256 durationWeeks,
        address recipient, uint256 maxPayment, uint256 deadline)
        external nonReentrant returns (uint256 payment, uint256 endtime) {
        if (recipient == address(0)) revert ZeroAddress();
        // Aladdin's proxy is an internal route selector, never a direct lease buyer.
        if (recipient == address(ALADDIN)) revert InvalidOffer();
        if (block.timestamp > deadline) revert DeadlineExpired();
        _checkLeaseAmount(boostAmount);
        (uint256 price, uint256 end, uint256 due) = quoteLease(boostAmount, durationWeeks);
        if (due > maxPayment) revert MaximumPaymentExceeded();
        payment = due;
        endtime = end;
        IERC20(USDC).safeTransferFrom(msg.sender, address(this), payment);
        LOCKER.forwardMerchantRevenue(payment);
        LOCKER.delegateBoost(boostAmount, endtime, recipient);
        emit DirectLease(msg.sender, recipient, USDC, boostAmount, price, payment, endtime);
    }

    function createMarketplaceListing(uint256 amount, uint256 minDuration,
        uint256 maxDuration, uint256 expiry)
        external onlyOwnerOrKeeper returns (uint256 listingId) {
        listingId = _createMarketplaceListing(amount, minDuration, maxDuration, expiry, false);
    }

    function _createMarketplaceListing(uint256 amount, uint256 minDuration,
        uint256 maxDuration, uint256 expiry, bool amountAlreadyChecked)
        internal returns (uint256 listingId) {
        if (!amountAlreadyChecked) _checkLeaseAmount(amount);
        if (minDuration == 0 || maxDuration < minDuration || maxDuration > MAX_MARKETPLACE_LISTING_WEEKS)
            revert InvalidDuration();
        uint256 price = currentPricePerWeek();
        listingId = LOCKER.marketplaceCreateListing(amount, price, minDuration, maxDuration, USDC, expiry);
        createdListings[listingId] = true;
        emit MarketplaceListingCreated(listingId, USDC, amount, price);
    }

    function refreshMarketplaceListing(uint256 listingId, uint256 newAmount) external onlyOwnerOrKeeper {
        if (!createdListings[listingId]) revert InvalidOffer();
        uint256 price = currentPricePerWeek();
        LOCKER.marketplaceUpdateListing(listingId, newAmount, price);
        emit MarketplaceListingUpdated(listingId, newAmount, price);
    }

    function cancelMarketplaceListing(uint256 listingId) external onlyOwnerOrKeeper {
        if (!createdListings[listingId]) revert InvalidOffer();
        LOCKER.marketplaceCancelListing(listingId);
        delete createdListings[listingId];
        emit MarketplaceListingCancelled(listingId);
    }

    /// @dev A live offer is read once per attempted fill. All fee and Aladdin
    ///      price reads are shared between offer approval and the fill-rate floor.
    function _acceptableOffer(IBoostMarketplace.BuyOffer memory offer, uint256 amount)
        internal view returns (bool acceptable, uint256 marketFee, uint256 aladdinMin)
    {
        if (offer.buyer == address(0) || offer.expiry <= block.timestamp
            || offer.paymentToken != USDC || offer.amount < offer.filled
            || amount == 0 || uint256(offer.amount) - uint256(offer.filled) < amount) return (false, 0, 0);
        if (offer.duration == 0 || offer.duration > MAX_REQUEST_WEEKS) return (false, 0, 0);
        uint256 endtime = Math.ceilDiv(block.timestamp + uint256(offer.duration) * WEEK, WEEK) * WEEK;
        if (endtime - block.timestamp > MAX_LEASE_SECONDS) return (false, 0, 0);
        if (minimumFillPricePerWeek == 0 || sdtWeiPerUsdc == 0
            || offer.pricePerWeek < minimumFillPricePerWeek) return (false, 0, 0);
        marketFee = MARKETPLACE.feeBps();
        if (marketFee >= BPS) return (false, marketFee, 0);
        aladdinMin = aladdinMinimumPriceInSDT();
        uint256 netSDT = Math.mulDiv(priceInSDT(offer.pricePerWeek), BPS - marketFee, BPS);
        acceptable = netSDT >= aladdinMin;
    }

    /// @dev Retains the independent 10% Aladdin premium requirement for the
    ///      owner's minimum fill *threshold*, using the already-read fee/rate.
    function _checkFillFloor(uint256 marketFee, uint256 aladdinMin) private view {
        uint256 price = minimumFillPricePerWeek;
        if (price == 0) revert InvalidPriceRange();
        if (marketFee >= BPS
            || Math.mulDiv(priceInSDT(price), BPS - marketFee, BPS) < aladdinMin)
            revert BelowAladdinPremium();
    }

    function _acceptOffer(uint256 offerId, uint256 fillAmount, uint256 minTotalPayment,
        uint256 maxEffectiveDuration, uint256 pricePerWeek) private returns (uint256 revenueAmount) {
        uint256 remaining = MAX_LEASE_SECONDS;
        if (maxEffectiveDuration != 0 && maxEffectiveDuration < remaining) remaining = maxEffectiveDuration;
        revenueAmount = LOCKER.marketplaceAcceptOffer(offerId, fillAmount, minTotalPayment,
            remaining, false);
        emit MarketplaceOfferFilled(offerId, fillAmount, pricePerWeek);
    }

    function fillProfitableOffer(uint256 offerId, uint256 fillAmount, uint256 minTotalPayment,
        uint256 maxEffectiveDuration) external nonReentrant returns (uint256 revenueAmount) {
        _checkLeaseAmount(fillAmount);
        if (offerId == 0) revert OfferBelowCurrentRate();
        IBoostMarketplace.BuyOffer memory offer = MARKETPLACE.getOffer(offerId);
        (bool acceptable, uint256 marketFee, uint256 aladdinMin) = _acceptableOffer(offer, fillAmount);
        if (!acceptable) revert OfferBelowCurrentRate();
        _checkFillFloor(marketFee, aladdinMin);
        revenueAmount = _acceptOffer(offerId, fillAmount, minTotalPayment,
            maxEffectiveDuration, offer.pricePerWeek);
    }

    function delegateAladdinBoost(uint256 amount, uint256 endtime)
        external onlyOwnerOrKeeper nonReentrant returns (uint256 commitmentId) {
        _checkLeaseAmount(amount);
        commitmentId = _delegateAladdinBoost(amount, endtime);
    }

    function _delegateAladdinBoost(uint256 amount, uint256 endtime)
        internal returns (uint256 commitmentId) {
        uint256 aligned = endtime / WEEK * WEEK;
        _checkEndtime(aligned);
        // Use Locker's EXISTING module-authorized delegateBoost entry point.
        // The Aladdin proxy address selects the Aladdin route; Locker remains the
        // actual delegator and receives the Aladdin reward shares.
        commitmentId = LOCKER.delegateBoost(amount, aligned, address(ALADDIN));
        emit AladdinDelegationSelected(commitmentId, amount, aligned);
    }

    function claimAladdinRewards() external nonReentrant returns (uint256 amount) {
        (, amount) = LOCKER.claimAndForwardRevenue();
        emit AladdinRewardsForwarded(amount);
    }

    /// @notice Deterministic routing: take a qualifying LIVE buy offer first; otherwise
    ///         list only if the owner enables the passive-listing fallback; else delegate to Aladdin.
    /// @dev Locker authorizes the Aladdin proxy only if needed during delegation.
    function executeBestRoute(RouteParams calldata p)
        external onlyOwnerOrKeeper nonReentrant returns (Route route, uint256 referenceId) {
        _checkLeaseAmount(p.amount);
        if (p.offerId != 0) {
            IBoostMarketplace.BuyOffer memory offer = MARKETPLACE.getOffer(p.offerId);
            (bool acceptable, uint256 marketFee, uint256 aladdinMin) = _acceptableOffer(offer, p.amount);
            if (acceptable) {
                _checkFillFloor(marketFee, aladdinMin);
                _acceptOffer(p.offerId, p.amount, p.minPayment,
                    MAX_LEASE_SECONDS, offer.pricePerWeek);
                route = Route.FillOffer;
                referenceId = p.offerId;
                emit RouteSelected(route, referenceId, p.amount);
                return (route, referenceId);
            }
        }
        if (postListingIfNoAcceptableOffer && postPricePerWeek != 0) {
            referenceId = _createMarketplaceListing(p.amount,
                p.minListingWeeks, p.maxListingWeeks, p.listingExpiry, true);
            route = Route.PostListing;
        } else {
            referenceId = _delegateAladdinBoost(p.amount, p.aladdinEndtime);
            route = Route.DelegateAladdin;
        }
        emit RouteSelected(route, referenceId, p.amount);
    }

}
