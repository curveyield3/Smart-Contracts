# BoostHub Contract Stack v56 — sole dual-child sdFXN deployment; no strategy APR

## Scope

- `script/DeployBoostHubStack.s.sol`: Ethereum PID 1 retains its sdFXN staking adapter and reward routes, but skips BOTH its single-strategy custom vault and its single-strategy Beefy partner vault. PID 0 sdCRV and Fraxtal PID 0 sdFXS deployment paths remain. Internal helper guards refuse accidental single-strategy Ethereum PID 1 deployment.
- `script/DeployEthereumSupplementV41.s.sol`: still creates the sdCRV and sdFXN staking adapters and approves both depositors; creates only sdCRV strategy/vault. Keeps `address[2]` returns for compatibility: `staking[1]` is sdFXN adapter, `strategies[1]`/`vaults[1]` stay zero.
- `script/DeployDualFXNPool8V42.s.sol`: now explicitly documented as the SOLE sdFXN vault deployment path, using the existing approved sdFXN staking adapter. The two children (BoostHub and Convex pool 8) and their owner-targeted allocations remain unchanged.
- `contracts/StrategyConvexBoostHubStakingV5.sol`: documented that the strategy and its parent already had **no APR/APY history, checkpoint, or virtual unit calculation in v55**. No functional strategy changes were necessary; inherited profit-locking state is preserved.
- `README.md`: current deployment policy and precedence clarified.

## Non-actions

- Did not remove the sdFXN BoostHub PID 1 gauge, staking contract or rewards routing: the dual-child strategy needs them.
- Did not touch existing deployed single-strategy vaults or migrate funds.
- No test files created, edited, or executed.
- No live deployment or ownership operations.

## Compilation status

- Source-level review performed. GitHub compilation not yet verified.
