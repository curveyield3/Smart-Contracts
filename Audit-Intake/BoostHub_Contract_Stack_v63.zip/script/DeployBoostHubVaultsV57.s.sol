// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/// @notice Sole vault-deployment entry point for an ALREADY configured BoostHub stack.
/// @dev Ethereum: PID 0 sdCRV single-child vault + PID 1 sdFXN dual-child vault.
///      Fraxtal: PID 0 sdFXS single-child vault. No staking, Hub, router,
///      CREATE3 factory, Beefy partner clone, or extra standalone sdFXN vault.
///      Input `staking` order MUST match the Hub's PID order.
import {IBoostHub} from "../contracts/interfaces/IBoostHub.sol";
import {BaseAllToWantBoostHubV5} from "../contracts/BaseAllToWantBoostHubV5.sol";
import {StrategyConvexBoostHubStakingV5} from "../contracts/StrategyConvexBoostHubStakingV5.sol";
import {StrategyBoostHubChildV42} from "../contracts/StrategyBoostHubChildV42.sol";
import {StrategyConvexFXNPool8V42} from "../contracts/StrategyConvexFXNPool8V42.sol";
import {StrategyDualFXNMasterV42, IYieldChildV42} from "../contracts/StrategyDualFXNMasterV42.sol";
import {BeefyVaultV7FixedV2} from "../contracts/BeefyVaultV7FixedV2.sol";
import {IStrategyBoostHubV1} from "../contracts/interfaces/IStrategyBoostHubV1.sol";

interface VmVaultV57 {
    function getNonce(address account) external view returns (uint64);
    function computeCreateAddress(address deployer, uint256 nonce) external pure returns (address);
    function startBroadcast() external;
    function stopBroadcast() external;
}

interface IHubVaultV57 {
    function isApprovedDepositor(uint256 pid, address depositor) external view returns (bool);
}

interface IStakingVaultV57 {
    function lp_token() external view returns (address);
    function boost_hub() external view returns (address);
    function pid() external view returns (uint256);
}

interface IFxnPoolVaultV57 {
    function coins(uint256 index) external view returns (address);
}

interface IRouterVaultV57 {
    function getAmountOut(address from, address to, uint256 amount) external view returns (uint256);
}

interface ICurveBoundsVaultV57 {
    function quoteDeposit(address pool, uint8 coinIndex, uint256 amount, uint16 slippageBps)
        external view returns (uint256 estimate, uint256 minOut);
}

contract DeployBoostHubVaultsV57 {
    VmVaultV57 private constant vm =
        VmVaultV57(address(uint160(uint256(keccak256("hevm cheat code")))));

    address private constant ETH_SDCRV = 0xD1b5651E55D4CeeD36251c61c50C889B36F6abB5;
    address private constant ETH_SDFXN = 0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD;
    address private constant FRAX_SDFXS = 0x1AEe2382e05Dc68BDfC472F1E46d570feCca5814;
    address private constant ETH_FXN = 0x365AccFCa291e7D3914637ABf1F7635dB165Bb09;
    address private constant FXN_SDFXN_CURVE = 0x28Ca243dc0aC075dD012fCf9375C25D18A844d96;
    address private constant FXN_CONVEX_BOOSTER = 0xAffe966B27ba3E4Ebb8A0eC124C7b7019CC762f8;
    address private constant OWNER_AND_FEE_RECEIVER = 0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;

    event VaultDeployed(uint256 indexed chainId, uint256 indexed pid, address vault, address strategy);
    event DualChildVaultDeployed(address indexed vault, address indexed master, address boostChild, address convexChild);

    /// @param hub The existing chain-local BoostHub containing all required PIDs.
    /// @param router The existing chain-local CurveYield OmniRouter, already configured.
    /// @param staking PID-indexed staking adapters emitted by DeployBoostHubStack::run.
    /// @param broadcaster The Foundry --sender EOA, used to predict nonce-coupled vault addresses.
    /// @param liquidityGuard Ethereum sdFXN Curve bounds guard; zero deliberately defers it.
    /// @return vaults Per-PID vault addresses (Ethereum length 2, Fraxtal length 1).
    function run(address hub, address router, address[] calldata staking, address broadcaster, address liquidityGuard)
        external returns (address[] memory vaults)
    {
        bool isEthereum = block.chainid == 1;
        require(isEthereum || block.chainid == 252, "UNSUPPORTED_CHAIN");
        require(hub.code.length > 0 && router.code.length > 0, "MISSING_CONFIGURED_INFRA");
        require(broadcaster != address(0), "INVALID_BROADCASTER");
        require(staking.length == (isEthereum ? 2 : 1), "WRONG_PID_COUNT");
        require(isEthereum || liquidityGuard == address(0), "FRAXTAL_GUARD_UNUSED");
        address[] memory assets = new address[](staking.length);
        if (isEthereum) {
            assets[0] = ETH_SDCRV;
            assets[1] = ETH_SDFXN;
            require(FXN_SDFXN_CURVE.code.length > 0 && ETH_FXN.code.length > 0
                && FXN_CONVEX_BOOSTER.code.length > 0, "MISSING_DUAL_CHILD_DEPENDENCY");
            require(IFxnPoolVaultV57(FXN_SDFXN_CURVE).coins(0) == ETH_FXN
                && IFxnPoolVaultV57(FXN_SDFXN_CURVE).coins(1) == ETH_SDFXN, "WRONG_FXN_POOL");
            require(_routeReady(router, ETH_SDFXN, ETH_FXN)
                && _routeReady(router, ETH_FXN, ETH_SDFXN), "MISSING_DUAL_ROUTER_ROUTES");
            if (liquidityGuard != address(0)) {
                require(liquidityGuard.code.length > 0, "CURVE_GUARD_NOT_CONTRACT");
                (,uint256 minLp) = ICurveBoundsVaultV57(liquidityGuard).quoteDeposit(
                    FXN_SDFXN_CURVE, 1, 1 ether, 100
                );
                require(minLp > 0, "CURVE_GUARD_NOT_READY");
            }
        } else {
            assets[0] = FRAX_SDFXS;
        }
        for (uint256 pid; pid < staking.length; ++pid) {
            require(staking[pid].code.length != 0, "STAKING_NOT_DEPLOYED");
            IStakingVaultV57 st = IStakingVaultV57(staking[pid]);
            require(st.lp_token() == assets[pid] && st.boost_hub() == hub
                && st.pid() == pid, "WRONG_STAKING_PID_OR_ASSET");
            IBoostHub.PoolView memory pool = IBoostHub(hub).poolInfo(pid);
            require(pool.active && pool.asset == assets[pid], "WRONG_HUB_POOL");
            require(IHubVaultV57(hub).isApprovedDepositor(pid, staking[pid]), "STAKING_NOT_APPROVED");
        }

        vaults = new address[](staking.length);
        vm.startBroadcast();
        if (isEthereum) {
            vaults[0] = _deployStandalone(staking[0], router, broadcaster, ETH_SDCRV,
                "CurveYield sdCRV", "cysdCRV", 35, 1000);
            vaults[1] = _deployDualFXN(staking[1], router, broadcaster, liquidityGuard);
        } else {
            vaults[0] = _deployStandalone(staking[0], router, broadcaster, FRAX_SDFXS,
                "CurveYield sdFXS", "cysdFXS", 30, 300);
        }
        vm.stopBroadcast();
    }

    function _routeReady(address router, address from, address to) internal view returns (bool) {
        try IRouterVaultV57(router).getAmountOut(from, to, 1 ether) returns (uint256 quote) {
            return quote > 0;
        } catch { return false; }
    }

    function _deployStandalone(
        address staking, address router, address broadcaster, address asset,
        string memory name, string memory symbol, uint256 withdrawBps, uint16 callerShareBps
    ) internal returns (address vault) {
        // Strategy constructor must know its vault before that vault is created.
        // Preserve the consecutive broadcaster CREATE nonce linkage.
        address expectedVault = vm.computeCreateAddress(broadcaster, vm.getNonce(broadcaster) + 1);
        BaseAllToWantBoostHubV5.Addresses memory a = BaseAllToWantBoostHubV5.Addresses({
            want: asset, vault: expectedVault, swapper: router, adminFeeReceiver: OWNER_AND_FEE_RECEIVER
        });
        BaseAllToWantBoostHubV5.FeeSettings memory f = BaseAllToWantBoostHubV5.FeeSettings({
            totalPerformanceFeeBps: 300, callShareBps: callerShareBps, adminShareBps: uint16(10_000 - callerShareBps)
        });
        address strategy = address(new StrategyConvexBoostHubStakingV5(staking, a, f, 1 days, 0));
        vault = address(new BeefyVaultV7FixedV2(
            IStrategyBoostHubV1(strategy), name, symbol, withdrawBps, OWNER_AND_FEE_RECEIVER
        ));
        require(vault == expectedVault, "SINGLE_VAULT_NONCE_MISMATCH");
        require(StrategyConvexBoostHubStakingV5(strategy).vault() == vault
            && address(StrategyConvexBoostHubStakingV5(strategy).staking()) == staking,
            "SINGLE_STRATEGY_BINDING_MISMATCH");
        require(address(BeefyVaultV7FixedV2(vault).strategy()) == strategy
            && address(BeefyVaultV7FixedV2(vault).want()) == asset, "SINGLE_VAULT_BINDING_MISMATCH");
        require(BeefyVaultV7FixedV2(vault).withdrawalFeeBps() == withdrawBps, "WITHDRAW_FEE_MISMATCH");
        BeefyVaultV7FixedV2(vault).transferOwnership(OWNER_AND_FEE_RECEIVER);
        emit VaultDeployed(block.chainid, 0, vault, strategy);
    }

    function _deployDualFXN(address staking, address router, address broadcaster, address liquidityGuard)
        internal returns (address vault)
    {
        // Identical nonce order to the former dedicated dual-FXN script:
        // CREATE master, CREATE BoostHub child, CREATE Convex child,
        // CALL configureChildren(), CREATE vault => nonce +4.
        address expectedVault = vm.computeCreateAddress(broadcaster, vm.getNonce(broadcaster) + 4);
        address master = address(new StrategyDualFXNMasterV42(expectedVault, ETH_SDFXN, ETH_FXN, router));
        BaseAllToWantBoostHubV5.Addresses memory a = BaseAllToWantBoostHubV5.Addresses({
            want: ETH_SDFXN, vault: master, swapper: router, adminFeeReceiver: OWNER_AND_FEE_RECEIVER
        });
        BaseAllToWantBoostHubV5.FeeSettings memory boostFees = BaseAllToWantBoostHubV5.FeeSettings({
            totalPerformanceFeeBps: 300, callShareBps: 1000, adminShareBps: 9000
        });
        address boostChild = address(new StrategyBoostHubChildV42(staking, a, boostFees, 1 days, 0));
        BaseAllToWantBoostHubV5.FeeSettings memory convexFees = BaseAllToWantBoostHubV5.FeeSettings({
            totalPerformanceFeeBps: 1300, callShareBps: 1000, adminShareBps: 9000
        });
        address convexChild = address(new StrategyConvexFXNPool8V42(
            FXN_CONVEX_BOOSTER, FXN_SDFXN_CURVE, ETH_FXN, a, convexFees, 1 days, 0
        ));
        StrategyDualFXNMasterV42(master).configureChildren(IYieldChildV42(boostChild), IYieldChildV42(convexChild));
        vault = address(new BeefyVaultV7FixedV2(
            IStrategyBoostHubV1(master), "CurveYield sdFXN", "cysdFXN", 45, OWNER_AND_FEE_RECEIVER
        ));
        require(vault == expectedVault, "DUAL_VAULT_NONCE_MISMATCH");
        require(address(BeefyVaultV7FixedV2(vault).strategy()) == master
            && StrategyDualFXNMasterV42(master).vault() == vault, "DUAL_MASTER_BINDING_MISMATCH");
        require(StrategyBoostHubChildV42(boostChild).vault() == master
            && StrategyConvexFXNPool8V42(convexChild).vault() == master, "DUAL_CHILD_BINDING_MISMATCH");
        if (liquidityGuard != address(0)) {
            StrategyDualFXNMasterV42(master).setConvexCurveLiquidityGuard(liquidityGuard);
            require(address(StrategyConvexFXNPool8V42(convexChild).curveLiquidityGuard()) == liquidityGuard,
                "CURVE_GUARD_NOT_SET");
        }
        BeefyVaultV7FixedV2(vault).transferOwnership(OWNER_AND_FEE_RECEIVER);
        StrategyDualFXNMasterV42(master).transferOwnership(OWNER_AND_FEE_RECEIVER);
        emit VaultDeployed(block.chainid, 1, vault, master);
        emit DualChildVaultDeployed(vault, master, boostChild, convexChild);
    }
}
