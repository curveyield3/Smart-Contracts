// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

// Ethereum-only supplement for EXISTING BoostHub and OmniRouter installations.
// Fresh staking adapters only; existing pool accounting, routes and Hub
// ownership are preserved. The new adapters are appended to Hub allowlists.
import {IBoostHub} from "../contracts/interfaces/IBoostHub.sol";

interface VmEthereumSupplementV41 {
    function readFile(string calldata path) external view returns (string memory);
    function parseJsonBytes(string calldata json, string calldata key) external pure returns (bytes memory);
    function parseJsonString(string calldata json, string calldata key) external pure returns (string memory);
    function parseJsonBytes32(string calldata json, string calldata key) external pure returns (bytes32);
    function startBroadcast() external;
    function stopBroadcast() external;
}

interface IBoostHubOwnerSupplementV41 {
    function owner() external view returns (address);
    function isApprovedDepositor(uint256 pid, address depositor) external view returns (bool);
    function setApprovedDepositors(uint256 pid, address[] calldata depositors, bool[] calldata approvals, bool lockList) external;
}

interface IStakingSupplementV41 {
    function lp_token() external view returns (address);
    function boost_hub() external view returns (address);
    function pid() external view returns (uint256);
    function admin() external view returns (address);
    function fee_receiver() external view returns (address);
    function reward_smoothing_units() external view returns (uint256);
    function name() external view returns (string memory);
}

/// @notice Optional staking-only supplement for EXISTING Ethereum Hub/router.
/// @dev Creates and authorizes sdCRV PID 0 and sdFXN PID 1 staking adapters.
///      Vault deployment is centralized in DeployBoostHubVaultsV57.
contract DeployEthereumSupplementV41 {
    VmEthereumSupplementV41 private constant vm =
        VmEthereumSupplementV41(address(uint160(uint256(keccak256("hevm cheat code")))));

    address private constant SDCRV = 0xD1b5651E55D4CeeD36251c61c50C889B36F6abB5;
    address private constant SDFXN = 0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD;
    address private constant ADMIN_AND_FEES = 0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;
    uint256 private constant SMOOTHING_UNITS = 150; // 15 days; distinct from vault profit unlock

    event NewStaking(uint256 indexed pid, address indexed staking);

    function run(address hub, address router) external returns (address[2] memory staking) {
        require(block.chainid == 1, "ETHEREUM_ONLY");
        require(hub.code.length != 0 && router.code.length != 0, "LIVE_HUB_ROUTER_REQUIRED");
        require(SDCRV.code.length != 0 && SDFXN.code.length != 0, "STAKING_ASSETS_MISSING");
        address broadcaster = msg.sender;
        require(IBoostHubOwnerSupplementV41(hub).owner() == broadcaster, "BROADCASTER_MUST_OWN_HUB");

        string memory artifact = vm.readFile("artifacts/staking.json");
        require(vm.parseJsonBytes32(artifact, ".sourceSha256") == sha256(bytes(vm.readFile("contracts/BoostHubStaking.vy"))), "STAKING_SOURCE_MISMATCH");
        require(keccak256(bytes(vm.parseJsonString(artifact, ".compilerVersion"))) == keccak256("0.4.3"), "STAKING_COMPILER_MISMATCH");
        bytes memory creation = vm.parseJsonBytes(artifact, ".bytecode");
        require(creation.length > 1000, "INVALID_STAKING_BYTECODE");

        address[2] memory assets = [SDCRV, SDFXN];
        string[2] memory stakingNames;
        stakingNames[0] = "CurveYield Boosthub sdCRV Staking";
        stakingNames[1] = "CurveYield Boosthub sdFXN Staking";

        // Verify both pool identities BEFORE broadcasting. Do not assume the PID order on an arbitrary Hub.
        IBoostHub.PoolView[2] memory pools;
        for (uint256 pid; pid < 2; ++pid) {
            pools[pid] = IBoostHub(hub).poolInfo(pid);
            require(pools[pid].asset == assets[pid] && pools[pid].active, "UNEXPECTED_HUB_POOL");
            require(!pools[pid].depositorLocked, "HUB_ALLOWLIST_PERMANENTLY_LOCKED");
        }

        vm.startBroadcast();
        for (uint256 pid; pid < 2; ++pid) {
            address[8] memory rewards;
            uint256 count;
            for (uint256 j; j < pools[pid].rewardTokens.length; ++j) {
                address reward = pools[pid].rewardTokens[j];
                if (reward == assets[pid]) continue;
                require(count < 8, "TOO_MANY_POOL_REWARDS");
                rewards[count++] = reward;
            }
            bytes memory initCode = abi.encodePacked(creation, abi.encode(
                assets[pid], hub, pid, ADMIN_AND_FEES, rewards, ADMIN_AND_FEES, SMOOTHING_UNITS
            ));
            address instance;
            assembly { instance := create(0, add(initCode, 32), mload(initCode)) }
            require(instance != address(0), "STAKING_CREATE_FAILED");
            IStakingSupplementV41 st = IStakingSupplementV41(instance);
            require(st.lp_token() == assets[pid] && st.boost_hub() == hub && st.pid() == pid, "STAKING_BINDING_MISMATCH");
            require(st.admin() == ADMIN_AND_FEES && st.fee_receiver() == ADMIN_AND_FEES, "STAKING_ADMIN_MISMATCH");
            require(st.reward_smoothing_units() == SMOOTHING_UNITS, "STAKING_SMOOTHING_MISMATCH");
            require(keccak256(bytes(st.name())) == keccak256(bytes(stakingNames[pid])), "STAKING_NAME_MISMATCH");
            staking[pid] = instance;
            emit NewStaking(pid, instance);
        }

        // Add one new depositor to each PID. The existing allowlists and pool settings remain unchanged.
        for (uint256 pid; pid < 2; ++pid) {
            address[] memory depositors = new address[](1);
            bool[] memory approvals = new bool[](1);
            depositors[0] = staking[pid];
            approvals[0] = true;
            IBoostHubOwnerSupplementV41(hub).setApprovedDepositors(pid, depositors, approvals, false);
            require(IBoostHubOwnerSupplementV41(hub).isApprovedDepositor(pid, staking[pid]), "STAKING_NOT_APPROVED");
        }

        vm.stopBroadcast();
    }
}
