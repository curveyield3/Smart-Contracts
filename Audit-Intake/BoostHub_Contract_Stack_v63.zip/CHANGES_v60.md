# BoostHub Contract Stack v60 — Default target 20% BoostHub / 80% Convex sdFXN

**Base:** `BoostHub_Contract_Stack_v59.zip` (the v57-derived release; v58 was never used).

## Changed Solidity source

- `contracts/StrategyDualFXNMasterV42.sol`: changed only two default variable initializers:
  - `boostCapBps`: `5_000` -> `2_000` (20% BoostHub).
  - `convexCapBps`: `5_000` -> `8_000` (80% Convex sdFXN/FXN pool-8 child).
- `setAllocationTargets(uint16,uint16)` still allows any owner-configured sum of exactly 10,000 bps, including 0% for either child.
- No other Solidity, Vyper, deployment script, interface, test or workflow is modified.

## Preserved behavior

- Owner-defined target-driven investment of unlocked deposits; existing larger-deficit-first routing.
- Existing single-child-first withdrawal and fallback routing, unchanged.
- No automatic migration; independent owner-directed migration remains available.
- Original Convex FXN/sdFXN price gate, Curve execution guard, custody checks, and exact withdrawal accounting.
- Original vault fee, shares/PPS/APY, profit locks, role checks and rewards.
- All externally callable selectors, events, constructor parameters and storage declarations unchanged relative to v59. Only the initial target storage values differ.

## Other files

- `README.md`: release label and current-version target documentation updated; legacy historical changelog text retained.
- This `CHANGES_v60.md` is newly added.
- `StrategyCurveSDTYearnV6(1).sol` is a separately provided strategy for source-only gas review, **not** part of this BoostHub deployment bundle.

## Verification

- Static ZIP/file integrity and byte-level comparison performed; no new or executed Solidity tests.
- Compilation, benchmarked gas and dynamic equivalence are not established by this change.
