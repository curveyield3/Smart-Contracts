# BoostHub Contract Stack v59 — Owner targets, no absolute caps

**Base:** Original `BoostHub_Contract_Stack_v57(3).zip` (SHA-256 `cb6fd18f5364e797a3fb01049cdb822227d8f9898c029519170344bba149f560`). **v58 is not used.**

## Exact source change: `contracts/StrategyDualFXNMasterV42.sol`

- Renamed the owner setter `setAllocationCaps(uint16,uint16)` to `setAllocationTargets(uint16,uint16)` (ABI selector changes). No alias is retained, per request.
- Targets must sum to **10,000 basis points (100%)**. Either strategy may receive **0%**; there is **no 1% minimum**. Default becomes `5,000/5,000` (same effective 50/50 allocation as v57's normalized `9,900/9,900`).
- Removed the absolute-cap-only `_capacity()` helper and external `allocationHeadroom()` query.
- Removed the cap-clamping statements from `_allocateAvailable()`. Retained the existing target-deficit allocation calculation and ordering.
- Removed cap-only destination checks from the existing owner-only `migrate()` method. Its owner permissions, token accounting, price and Curve guards, and child withdraw/deposit operations are untouched.
- Updated directly relevant comments only. Retained `boostCapBps` / `convexCapBps` public state getter names and `AllocationCapsUpdated` event name to minimize unrelated ABI changes; these legacy names now describe targets, not maximum positions.

## Everything else preserved

- Existing **single-child-first withdrawal** method (`_withdrawForVault()`, `_take()`) is unchanged.
- No migration when owner changes targets; owner-directed `migrate()` remains separate.
- Original FXN/sdFXN peg guard, Convex Curve execution guard, profit locks, vault share accounting, fees, APY, rewards, deployment ordering and constructor ABI remain unchanged.
- Base vault and all four strategy contracts other than the dual-strategy master remain byte-for-byte unchanged.
- No new, modified or executed tests. No deployment or on-chain transactions.

## API changes

- Removed: `setAllocationCaps(uint16,uint16)`, `allocationHeadroom()`.
- Added: `setAllocationTargets(uint16,uint16)`.
- Unchanged: `allocationTargets()`, `boostCapBps()`, `convexCapBps()`, `AllocationCapsUpdated` event, constructor arguments, all other entry points.
- Any frontend/automation previously calling `setAllocationCaps` must call `setAllocationTargets` instead.

## Verification

Static source checks included only in the release process (not as added tests). Compiler status: not established by these source checks. No tests were run.
