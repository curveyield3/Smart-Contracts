// SPDX-License-Identifier: MIT
/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * dApp: https://curveyield.com & https://curveyield.org
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */
pragma solidity ^0.8.20;

// Minimal, source-specific Convex f(x) staking-proxy adapter, NOT the conventional
// Convex Curve Booster.deposit(pid,amount,true) interface.
import "@openzeppelin-4/contracts/token/ERC20/utils/SafeERC20.sol";
import "./BaseAllToWantBoostHubV5.sol";

interface IFXPoolRegistryV42 {
    function poolInfo(uint256) external view returns
        (address implementation, address gauge, address lpToken, address rewards, uint8 active);
}
interface IFXBoosterV42 {
    function poolRegistry() external view returns (address);
    function createVault(uint256 pid) external returns (address);
}
interface IFXStakingProxyV42 {
    function owner() external view returns (address);
    function pid() external view returns (uint256);
    function stakingToken() external view returns (address);
    function gaugeAddress() external view returns (address);
    function deposit(uint256) external;
    function withdraw(uint256) external;
    function getReward() external;
}
interface IFXCurvePoolV42 {
    function coins(uint256 i) external view returns (address);
    function calc_withdraw_one_coin(uint256 lp, int128 index) external view returns (uint256);
    function add_liquidity(uint256[2] calldata amounts, uint256 minMint) external returns (uint256);
    function remove_liquidity_one_coin(uint256 lp, int128 index, uint256 minAmount) external returns (uint256);
}
interface ICurveLiquidityBoundsFXNV49 {
    function quoteDeposit(address pool, uint8 coinIndex, uint256 amount, uint16 slippageBps)
        external view returns (uint256 estimate, uint256 minOut);
    function quoteWithdraw(address pool, uint8 coinIndex, uint256 lpAmount, uint16 slippageBps)
        external view returns (uint256 estimate, uint256 minOut);
}
interface IFXGaugeV42 { function balanceOf(address account) external view returns (uint256); }
interface IFXRewardsV42 {
    function rewardTokenLength() external view returns (uint256);
    function rewardTokens(uint256) external view returns (address);
}

/// @notice sdFXN single-token -> FXN/sdFXN Curve LP -> Convex f(x) pool 8.
/// @dev FXN/sdFXN pool 8 is on Ethereum mainnet; NOT compatible with sdFXS/Fraxtal.
contract StrategyConvexFXNPool8V42 is BaseAllToWantBoostHubV5 {
    using SafeERC20 for IERC20;

    uint256 public constant PID = 8;
    // 0.75% haircut on the external historical-oracle LP estimate; NOT an absolute spot-price cap.
    uint16 public constant CURVE_LP_SLIPPAGE_BPS = 75;
    uint8 public constant WANT_COIN_INDEX = 1;
    int128 private constant WANT_COIN = 1;

    IFXCurvePoolV42 public immutable curvePool;
    ICurveLiquidityBoundsFXNV49 public curveLiquidityGuard;

    event CurveLiquidityGuardUpdated(address indexed previousGuard, address indexed newGuard);
    event EmergencyCurveExit(uint256 lpRedeemed, uint256 underlyingReceived);
    IFXStakingProxyV42 public immutable convexVault;
    IFXGaugeV42 public immutable gauge;
    IFXRewardsV42 public immutable rewardPool;
    address public immutable fxnRewardToken;

    constructor(
        address booster_,
        address curvePool_,
        address fxn_,
        Addresses memory a,
        FeeSettings memory fee,
        uint256 lockDuration,
        uint256 minWantOutput
    ) BaseAllToWantBoostHubV5(a, fee, lockDuration, minWantOutput) {
        require(block.chainid == 1, "ETHEREUM_ONLY");
        require(booster_.code.length != 0 && curvePool_.code.length != 0, "MISSING_CONVEX");
        require(fee.totalPerformanceFeeBps == 1300, "CONVEX_13_PERCENT_FEE");
        IFXCurvePoolV42 pool = IFXCurvePoolV42(curvePool_);
        require(pool.coins(0) == fxn_ && pool.coins(1) == a.want, "BAD_FX_POOL_COINS");
        IFXBoosterV42 booster = IFXBoosterV42(booster_);
        (,,address lp,address poolRewards,uint8 active) = IFXPoolRegistryV42(booster.poolRegistry()).poolInfo(PID);
        require(active != 0 && lp == curvePool_ && poolRewards.code.length != 0, "BAD_CONVEX_PID8");
        address personalVault = booster.createVault(PID);
        require(personalVault != address(0), "NO_CONVEX_VAULT");
        IFXStakingProxyV42 proxy = IFXStakingProxyV42(personalVault);
        require(proxy.owner() == address(this) && proxy.pid() == PID
            && proxy.stakingToken() == curvePool_, "INVALID_CONVEX_PROXY");
        address gaugeAddress = proxy.gaugeAddress();
        require(gaugeAddress.code.length != 0, "INVALID_CONVEX_GAUGE");
        curvePool = pool;
        convexVault = proxy;
        gauge = IFXGaugeV42(gaugeAddress);
        rewardPool = IFXRewardsV42(poolRewards);
        fxnRewardToken = fxn_;
        IERC20(want).forceApprove(curvePool_, type(uint256).max);
        IERC20(curvePool_).forceApprove(personalVault, type(uint256).max);
    }

    /// @notice Master-only guard configuration after deployment. Zero disables guarded LP operations.
    /// @dev Only the master strategy controls this child; the master checks its Ownable owner.
    function setCurveLiquidityGuard(address newGuard) external {
        require(msg.sender == vault, "MASTER_ONLY");
        require(newGuard == address(0) || newGuard.code.length != 0, "INVALID_CURVE_GUARD");
        address previous = address(curveLiquidityGuard);
        curveLiquidityGuard = ICurveLiquidityBoundsFXNV49(newGuard);
        emit CurveLiquidityGuardUpdated(previous, newGuard);
    }

    function _guard() private view returns (ICurveLiquidityBoundsFXNV49 guard) {
        guard = curveLiquidityGuard;
        require(address(guard).code.length != 0, "CURVE_GUARD_NOT_SET");
    }

    function stratName() public pure override returns (string memory) { return "ConvexFXNsdFXNPool8"; }
    function lpBalance() public view returns (uint256) {
        return gauge.balanceOf(address(convexVault)) + IERC20(address(curvePool)).balanceOf(address(this));
    }
    /// @dev Curve's finite-size quote is retained solely for vault NAV accounting;
    ///      it never sets any add/remove liquidity minimum. Those come only from V6.
    function balanceOfPool() public view override returns (uint256) {
        uint256 lp = lpBalance();
        return lp == 0 ? 0 : curvePool.calc_withdraw_one_coin(lp, WANT_COIN);
    }
    function _deposit(uint256 amount) internal override {
        if (amount == 0) return;
        uint256[2] memory amounts;
        amounts[1] = amount;
        (, uint256 minLpOut) = _guard().quoteDeposit(
            address(curvePool), WANT_COIN_INDEX, amount, CURVE_LP_SLIPPAGE_BPS
        );
        require(minLpOut > 0, "GUARD_LP_DUST");
        uint256 beforeLp = IERC20(address(curvePool)).balanceOf(address(this));
        curvePool.add_liquidity(amounts, minLpOut);
        uint256 received = IERC20(address(curvePool)).balanceOf(address(this)) - beforeLp;
        require(received > 0, "NO_LP_RECEIVED");
        convexVault.deposit(received);
    }
    function _withdraw(uint256 amount) internal override {
        // An exact underlying liability is required; never silently deliver less
        // while the upstream vault burns all user shares.
        uint256 wantBal = balanceOfWant();
        for (uint256 n; n < 3 && wantBal < amount; ++n) {
            uint256 idleLp = IERC20(address(curvePool)).balanceOf(address(this));
            uint256 availableLp = gauge.balanceOf(address(convexVault)) + idleLp;
            require(availableLp > 0, "INSUFFICIENT_LP");
            // The external historical-oracle guard, not a Curve spot quote,
            // estimates the LP units needed for this exact-asset withdrawal.
            (uint256 estimatedWant,) = _guard().quoteWithdraw(
                address(curvePool), WANT_COIN_INDEX, availableLp, CURVE_LP_SLIPPAGE_BPS
            );
            require(estimatedWant > 0, "UNPRICEABLE_LP");
            uint256 needed = amount - wantBal;
            // Include 1% headroom on the LP estimate; unused withdrawn sdFXN
            // remains at the strategy for the next withdrawal/deposit.
            uint256 targetLp = (availableLp * needed + estimatedWant - 1) / estimatedWant;
            targetLp = targetLp + targetLp / 100 + 1;
            if (targetLp > availableLp) targetLp = availableLp;
            if (targetLp > idleLp) convexVault.withdraw(targetLp - idleLp);
            (, uint256 minWantOut) = _guard().quoteWithdraw(
                address(curvePool), WANT_COIN_INDEX, targetLp, CURVE_LP_SLIPPAGE_BPS
            );
            require(minWantOut > 0, "GUARD_WANT_DUST");
            curvePool.remove_liquidity_one_coin(targetLp, WANT_COIN, minWantOut);
            // Refresh only after the Curve redemption changes the want balance.
            wantBal = balanceOfWant();
        }
        require(wantBal >= amount, "INSUFFICIENT_SD_FXN_EXIT");
    }
    /// @notice Master-only sdFXN exit without the external Curve liquidity oracle guard.
    /// @dev This bypasses quoteWithdraw/minWantOut, but still requires a complete
    ///      sdFXN exit in atomic units. Curve may return fewer than expected and
    ///      the entire transaction reverts when the requested amount is unavailable.
    ///      No permissionless or external operator can withdraw from the child.
    function emergencyWithdraw(uint256 amount) external {
        require(msg.sender == vault, "MASTER_ONLY");
        uint256 wantBal = balanceOfWant();
        if (wantBal < amount) {
            _withdrawEmergency(amount);
            wantBal = balanceOfWant();
        }
        require(wantBal >= amount, "EMERGENCY_EXIT_SHORTFALL");
        IERC20(want).safeTransfer(vault, amount);
        emit Withdraw(amount);
    }

    function _withdrawEmergency(uint256 amount) private {
        uint256 wantBal = balanceOfWant();
        for (uint256 n; n < 3 && wantBal < amount; ++n) {
            uint256 idleLp = IERC20(address(curvePool)).balanceOf(address(this));
            uint256 availableLp = gauge.balanceOf(address(convexVault)) + idleLp;
            require(availableLp > 0, "INSUFFICIENT_LP");
            // The emergency path uses Curve's live quote for LP sizing only.
            // No external guard oracle quote or oracle-derived minOut is invoked.
            uint256 estimatedWant = curvePool.calc_withdraw_one_coin(availableLp, WANT_COIN);
            require(estimatedWant > 0, "UNPRICEABLE_LP");
            uint256 needed = amount - wantBal;
            uint256 targetLp = (availableLp * needed + estimatedWant - 1) / estimatedWant;
            targetLp = targetLp + targetLp / 100 + 1;
            if (targetLp > availableLp) targetLp = availableLp;
            if (targetLp > idleLp) convexVault.withdraw(targetLp - idleLp);
            uint256 beforeWant = balanceOfWant();
            // Intentionally zero: the caller explicitly invokes the emergency route.
            // Final exact-asset and user-supplied minimum payout checks remain.
            curvePool.remove_liquidity_one_coin(targetLp, WANT_COIN, 0);
            wantBal = balanceOfWant();
            emit EmergencyCurveExit(targetLp, wantBal - beforeWant);
        }
        require(wantBal >= amount, "EMERGENCY_EXIT_SHORTFALL");
    }

    /// @notice Master-directed migration of exactly `gaugeLpUnits` from the
    ///         Convex gauge to single-sided sdFXN. Unlike withdraw(uint256),
    ///         input is in Curve LP / gauge token units, NOT sdFXN units.
    /// @dev Transfers only newly redeemed sdFXN, never unrelated idle balance.
    function withdrawGaugeUnits(uint256 gaugeLpUnits) external returns (uint256 received) {
        require(msg.sender == vault, "!vault");
        require(gaugeLpUnits != 0 && gaugeLpUnits <= gauge.balanceOf(address(convexVault)),
            "GAUGE_UNITS_SHORTFALL");
        uint256 beforeValue = balanceOf();
        (, uint256 minWantOut) = _guard().quoteWithdraw(
            address(curvePool), WANT_COIN_INDEX, gaugeLpUnits, CURVE_LP_SLIPPAGE_BPS
        );
        require(minWantOut > 0 && beforeValue > 0, "LOCKED_OR_DUST_LP");
        uint256 beforeWant = balanceOfWant();
        convexVault.withdraw(gaugeLpUnits);
        curvePool.remove_liquidity_one_coin(gaugeLpUnits, WANT_COIN, minWantOut);
        received = balanceOfWant() - beforeWant;
        require(received != 0 && received <= beforeValue, "LOCKED_LP_WITHDRAWAL");
        IERC20(want).safeTransfer(vault, received);
        emit Withdraw(received);
    }

    function _claim() internal override returns (address[] memory) {
        convexVault.getReward();
        return _swappableRewards();
    }
    function _swappableRewards() internal view override returns (address[] memory tokens) {
        // Include the primary FXN gauge emission plus Convex's dynamic extra
        // reward registry. Duplicate FXN/zero/want entries are ignored.
        uint256 length = rewardPool.rewardTokenLength();
        require(length <= 12, "EXCESS_CONVEX_REWARDS");
        address[] memory list = new address[](length + 1);
        uint256 count = 1;
        list[0] = fxnRewardToken;
        for (uint256 i; i < length; ++i) {
            address token = rewardPool.rewardTokens(i);
            if (token == address(0) || token == want || token == address(curvePool)
                || token == fxnRewardToken) continue;
            bool repeated;
            for (uint256 j; j < count; ++j) if (list[j] == token) repeated = true;
            if (!repeated) list[count++] = token;
        }
        tokens = new address[](count);
        for (uint256 i; i < count; ++i) tokens[i] = list[i];
    }
    function rewardTokens() external view returns (address[] memory) { return _swappableRewards(); }
}
