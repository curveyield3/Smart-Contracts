# Changes v63 — Restore original Beefy economic logic

**Baseline:** BoostHub v62, with exact original calculations from v61 restored.

- Preserve all ERC-4626 functions and public read methods introduced in v62: `asset`, `totalAssets`, `convertToAssets`, `convertToShares`, `previewDeposit`, `previewMint`, `previewWithdraw`, `previewRedeem`, `maxDeposit`, `maxMint`, `maxWithdraw`, `maxRedeem`, `deposit(uint256,address)`, `mint(uint256,address)`, `withdraw(uint256,address,address)`, `redeem(uint256,address,address)`.
- Restore the v61 `convertToAssets` formula exactly: zero-supply returns shares, otherwise `shares * balance() / totalSupply()`. It is public only so added preview adapters can call it internally.
- Restore v61 deposit fees, real received-token deltas, net-NAV-based share minting `(amount * supply) / preDepositPool`, and APY checkpoint timing. No new deposit slippage or caps.
- Restore v61 withdrawal gross value `(balance() * shares) / supply`, fee and admin split, exact strategy settlement, retained-profit locking, emergency minimum-out and APY timing.
- Restore original `depositAll` and `withdrawAll` entrypoints as calls to the original single-argument functions.
- The new ERC-4626 entrypoints retain receiver/owner handling and their required net-assets/exact-shares routing. The original single-argument deposit/withdraw routes use exactly the v61 formulas and full net settlement.
- No other contract, strategy, deployment script or pre-v63 documentation modified.

**Qualification:** ERC-4626 previews for deposits cannot predict actual Curve execution losses; mint can revert if the post-investment NAV does not satisfy requested shares. ERC exact-assets withdraw rejects a final-share rounding surplus that would strand assets; the original legacy full withdrawal and ERC `redeem()` continue to pay the complete net value. These are standard-interface compatibility limitations, not changes to legacy economics.

**Verification:** static source comparison and ZIP integrity only. No tests, compilation, fork simulation or deployment performed for this v63 release.
