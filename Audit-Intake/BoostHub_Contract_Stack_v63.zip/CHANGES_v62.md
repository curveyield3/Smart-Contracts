# BoostHub Contract Stack v62 — ERC-4626 entrypoints

Built from exact v61 baseline; only `contracts/BeefyVaultV7FixedV2.sol` changes in Solidity.

- Adds ERC-4626 `totalAssets`, `convertToShares`, `previewDeposit`, `previewMint`, `previewWithdraw`, `previewRedeem`, `maxDeposit`, `maxMint`, `maxWithdraw`, `maxRedeem`, `deposit(uint256,address)`, `mint(uint256,address)`, `withdraw(uint256,address,address)`, and `redeem(uint256,address,address)`.
- Adds ERC-4626 Deposit and Withdraw events; preserves Beefy `deposit(uint256)`, `withdraw(uint256)`, `depositAll`, `withdrawAll`, and emergency withdrawal selectors.
- Supports third-party share redemption with ERC-20 allowances and independent receiver/owner.
- Retains exact post-investment NAV-based issuance, configured deposit fee, immutable withdrawal fee and 30/70 share retention (100% admin on final share).
- Reconciles preview math with fee rounding, reverts exact-share mint if real conversion slippage prevents issuing all requested shares.
- The ERC-4626 deposit preview is an ideal NAV estimate; realized investment conversion loss can mint fewer shares. Therefore strict preview underestimation cannot be guaranteed with present strategy interfaces; require fork and production-interface verification before calling the vault strictly EIP-4626 compliant.
- No changes to APY or strategy implementations. No chain deployment.
