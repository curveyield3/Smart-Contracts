# BoostHub Contract Stack v57 — infrastructure / vault deployments separated

## Primary operational change

1. `script/DeployBoostHubStack.s.sol` now performs **only** Hub/CREATE3 factory, two Ethereum or one Fraxtal staking adapters, Hub pool/depositor/fee configuration, and OmniRouter deployment / route configuration. It no longer constructs *any* custom vault, strategy, or official Beefy partner pair. Existing router-oracle preflights remain; obsolete partner-factory dependencies were removed from the infrastructure preflight.
2. **New** `script/DeployBoostHubVaultsV57.s.sol` is the single authoritative vault-only entrypoint. Per-chain deployment requirements: Ethereum PID 0 cysdCRV single BoostHub strategy and PID 1 cysdFXN dual master with BoostHub/Convex children; Fraxtal PID 0 cysdFXS single BoostHub strategy. Each uses `BeefyVaultV7FixedV2` including its existing on-chain 10-slot APY facility.
3. Both legacy supplements `DeployEthereumSupplementV41.s.sol` and `DeployFraxtalSupplementV40.s.sol` are now **staking-adapter-only**. They still verify matching pools, create the Vyper staking adapters and add them to the existing Hub depositor allowlists, but no longer deploy vaults or strategies.
4. Removed the older `DeployDualFXNPool8V42.s.sol`, superseded by `DeployBoostHubVaultsV57.s.sol`. No second single-strategy sdFXN vault deployment path remains.

## Preserved behavior

- sdCRV: 0.35% withdraw fee, 3% performance fee with 10% caller share of that performance fee, 24h strategy profit lock.
- sdFXN: 0.45% withdraw fee, two children (BoostHub 3% fee, Convex 13% fee), 24h profit locks, owner percentage allocation, original >0.969 FXN peg guard and external Curve execution guard, optional initial guard binding. If guard is missing Convex deposits remain blocked until it is configured.
- sdFXS: 0.30% withdraw fee, 3% performance fee with 3% caller share, 24h strategy profit lock.
- Hub/staking reward paths, Vyper source binding, source-bound artifact checks, infrastructure router settings and ownership mechanisms are not changed.
- Vault-only PPS APY checkpoints, `getAPY()` and `updateAPY()`, user-triggered update checks, emergencyWithdraw() are unchanged. All child APR histories were removed in prior releases and remain absent.
- Legacy Beefy partner source and helpers remain archived in `beefy-partner/` but are not constructed by either v57 entrypoint.

## Deployment prerequisites and caveats

- Deploy or identify a valid Hub/router/staking for the chain **before** invoking the vault script; all adapters must already be approved Hub depositors.
- All vault deployments use the nonce-predicting broadcasting EOA. Single vault CREATE order: strategy then vault. Dual sdFXN CREATE order: master, BoostHub child, Convex child, configureChildren EOA CALL, then vault. Do not interleave other broadcasts.
- The v57 vault script must be invoked once per chain: 2 Ethereum PIDs and 1 Fraxtal PID. No vaults were deployed in preparing this package.
- The original full-stack constructor salt and owner setting are unchanged. Its Hub CREATE3 salt may already be consumed on a chain; do **not** attempt to rerun it against an already-deployed Hub. Instead use existing infrastructure and the vault-only script.
- No tests created, edited or executed. Compilation pending. No Ethereum or Fraxtal transactions broadcast.
