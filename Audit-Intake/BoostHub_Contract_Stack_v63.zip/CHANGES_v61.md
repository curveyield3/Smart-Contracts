# BoostHub Contract Stack v61 — Source-level gas optimizations 2–6

**Base:** exact v60 release ZIP `BoostHub_Contract_Stack_v60.zip`. The release is a fresh-deployment source artifact, not a deployed contract upgrade. This package does not use v58.

## Modified production source (only two files)

### `contracts/StrategyDualFXNMasterV42.sol`

- **2 — Deposit:** `_allocateAvailable()` now reads the master want balance once and each child's net balance and locked profit once. The gross TVL and per-child deficits derive from that single pre-mutation snapshot. Deleted now-unused private `_grossAssets()` and `_unlockedIdle()` helpers.
- **3 — Withdrawal:** `_withdrawForVault()` captures child net NAV once for the original solvency ceiling and subsequent priority calculation. Child profit locks are queried only when investments must be redeemed, and counted toward gross allocation targets as before. `_take()` accepts its pre-transaction available NAV; the second child is freshly read after the first child withdrawal changes external state. The same snapshot is also used in owner-only BoostHub-to-Convex manual migrations without changing the migration rules.
- **5 — Deposit Convex eligibility:** the existing `convexEligible()` FXN price/guard check runs only for a positive Convex allocation deficit. If Convex would receive zero capital, that irrelevant preflight is skipped; if Convex would receive capital, the original check and original blocked-deposit behavior remain.
- **6 — Target arithmetic:** `_targetBalances()` divides by constant `MAX_BPS = 10_000`. `allocationTargets()` returns the two owner-set BPS values directly. The existing owner setter already enforces their sum equals 10,000.

### `contracts/StrategyConvexFXNPool8V42.sol`

- **4 — Withdrawals:** normal and emergency loops each snapshot idle Curve LP, gauge LP and current want balance per round instead of repeating unchanged external calls. Want balance is refreshed after each actual Curve redemption; `EmergencyCurveExit` retains its accurate pre-/post-transaction balance delta. The normal path still uses both original external Curve guard `quoteWithdraw()` calls; their outputs feed the same exact sizing and Curve `minOut` parameters. The emergency path remains a deliberately distinct guard-bypass route.

## Unchanged behavior and ownership

- Initial target remains 2,000/8,000 bps; either child may be set to 0%; percentages must sum to 10,000.
- Deposits still invest the larger target shortfall first. Withdrawals retain the **single-child-first** approach and use the second child only for an unsatisfied remainder. No new target-capping withdrawal math.
- Vault full-PPS NAV, fee accounting, APY, reward conversion, profit locks, exact user settlement, unauthorized-caller checks and owners unchanged.
- The existing Convex FXN peg check, 75-bps external Curve min-output guard, and manual migration output guards remain intact.
- No changes to public/external function names, parameter types, events, storage declarations, constructors, other contracts, scripts, interfaces, Vyper, tests or Foundry profile.

## Separate SDT/Yearn optimization

Review item **7** is implemented separately in `StrategyCurveSDTYearnV8.sol` (successor to independent SDT/Yearn strategy v7); its source is **not merged** into this BoostHub stack.

## Verification status

- v60-to-v61 source diffs inspected; bytewise comparison verifies the two named Solidity sources and README changed, plus this new versioned changelog; all remaining v60 entries retained intact.
- No tests created, modified, or executed. No deployment or broadcast.
- **Compilation and execution gas are not established.** The available GitHub BoostHub benchmark workflow performs Anvil executions and is not suitable for a no-tests request. This release makes no quantified gas savings claim.
