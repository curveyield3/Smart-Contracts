# cyavKAT unified Hardhat deployment v1

## Entrypoint and semantics

There is **one simulator-discoverable deployment entrypoint**:

`npx hardhat run --no-compile scripts/deploy-cyavkat-unified-v1.cjs --network localhost`

The entrypoint consolidates execution ordering, Quest mode discovery, signer identity, RPC binding, Merkl preflight, phase failure handling, and transaction evidence into **one Hardhat-controlled process**. It deliberately delegates Solidity create/configure transactions to the source-faithful Foundry scripts now stored under `internal/`, because the v25 scripts rely on Forge cheatcodes and complex IPOR configuration. This is *not* a pure Hardhat/ethers rewrite of those transactions; Forge must be available on the GitHub runner. There is no second publicly discoverable auto-deploy script. Hardhat's Solidity source directory is empty by design and Forge compiles the original contracts using `foundry.toml` settings.

The complete migration consists of: `K1_QuestSigning`, `P0_00_DeployGateConfig`, `P2_00_VerifyQuestSigning`, `P2_01_Deploy`, `P2_02_ConfigureVault`, `P2_03_Cutover`, `merkl_preflight_v6`, `P2_04_RemoveV1Fuses`, `P3_03_DeployGovernanceCore`, `P3_04_ConfigureGate`, `P5_01_DeployPol`, `P3_05_Handover`, `P6_01_CustodyV2Migration`, `L10_RouteWrapperFeesToCustodyV2`, `P9_FinalizeFeeAuthority`.

The `L1`/`L2`/`L3`/`L5`/`L5b`/`L6`/`L7`/`L8`/`L9` prior market migrations and `P3_99_Rollback` are not part of the current cutover. They remain under `internal/` as source dependencies and historical operational code, not auto-run phases.

## Legacy withdrawal request policy

The 130-day Anvil time jump and `pruneExpiredRequests(500)` have been **eliminated**. The `P2_03_Cutover` source no longer rejects nonzero `activeRequestedShares()`, `getSharesToRelease()`, or old-manager fee-share balances. The fork test fixture no longer stubs the old manager or artificially transfers fee shares to pass cutover.

**Important:** accepting outstanding old-manager requests does not mean they can necessarily be redeemed afterward. `CurveYieldRequestFeeSharesFuse._configureAllowance` still revokes the prior manager's underlying-asset allowance; the old controller's ALPHA role is also revoked. This remains an operational compatibility risk that must be separately tested. The deployment script **does not** silently preserve legacy unlimited spending authority or claim customer withdrawals are protected.

Other prerequisites are still enforced by the original script logic: Quest V2, fee registry, market map, vKAT locks, price sources, external Merkl claimability, fee role routing, governance authority, and all phase postconditions. A failed stage is a hard failure, not a skipped step.

## GitHub Actions / Katana simulator invocation

1. Run in **GitHub Actions**, not locally: install Foundry and Hardhat 2.26.3 in the runner environment.
2. Extract the source package and verify its SHA-256. Work from `cyavKAT/upgrade`.
3. Start one Anvil fork from trusted Katana state: `anvil --fork-url "$RPC_KATANA" --chain-id 747474 --auto-impersonate --host 127.0.0.1 --port 8545`.
4. Fund the **local fork-only** deployer using `anvil_setBalance`.
5. Execute `npm install --ignore-scripts --no-audit --no-fund`, `forge build --skip test --build-info`, then the Hardhat command above.
6. Gate `CYAVKAT_UNIFIED_HARDHAT_DEPLOYMENT_v1.json.status == "PASS"` and inspect phase logs, on-chain receipts, deployed addresses, and `out/` build artifacts. Failed or missing receipts block the gate.

The workflow in the companion `katana-cyavkat-unified-hardhat-workflow_v1.yml` implements these steps, with a 90-minute job guard and artifact persistence on success or failure.

## Required environment

- `LOCALHOST_RPC_URL=http://127.0.0.1:8545` (or `ETH_RPC_URL` / `RPC_URL` pointing at the **same local Anvil**).
- `UNIFIED_DEPLOY_OUTPUT=...` optional evidence directory.
- GitHub-provided upstream Katana RPC (only for the **Anvil fork creation**, never the Hardhat/Forge broadcast target).

The runner will reject a non-loopback RPC, non-Anvil client, non-Katana chain ID, or missing vault bytecode. Production `PRIVATE_KEY` values are scrubbed. It only calls `eth_sendTransaction` on a local Anvil fork; **there is no live-chain mode**.

## Simulator compatibility

The Contract-Automation Phase 0 script inventory detects `scripts/deploy-cyavkat-unified-v1.cjs` as the single Hardhat candidate, discovers a mechanically bound `localhost` network, and no longer detects original Foundry scripts under `internal/`. The generic **Ethereum-only** Phase 0 runner still insists on Ethereum chain ID 1; it must **not** run this Katana deployment or be told the Katana deployment used Ethereum. Instead, run the provided Katana-specific GitHub Actions workflow and consume the generated evidence.

## Verification performed

- Node.js static syntax checks for the Hardhat entrypoint and config.
- Entrypoint `--self-test`: checks phase order, mandatory scripts, Merkl preflight, absence of all three legacy cutover blockers.
- Static simulator discovery reproduction: exactly one safe Hardhat deployment candidate and zero Foundry auto-run candidates.
- ZIP integrity check and source manifest hash comparison when packaged.

Neither Solidity compilation nor Anvil transaction simulation is claimed to have been executed locally.
