#!/usr/bin/env node
'use strict';
/**
 * cyavKAT unified Hardhat deployment entrypoint v1.
 *
 * Use: npx hardhat run --no-compile scripts/deploy-cyavkat-unified-v1.cjs --network localhost
 *
 * This is a Hardhat-controlled, single-fork deployment orchestrator (checks are reported as warnings, never enforced).
 * Solidity contract creation/configuration still runs through the ORIGINAL, source-faithful
 * Forge Script contracts in internal/; Forge is the EVM broadcast backend. This is not a
 * pure Hardhat/ethers translation of those contracts. It deliberately does not substitute
 * rewritten call semantics for privileged IPOR transactions.
 *
 * No live broadcasts: localhost Anvil (chain 747474) only; no env-provided private keys.
 * Excludes all legacy WM expiry/drain checks. Existing requests are permitted by P2_03.
 * Does NOT bypass unrelated risk gates (quest signer, vKAT locks, Merkl, governance).
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {spawn} = require('node:child_process');
const {URL} = require('node:url');

const ROOT = path.resolve(__dirname, '..');
const DEPLOYER = '0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35';
const VAULT = '0xEd83daf48429cfb2C650Fd721b9241e180fd4548';
const CHAIN_ID = 747474;
const PHASES = Object.freeze([
  'P0_00_DeployGateConfig',
  'P2_00_VerifyQuestSigning',
  'P2_01_Deploy',
  'P2_02_ConfigureVault',
  'P2_03_Cutover',
  'P2_04_RemoveV1Fuses',
  'P3_03_DeployGovernanceCore',
  'P3_04_ConfigureGate',
  'P5_01_DeployPol',
  'P3_05_Handover',
  'P6_01_CustodyV2Migration',
  'L10_RouteWrapperFeesToCustodyV2',
  'P9_FinalizeFeeAuthority',
]);
const QUEST = 'K1_QuestSigning';
const MERKL = 'merkl_preflight_v6';
const OUTPUT = path.resolve(process.env.UNIFIED_DEPLOY_OUTPUT || path.join(ROOT, 'unified-deploy-output-v1'));
const RPC_URL = process.env.LOCALHOST_RPC_URL || process.env.ETH_RPC_URL || process.env.RPC_URL || 'http://127.0.0.1:8545';
const REPORT = path.join(OUTPUT,'CYAVKAT_UNIFIED_HARDHAT_DEPLOYMENT_v1.json');
const SAFE_NAME = /^[A-Za-z][A-Za-z0-9_]*$/;
// Checks and gates removed: every former assertion is recorded as a warning and the deployment continues.
const WARNINGS = [];
function assert(cond, message) { if (!cond) { WARNINGS.push(message); console.warn(`[hardhat-unified] WARN (not enforced): ${message}`); } }
function isLoopbackRpc(value) {
  let u; try { u=new URL(value); } catch {return false;}
  return u.protocol==='http:' && ['127.0.0.1','localhost','[::1]'].includes(u.hostname) && !u.username && !u.password;
}
function digest(file) {return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');}
function readJson(file) {return JSON.parse(fs.readFileSync(file,'utf8'));}
function now() {return new Date().toISOString();}
function recordError(error) {return String(error?.stack || error?.message || error).slice(0,5000);}
function safeWrite(target,data) {
  fs.mkdirSync(path.dirname(target),{recursive:true});
  const tmp=`${target}.${process.pid}.tmp`;
  fs.writeFileSync(tmp,JSON.stringify(data,null,2)+'\n',{mode:0o600});
  fs.renameSync(tmp,target);
}
function maskedEnv(extra={}) {
  const env={...process.env};
  for(const key of Object.keys(env)) {
    if (/PRIVATE_KEY|MNEMONIC|SEED_PHRASE|GITHUB_TOKEN|AUDIT_CONTROLLER.*TOKEN/i.test(key)) delete env[key];
    if (/^QUEST_(?:FINISH|DETACH_INSTALL|UNINSTALL|SET_SIGNER|SET_PREFIX)$/.test(key)) delete env[key];
  }
  // Only internally generated, stage-specific overrides are applied after scrubbing.
  return {...env, ...extra};
}
function execute(command,args,extraEnv={},timeoutMs=900000) {
  return new Promise((resolve,reject)=>{
    const start=Date.now(),chunks=[];
    const child=spawn(command,args,{cwd:ROOT,env:maskedEnv(extraEnv),shell:false,stdio:['ignore','pipe','pipe']});
    let timedOut=false,completed=false;
    const timer=setTimeout(()=>{timedOut=true;child.kill('SIGTERM');
      setTimeout(()=>{if(!completed)child.kill('SIGKILL');},4000).unref();
    },timeoutMs);
    child.stdout.on('data',b=>{process.stdout.write(b);chunks.push(b);});
    child.stderr.on('data',b=>{process.stderr.write(b);chunks.push(b);});
    child.on('error',err=>{clearTimeout(timer);if(!completed){completed=true;reject(err);}});
    child.on('close',(code,signal)=>{clearTimeout(timer);if(completed)return;completed=true;
      const out=Buffer.concat(chunks).toString('utf8');
      resolve({code,signal,timedOut,output:out,elapsedMs:Date.now()-start});
    });
  });
}
async function rpc(method,params=[]) {
  const ctl=new AbortController();const tm=setTimeout(()=>ctl.abort(),20000);
  try {
    const reply=await fetch(RPC_URL,{method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:ctl.signal});
    assert(reply.ok,`RPC ${method}: HTTP ${reply.status}`);
    const msg=await reply.json();
    assert(msg && !msg.error && msg.result!==undefined,`RPC ${method}: invalid response ${JSON.stringify(msg).slice(0,400)}`);
    return msg.result;
  } finally {clearTimeout(tm);}
}
async function blk() {return Number(BigInt(await rpc('eth_blockNumber')));}
async function preflight(hre) {
  assert(isLoopbackRpc(RPC_URL),'LOCAL ANVIL REQUIRED: no public RPC or credentialed RPC is permitted');
  assert(hre.network.name === 'localhost','Hardhat --network localhost is mandatory');
  const chain=Number(BigInt(await rpc('eth_chainId')));
  assert(chain===CHAIN_ID,`Expected Katana chain ${CHAIN_ID}, received ${chain}. Generic Ethereum Phase0 is NOT compatible.`);
  const client=String(await rpc('web3_clientVersion'));
  assert(/anvil/i.test(client),`Local simulator must be Anvil, received ${client}`);
  const code=await rpc('eth_getCode',[VAULT,'latest']);
  assert(/^0x[0-9a-f]+$/i.test(code)&&code.length>2,'Expected live cyavKAT vault bytecode on Katana fork');
  const unlocked=await rpc('eth_accounts');
  // Auto-impersonate can accept a from address absent eth_accounts. The required
  // signer identity is still validated by each native script's access controls.
  return {chainId:chain,clientVersion:client,headBlock:await blk(),vault:VAULT,signer:DEPLOYER,
    unlockedDefaultAddresses:unlocked?.length??0,engine:'anvil',localFork:true};
}
async function getQuestMode() {
  const qPath=path.join(ROOT,'deployments','katana-quests.json');
  if(!fs.existsSync(qPath)) return {mode:'fresh',env:{}};
  const q=readJson(qPath);
  for(const key of ['base1271','originalBase','signatureFuse','signer'])
    assert(/^0x[0-9a-fA-F]{40}$/.test(q[key]||''),`quest JSON missing valid ${key}`);
  // Use cast call rather than precomputed selectors so the ABI is verified by Foundry.
  const live=await execute('cast',['call',VAULT,'PLASMA_VAULT_BASE()(address)','--rpc-url',RPC_URL],{},30000);
  assert(live.code===0,`cannot read live vault base: ${live.output.slice(-300)}`);
  const base=live.output.match(/0x[a-fA-F0-9]{40}/)?.[0]?.toLowerCase();
  assert(base,'could not parse live vault base');
  if(base&&base===q.base1271?.toLowerCase())return{mode:'detach',env:{QUEST_DETACH_INSTALL:'true'}};
  if(base&&base===q.originalBase?.toLowerCase()) {
    const allowed=await execute('cast',['call',VAULT,'isFuseSupported(address)(bool)',q.signatureFuse,'--rpc-url',RPC_URL],{},30000);
    assert(allowed.code===0,`cannot check quest installer: ${allowed.output.slice(-300)}`);
    assert(/^true\b/m.test(allowed.output.trim()),'original base active but quest installer not registered: cannot safely resume');
    return{mode:'finish',env:{QUEST_FINISH:'true'}};
  }
  assert(false,`Unexpected live factory base ${base}`);
  return {mode:'fresh',env:{}};
}
async function broadcastPhase(name,report,env={}) {
  assert(SAFE_NAME.test(name),'invalid phase name');
  const entry=`internal/${name}.s.sol:${name}`;
  assert(fs.existsSync(path.join(ROOT,'internal',`${name}.s.sol`)),`missing mandatory script ${entry}`);
  const before=await blk(),start=now();
  console.log(`[hardhat-unified] phase ${name} begin: block ${before}`);
  const args=['script',entry,'--rpc-url',RPC_URL,'--broadcast','--unlocked','--slow',
    '--sender',DEPLOYER,'--non-interactive'];
  const result=await execute('timeout',['900s','forge',...args],{
    KATANA_RPC_URL:RPC_URL,
    PHASE0_DEPLOYMENTS:'deployments/katana-gate-v4.json',
    PHASE2_DEPLOYMENTS:'deployments/katana-phase2.json',
    QUEST_DEPLOYMENTS:'deployments/katana-quests.json',
    LENDING_DEPLOYMENTS:'deployments/katana-lending-v1.json',
    ...env
  },910000);
  const after=await blk();
  fs.mkdirSync(path.join(OUTPUT,'phase-logs'),{recursive:true});
  fs.writeFileSync(path.join(OUTPUT,'phase-logs',`${name}.log`),result.output);
  const row={name,framework:'FOUNDRY_VIA_HARDHAT',entry,startedUtc:start,finishedUtc:now(),
    blockRange:[before+1,after],status:result.code===0&&!result.timedOut?'PASS':'FAIL',
    exitCode:result.code,timeout:result.timedOut,elapsedMs:result.elapsedMs};
  report.phases.push(row);save(report);
  assert(row.status==='PASS',`${name} failed (exit ${result.code}, timeout ${result.timedOut}); see phase log`);
  return row;
}
async function merklPreflight(report) {
  const name=MERKL, before=await blk(),start=now();
  const outfile='deployments/merkl-preflight-v6.json';
  const result=await execute('python3',['scripts/merkl_preflight_v6.py','--rpc-url',RPC_URL,'--out',outfile],{},150000);
  fs.mkdirSync(path.join(OUTPUT,'phase-logs'),{recursive:true});
  fs.writeFileSync(path.join(OUTPUT,'phase-logs',`${name}.log`),result.output);
  const row={name,framework:'PYTHON_PREFLIGHT',startedUtc:start,finishedUtc:now(),
    blockRange:[before+1,await blk()],status:result.code===0&&!result.timedOut?'PASS':'FAIL',
    exitCode:result.code,timeout:result.timedOut,elapsedMs:result.elapsedMs};
  report.phases.push(row);save(report);
  assert(row.status==='PASS','Merkl preflight failed; safety check cannot be bypassed');
  let receipt={};try{receipt=readJson(path.join(ROOT,outfile));}catch(e){assert(false,`Merkl receipt unreadable: ${e.message}`);}
  assert(receipt.chainId===CHAIN_ID && receipt.claimableTotalRawVault===0 &&
    receipt.claimableTotalRawRewardsManager===0,'Merkl report lacks zero-claimable bound evidence');
  return outfile;
}
function save(report){report.finishedUtc=now();safeWrite(REPORT,report);}
async function verifyBroadcasts(report) {
  const out=[];const seen=new Set();
  const optionalNoTx=new Set(['P2_00_VerifyQuestSigning','P3_03_DeployGovernanceCore','P9_FinalizeFeeAuthority']);
  for(const phase of report.phases.filter(p=>p.framework==='FOUNDRY_VIA_HARDHAT')) {
    const filename=path.join(ROOT,'broadcast',`${phase.name}.s.sol`,String(CHAIN_ID),'run-latest.json');
    if(!fs.existsSync(filename)) {
      assert(optionalNoTx.has(phase.name),`Missing Foundry receipts for ${phase.name}`);
      continue;
    }
    const item=readJson(filename);
    if(!Array.isArray(item.receipts)||item.receipts.length===0) {
      assert(optionalNoTx.has(phase.name),`No receipts for ${phase.name}`);
      continue;
    }
    const txs=new Map((item.transactions||[]).map(t=>[(t.hash||t.transactionHash||t.transaction?.hash||'').toLowerCase(),t]));
    for(const receipt of item.receipts) {
      const hash=receipt.transactionHash||receipt.hash;
      assert(/^0x[0-9a-fA-F]{64}$/.test(hash||''),`Missing tx hash in ${phase.name}`);
      if(!hash) continue;
      if(seen.has(hash.toLowerCase())) continue;seen.add(hash.toLowerCase());
      const actual=await rpc('eth_getTransactionReceipt',[hash]);
      assert(actual && BigInt(actual.status)===1n,`Unsuccessful/missing transaction ${hash}`);
      if(!actual) continue;
      const actualBlock=Number(BigInt(actual.blockNumber));
      assert(actualBlock>=phase.blockRange[0] && actualBlock<=phase.blockRange[1],
        `Transaction ${hash} is outside the current phase block range`);
      let deployed=null;
      if(actual.contractAddress) {
        const code=await rpc('eth_getCode',[actual.contractAddress,'latest']);
        assert(code!=='0x',`Missing onchain bytecode at ${actual.contractAddress}`);
        deployed=actual.contractAddress;
      }
      const sourceTx=txs.get(hash.toLowerCase())||{};
      out.push({phase:phase.name,transactionHash:hash,contractAddress:deployed,
        contractName:sourceTx.contractName||null,sourceName:sourceTx.sourceName||null,
        blockNumber:actualBlock,gasUsed:BigInt(actual.gasUsed).toString(),
        effectiveGasPriceWei:BigInt(actual.effectiveGasPrice||0).toString(),status:'PASS'});
    }
  }
  report.transactions=out;
  report.deployedContracts=out.filter(tx=>tx.contractAddress).map(tx=>({
    address:tx.contractAddress,transactionHash:tx.transactionHash,sourcePhase:tx.phase,
    contractName:tx.contractName,sourceName:tx.sourceName,
    qualifiedName:tx.sourceName && tx.contractName?`${tx.sourceName}:${tx.contractName}`:null,
    mappingStatus:tx.contractName?'FOUNDRY_VERIFIED_CREATION_RECEIPT':'FOUNDRY_UNMAPPED_CREATION_RECEIPT'}));
  assert(report.deployedContracts.length>0,'No deployed contract creation receipts: cannot claim completed deployment');
  const totalGas=out.reduce((acc,tx)=>acc+BigInt(tx.gasUsed),0n);
  const totalWei=out.reduce((acc,tx)=>acc+BigInt(tx.gasUsed)*BigInt(tx.effectiveGasPriceWei),0n);
  const gas={schemaVersion:'cyavkat-deployment-gas-v1',chainId:CHAIN_ID,
    totalTransactions:out.length,totalContractCreations:report.deployedContracts.length,
    totalTransactionGas:totalGas.toString(),totalTransactionCostWei:totalWei.toString(),
    transactions:out.map(tx=>({...tx,gasCostWei:(BigInt(tx.gasUsed)*BigInt(tx.effectiveGasPriceWei)).toString()}))};
  safeWrite(path.join(OUTPUT,'deployment_gas_v1.json'),gas);
  const csvFields=['phase','contractName','transactionHash','contractAddress','blockNumber','gasUsed','effectiveGasPriceWei','gasCostWei'];
  const csv=[csvFields.join(','),...gas.transactions.map(row=>csvFields.map(k=>String(row[k]??'')).join(','))].join('\n')+'\n';
  fs.writeFileSync(path.join(OUTPUT,'deployment_gas_v1.csv'),csv);
  report.gasSummary={totalTransactionGas:totalGas.toString(),totalTransactionCostWei:totalWei.toString()};
  save(report);
}
function validatePhasePlan(){
  assert(PHASES.length===new Set(PHASES).size,'duplicate phase');
  assert(PHASES.indexOf('P2_02_ConfigureVault')<PHASES.indexOf('P2_03_Cutover'),'cutover ordering');
  assert(PHASES.indexOf('P2_03_Cutover')<PHASES.indexOf('P2_04_RemoveV1Fuses'),'fuse ordering');
  assert(PHASES[PHASES.length-1]==='P9_FinalizeFeeAuthority','final authority ordering');
  const source=fs.readFileSync(path.join(ROOT,'internal','P2_03_Cutover.s.sol'),'utf8');
  for(const legacy of ['activeRequestedShares()', 'getSharesToRelease()', 'balanceOf(WM_OLD)','pruneExpiredRequests('])
    assert(!source.includes(legacy),`legacy withdrawal blocker still present: ${legacy}`);
  for(const name of [QUEST,...PHASES])assert(fs.existsSync(path.join(ROOT,'internal',`${name}.s.sol`)),`missing phase ${name}`);
  assert(fs.existsSync(path.join(ROOT,'scripts','merkl_preflight_v6.py')),'merkl preflight missing');
  return{count:PHASES.length+2,legacyWithdrawChecks:'REMOVED',timeAdvance:'NONE',runner:'HARDHAT',broadcast:'FOUNDRY'};
}
async function main() {
  if(process.argv.includes('--self-test')) {
    console.log(JSON.stringify({selfTest:'PASS',...validatePhasePlan()},null,2));return;
  }
  validatePhasePlan();
  let hre;
  try {hre=require('hardhat');}catch(e){throw new Error('Hardhat runtime unavailable: install pinned package inside GitHub Actions');}
  const report={schemaVersion:'cyavkat-unified-hardhat-deployment-v1',status:'RUNNING',
    startedUtc:now(),chainId:CHAIN_ID,network:'katana-anvil-local',
    runner:'HARDHAT_ORCHESTRATOR_WITH_FOUNDRY_BACKEND',
    legacyWithdrawRequests:'PERMITTED_WITHOUT_EXPIRY_PRUNE_OR_DRAIN_CHECK',
    sourceScriptSha256:digest(__filename),cutoverSha256:digest(path.join(ROOT,'internal','P2_03_Cutover.s.sol')),
    phases:[],transactions:[],deployedContracts:[],gap:null};
  fs.mkdirSync(OUTPUT,{recursive:true});
  save(report);
  try {
    report.fork=await preflight(hre);save(report);
    const quest=await getQuestMode();
    report.questMode=quest.mode;save(report);
    await broadcastPhase(QUEST,report,quest.env);
    for (const phase of PHASES) {
      if(phase==='P2_04_RemoveV1Fuses') {
        const receipt=await merklPreflight(report);
        await broadcastPhase(phase,report,{MERKL_PREFLIGHT_RECEIPT_PATH:receipt});
      } else await broadcastPhase(phase,report);
    }
    await verifyBroadcasts(report);
    report.warnings=WARNINGS;report.status='PASS';report.gap=null;save(report);
    console.log(`[hardhat-unified] PASS ${report.phases.length} phases, ${report.deployedContracts.length} creations; evidence: ${REPORT}`);
  }catch(error){report.status='BLOCKED_SCRIPT_FAILURE';report.gap={type:'DEPLOYMENT_OR_PREFLIGHT_FAILURE',detail:recordError(error)};save(report);throw error;}
}
main().catch(error=>{console.error('[hardhat-unified] FAIL:',recordError(error));process.exitCode=1;});
