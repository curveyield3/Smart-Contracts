// cyavKAT Hardhat simulator network binding v1: local Anvil only.
module.exports = {
  // Exact pinned Solidity compilation happens in Forge (foundry.toml), not in Hardhat.
  solidity: '0.8.30',
  networks: {
    localhost: {
      url: process.env.LOCALHOST_RPC_URL || process.env.ETH_RPC_URL || process.env.RPC_URL || 'http://127.0.0.1:8545',
      chainId: 747474,
      timeout: 60000
    }
  },
  paths: {sources:'./hardhat-src',tests:'./test',cache:'./.hh-cache',artifacts:'./.hh-artifacts'}
};
