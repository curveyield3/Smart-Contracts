Hardhat compiles no Solidity directly in this unified orchestration. Source-faithful Forge compiles internal/*.s.sol and src/*.sol using foundry.toml.
