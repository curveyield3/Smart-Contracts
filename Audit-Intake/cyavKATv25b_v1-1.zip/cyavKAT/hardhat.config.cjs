// Audit-only Hardhat build wrapper for the cyavKAT package.
//
// The ACTIVE project is the Foundry project in upgrade/ (see README.md). This wrapper mirrors
// upgrade/foundry.toml exactly -- solc 0.8.30, via_ir, optimizer_runs = 1, evm_version = prague,
// bytecode_hash = none and the same remappings -- so automated audit tooling can compile the
// production sources (upgrade/src) and their pinned IPOR dependencies without modifying any
// source file. Foundry remains the authoritative test/deployment toolchain.
const fs = require("fs");
const path = require("path");
const { subtask } = require("hardhat/config");
const { TASK_COMPILE_GET_REMAPPINGS } = require("hardhat/builtin-tasks/task-names");

// upgrade/foundry.toml resolves these npm packages from ../ipor-fusion/node_modules. Hardhat
// resolves npm packages from <root>/node_modules, so link the identical vendored package
// directories there (after `npm ci`). Nothing is copied or modified.
const VENDORED_PACKAGES = [
  "@openzeppelin/contracts",
  "@openzeppelin/contracts-upgradeable",
  "@morpho-org/morpho-blue",
  "@uniswap/v3-core",
];
for (const name of VENDORED_PACKAGES) {
  const target = path.join(__dirname, "ipor-fusion", "node_modules", ...name.split("/"));
  const link = path.join(__dirname, "node_modules", ...name.split("/"));
  if (!fs.existsSync(target)) throw new Error(`vendored package missing: ${target}`);
  if (fs.existsSync(link)) {
    if (fs.realpathSync(link) !== fs.realpathSync(target)) throw new Error(`conflicting package at ${link}`);
    continue;
  }
  fs.mkdirSync(path.dirname(link), { recursive: true });
  fs.symlinkSync(path.relative(path.dirname(link), target), link, "dir");
}

// Same local (non-npm) remappings as upgrade/foundry.toml, relative to this package root.
const REMAPPINGS = {
  "contracts/": "ipor-fusion/contracts/",
  "managers/": "ipor-fusion/contracts/managers/",
  "interfaces/": "ipor-fusion/contracts/interfaces/",
  "libraries/": "ipor-fusion/contracts/libraries/",
  "forge-std/": "ipor-fusion/lib/forge-std/src/",
};
subtask(TASK_COMPILE_GET_REMAPPINGS).setAction(async () => REMAPPINGS);

// Foundry/solc name each file by its REMAPPED path, so `interfaces/X.sol` and
// `contracts/interfaces/X.sol` are one source unit. Hardhat 2 keeps the pre-remapping import
// string as the source name, which would split one file into two units (HH415). Use the
// remapped path as the source name, and pass the same remappings to solc so every import
// string resolves to that single unit -- identical to `forge build`.
const { Resolver } = require("hardhat/internal/solidity/resolver");
const resolveLocal = Resolver.prototype._resolveLocalSourceName;
Resolver.prototype._resolveLocalSourceName = function (_sourceName, remappedSourceName) {
  return resolveLocal.call(this, remappedSourceName, remappedSourceName);
};
const SOLC_REMAPPINGS = Object.entries(REMAPPINGS).map(([from, to]) => `${from}=${to}`);

module.exports = {
  solidity: {
    version: "0.8.30",
    settings: {
      optimizer: { enabled: true, runs: 1 },
      viaIR: true,
      evmVersion: "prague",
      metadata: { bytecodeHash: "none" },
      remappings: SOLC_REMAPPINGS,
      outputSelection: {
        "*": {
          "*": [
            "abi",
            "evm.bytecode",
            "evm.deployedBytecode",
            "evm.methodIdentifiers",
            "evm.gasEstimates",
            "metadata",
            "storageLayout",
            "devdoc",
            "userdoc",
          ],
          "": ["ast"],
        },
      },
    },
  },
  paths: {
    sources: "upgrade/src",
    cache: "cache-hardhat",
    artifacts: "artifacts",
  },
  networks: {
    // Katana mainnet chain id; forking is supplied only by the trusted runner.
    hardhat: { chainId: 747474 },
  },
};
