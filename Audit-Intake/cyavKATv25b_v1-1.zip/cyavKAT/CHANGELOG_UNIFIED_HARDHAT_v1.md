# Unified Hardhat simulation v1

- Added a unified Hardhat deployment entrypoint and hardhat.config.cjs for Katana Anvil workflows.
- Consolidated all in-scope v25 deployment/configuration phases in a single fail-closed execution plan; source Solidity preserved under `upgrade/internal/` and not auto-discovered as competing Foundry deployment targets.
- Removed time advancement, legacy expiration pruning, old-manager pending-request drain requirements, old-manager released-share restrictions, and old-manager fee-share cutover requirement.
- Removed fork test `OldWmStub` and fake old-manager fee-share settlement to test against real forked withdrawal-manager state.
- Retained independent Quest, vKAT, Merkl, governance, fee authority, and post-cutover checks.
- Added machine-readable per-phase and transaction receipt evidence. Does not claim existing legacy redemptions work following allowance rotation.
