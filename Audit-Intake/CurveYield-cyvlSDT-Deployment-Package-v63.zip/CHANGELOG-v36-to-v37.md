# CurveYield cyvlSDT v36 → v37

## Approved revenue and PoL allocation changes

1. **Locker LP Bribe Revenue Share.** Added owner-configured `lpBribeRevenueShareBps` (0–1,500 bps) and `lpBribeContract`. The same pre-Staking diversion is applied to SDT/USDC obtained from vlSDT distributors, Merchant marketplace receipts, direct Merchant leases, and Aladdin claims. The bribe portion transfers to the configured recipient, and only the net reaches `CurveYieldvlSDTStaking.notifyReward`.
2. **Locker PoL Deposit Share.** Added owner-configured `poLDepositShareBps` (0–1,500 bps) and `cyvlSdtPoLContract`. Every SDT `deposit()` first diverts the configured percentage to PoL, then mints/buys cyvlSDT with the remainder. The PoL SDT does **not** stake into vlSDT, and minting stays 1:1 with net SDT actually staked.
3. **Aladdin no longer compounds.** Replaced `claimAladdinRewardsAndCompound()` in both Merchant and Locker with `claimAladdinRewards()`. The Locker claims SDT and forwards it through the same LP-bribe and Staking reward route. It does **not** stake claimed SDT or mint cyvlSDT. Removed `totalDonatedSDT` and the `_donateSDTHeld` path. Retained the existing `donateSDT()` ABI solely as a backward-compatible **SDT revenue contribution**: it now forwards the received SDT through the LP bribe share and Staking fee tiers instead of staking it into vlSDT. No share-neutral backing donation mechanism remains.
4. **Rebalanced marginal excess tiers, independently for SDT/USDC:**

   | Revenue band | Stakers | DAO | Admin | cyvlSDT PoL |
   |---|---:|---:|---:|---:|
   | Base, 0–100% of benchmark | 100% | 0% | 0% | 0% |
   | First excess, 100–150% | 75% | 15% | 5% | 5% |
   | Second excess, >150% | 60% | 20% | 10% | 10% |

   Stakers receive base SDT and USDC in their original tokens via independent seven-day streams. Each new receipt is classified against the *cumulative total of receipts in its week*. Only its incremental staker excess is queued for conversion to cyvlSDT and then streamed independently for seven days. DAO, admin and PoL allocations are in the **original incoming token**, not cyvlSDT. These tier shares apply **after** any configured pre-Staking LP bribe diversion.
5. **Gross SDT base reward benchmark, including PoL principal.** The Locker tracks `grossSDTPrincipalForBase`: on mint it increments by the full SDT deposit, including the diverted PoL portion. `baseSDTEquivalent(activeCyvlSDT)` computes `activeCyvlSDT × grossSDTPrincipalForBase / cyvlSDT.totalSupply()`. Staking uses that SDT-equivalent principal when applying the most recent fully checkpointed SDT and USDC distributor epoch rates. On emergency share burns, the benchmark principal is reduced pro-rata. Acquiring already-minted cyvlSDT on the post-deployment StableSwap route does **not** increase this principal. This accounting balance is for **reward benchmarking only**, never redeemable backing.
6. **PoL delayed recipient support.** If PoL has not yet been configured when a tier fee accrues, Staking escrows that token's PoL fees in `pendingPoLRevenue(token)`, so claims or Merchant revenue are not blocked. Once the Locker's existing PoL recipient is configured, anyone can call `forwardPendingPoLRevenue(token)`. When the recipient is set, current fees go straight to it.
7. **Deployment scripts.** Version consistency updated to v37; post-configuration and verification check both 15%-capped Locker shares, the new 75/15/5/5 and 60/20/10/10 tiers, and the gross reward benchmark getter. The PoL recipient's contract existence is verified by deployment scripts when the Locker's PoL deposit share is nonzero. Missing post-deployment StableSwap routes remain optional.

## Economic caveats

- The higher **synthetic base-reward benchmark is not backed by actual additional vlSDT**: PoL-diverted SDT is not staked. Base payouts up to this benchmark require sufficient SDT/USDC receipts, including strategy income. No source can guarantee them if receipts are insufficient.
- The LP-bribe diversion occurs *before* the base/excess split, as requested. At high diversion rates or low revenue, a 100% full normal-vlSDT base payout can be underfunded. The reward accounting does not mint unbacked tokens to fill that shortfall.
- PoL tier allocations are SDT/USDC received by Staking; the PoL contract must be able to manage or recover both tokens before production transfers are enabled. PoL payment is not a reward stream.
- The optional StableSwap route still cannot be configured until the three-token pool exists. USDC->SDT excess conversion remains pending until an OmniRouter route is configured.

No tests were added or run, and no blockchain writes were made. Solidity compilation could not be confirmed because the local `solc` dependency is incomplete; an existing Hardhat invocation timed out. Syntax and package checks are not compiler verification.
