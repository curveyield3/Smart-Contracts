# CurveYield cyvlSDT v61 — Staking optimization change report

**Baseline:** v60 package; `contracts/CurveYieldvlSDTStaking.sol` SHA-256 `f6847e0d3617863d9c94011d98caec7be27ccbb4d3f9485dcfd655a153bbf1d6`.
**New source SHA-256:** `24ed4197b8975540a00f6affc6a4fb48c28f03a4fd91587637ce01f6438d230d`.
**Scope:** one Solidity contract modified out of 17; no other Solidity sources edited.
**Compiler profile:** Hardhat, solc `0.8.28`, `viaIR: true`, optimizer runs `200`, EVM `cancun` (pinned in `hardhat.config.js`).

## Implemented, by requested optimization category

1. **Standing unlimited allowances:** `USDC` to `OMNI_ROUTER` and `SDT` to `LOCKER` granted as maximum allowance in constructor. On `setOmniRouter()`/`setLocker()`, revoke old spender first, approve new spender at max (unless rebind to zero), update pointer. Same-address rebind does not repeat approvals. Removed the two per-conversion approve/reset pairs in `convertExcess()`.
2. **Single reward-stream checkpoint traversal:** `_checkpointReward()` calculates vesting and identifies the new `streamHead` in one pass; the separate expired-stream loop is removed. It retains the original `_vested(to)-_vested(from)` floor arithmetic, historical stream storage and timestamps.
3. **No-op reward-write avoidance:** `_checkpointUser()` skips zero accrued balance writes, while still updating `userRewardPerTokenPaid` when needed. `_checkpointReward()` skips unchanged remainder and zero accumulator writes and skips processing absent streams.
4. **Queued exits:** both `completeQueuedWithdrawal()` and `withdrawQueuedImmediate()` retain global stream/treasury checkpointing but omit user checkpointing because their user active stake is unchanged after the original queued request. Outstanding user rewards settle on the next balance-sensitive action and remain visible through `earned()`.
5. **Loop caching:** cache stream-array length and stream amount/start/end values during preview and checkpoint, reward-token count during checkpoints, and active stake balance during immediate and queued withdrawal request.
6. **Weekly income accounting:** compute received/tiers once, skip unchanged base/first/excess and fee-ledger writes; reuse one fee-target calculation for admin and PoL whose constants are identical in v60. Preserve independent allocated counters, payout conditions, original event fields, and same rounding.
7. **Claims:** copy the bounded reward-token list once; perform all checkpoints first, then all token transfers, preserving call ordering and per-user entitlement.

## Explicit preservation / limitations

- `notifyReward()`'s measured-token-transfer validation and LP-bribe diversion remain unchanged.
- Reward stream exact `Math.mulDiv` floor rounding, 7-day unlocking, treasury no-staker behavior, early exit fee and weekly base/excess benchmark preserved by code inspection; not dynamically verified.
- External function names/arguments and events intentionally unchanged; storage declarations unchanged. Only constructor allowance side effects and owner rebind allowance side effects are intentional permission changes.
- **Allowance risk:** approved spenders have standing ability to spend the full corresponding token balance until revoked. Previous approved spenders are explicitly revoked on rebind.
- **No contract tests or simulations created/executed.** Solidity compilation, per-function execution gas, deployed runtime bytes, deployment gas and semantic equivalence have **not been verified**, because the pinned solc/OpenZeppelin packages were unavailable in the local runtime. Do not describe this as a compiled or gas-benchmarked release.
- The source changes may increase runtime bytes despite operational-gas intent. Benchmark under identical v60/v61 settings before deployment.

## Source-size measurements (not runtime bytes)

- v60 staking Solidity source: `29,983` bytes.
- v61 staking Solidity source: `32,239` bytes.
- Difference (v61 minus v60): `+2,256` source bytes.
