# CurveYield v53 — direct contract replacement, NO PROXIES

Source basis: v52 and exact original V9 strategy. Status: source changes produced and inspected; **NOT COMPILED, TESTED, DEPLOYED OR ACCEPTED ON CHAIN**. The unmodified original V9 is retained; the active v53 deployment uses the separately named rebindable derivative.

## Exact architecture

Each component is independently redeployed at a **new address**. An authorized operator/owner updates the dependent contract's existing storage pointer through a dedicated setter. No proxy, delegatecall, implementation slot, upgrade-admin or address registry is introduced. Externally owned end-user claims cannot be transferred invisibly by a setter; positions must be withdrawn, migrated through a separately authorized transfer path, or redeemed before replacement.

| Component being replaced | Dependent contract(s) and v53 owner-controlled rebind | Safety rule / limitation |
|---|---|---|
| Locker | `CurveYieldVlSDTToken.setLocker`, `CurveYieldvlSDTStaking.setLocker`, `CurveYieldVlSDTBoostMerchant.setLocker`, `CurveYieldRevenueStrategyV7.setLocker` | Old token supply must be zero; open old-locker economic obligations and marketplace listings must be settled. New locker must be fully configured before staking/merchant rebind. |
| cyvlSDT token | Locker `setCyvlSDT`, staking `setCyvlSDT`, revenue strategy `setWant`, PoL `setCyvlSDT` | All outstanding original token supply and vault/staking claims must be retired. Add new token as a supported staking reward token before staking rebind. Old token rewards stay separately claimable. PoL must first retire old Curve/NFT bindings and old-token assets. |
| Revenue staking | Locker `setRevenueStaking`; revenue strategy `setRevenueStaking` | Old total active/queued stake and the revenue strategy's stake/queued withdrawals must be zero; strategy must have no pending withdrawal requests or outstanding accrued staking rewards. Existing users must claim old accrued rewards from old staking. |
| Boost merchant | Locker `setBoostMerchant` | No outstanding merchant delegation or marketplace commitments. Old merchant must have no tracked open listings. New merchant must reference the locker. |
| Boost marketplace external instance | Locker `setBoostMarketplace`; merchant `setMarketplace` | Zero marketplace commitments and no tracked open listings. Locker also transfers vlBoost operator authorization from the old to the new marketplace if previously authorized. |
| Asynchronous revenue strategy | `CurveYieldVault.setStrategy` | Old strategy invested balance, unharvested value and total outstanding queued user withdrawals must all be zero. Same `want` asset. Share balances stay at the vault address. |
| Revenue vault | `CurveYieldRevenueStrategyV7.setVault` | Old vault total supply and strategy's staking positions/requests must be zero. A new vault may first have an unset strategy; afterward call its `setStrategy`. Persistent configurator role must be transferred to Safe. |
| Beefy V8 strategy | `BeefyVaultCurveYieldV8.setStrategy` | Both old and new strategies must have zero accounted balance; both use same underlying and candidate points to this vault. APY history resets on switch; share balances remain at existing vault address. |
| Beefy V8 vault | `StrategyCurveSDTYearnRebindable.setVault` | Old vault share supply must be zero before rebinding; new address may be a predicted CREATE address because Beefy constructor validates strategy.vault(). **Original byte-exact V9 is not rebindable**; deploy the new derivative for future independence. |
| Yearn factory vault | `StrategyCurveSDTYearnRebindable.setYearnVault` | Old Yearn strategy shares must be zero; new vault must hold identical SDT/WETH Curve LP; approvals rotated, decimals/share-unit updated. |
| Curve LP oracle guard | `PoLManager.setLiquidityBounds` (already present), `StrategyCurveSDTYearnRebindable.setCurveLiquidityGuard` | New contract must expose the same quote ABI. Source Guard V8 is stateless and independently deployable. |
| PoL Manager | Locker `setPoLDepositShare` (already present) | No dependency redeployment; funds held inside old PoL Manager still require independent withdrawal/migration. V22 has the already identified emergency LP/share recovery limitation. |
| PoL's external modules | PoL `setVault` (existing), `configureCurvePool`, `configureCurveGauge`, `configureUniswapPosition`, `clearCurvePool`, `clearUniswapPosition`, `setOmniRouter`, `setCyvlSDT` | Yearn/Morpho shares, Curve LP/gauge, and Uniswap NFT positions must be empty or transferred out before replacing their dependency; router allowances explicitly revoked and reapproved. |
| Bribe allocator | Revenue staking `setLpBribeRevenueShare` (existing) | No redeployment required; old pending bribes/bounty need settlement. |
| VoteMarket / router used by bribe allocator | Bribe allocator `setVoteMarket`, `setOmniRouter` | Owner-only, active bounty must be closed before VoteMarket changes. |
| Fixed SDT, WETH, USDC, CRV, StakeDAO protocol primitives | No automatic token replacement | These are external protocol/asset identities, not locally redeployable CurveYield stack components. Replacing the underlying economic asset is a different migration and cannot be guaranteed ABI-equivalent. |

## Required ordering examples

**Rotate locker:** withdraw/redeem all outstanding cyvlSDT and settle boost/withdrawal requests; deploy and configure the new locker with the existing cyvl token, staking and merchant; set the token's new locker; update staking and merchant pointers to new locker; update the revenue strategy locker pointer; route PoL revenue and operator authorizations correctly; read back both sides. This is a gated **multi-call migration**, not an automatic operation.

**Rotate cyvlSDT token:** redeem old cyvl supply and clear staking active/queued and vault strategy shares; deploy new token; call its initial `setLocker(existingLocker)`; register the new token as a reward token; update staking `setCyvlSDT`, revenue strategy `setWant`, locker `setCyvlSDT`, and PoL only after clearing any old-token Curve/NFT assets; preserve old reward claims until settled. These operations should be batched in one Safe execution when practical.

**Rotate Beefy vault:** withdraw every user share from the old Beefy vault (or complete a separate user-approved share migration), predict next vault address, have rebindable strategy point at the predicted address, deploy the new Beefy vault with the same strategy and expected constructor checks. This does **not** transfer user share balances automatically.

**Rotate revenue strategy:** retire the old strategy (including any queued user withdrawals); deploy replacement with `vault` pointing to the existing revenue vault and the same `want`; call `CurveYieldVault.setStrategy` through Safe configurator. The vault keeps its own share ledger. The old strategy's idle tokens/rewards remain its own custody until settled.

## Preservation and security caveats

- Existing economic formulas, withdrawal fee rates, reward/boost tiers and guard slippage settings have not deliberately been rewritten. However new setters change authorization/reconfiguration surfaces and require independent review/compilation before production.
- No silent migration of custody or mapping storage is claimed. Replacement of a funded locker, token, vault or staking ledger is **not instantaneous** merely because dependent references can change. Users may need to exit/redeposit; permanent token identity in third-party Curve pools cannot be replaced by owner setters.
- Stale approvals to an old token spender are revoked in the modified PoL router and pool paths and locker boost marketplace path. Other owner-controlled changes may require follow-up allowance/route verification in their respective contracts.
- The old, already-deployed **immutable** contracts cannot be retroactively modified. A one-time deployment of these no-proxy replacements is needed before future individual rebindings work.
- PoL source was 22,806 bytes at a previous live deployed revision, near the EIP-170 24,576-byte limit. The added non-proxy configuration code **has not been compiled/measured**; deployment-size headroom is a material unresolved blocker. Do not deploy on the assumption it fits.
- Existing v47 verification/handoff scripts were edited only where the nonburnable Safe-held `configurator` contradicts legacy checks. The old v51 SDT strategy deployer remains included for reference; new v53 deploy command uses rebindable strategy and its Safe-owner constructor argument.
- Tests were not created, changed, or executed; no fork simulation or on-chain call was made. Local JavaScript syntax checking and ZIP/file integrity checking are not contract compilation, and do not demonstrate deployment readiness.
