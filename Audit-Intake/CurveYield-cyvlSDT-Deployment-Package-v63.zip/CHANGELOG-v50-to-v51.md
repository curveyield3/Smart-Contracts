# cyvlSDT package v50 → v51

1. Restored `contracts/StrategyCurveSDTYearnV9.sol` **byte-for-byte** from the original attached strategy ZIP (SHA-256 `c280bd632a02776a21999f7a0f16d768405036646aad8e70ded6431652594b87`). Removed the previously adapted `StrategyCurveSDTYearnV10.sol`.
2. Changed the additional vault/strategy deployment script and configuration to refer to the **unchanged V9** contract. Kept the additional BeefyVaultCurveYieldV8 vault and external Yearn factory vault deployment flow.
3. Replaced v50 SDT/Yearn deployment script/config with v51 versions, updated package/npm metadata, and added this changelog, `README-v51.md`, and the v51 checksum manifest.
4. All other Solidity sources are identical to their v50 ZIP bytes, including `BeefyVaultCurveYieldV8`, `PoL_Manager_Contract_v22`, and Guard V8. No tests or on-chain actions occurred.
