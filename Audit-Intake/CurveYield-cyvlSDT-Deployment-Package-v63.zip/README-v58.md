# CurveYield cyvlSDT deployment package — v58 (locker optimization only)

This replaces the earlier, DISCARDED experimental v58 optimization package. **Base is the unchanged v57 ZIP**, not the prior v58 optimizer work. The only edited Solidity file is `contracts/CurveYieldVlSDTLocker.sol`; all other Solidity contracts, strategies, guards, and interfaces match v57 byte for byte.

Approved changes: SDT→vlSDT and SDT/USDC→revenue-staking unlimited approvals, approved on first configuration and rotated on revenue-staking rebinding; consolidate `merchantDelegableBoost` storage/external reads; exact overflow-safe quotient/remainder formula for PoL deposit share. See CHANGELOG-v57-to-v58.md and SOURCE-DIFF-v57-to-v58.patch.

No Solidity compiler or gas benchmark has run successfully on this version. **Not deployment-verified**. No tests, chain transactions or deployments performed.
