# CurveYield cyvlSDT v59 — 1:1 gross issuance and SDT-to-PoL

Based on the approved **v58 locker-only** package, not the discarded all-contract v58 optimizations.

Deposits mint 1 cyvlSDT per input SDT; configured PoL share transfers as SDT directly to PoL and only the remainder becomes vlSDT. Queued emergency redemption is proportional to the locker’s real vlSDT balance, NOT 1 SDT per cyvlSDT. The RevenueStrategyV8 reward estimate now reflects the full 1:1 issuance. Read `CHANGELOG-v58-to-v59.md` for the economic warning and public getter change.

Solidity build and dynamic tests are not established by source inspection.
