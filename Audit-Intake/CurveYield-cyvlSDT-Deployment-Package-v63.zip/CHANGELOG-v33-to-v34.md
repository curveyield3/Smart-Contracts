# CurveYield cyvlSDT v34 — complete change log

**Source lineage:** v33 → v34. **Network:** Ethereum mainnet. **Package version:** v34.  
**Scope:** Source changes only. No on-chain transactions, deployments, tests or simulations were performed.

## Contracts removed

| Source removed | Why |
|---|---|
| `CurveYieldVlSDTBoostStaking.sol` | Eliminate user-facing multiplied-vlBoost staking/delegations. Only the Merchant now receives module-1 delegated capacity. |
| `CurveYieldRevenueConverter.sol` | Remove intermediary converter contract. Revenue Strategy now calls the deployed OmniRouter and existing Locker directly. |
| `CurveYieldUsdcToSdtConverter.sol` | Remove separate Curve-pool converter and embedded two-hop USDC→WETH→SDT path. |
| `interfaces/ICurveYieldRevenueConverter.sol` | Obsolete interface. |
| `interfaces/ICompounderAdapter.sol` | Obsolete converter adapter interface. |
| `interfaces/ICurveCryptoPools.sol` | Obsolete converter pool interface. |

## Contract renamed

`CurveYieldVlSDTRevenueStaking.sol` → **`CurveYieldvlSDTStaking.sol`**, and the Solidity contract is now `CurveYieldvlSDTStaking`. The interface was renamed to `ICurveYieldvlSDTStaking`. The deployment-state key `revenueStaking` and existing contract method selectors remain stable for cross-contract integration.

## Contract changes

### `CurveYieldVlSDTToken.sol`
- Removed inherited unrestricted `ERC20Burnable` (`burn`/`burnFrom`).
- Preserved *only* `burnForEmergencyWithdrawal(uint256)` restricted to the Locker, for existing 1:1 redemption accounting. Ordinary holders cannot burn shares directly.
- Issuance remains Locker-only.

### `CurveYieldVlSDTLocker.sol`
- Removed module-2 multiplied-boost staking registration and external module add/remove admin API. Merchant is the **only** user-facing boost module, ID 1.
- `configureSystem(revenueStaking, boostMerchant)` now binds just the staking and Merchant contracts.
- Existing boost commitment reservations, expiry-release call, listing create/update/cancel/offer-fill execution paths remain in place; no duplicate capacity ledger was added.
- Before minting cyvlSDT for deposited SDT, check the deployed OmniRouter's optional SDT→cyvlSDT route; compare its **net** quote to the 1:1 mint result. Swap only if the quote is better, setting actual minimum output to strictly exceed `amount` of cyvlSDT. Failed quote/trade falls back to original 1:1 stake/mint operation.
- On a successful pool purchase, deliver pre-existing cyvlSDT straight to the requested receiver **without minting new shares**. The pool can be a three-coin Curve StableSwap configured later; no pool address or coin index is hard-coded.
- Unconfigured route leaves normal deposits fully functional: 1 SDT stakes into 1 vlSDT and mints 1 cyvlSDT.
- Aladdin operator authorization is performed conditionally during `delegateBoost` itself, so separate pre-authorization is unnecessary. The pre-existing owner-only operator toggle is retained to permit emergency revocation.
- Aladdin SDT rewards still use `_donateSDTHeld()` (existing donation compounding) and mint no cyvlSDT shares. They are **not** redirected through the optional swap/mint choice.
- Emergency withdrawal uses the new Locker-only burn, preserving withdrawal accounting.

### `CurveYieldVlSDTBoostMerchant.sol`
- Replaced the prior token-configurable payment registry with **USDC-only** payments, pricing and offer acceptance.
- Owner-configurable `setSaleRates(postPricePerWeek, minimumFillPricePerWeek, sdtWeiPerUsdc)` replaces `setPaymentToken`.
- Listing and offer profitability remain checked against 110% of Aladdin's last complete reward epoch, including marketplace fees.
- Maximum executed lease duration remains **90 days** after week-boundary alignment (listing 11 weeks maximum, requested direct lease 12 weeks subject to actual-seconds cap).
- Merchant retains listing cancellation via the Locker and remains the decision maker for posting, filling or Aladdin delegation. It does **not** add another allocation system.

### `CurveYieldRevenueStrategyV20.sol` (`CurveYieldRevenueStrategyV7`)
- Removed `CONVERTER`, `setConverter`, converter validation, converter quotes and adapter approvals.
- New immutable references to the deployed **CurveYieldOmniRouter** and existing Locker.
- USDC revenue: route USDC→SDT via OmniRouter's `guardedMinOut` and `swapExactInput`, then call `LOCKER.deposit` for SDT→cyvlSDT (which independently prefers the eventual three-token pool if strictly better than 1:1 minting).
- SDT revenue: call `LOCKER.deposit` directly. cyvlSDT revenue: remains held/staked directly.
- Until OmniRouter's USDC→SDT route is configured, USDC remains held for later conversion; failed swaps are not allowed to block the ordinary best-effort harvest/withdrawal path.
- Valuation uses 1:1 for SDT and conservative guarded OmniRouter quotations for USDC if a route exists; unavailable USDC quotations contribute zero instead of reverting.
- Fee assessment continues on actual newly received cyvlSDT and existing revenue staking/withdrawal logic is preserved.

### Interfaces and deployment
- Added minimal `ICurveYieldOmniRouter.sol` for `routeLength`, `getAmountOut`, `guardedMinOut`, `swapExactInput`.
- Updated `ICurveYield.sol` and `IStakeDao.sol` for interface renames, Locker-only withdrawal burn, and conditional `vlBoost.isOperator`.
- Deployment scripts now create **six** contracts: token, Locker, renamed staking, Merchant, Vault, Revenue Strategy.
- Removed converter-related deploy/configure/verify/handoff requirements, constructor arguments and pricing config.
- Pinned the pre-existing deployed OmniRouter at `0xa4a533025fef8d3446e7cb8a434824e1ee865b00` through both deployment configs; scripts check code presence, owner and required read ABI.
- The existing `config-mainnet-v34.json`/`config-production-v34.json` include nullable post-deployment pool details; **the future SDT/cyvlSDT stable pool is not configured and does not block the initial deployment**.
- Existing deployment post-config script optionally verifies the proposed stable pool's three coins (including SDT and cyvlSDT), and reports configured OmniRouter route lengths; neither route is a pre-deployment requirement.
- Merchant sale rates are unfilled intentionally (owner has not supplied values). They remain disabled until configured and are reported separately from initial deployment readiness.

## Important economic choice and operational limitations

- **1:1 stake-to-mint remains by instruction.** Donating/compounding SDT increases vlSDT backing without increasing cyvlSDT supply. Subsequent 1:1 deposits may dilute that increased backing per share. The proposed proportional-share minting correction from the previous audit is intentionally **not implemented** following the user's reversal.
- Public burning is disabled, but the emergency withdrawal route must destroy cyvlSDT held by the Locker to redeem the corresponding 1:1 SDT amount.
- The three-coin SDT/cyvlSDT pool, its address, the third coin and StableSwap coin indices are unknown today. **Do not invent them**. Once deployed, the owner must configure the OmniRouter route using its existing `setRoute` interface.
- OmniRouter's `getAmountOut` is a **historical/oracle-based net estimate**, not a guaranteed executable pool quote. Locker executes a swap only if actual settlement provides more cyvlSDT than minting, otherwise it falls back to minting.
- The USDC→SDT route is currently absent on the deployed OmniRouter. Revenue conversion from USDC stays dormant until the router owner configures it. Neither the future USDC route nor the future pool is auto-configured or deployed by v34.
- Before deployment, supply actual owner-selected Merchant USDC rates, and verify all external contract addresses, interface compatibility, final owner rights and chosen configuration. Do not claim sale readiness or future pool readiness without those values.

## Verification evidence and limits

- Local JavaScript parsing and Solidity import-path existence checks passed.
- Configuration files include no placeholder address for the future stable pool.
- Local npm dependency installation timed out, so **Solidity compilation remains unverified**. No tests, simulations, deployments or chain writes were executed.
- Live reads confirmed the OmniRouter contract and its methods at the address above. At inspection, its USDC→SDT and SDT→cyvlSDT route lengths were both zero; these remain future actions.
- Changes are provided as auditable source, not as an audited or production-validated release.
