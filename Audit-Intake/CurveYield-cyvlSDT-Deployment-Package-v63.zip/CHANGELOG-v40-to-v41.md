# CurveYield cyvlSDT — v40 to v41

## Change: Keeper-managed PoL allocations

- In `CurveYieldVlSDTLocker.deposit()`, retain the immediate `safeTransfer` of the configured PoL SDT share to the configured PoL Manager **before** further processing the user's deposit.
- Remove the direct `PoLManager.allocateFunds(SDT, poLAmount)` call, including its `try/catch` and the now-unused `PoLAllocationDeferred` event. No PoL investment is performed during user deposit.
- PoL Manager v9's `allocateFunds(address token,uint256 amount)` invests **existing idle token balances** in its custody. A keeper allowed via `PoLManager.setOperator(keeper, true)` can call it after one or more deposits, subject to enabled allocations, available free balance and normal Manager constraints. The PoL Manager itself is unchanged.
- Retain the existing optional owner-only Locker `allocatePoLFunds` helper for manual intervention. The keeper should call the PoL Manager directly, not the Locker helper.
- PoL-designated SDT stays outside the Locker immediately, so `forwardMarketplaceRevenue(SDT)` cannot capture it. PoL performance-fee SDT transferred back to the Locker remains separately sweepable via the existing bribe/Staking path.
- Update v41 deployment script/config/package version references only; no other economic parameters or allocation formulas changed.

No compilation, tests, simulations or deployments were performed.
