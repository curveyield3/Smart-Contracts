# v58 → v59 — cyvlSDT gross mint and SDT PoL routing

**Base source:** CurveYield-cyvlSDT-Deployment-Package-v58-Locker-Optimizations.zip (the approved locker-only branch, NOT the discarded generic optimized v58).

## Implemented

1. Locker `deposit(amount,receiver)` now mints exactly `amount` cyvlSDT on each successful deposit. The configured PoL share continues to be transferred **as SDT** directly to `cyvlSdtPoLContract`. Only `amount - PoLShare` is staked into vlSDT. The vlSDT stake balance-delta check remains intact.
2. Locker `requestEmergencyWithdrawal(shares)` now burns the requested cyvlSDT shares and unstakes `floor(lockerVLSDT * shares / cyvlSDTTotalSupply)` native vlSDT. It records the separate `unstakedPrincipal` per request. This prevents demanding unstake of vlSDT that the locker never held after routing SDT to PoL. Zero-unstake requests revert without burning shares. Existing boosts may restrict unstaking.
3. Locker `completeEmergencyWithdrawal`: matured returns actual unstaked vlSDT principal as SDT; early payout is calculated using the snapshotted early-redemption rate times the unstaked principal. Both paths preserve original share-burn event reporting.
4. Revenue strategy `estimatedUnharvestedWant()` no longer subtracts PoL BPS from SDT rewards or quoted USDC->SDT rewards; the locker converts those inputs at exactly 1:1 into cyvlSDT even when it diverts SDT to PoL.

## IMPORTANT economic distinction

**1:1 issuance does NOT mean 1:1 SDT redeemable collateral.** If 100 SDT is deposited with a 25% PoL allocation, the user receives 100 cyvlSDT, 25 SDT is sent to PoL, and 75 SDT is staked as vlSDT. A proportional emergency withdrawal can redeem at most its share of the 75 staked vlSDT (subject to Stake DAO limitations), NOT all 100 SDT. The 25 SDT held by the separate PoL contract is not claimable through the locker. Changes in PoL allocation can alter backing per outstanding share. This is a material economic design choice requested by the user, not a fully collateralized 1:1 peg.

## Interface / storage change

- `emergencyWithdrawals(uint256)` public getter returns an appended `uint128 unstakedPrincipal` field. It preserves previous fields and selector but changes ABI return encoding and the storage struct layout; consumers decoding the original 3-field return must update.
- No new privileged actions, proxies, router functions, extra tests, or contract deployments.
- Public deposit and withdrawal function selectors, owner configuration permissions and reward forwarding paths are unchanged.
- Only two Solidity source files changed (Locker and RevenueStrategyV8); all others retain v58 locker-branch hashes.

## Verification

Static source diff, package hash manifest, ZIP integrity and deployment JS syntax are checked. The new economic path and fork behavior are unverified without authorized integration testing. Solidity compilation is unverified if no compiler/build output is attached.
