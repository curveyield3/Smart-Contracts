# CurveYield cyvlSDT Deployment Package — v63

Based on v62. The **standard SDT/Yearn Beefy V8 vault** and **both SDT/Yearn strategy variants** were revised for gas and deployed-bytecode optimization candidates, while retaining existing ABI and economic rules.

Source changes:
- `contracts/BeefyVaultCurveYieldV8.sol`
- `contracts/StrategyCurveSDTYearnRebindable.sol`
- `contracts/StrategyCurveSDTYearnV9.sol`

See `CHANGELOG-v62-to-v63.md` for YV1–YV5 / YS1–YS5 individual dispositions and `SOURCE-DIFF-v62-to-v63.patch` for the exact baseline diff.

**Legacy compatibility:** The v51 and v53 SDT/Yearn deployment paths are retained. Historical V9 byte-for-byte source identity is not retained by the modified V9 in v63; refer to v62 for the original unchanged artifact. All other Solidity implementations remain unchanged from v62.

**Verification status:** Static source/ZIP reconciliation only. No Solidity compilation, gas benchmarks, tests, simulation or deployment have been performed. Do not construe source optimization as security or production qualification.
