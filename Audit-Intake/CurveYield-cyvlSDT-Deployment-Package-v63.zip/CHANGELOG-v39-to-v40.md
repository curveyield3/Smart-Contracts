# CurveYield cyvlSDT v40 — Automatic PoL Allocation on User Deposits

Source-only update based on v39, which integrated the unchanged PoL Manager v9.

## Change

- In `CurveYieldVlSDTLocker.deposit()`, transfer the configured SDT PoL share directly to PoL Manager v9 **before** cyvlSDT minting or any OmniRouter swap.
- Immediately attempt `PoLManager.allocateFunds(SDT, poLAmount)` inside a Solidity `try/catch`. Each successful deposit thus handles its own PoL investment without a second owner transaction.
- If PoL allocation fails (paused manager, absent operator authorization, unset allocations, failed swap, etc.), the **investment call alone** is caught. Minting continues. The diverted SDT remains idle *at PoL Manager*, never at the Locker; emit `PoLAllocationDeferred(poLAmount)`.
- Existing `Locker.allocatePoLFunds(token, amount)` remains an **optional recovery operation** for previously deferred idle SDT or USDC, not an action required after each deposit.
- `forwardMarketplaceRevenue` still forwards PoL *performance fees* received as ordinary SDT to bribe allocation and Staking. It cannot sweep PoL **principal** because that principal is already outside the Locker.
- The original PoL Manager v9, its source/ABI, and existing post-deployment ownership/operator/profitRecipient configuration remain unchanged.

## Source invariants

1. `poLAmount = floor(amount * poLDepositShareBps / 10000)` (maximum 15%).
2. On a successful SDT deposit, exactly `poLAmount` is transferred to the PoL Manager before the refundable/mintable `amount - poLAmount` is processed.
3. Failure to **transfer** PoL-designated SDT still reverts the deposit (preventing accidental leakage to Staking). Failure to **invest** already-transferred SDT is caught and leaves those tokens idle at PoL.
4. The owner must arrange `PoLManager.setOperator(locker,true)` for automatic investment. If not yet authorized, deposits still succeed, but emit `PoLAllocationDeferred` and accumulate idle PoL tokens.
5. The Locker's existing public revenue sweep sees only assets held by the Locker; no new reservation ledger, PoL token shadow balance, approval mechanism, or parallel performance-fee forwarding system was added.
6. Manager-level approvals, per-position weights, supported vaults, and swaps remain exclusively PoL Manager v9's responsibility.

## Verification boundary

No compilation, tests, simulations, or deployments were performed. Source diff and artifact manifest were inspected; full runtime behavior is unverified.
