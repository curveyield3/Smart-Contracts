# CurveYield cyvlSDT Deployment Package v57

**Revenue vault Solidity contract:** `BeefyVaultCurveYieldV8cyvlSDT` (`contracts/BeefyVaultCurveYieldV8cyvlSDT.sol`).

**Revenue vault ERC-20 name:** `Compounding CurveYield vlSDT`

**Revenue vault ERC-20 symbol:** `cyvlSDTcv`

The cyvlSDT revenue vault retains v56's queued withdrawal, live StakeDAO instant-withdrawal fee, and shareholder fee retention paths. `CurveYieldRevenueStrategyV8` remains unchanged.

**Separate standard vault:** `BeefyVaultCurveYieldV8` (`contracts/BeefyVaultCurveYieldV8.sol`), restored from v55. The SDT/Yearn V9 and rebindable strategy deployments keep referencing this standard vault; the SDT/Yearn strategy sources remain unchanged.

**Core deployment:** `deployment-v27/deploy-cyvlsdt-v27-v1.js` uses the cyvlSDT-specific artifact. `deployment-v20/lib-v20.js` maps `revenueVault` to the same artifact. Both production/mainnet JSON files have the revised token metadata. No proxies.

**Validation:** source equivalence, ZIP integrity and JS parsing checked. Solidity compilation, integration tests and deployment are NOT evidenced. Review v56's withdrawal accounting before production usage.
