# cyvlSDT revenue-vault withdrawal update — v56

The shared `BeefyVaultCurveYieldV8` now offers the original instant `withdraw/redeem` entrypoints plus `requestWithdrawal(shares)`, `completeWithdrawal()`, and `withdrawQueuedImmediate()` when paired with `CurveYieldRevenueStrategyV8`. Its separate SDT/Yearn strategy retains the original Beefy behavior and is byte-for-byte unchanged.

## Live staking fee — instant paths only

- `CurveYieldRevenueStrategyV8.immediateWithdrawFeePpm()` reads `CurveYieldvlSDTStaking.immediateWithdrawFeePpm()` on every call, so updates by staking governance take effect without redeployment.
- `BeefyVaultCurveYieldV8.stakingExitFeePpm()` reads that strategy getter (other strategies do not implement it and keep zero additional fee).
- The vault subtracts the *live* fee as an additional exit charge, retaining **100% in the vault for remaining shareholders**, on top of the constructor-set withdrawal fee (unchanged 30% admin / 70% shareholder split, except final-holder admin rule).
- When there are no remaining shareholders, the extra shareholder-only fee is waived, rather than trapping assets.
- The revenue strategy *continues* to gross up actual staking instant withdrawals so that the vault receives the exact underlying requested. Its `balanceOf()` continues valuing active stakes net of the live backend instant fee.
- The backend's own instant exit fee is still paid by the staking contract to its treasury. The vault's additional fee is a different charge retained for other vault shareholders; both costs must be explained to depositors.
- ERC-4626 preview methods include the live vault fee; standard `convertToAssets` remains fee-neutral per ERC-4626 accounting convention.

## Queued withdrawals

- `requestWithdrawal(shares)` burns shares, reserves otherwise idle assets and places the remainder into the staking contract's seven-day queue. One pending withdrawal per wallet is supported, matching the old cyvlSDT vault model.
- `completeWithdrawal()` calls the staking backend's fee-free completion after unlock; **only the constructor withdrawal fee applies**.
- `withdrawQueuedImmediate()` permits an early exit at the staking backend's then-current fee, *plus* the vault's additional current shareholder-retained fee and constructor fee.
- The strategy's `reservedWithdrawalAssets` and per-request records prevent reserved idle or queued staked tokens from inflating active vault NAV or being re-staked.
- The queued entitlement is calculated from **gross active staking principal plus unreserved idle**, not the instantaneous-net NAV. This is necessary for a full queued redemption to recover its entire pro-rata principal without stranding the backend's 3.125% discounted valuation in the strategy. Instant redemptions continue to use the live-fee-discounted NAV. `previewQueuedRedeem(shares)` quotes the fee-free queued payout after the constructor fee.
- The pre-v55 `withdrawWithOptions(...,strictHarvest,...)` selector is **not** reinstated; use the three direct queued-withdrawal functions. Best-effort harvest hooks from the old vault are not reinstated either.

## Important operational constraints

- The queued strategy and vault must remain mutually callable while withdrawals are pending; owner rebinding does **not** migrate outstanding claims.
- Staking fee changes are read live. New fees affect instant exits immediately; queued requests do not lock a fee rate.
- Only the revenue-vault *name* in both production configs is suffixed with `cyvlSDT`. The symbol and unrelated Yearn/Beefy vault name are unchanged.
- Source changes are not Solidity-compiled, deployed or tested in this artifact. Existing tests were not executed or altered.
