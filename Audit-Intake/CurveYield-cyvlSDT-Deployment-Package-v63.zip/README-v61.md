# CurveYield cyvlSDT deployment package — v61

Based on approved **v60** deployment package. Changes are limited to staking gas optimizations in `contracts/CurveYieldvlSDTStaking.sol`, and package version metadata. The locker’s existing v60 approvals, 1:1 cyvlSDT issuance, SDT-to-PoL routing and removal of the locker emergency withdrawal system are unchanged. Revenue vault continues to use `BeefyVaultCurveYieldV8cyvlSDT` with token name **Compounding CurveYield vlSDT** and symbol **cyvlSDTcv**.

See `OPTIMIZATION-REPORT-v61.md` and `SOURCE-DIFF-v60-to-v61.patch`. Solidity compilation and contract tests are NOT complete; not certified for deployment.
