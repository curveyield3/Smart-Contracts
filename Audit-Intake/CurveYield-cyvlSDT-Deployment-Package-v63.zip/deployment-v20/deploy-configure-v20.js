#!/usr/bin/env node
"use strict";

const {
  ethers, makeContext, send, contract, assertExternalDependencies,
  saveState
} = require("./lib-v20");

function assertContractAbi(label, target, methodNames) {
  for (const method of methodNames) {
    let fragment = null;
    try { fragment = target.interface.getFunction(method); } catch {}
    if (!fragment) throw new Error(`configuration ABI mismatch: ${label}.${method}`);
  }
}

function assertActiveConfigurationAbi(targets) {
  assertContractAbi("cyvlSdt", targets.cyvlSdt, ["locker", "setLocker"]);
  assertContractAbi("locker", targets.locker, [
    "systemConfigured", "configureSystem", "setMarketplaceOperator", "setPoLDepositShare",
    "merchantDelegableBoost", "claimAndForwardRevenue"
  ]);
  assertContractAbi("revenueStaking", targets.revenueStaking, [
    "isRewardToken", "addRewardToken", "immediateWithdrawFeePpm", "setImmediateWithdrawFeePpm", "setLpBribeRevenueShare"
  ]);
  assertContractAbi("boostMerchant", targets.boostMerchant, ["setSaleRates"]);
  assertContractAbi("revenueVault", targets.revenueVault, ["strategy", "setStrategy"]);
  assertContractAbi("revenueStrategy", targets.revenueStrategy, ["vault", "want", "deposit", "withdraw", "emergencyWithdraw", "lockVaultProfit", "performanceFeeBps", "callFeeBps"]);
}

async function deployAndConfigure(options = {}) {
  const ctx = await makeContext({
    configPath: options.configPath || process.argv[2],
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag: options.tag || process.env.DEPLOYMENT_TAG || "v55-live",
    confirmations: options.confirmations,
    stateFile: options.stateFile
  });
  const c = ctx.config;
  const feeDistributorRewardTokens = await assertExternalDependencies(ctx.provider, c);
  ctx.state.external = { ...c.stakeDao, feeDistributorRewardTokens };
  saveState(ctx.stateFile, ctx.state);
  const cyvlSdt = contract(ctx, "cyvlSdt");
  const locker = contract(ctx, "locker");
  const revenueStaking = contract(ctx, "revenueStaking");
  const boostMerchant = contract(ctx, "boostMerchant");
  const revenueVault = contract(ctx, "revenueVault");
  const revenueStrategy = contract(ctx, "revenueStrategy");
  const bribeAllocator = contract(ctx, "bribeAllocator");
  assertActiveConfigurationAbi({
    cyvlSdt, locker, revenueStaking, boostMerchant,
    revenueVault, revenueStrategy
  });
  assertContractAbi("bribeAllocator", bribeAllocator, [
    "gauge", "setGauge", "minimumReturnWad", "setMinimumReturnWad", "OMNI_ROUTER", "VOTEMARKET"
  ]);

  if ((await cyvlSdt.locker()) === ethers.ZeroAddress) await send(ctx, "configure:cyvlSdt.setLocker", cyvlSdt, "setLocker", [await locker.getAddress()]);
  if (!(await locker.systemConfigured())) await send(ctx, "configure:locker.configureSystem", locker, "configureSystem", [await revenueStaking.getAddress(), await boostMerchant.getAddress()]);
  for (const rewardToken of [...feeDistributorRewardTokens.all, await cyvlSdt.getAddress()]) {
    if (!(await revenueStaking.isRewardToken(rewardToken))) {
      await send(
        ctx,
        `configure:revenue.addRewardToken:${rewardToken}`,
        revenueStaking,
        "addRewardToken",
        [rewardToken]
      );
    }
  }
  if (Number(await revenueStaking.immediateWithdrawFeePpm()) !== c.revenueStakingConfig.immediateWithdrawFeePpm) {
    await send(
      ctx,
      "configure:revenue.immediateWithdrawFee",
      revenueStaking,
      "setImmediateWithdrawFeePpm",
      [c.revenueStakingConfig.immediateWithdrawFeePpm]
    );
  }
  // Configure the actual deployed allocator; no external bribe recipient is accepted.
  const ba = c.bribeAllocator;
  const expectedGauge = ba.gauge || ethers.ZeroAddress;
  if ((await bribeAllocator.gauge()).toLowerCase() !== expectedGauge.toLowerCase()) {
    await send(ctx, "configure:bribeAllocator.setGauge", bribeAllocator, "setGauge", [expectedGauge]);
  }
  if (await bribeAllocator.minimumReturnWad() !== BigInt(ba.minimumReturnWad)) {
    await send(ctx, "configure:bribeAllocator.setMinimumReturnWad", bribeAllocator,
      "setMinimumReturnWad", [BigInt(ba.minimumReturnWad)]);
  }
  // LP-bribe revenue diversion belongs to Staking, not Locker.
  const diversions = c.lockerRevenueDiversions;
  const bribeShare = Number(diversions.lpBribeRevenue.shareBps);
  const bribeRecipient = await bribeAllocator.getAddress();
  if (Number(await revenueStaking.lpBribeRevenueShareBps()) !== bribeShare
      || (await revenueStaking.lpBribeContract()).toLowerCase() !== bribeRecipient.toLowerCase()) {
    await send(ctx, "configure:staking.setLpBribeRevenueShare", revenueStaking,
      "setLpBribeRevenueShare", [bribeShare, bribeRecipient]);
  }
  const polShare = Number(diversions.poLDeposit.shareBps);
  const poL = contract(ctx, "poLManager");
  const polRecipient = await poL.getAddress();
  if (Number(await locker.poLDepositShareBps()) !== polShare
      || (await locker.cyvlSdtPoLContract()).toLowerCase() !== polRecipient.toLowerCase()) {
    await send(ctx, "configure:locker.setPoLDepositShare", locker, "setPoLDepositShare",
      [polShare, polRecipient]);
  }
  // Always configure the bundled manager's guard and fee destination; neither the
  // Curve pool nor the NFT is required to complete core deployment.
  const guardAddress = await contract(ctx, "poLLiquidityBounds").getAddress();
  const lockerAddress = await locker.getAddress();
  const p = c.poLManager;
  const deployerOwnsManager = (await poL.owner()).toLowerCase() === ctx.wallet.address.toLowerCase();
  const mustConfigure = async (label, observed, expected, method, args) => {
    if (observed.toString().toLowerCase() === expected.toString().toLowerCase()) return;
    if (!deployerOwnsManager) throw new Error(`${label} must be configured by PoL Manager owner`);
    await send(ctx, `configure:poL.${method}`, poL, method, args);
  };
  await mustConfigure("PoL bounds", await poL.liquidityBounds(), guardAddress,
    "setLiquidityBounds", [guardAddress]);
  await mustConfigure("PoL Curve slippage", await poL.curveSlippageBps(), p.curveSlippageBps,
    "setCurveSlippageBps", [p.curveSlippageBps]);
  await mustConfigure("PoL Uniswap slippage", await poL.uniSlippageBps(), p.uniSlippageBps,
    "setUniSlippageBps", [p.uniSlippageBps]);
  await mustConfigure("PoL fee receiver", await poL.profitRecipient(), lockerAddress,
    "setProfitRecipient", [lockerAddress]);

  // Each immutable-in-practice position is configured only once, when its real
  // address and ID have been provided. Missing positions stay disabled.
  if (p.curvePool) {
    await mustConfigure("PoL Curve pool", await poL.curvePool(), p.curvePool,
      "configureCurvePool", [p.curvePool, p.curveLp]);
    // A position already configured to the same pool must also match its LP token.
    if ((await poL.curveLp()).toLowerCase() !== p.curveLp.toLowerCase()) {
      throw new Error("PoL Curve LP differs from the one-time configured LP");
    }
  }
  if (p.curveGauge) {
    await mustConfigure("PoL Curve gauge", await poL.curveGauge(), p.curveGauge,
      "configureCurveGauge", [p.curveGauge]);
  }
  if (p.uniNftManager) {
    await mustConfigure("PoL Uniswap manager", await poL.uniNftManager(), p.uniNftManager,
      "configureUniswapPosition", [p.uniNftManager, p.uniTokenId]);
    if ((await poL.uniTokenId()) !== BigInt(p.uniTokenId)) {
      throw new Error("PoL Uniswap token ID differs from the one-time configured token ID");
    }
  }

  if (await boostMerchant.postListingIfNoAcceptableOffer() !== !!c.boostEconomics.postListingIfNoAcceptableOffer) {
    await send(ctx, "configure:merchant.setPostListingFallback", boostMerchant,
      "setPostListingIfNoAcceptableOffer", [!!c.boostEconomics.postListingIfNoAcceptableOffer]);
  }

  const rates = c.boostEconomics.merchantSaleRates;
  if (rates && rates.postPricePerWeek && rates.minimumFillPricePerWeek && rates.sdtWeiPerUsdc) {
    const proposed = [BigInt(rates.postPricePerWeek), BigInt(rates.minimumFillPricePerWeek), BigInt(rates.sdtWeiPerUsdc)];
    const actual = [await boostMerchant.postPricePerWeek(), await boostMerchant.minimumFillPricePerWeek(), await boostMerchant.sdtWeiPerUsdc()];
    if (actual.some((v, i) => v !== proposed[i])) {
      await send(ctx, "configure:merchant.setSaleRates", boostMerchant, "setSaleRates", proposed);
    }
  }
  if (ethers.getAddress(await revenueVault.strategy()) !== ethers.getAddress(await revenueStrategy.getAddress())) {
    throw new Error("revenue Beefy V8 vault is bound to a different strategy");
  }
  const rv = c.revenueVault;
  if (Number(await revenueVault.withdrawalFeeBps()) !== rv.withdrawalFeeBps
      || Number(await revenueStrategy.performanceFeeBps()) !== rv.performanceFeeBps
      || Number(await revenueStrategy.callFeeBps()) !== rv.callFeeBps) {
    throw new Error("Revenue Beefy V8 fee configuration differs from deployment config");
  }

  // This is a direct call to the external vlBoost contract, not an Aragon action.
  await send(ctx, "configure:locker.setMarketplaceOperator", locker, "setMarketplaceOperator", [true]);

  ctx.state.phase = "configured";
  saveState(ctx.stateFile, ctx.state);
  console.log(`configuration complete; state=${ctx.stateFile}`);
  return ctx;
}


if (require.main === module) deployAndConfigure().catch(e => { console.error(e); process.exitCode = 1; });
module.exports = { assertContractAbi, assertActiveConfigurationAbi, deployAndConfigure };
