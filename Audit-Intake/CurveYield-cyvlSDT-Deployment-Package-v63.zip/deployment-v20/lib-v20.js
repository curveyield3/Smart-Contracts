#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { ethers } = require("ethers");

const ROOT = path.resolve(__dirname, "..");
const EXPECTED_FINAL_OWNER = "0x9f2B20A772246960810045905B7daccf960eE288";

const DEPLOYABLES = [
  ["cyvlSdt", "CurveYieldVlSDTToken"],
  ["locker", "CurveYieldVlSDTLocker"],
  ["revenueStaking", "CurveYieldvlSDTStaking"],
  ["boostMerchant", "CurveYieldVlSDTBoostMerchant"],
  ["revenueStrategy", "CurveYieldRevenueStrategyV8"],
  ["revenueVault", "BeefyVaultCurveYieldV8cyvlSDT"],
  ["bribeAllocator", "VoteMarketSingleGaugeBribeAllocator"],
  ["poLLiquidityBounds", "CurvePairOracleBoundsV8"],
  ["poLManager", "PoLManager"]
];

const OWNABLE_CONTRACTS = DEPLOYABLES.filter(([key]) => !["poLLiquidityBounds"].includes(key));

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(
    file,
    JSON.stringify(value, (_, v) => typeof v === "bigint" ? v.toString() : v, 2) + "\n"
  );
}

function requireAddress(label, value) {
  if (!ethers.isAddress(value) || value === ethers.ZeroAddress) {
    throw new Error(`${label} must be a non-zero address`);
  }
  return ethers.getAddress(value);
}

function optionalAddress(label, value) {
  if (value === null || value === undefined || value === "") return ethers.ZeroAddress;
  if (!ethers.isAddress(value)) throw new Error(`${label} must be an address or null`);
  return ethers.getAddress(value);
}

function integerInRange(label, value, min, max) {
  if (!Number.isInteger(value) || value < min || value > max) {
    throw new Error(`${label} must be an integer in ${min}..${max}`);
  }
  return value;
}

function loadConfig(configPath) {
  const resolved = path.resolve(configPath || path.join(ROOT, "config-mainnet-v47.json"));
  const c = readJson(resolved);
  if (c.version !== 47 || c.release !== "47" || c.chainId !== 1) {
    throw new Error("V47 Ethereum-mainnet config required");
  }

  c.finalOwner = requireAddress("finalOwner", c.finalOwner);
  c.finalAdmin = requireAddress("finalAdmin", c.finalAdmin);
  c.feeReceivers.treasury = requireAddress("feeReceivers.treasury", c.feeReceivers.treasury);
  if (c.finalOwner !== ethers.getAddress(EXPECTED_FINAL_OWNER)) {
    throw new Error(`finalOwner must be ${EXPECTED_FINAL_OWNER}`);
  }
  if (c.feeReceivers.treasury !== c.finalOwner) {
    throw new Error("feeReceivers.treasury must equal finalOwner");
  }

  c.existingContracts = c.existingContracts || {};
  for (const [key, value] of Object.entries(c.existingContracts)) {
    c.existingContracts[key] = requireAddress(`existingContracts.${key}`, value);
  }

  for (const [key, value] of Object.entries(c.stakeDao)) {
    c.stakeDao[key] = requireAddress(`stakeDao.${key}`, value);
  }

  c.revenueStakingConfig = c.revenueStakingConfig || {};
  integerInRange(
    "revenueStakingConfig.immediateWithdrawFeePpm",
    c.revenueStakingConfig.immediateWithdrawFeePpm,
    0,
    35_000
  );

  c.revenueVault = c.revenueVault || {};
  integerInRange("revenueVault.withdrawalFeeBps", c.revenueVault.withdrawalFeeBps, 0, 100);
  integerInRange("revenueVault.performanceFeeBps", c.revenueVault.performanceFeeBps, 0, 900);
  integerInRange("revenueVault.callFeeBps", c.revenueVault.callFeeBps, 0, 100);
  if (c.revenueVault.performanceFeeBps + c.revenueVault.callFeeBps > 1000) {
    throw new Error("combined revenue-vault harvest fees exceed 10%");
  }


  const b = c.bribeAllocator;
  if (!b || !b.voteMarket || !ethers.isAddress(b.voteMarket)) {
    throw new Error("bribeAllocator.voteMarket must be an Ethereum VoteMarket contract");
  }
  b.voteMarket = requireAddress("bribeAllocator.voteMarket", b.voteMarket);
  if (b.gauge) b.gauge = requireAddress("bribeAllocator.gauge", b.gauge);
  if (!b.minimumReturnWad || BigInt(b.minimumReturnWad) < 10n ** 18n) {
    throw new Error("bribeAllocator.minimumReturnWad must be >= 1e18");
  }

  if (c.lockerRevenueDiversions?.poLDeposit?.recipient) {
    throw new Error("poLDeposit.recipient must be null; deploy the bundled PoL Manager");
  }
  const p = c.poLManager;
  if (!p || p.sourceVersion !== 22 || !p.crv) throw new Error("PoL Manager v22 configuration required");
  p.crv = requireAddress("poLManager.crv", p.crv);

  c.omniRouter = requireAddress("omniRouter", c.omniRouter);
  c.usdc = requireAddress("usdc", c.usdc);
  return { config: c, configPath: resolved };
}

const ARTIFACT_SOURCE_FILES = {
  CurvePairOracleBoundsV8: "external_guard_v8/CurvePairOracleBounds_v8",
  PoLManager: "PoL_Manager_Contract_v22"
};

function artifactPath(name) {
  const sourceName = ARTIFACT_SOURCE_FILES[name] || name;
  return path.join(ROOT, "artifacts-v47", "contracts", `${sourceName}.sol`, `${name}.json`);
}

function loadArtifact(name) {
  const artifactFile = artifactPath(name);
  if (!fs.existsSync(artifactFile)) {
    const hint = "Run npm run compile:v47 first.";
    throw new Error(`Missing artifact ${artifactFile}. ${hint}`);
  }
  const artifact = readJson(artifactFile);
  if (!artifact.bytecode || artifact.bytecode === "0x") {
    throw new Error(`Artifact ${name} has no deployable bytecode`);
  }
  return artifact;
}

function statePath(chainId, tag = "live") {
  return path.join(ROOT, "deployment-output-v47", `deployment-state-v47-${tag}-${chainId}.json`);
}

function loadState(file, chainId, deployer) {
  if (fs.existsSync(file)) return readJson(file);
  return {
    version: 47,
    chainId: String(chainId),
    deployer,
    phase: "new",
    contracts: {},
    transactions: [],
    gasUsed: "0"
  };
}

function saveState(file, state) {
  writeJson(file, state);
}

function gasLimit(estimate, bps) {
  return estimate * BigInt(bps || 12000) / 10000n + 25000n;
}

async function pendingNonce(ctx) {
  const value = await ctx.provider.send(
    "eth_getTransactionCount",
    [ctx.wallet.address, "pending"]
  );
  return Number(value);
}

async function codeExists(provider, address) {
  return (await provider.getCode(address)) !== "0x";
}

async function recordReceipt(state, label, receipt) {
  const used = receipt.gasUsed || 0n;
  state.gasUsed = (BigInt(state.gasUsed || "0") + used).toString();
  state.transactions.push({
    label,
    hash: receipt.hash,
    blockNumber: receipt.blockNumber,
    gasUsed: used.toString(),
    status: receipt.status
  });
}

async function deployOne(ctx, key, name, args) {
  const configuredAddressRaw = ctx.config.existingContracts?.[key];
  if (configuredAddressRaw) {
    const configuredAddress = requireAddress(`existingContracts.${key}`, configuredAddressRaw);
    const existing = ctx.state.contracts[key];
    if (existing?.address && ethers.getAddress(existing.address) !== configuredAddress) {
      throw new Error(
        `${key} state address ${existing.address} differs from configured predeployed address ${configuredAddress}`
      );
    }
    if (!await codeExists(ctx.provider, configuredAddress)) {
      throw new Error(`configured predeployed ${key} has no code: ${configuredAddress}`);
    }
    const artifact = loadArtifact(name);
    if (!existing) {
      ctx.state.contracts[key] = {
        name,
        address: configuredAddress,
        constructorArgs: null,
        deploymentTx: null,
        deploymentGas: "0",
        predeployed: true
      };
      saveState(ctx.stateFile, ctx.state);
    }
    console.log(`attached predeployed ${name} ${configuredAddress}`);
    return new ethers.Contract(configuredAddress, artifact.abi, ctx.wallet);
  }

  const existing = ctx.state.contracts[key];
  if (existing && await codeExists(ctx.provider, existing.address)) {
    return new ethers.Contract(existing.address, loadArtifact(name).abi, ctx.wallet);
  }
  const artifact = loadArtifact(name);
  const factory = new ethers.ContractFactory(artifact.abi, artifact.bytecode, ctx.wallet);
  const txRequest = await factory.getDeployTransaction(...args);
  const estimate = await ctx.provider.estimateGas({ ...txRequest, from: ctx.wallet.address });
  const nonce = await pendingNonce(ctx);
  const deployed = await factory.deploy(...args, {
    gasLimit: gasLimit(estimate, ctx.config.deployment.gasLimitMultiplierBps),
    nonce
  });
  const receipt = await deployed.deploymentTransaction().wait(ctx.confirmations);
  const address = await deployed.getAddress();
  ctx.state.contracts[key] = {
    name,
    address,
    constructorArgs: args.map(a => typeof a === "object" ? JSON.stringify(a) : String(a)),
    deploymentTx: receipt.hash,
    deploymentGas: receipt.gasUsed.toString()
  };
  await recordReceipt(ctx.state, `deploy:${name}`, receipt);
  saveState(ctx.stateFile, ctx.state);
  console.log(`deployed ${name} ${address} gas=${receipt.gasUsed}`);
  return deployed;
}

async function send(ctx, label, target, method, args = []) {
  const populated = await target[method].populateTransaction(...args);
  const estimate = await ctx.provider.estimateGas({ ...populated, from: ctx.wallet.address });
  const nonce = await pendingNonce(ctx);
  const tx = await target[method](...args, {
    gasLimit: gasLimit(estimate, ctx.config.deployment.gasLimitMultiplierBps),
    nonce
  });
  const receipt = await tx.wait(ctx.confirmations);
  await recordReceipt(ctx.state, label, receipt);
  saveState(ctx.stateFile, ctx.state);
  console.log(`${label} gas=${receipt.gasUsed} tx=${receipt.hash}`);
  return receipt;
}

async function makeContext({
  configPath,
  rpcUrl,
  privateKey,
  tag = "live",
  confirmations,
  stateFile,
  allowWalletMismatch = false
} = {}) {
  const { config } = loadConfig(configPath);
  if (!rpcUrl) throw new Error("RPC URL required");
  if (!privateKey) throw new Error("private key required");
  const provider = new ethers.JsonRpcProvider(
    rpcUrl,
    config.chainId,
    { staticNetwork: true, batchMaxCount: 1 }
  );
  const wallet = new ethers.Wallet(privateKey, provider);
  const network = await provider.getNetwork();
  if (Number(network.chainId) !== config.chainId) {
    throw new Error(`wrong chain: ${network.chainId}, expected ${config.chainId}`);
  }
  const file = stateFile || statePath(network.chainId, tag);
  const state = loadState(file, network.chainId, wallet.address);
  if (!allowWalletMismatch && ethers.getAddress(state.deployer) !== wallet.address) {
    throw new Error("state deployer differs from current wallet");
  }
  return {
    config,
    provider,
    wallet,
    state,
    stateFile: file,
    confirmations: confirmations ?? config.deployment.confirmations
  };
}

function contract(ctx, key, signer = ctx.wallet) {
  const entry = ctx.state.contracts[key];
  if (!entry) throw new Error(`missing deployed contract ${key}`);
  const pair = DEPLOYABLES.find(([candidate]) => candidate === key);
  const artifactName = pair?.[1] || entry.name;
  if (!artifactName) throw new Error(`missing artifact name for deployed contract ${key}`);
  return new ethers.Contract(entry.address, loadArtifact(artifactName).abi, signer);
}

async function assertExternalDependencies(provider, config) {
  for (const [label, address] of Object.entries(config.stakeDao)) {
    if (!await codeExists(provider, address)) throw new Error(`${label} has no code: ${address}`);
  }
  const usdcDistributor = new ethers.Contract(
    config.stakeDao.vlSdtFeeDistributorUsdc,
    ["function REWARD_TOKEN() view returns (address)"],
    provider
  );
  const sdtDistributor = new ethers.Contract(
    config.stakeDao.vlSdtFeeDistributorSdt,
    ["function REWARD_TOKEN() view returns (address)"],
    provider
  );
  const usdc = requireAddress(
    "vlSdtFeeDistributorUsdc.REWARD_TOKEN",
    await usdcDistributor.REWARD_TOKEN()
  );
  const sdt = requireAddress(
    "vlSdtFeeDistributorSdt.REWARD_TOKEN",
    await sdtDistributor.REWARD_TOKEN()
  );
  if (!await codeExists(provider, usdc)) {
    throw new Error(`USDC fee distributor reward token has no code: ${usdc}`);
  }
  if (!await codeExists(provider, sdt)) {
    throw new Error(`SDT fee distributor reward token has no code: ${sdt}`);
  }
  if (sdt !== config.stakeDao.sdt) {
    throw new Error(`SDT fee distributor reward token mismatch: ${sdt}`);
  }
  if (usdc !== config.usdc) {
    throw new Error(`USDC fee distributor reward token mismatch: ${usdc}`);
  }
  if (!await codeExists(provider, config.omniRouter)) throw new Error(`OmniRouter has no code: ${config.omniRouter}`);
  // Validate the deployed router ABI even when pool routes do not exist yet.
  const omni = new ethers.Contract(config.omniRouter, [
    "function owner() view returns (address)",
    "function routeLength(address,address) view returns (uint256)",
    "function guardedMinOut(address,address,uint256) view returns (uint256)"
  ], provider);
  if ((await omni.owner()) === ethers.ZeroAddress) throw new Error("OmniRouter has no owner");
  await omni.routeLength(config.stakeDao.sdt, config.usdc);
  return { usdc, sdt, all: [usdc, sdt] };
}

async function assertOwner(target, expected, label) {
  const actual = ethers.getAddress(await target.owner());
  if (actual !== ethers.getAddress(expected)) {
    throw new Error(`${label}.owner=${actual}, expected ${expected}`);
  }
}

module.exports = {
  ROOT,
  EXPECTED_FINAL_OWNER,
  DEPLOYABLES,
  OWNABLE_CONTRACTS,
  ethers,
  readJson,
  writeJson,
  requireAddress,
  optionalAddress,
  loadConfig,
  loadArtifact,
  statePath,
  loadState,
  saveState,
  gasLimit,
  codeExists,
  recordReceipt,
  deployOne,
  send,
  makeContext,
  contract,
  assertExternalDependencies,
  assertOwner
};
