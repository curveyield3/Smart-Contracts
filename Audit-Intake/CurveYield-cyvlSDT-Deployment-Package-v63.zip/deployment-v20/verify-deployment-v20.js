#!/usr/bin/env node
"use strict";

const path = require("path");
const {
  ethers,
  makeContext,
  contract,
  assertExternalDependencies,
  assertOwner,
  writeJson,
  ROOT,
  OWNABLE_CONTRACTS
} = require("./lib-v20");

async function verifyDeployment(options = {}) {
  const ctx = await makeContext({
    configPath: options.configPath || process.argv[2],
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag: options.tag || process.env.DEPLOYMENT_TAG || "live",
    confirmations: 0,
    allowWalletMismatch: true
  });

  const c = ctx.config;
  const expectedOwner = options.expectedOwner || process.env.EXPECTED_OWNER || ctx.wallet.address;
  const expectedAdmin = options.expectedAdmin || process.env.EXPECTED_ADMIN
    || (ethers.getAddress(expectedOwner) === c.finalOwner ? c.finalAdmin : ctx.wallet.address);
  const feeDistributorRewardTokens = await assertExternalDependencies(ctx.provider, c);

  for (const [key] of OWNABLE_CONTRACTS) {
    await assertOwner(contract(ctx, key), expectedOwner, key);
  }

  const cyvlSdt = contract(ctx, "cyvlSdt");
  const locker = contract(ctx, "locker");
  const revenueStaking = contract(ctx, "revenueStaking");
  const boostMerchant = contract(ctx, "boostMerchant");
  const revenueVault = contract(ctx, "revenueVault");
  const revenueStrategy = contract(ctx, "revenueStrategy");
  const bribeAllocator = contract(ctx, "bribeAllocator");
  const poL = contract(ctx, "poLManager");
  const poLBounds = contract(ctx, "poLLiquidityBounds");

  const eq = (actual, expected, label) => {
    if (ethers.getAddress(actual) !== ethers.getAddress(expected)) {
      throw new Error(`${label}: ${actual} != ${expected}`);
    }
  };

  eq(await locker.treasuryReceiver(), c.finalOwner, "locker treasury");
  eq(await revenueStaking.treasuryReceiver(), c.finalOwner, "revenue treasury");
  eq(await revenueStaking.admin(), expectedAdmin, "revenue admin");
  if (Number(await revenueStaking.immediateWithdrawFeePpm()) !== c.revenueStakingConfig.immediateWithdrawFeePpm) {
    throw new Error("revenue staking immediate withdrawal fee mismatch");
  }
  if ((await revenueStaking.STREAM_DURATION()) !== 604800n
      || (await revenueStaking.FIRST_EXCESS_TREASURY_BPS()) !== 1500n
      || (await revenueStaking.FIRST_EXCESS_ADMIN_BPS()) !== 500n
      || (await revenueStaking.FIRST_EXCESS_POL_BPS()) !== 500n
      || (await revenueStaking.SECOND_EXCESS_TREASURY_BPS()) !== 2000n
      || (await revenueStaking.SECOND_EXCESS_ADMIN_BPS()) !== 1000n
      || (await revenueStaking.SECOND_EXCESS_POL_BPS()) !== 1000n) {
    throw new Error("seven-day independent streams / two-tier fee policy mismatch");
  }
  if ((await locker.DAO_BOOST_BPS()) !== 1000n) throw new Error("DAO boost cap must be 10%");
  if ((await locker.MAX_POL_DEPOSIT_SHARE_BPS()) !== 2500n) throw new Error("PoL deposit maximum must be 25%");
  // New deposits must track gross SDT for the reward benchmark, not only vlSDT backing.
  if ((await locker.grossSDTPrincipalForBase()) !== (await locker.baseSDTEquivalent(await cyvlSdt.totalSupply()))) {
    throw new Error("base benchmark principal does not account for gross mint deposits");
  }
  eq(await revenueStaking.SDT_DISTRIBUTOR(), c.stakeDao.vlSdtFeeDistributorSdt, "SDT distributor");
  eq(await revenueStaking.USDC_DISTRIBUTOR(), c.stakeDao.vlSdtFeeDistributorUsdc, "USDC distributor");
  eq(await revenueStaking.OMNI_ROUTER(), c.omniRouter, "Staking OmniRouter");
  eq(await revenueStaking.LOCKER(), await locker.getAddress(), "Staking Locker");
  eq(await locker.admin(), expectedAdmin, "locker admin source");
  if (Number(await locker.ADMIN_BOOST_BPS()) !== 500) throw new Error("admin boost cap is not fixed at 5%");
  eq(await cyvlSdt.locker(), await locker.getAddress(), "cyvl locker");
  eq(await locker.revenueStaking(), await revenueStaking.getAddress(), "locker revenue staking");
  eq(await locker.boostMerchant(), await boostMerchant.getAddress(), "locker merchant");
  eq(await locker.STAKE_DAO_ROUTER(), c.stakeDao.router, "locker Stake DAO Router");
  eq(
    await locker.VLSDT_FEE_DISTRIBUTOR_USDC(),
    c.stakeDao.vlSdtFeeDistributorUsdc,
    "locker USDC vlSDT FeeDistributor"
  );
  eq(
    await locker.VLSDT_FEE_DISTRIBUTOR_SDT(),
    c.stakeDao.vlSdtFeeDistributorSdt,
    "locker SDT vlSDT FeeDistributor"
  );
  eq(
    await locker.USDC_REWARD_TOKEN(),
    feeDistributorRewardTokens.usdc,
    "locker USDC reward token"
  );

  eq(await revenueVault.strategy(), await revenueStrategy.getAddress(), "revenue Beefy V8 strategy");
  eq(await revenueStrategy.vault(), await revenueVault.getAddress(), "revenue strategy vault");
  eq(await revenueStrategy.want(), await cyvlSdt.getAddress(), "revenue strategy want");
  eq(await revenueVault.want(), await cyvlSdt.getAddress(), "revenue Beefy V8 underlying");
  eq(await revenueStrategy.OMNI_ROUTER(), c.omniRouter, "revenue strategy OmniRouter");
  eq(await revenueStrategy.LOCKER(), await locker.getAddress(), "revenue strategy Locker");
  eq(await revenueVault.adminFeeReceiver(), c.feeReceivers.treasury, "revenue Beefy V8 fee receiver");
  if (Number(await revenueVault.withdrawalFeeBps()) !== c.revenueVault.withdrawalFeeBps
      || Number(await revenueStrategy.performanceFeeBps()) !== c.revenueVault.performanceFeeBps
      || Number(await revenueStrategy.callFeeBps()) !== c.revenueVault.callFeeBps) {
    throw new Error("revenue Beefy V8/strategy configured fees mismatch");
  }
  if ((await revenueStrategy.MAX_PERFORMANCE_FEE_BPS()) !== 900n) {
    throw new Error("revenue strategy performance fee cap is not 9%");
  }

  for (const rewardToken of [...feeDistributorRewardTokens.all, await cyvlSdt.getAddress()]) {
    if (!(await revenueStaking.isRewardToken(rewardToken))) {
      throw new Error(`fee distributor reward token not registered: ${rewardToken}`);
    }
  }
  // A single Locker receipt path prevents Merchant leases bypassing the LP bribe share.
  eq(await revenueStaking.LOCKER(), await locker.getAddress(), "sole revenue notification source");
  if (Number(await revenueStaking.lpBribeRevenueShareBps()) !== c.lockerRevenueDiversions.lpBribeRevenue.shareBps)
    throw new Error("Staking LP-bribe revenue share differs from config");
  eq(await revenueStaking.lpBribeContract(), await bribeAllocator.getAddress(), "Staking LP-bribe recipient");
  if (Number(await locker.poLDepositShareBps()) !== c.lockerRevenueDiversions.poLDeposit.shareBps)
    throw new Error("PoL deposit share differs from config");
  eq(await locker.cyvlSdtPoLContract(), await poL.getAddress(), "PoL recipient");
  eq(await poL.sdt(), c.stakeDao.sdt, "PoL SDT");
  eq(await poL.omniRouter(), c.omniRouter, "PoL OmniRouter");
  eq(await poL.liquidityBounds(), await poLBounds.getAddress(), "PoL bounds");
  eq(await poL.profitRecipient(), await locker.getAddress(), "PoL performance-fee recipient");
  if (Number(await poL.curveSlippageBps()) !== c.poLManager.curveSlippageBps)
    throw new Error("PoL Curve slippage mismatch");
  if (Number(await poL.uniSlippageBps()) !== c.poLManager.uniSlippageBps)
    throw new Error("PoL Uniswap slippage mismatch");
  if (c.poLManager.curvePool) {
    eq(await poL.curvePool(), c.poLManager.curvePool, "PoL Curve pool");
    eq(await poL.curveLp(), c.poLManager.curveLp, "PoL Curve LP");
  }
  if (c.poLManager.curveGauge) eq(await poL.curveGauge(), c.poLManager.curveGauge, "PoL gauge");
  if (c.poLManager.uniNftManager) {
    eq(await poL.uniNftManager(), c.poLManager.uniNftManager, "PoL Uniswap manager");
    if ((await poL.uniTokenId()) !== BigInt(c.poLManager.uniTokenId))
      throw new Error("PoL Uniswap NFT ID mismatch");
  }
  eq(await bribeAllocator.OMNI_ROUTER(), c.omniRouter, "bribe allocator OmniRouter");
  eq(await bribeAllocator.VOTEMARKET(), c.bribeAllocator.voteMarket, "bribe allocator VoteMarket");
  eq(await bribeAllocator.gauge(), c.bribeAllocator.gauge || ethers.ZeroAddress, "bribe allocator gauge");
  if ((await bribeAllocator.minimumReturnWad()) !== BigInt(c.bribeAllocator.minimumReturnWad)) {
    throw new Error("bribe allocator configured return multiple mismatch");
  }
  const report = {
    version: 47,
    release: c.release || "31",
    chainId: String((await ctx.provider.getNetwork()).chainId),
    expectedOwner,
    deployer: ctx.wallet.address,
    finalOwner: c.finalOwner,
    finalAdmin: c.finalAdmin,
    expectedAdmin,
    feeDistributorRewardTokens,
    contracts: ctx.state.contracts,
    gasUsed: ctx.state.gasUsed,
    verifiedAt: new Date().toISOString()
  };
  const output = path.join(
    ROOT,
    "deployment-output-v47",
    `verification-v47-${options.tag || process.env.DEPLOYMENT_TAG || "live"}.json`
  );
  writeJson(output, report);
  console.log(`verification passed; report=${output}`);
  return { ctx, report };
}

if (require.main === module) {
  verifyDeployment().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { verifyDeployment };
