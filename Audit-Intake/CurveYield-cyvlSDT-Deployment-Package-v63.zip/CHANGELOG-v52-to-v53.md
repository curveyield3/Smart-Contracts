# cyvlSDT v52 → v53

- Removed the unshipped v53 proxy plan. No proxies, delegatecall, implementation slots, or upgradeable implementation sources.
- Added explicit owner-controlled, liability-gated setter functions across token, locker, staking, merchant, asynchronous revenue vault/strategy, Beefy V8 vault and bribe allocator.
- Added direct rebinding methods to PoL v22 for its OmniRouter, cyvlSDT token, Curve pool/gauge, and Uniswap NFT configuration, with explicit approval revocation and position-drain prerequisites.
- Preserved `StrategyCurveSDTYearnV9.sol` byte-for-byte. Added an independently named V9-derived rebindable strategy to support future vault, Yearn and oracle-guard replacement; deployed owner is the CurveYield Safe.
- Added v53 SDT-Yearn-Beefy deployment config/script invoking the rebindable strategy, retaining existing v51 inputs for provenance.
- Added a permanent `CurveYieldVault` configurator role (instead of permanently burning it), transferred to the Safe in the existing owner handoff and checked in deployment verification.
- Preserved economic calculations, subject to future source compilation/security verification; actual runtime equivalence unverified.
- No tests, deployment, simulations, Safe proposals or contract compilation performed.
