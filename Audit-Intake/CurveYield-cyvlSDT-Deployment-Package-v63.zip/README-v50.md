# CurveYield cyvlSDT Deployment Package v50

**Source update only — no contracts or factory vaults deployed.** Successor to the intact v49 package.

## Requested integration implemented

The supplied `CurveYield_SDT_Yearn_Beefy_v9 (1).zip` provides `StrategyCurveSDTYearnV9.sol`, which previously targeted the old `BeefyVaultV7FixedV2` interface. Version **v50** imports that actual strategy as `contracts/StrategyCurveSDTYearnV10.sol` and binds it explicitly to the **existing renamed** `contracts/BeefyVaultCurveYieldV8.sol` from v49 (sourced from BoostHub Contract Stack v63). It does **not** copy the stale old vault shipped with the strategy ZIP.

Source changes to the strategy (v9 → v10):

- Import and explicitly implement `IStrategyBoostHubV1` required by `BeefyVaultCurveYieldV8` (including compiler-checked overrides of the immutable `vault` and `want` getters, `deposit`, `withdraw`, `balanceOf`, `lockVaultProfit`).
- Rename the minimal vault read interface to `IBeefyVaultCurveYieldV8` (`totalSupply`, `adminFeeReceiver`), using the exact selectors available in the new vault. Remove the unused fee getter from this interface.
- Update NatSpec, constructor binding documentation and emergency-withdrawal semantics to the v63-derived V8 vault and Guard V8. **No strategy valuation, slippage algorithm, withdrawal, Yearn V2 accounting, fee, or asset flow changed.**
- Preserve the source strategy constructor `(address predictedBeefyVault, address factoryYearnV2Vault, address curveGuardV8)` and immutable binding. The strategy is **not** pointed at a generic Yearn V3 ERC-4626 vault.

## Additional deployment (two vaults plus one strategy)

Executable deployment entrypoint: `deployment-v27/deploy-sdt-yearn-beefy-v50.js` using `config-sdt-yearn-v50.json`.

1. Confirm Ethereum mainnet (`chainId=1`), live Curve Twocrypto-NG SDT/WETH pool and attached gauge, and the configured external CurvePairOracleBounds **V8** guard.
2. Ask Yearn's official **Curve LP Factory** `0x21b1FC8A52f179757bf555346130bF27c0C2A17A` for `latestStandardVaultFromGauge(gauge)`. If absent, call the exact permissionless `createNewVaultsAndStrategies(gauge)` method **once**, read the real `NewAutomatedVault` event and retain the vault address. The event/contract is the source of truth; this stage deploys a **Yearn V2 factory vault** and its associated Yearn strategies for the Curve SDT/WETH LP. The pool itself already exists and is **not** redeployed.
3. Verify that the Yearn V2 vault `token()` equals the Curve SDT/WETH LP. Its `pricePerShare` and share-denominated `withdraw(maxShares,recipient,maxLoss)` match the supplied strategy, unlike ERC-4626 V3.
4. Read the next unused Ethereum deployer CREATE nonce `N`. Predict the additional Beefy vault's address as the deployer's address at `N+1`.
5. Deploy `StrategyCurveSDTYearnV10` at nonce `N` using `(predictedBeefy, factoryYearnV2Vault, curveGuardV8)`. Check the strategy's live getters.
6. Deploy `BeefyVaultCurveYieldV8` at nonce `N+1` using `(strategy, name, symbol, withdrawalFeeBps=50, adminFeeReceiver)`. The vault constructor verifies `strategy.vault() == address(this)`.
7. Set deposit fee if different from zero, transfer Beefy vault ownership to CurveYield Safe and verify on-chain strategy, underlying, owner and fee addresses. Save transaction hashes and addresses in `deployment-output-v50/sdt-yearn-beefy-v50-ethereum.json` (generated at runtime, not pre-filled).

**Live source-bound preflight at package assembly:** Curve pool `0xA19bf6fBf05624282cb6ed498f4761f22e084Edd` has `coins(0)=WETH`, `coins(1)=SDT`, `factory()=0x98EE851a00abeE0d95D08cF4CA2BdCE32aeaAF7F` and gauge `0xb84637ab9be835580821a67823f414ffd0bbf625` (the gauge reports that same pool as `lp_token()`). The Yearn factory reported `canCreateVaultPermissionlessly(gauge)=true` and `latestStandardVaultFromGauge(gauge)=0x0` at observation time (Nov 22, 2026). Guard V8 at `0xAB989D9Daa0279e123d453204545be556F2D3072` returned nonzero quote minimums for sample SDT deposits and LP redemptions. All of those reads must be rechecked at execution time.

## Fees, guarded behavior and known caveats

- Beefy V8 immutable withdrawal fee default **50 bps**; it distributes **30% to the admin receiver / 70% retained for remaining shares**, while the **final-share withdrawal sends the entire fee to the admin receiver**. The new strategy's `lockVaultProfit` is a vault-only no-op, retaining SDT in strategy NAV rather than lockups or reward harvesting.
- SDT-only one-sided Curve deposit and withdrawal use Guard V8 `quoteDeposit/quoteWithdraw(pool,1,...,200)` for **2%** external historical-oracle minimums. The emergency path through the SDT Yearn strategy **still uses this guard**. A failed Curve guard, Curve execution or gross SDT settlement reverts.
- Yearn V2 deposit errors can be deferred with Curve LP retained in the strategy. Yearn V2 redemption with `maxLoss=0` can revert if losses/liquidity cannot satisfy the request. `balanceOf()` values shares through Yearn V2 `pricePerShare` followed by Curve one-sided withdrawal quotation.
- The v63 Beefy V8 vault can skip calling the strategy when it already holds enough idle SDT. Thus a last-share redemption with negligible strategy dust valued at zero might not invoke strategy's final sweep. This is a limitation of the preserved V8 vault/strategy ABI; this v50 update does **not** silently change the V8 implementation.
- The new Beefy vault and strategy are **additional**. The existing asynchronous `contracts/CurveYieldVault.sol` and `CurveYieldRevenueStrategyV20.sol` stay in the unchanged original cyvlSDT revenue subsystem; attempting to switch them to Beefy V8 would break asynchronous redemptions.
- The Yearn factory and strategies are external code and can have governance restrictions, actual deposit limits and return profiles. A green permissionless creation flag is not a guarantee of future deposit success or yield.

## Reproducible build and execution instructions

The root Hardhat project already contains the OpenZeppelin 5 core plus pinned separate `@openzeppelin-4/contracts@4.9.6` alias used by V8/SDT Yearn strategy. Its Solidity settings are 0.8.28/0.8.30, optimizer 200 runs, viaIR, Cancun. The v49 lockfile retained an OZ4 alias without a verified npm integrity digest; regenerate/verify the lockfile in a trusted environment with registry access before claiming `npm ci` reproducibility. The historical standalone SDT package's Foundry profile was solc 0.8.20/Paris; **v50 uses the cyvlSDT project Hardhat profile instead**, so bytecode differs from standalone v9 artifacts even when economic code is unchanged.

```sh
npm ci
npm run compile:v50
RPC_URL=<ethereum-rpc> DEPLOYER_PRIVATE_KEY=<deployer-private-key> \
  npm run deploy:sdt-yearn:v50
```

Do **not** publish your private key in repository files or logs. Deployment creates Ethereum mainnet transactions if explicitly run; packaging or compilation alone does not run it. The deployment entrypoint is separate from original `deploy:v47` and does not require running the obsolete v4 Safe handoff. `deployment-output-v50` must be preserved after each successful stage for restarts. When a reserved CREATE nonce has been consumed externally, the script aborts rather than risk pointing the vault at the wrong strategy.

## Compilation and deployment status

`node --check` of the new deployment script completed without syntax errors. Static source/interface mapping and actual read-only chain ABI checks were performed. **No Solidity compiler was run, no test or simulation executed, no factory creation transaction was submitted, and no contract deployment/verification was broadcast** in this packaging operation. Compiler/deployment acceptance remain unverified until separately executed.
