# CurveYield cyvlSDT source package v53 — NO PROXIES

Successor to v52. Owner-controlled rebinding for individually redeployable contracts, retaining the original V9 strategy bytes. New active V9-derived source: `contracts/StrategyCurveSDTYearnRebindable.sol`. See `REPLACEMENT_ARCHITECTURE_REPORT_v1.md` for every dependency, safety precondition, migration order, and current compile/deployment limits.

**No proxy source or upgrade controller is shipped.** Replacing a contract means deploying a new independent contract and changing the explicitly controlled address in its dependent contract(s). Economic liabilities must be settled before those changes. No test execution, compile, simulation, GitHub write, Safe proposal, or on-chain deployment was performed.

Source-only status: do not treat the package as audited or production-deployable until compiled and independent runtime/security verification is authorized.
