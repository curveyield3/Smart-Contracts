# CurveYield cyvlSDT v31 → v32 — implementation audit trail

**Source lineage:** exact v31 `CurveYield-cyvlSDT-Deployment-Package-v31.zip`, retained nine-deployable design. This changelog enumerates all code changes in v32.

## Removed contracts and interfaces

**None in this upgrade.** Seven v30 cyGOV-only contracts and the v30 ChildGauge were already removed in v31; no removed dependencies were restored.

## Contract changed: `contracts/CurveYieldVlSDTLocker.sol`

1. Added the **minimal** `IAladdinVlSDTDelegation` interface (`boost(uint256,uint256,address)`, `claim(address,address)`) in the existing Locker source; **no new contract is deployed**.
2. Added `ALADDIN_DELEGATION` mainnet proxy address constant `0x322c76e1205dE5ee4146e40644563B482B1CDA43`. The destination is the live proxy, not the underlying implementation.
3. Added `setAladdinDelegationOperator(bool)` for the owner to call existing `VLBOOST.setOperator(ALADDIN_DELEGATION, approved)` as the Locker itself. Added `AladdinDelegationOperatorSet` event. This does not authorize a keeper or EOA to delegate the Locker's boost independently.
4. Added `delegateAladdinBoost(amount,endtime)` (owner only, reentrancy guarded): floors expiry to a week boundary, uses **existing** `_validateBoostEndtime`, caps delegation by **existing** `daoDelegableBoost()`, records commitment through existing `_recordDaoBoost(amount,alignedEndtime,false)`, then calls `Aladdin.boost(amount,alignedEndtime,address(this))`; emits `AladdinBoostDelegated`. The delegation is charged against the 20% DAO reserve and released using existing `releaseDaoBoostCommitment`.
5. **Refactored the existing `donateSDT` implementation**, without changing its ABI or share-neutral semantics: `donateSDT` still pulls SDT from the donor, then invokes private `_donateSDTHeld(amount, donor)`. That helper retains its original approve, `VLSDT.stake`, allowance cleanup, exact 1:1 staking assertion, `totalDonatedSDT` increment and `SDTDonated` event. This is the **one** existing compounding path; it is not a parallel mechanism.
6. Added permissionless, configured, nonreentrant `claimAladdinRewardsAndCompound()`: calls `Aladdin.claim(address(this),address(this))`, computes the actual received SDT by balance delta, returns zero for no currently claimable SDT, and passes positive rewards into `_donateSDTHeld(amount,address(this))`. Emits `AladdinRewardsCompounded` to attribute the origin. No additional compounding accumulator, minted share, reward distribution, swap route or separate vault was introduced.
7. Added `AladdinBoostDelegated` and `AladdinRewardsCompounded` events. No existing contract storage fields were removed or reordered. No **new mutable storage** was introduced.

## Other contract source files

The remaining **eight contract sources** and all existing interfaces are unchanged from v31. In particular `CurveYieldVlSDTBoostStaking`, `CurveYieldVlSDTRevenueStaking`, `CurveYieldRevenueStrategyV20`, `CurveYieldVault`, the token, boost merchant and swap converters are not edited.

## Source-level behavior and limitations

- `CYVLSDT.mint` remains in ordinary Locker `deposit` only, and is **not called** on Aladdin claims or `donateSDT`.
- `totalDonatedSDT` now tracks **both direct SDT donations and Aladdin-compounded SDT**, retaining one share-neutral contribution counter. Attribution is observable in the two reward events.
- Existing `claimVlSDTRewards` continues to forward its original fee-distributor rewards to Revenue Staking; Aladdin payout is separate and not forwarded.
- Aladdin's external `claim` operates in completed weekly reward epochs and can return zero; its implementation processes at most 50 weeks per call. Do not assume all past rewards necessarily settle in a single call.
- Claiming SDT does not extend the delegation. No auto-renewal/auto-delegation schedule is created.
- Owner must explicitly activate proxy permissions from **the Locker** via `setAladdinDelegationOperator(true)` before delegating. The implementation does not auto-approve an externally upgradeable proxy without owner consent.
- External on-chain operability depends on the Locker actually having positive `vlBoost.delegableBalance(address(this))` and live external Aladdin/Stake DAO contracts behaving as in the supplied `vlSDT_vlBoost_asdCRV_Delegation_Integration_Handoff_v2.md`.

## Deployment and packaging changes

- Changed `package.json` / root package-lock metadata from `31.0.0` to `32.0.0`, CLI script suffixes from `:v31` to `:v32`, and all tracked deployment output and artifact/cache directories to v32.
- Renamed `config-mainnet-v31.json` and `config-production-v31.json` to corresponding `-v32.json`, with `version=32`, `release="32"`; retained all network addresses and economic settings.
- Updated the existing deployment/configuration/verification/ownership-handoff scripts' package-version references to v32. **No new deployment, approval, transaction, or test workflows** were added.
- Added `README-v32.md`, this changelog, exact `SOURCE-DIFF-v31-to-v32.patch`, and two integrity manifest files.

## Verification and authority limitations

- All modified JavaScript files were parsed using `node --check`.
- v32 production config was produced through the existing materializer and its embedded version validation.
- All relative Solidity imports were found within the delivered tree. Source and archive hashes are included for external reproduction.
- **No Solidity compile or execution tests** were run in the package-building environment (required npm dependencies unavailable). Live on-chain capability and gas cost therefore remain unverified; do not assume audited/deployment-ready status.
