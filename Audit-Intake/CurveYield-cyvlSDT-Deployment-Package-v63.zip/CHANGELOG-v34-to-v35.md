# CurveYield cyvlSDT v35 change log

## Implemented in v35

- Staking splits all receipt income itself, including 100% of Merchant lease/marketplace proceeds and the Locker's SDT/USDC reward claims. Merchant does not perform fee-share calculations.
- On the first receipt of an accounting week, the Staking contract freezes **one benchmark per token**. It reads `lastTokenTime()` and `tokensPerEpoch()` from the appropriate live Stake DAO FeeDistributor and `totalSupplyAt()` from live vlSDT; it uses the most recently **fully checkpointed** historical week. The benchmark equals source tokens per vlSDT multiplied by active cyvlSDT stake at that first receipt. It is not a prediction of future SDT deposits.
- All receipts of the same token during the same week are aggregated cumulatively in `epochAccounting`. The first 100% of weekly benchmark goes to stakers as original SDT/USDC; excess from 100%-150% of benchmark uses **75% stakers / 20% DAO / 5% admin**; excess above 150% uses **60% stakers / 30% DAO / 10% admin**. Each receipt applies only the *marginal changes* to the cumulative totals, preventing duplicate base entitlements and rounding inconsistencies.
- **Independent streams, not restarted streams**: every received base allocation opens a brand-new 7-day token-specific SDT/USDC stream, preserving pre-existing streams. Every individual pending excess allocation retains its own ID and is converted separately into cyvlSDT before opening a new, independent 7-day cyvlSDT stream. Streams can overlap and are never reset on additional receipts.
- Pending excess USDC waits if the live OmniRouter's USDC→SDT route is unavailable; `convertExcess(id)` works once the route is configured. SDT→cyvlSDT conversion uses the Locker's existing swap-better-than-mint 1:1 deposit route. There is no need to deploy a converter contract or configure the future three-token StableSwap before initial cyvlSDT deployment.
- The DAO's vlBoost reserve `DAO_BOOST_BPS` decreased from 2000 (20%) to 1000 (10%). No new DAO listing mechanism has been created.
- Deployment constructor, reward-token registrations (including cyvlSDT), mainnet config, script version labels, and verification assertions updated to v35.

## Retained behaviors and limitations

- Normal underlying SDT/USDC rewards are payable as their original tokens; only the **stakers' excess allocations** become cyvlSDT. DAO and admin allocations retain their original currency.
- Incoming rewards when `totalActiveStake == 0` retain the previous 100%-to-treasury policy; no user stream is started, **but those receipts still count toward the cumulative weekly gross threshold**, so a later transfer cannot re-use an already-consumed weekly base allowance. Streamed rewards vesting during a period of zero active stakers likewise go to treasury.
- The weekly benchmark is frozen at first receipt; stake additions/removals within that week affect stream accrual but do not retroactively change its benchmark.
- Irregular SDT funding can leave `lastTokenTime` stale. v35 deliberately uses the last **fully checkpointed** epoch, which may be older than the previous calendar week, rather than assuming nonzero issuance for an uncheckpointed week.
- A zero distributor benchmark places all income in the second excess tier. This follows the requested marginal thresholds, but may produce fee shares higher than a smoothing-based forecast.
- Each separate transfer/convert action yields a separate stream; extensive high-frequency notifications can make accrued-reward checkpoint operations gas-intensive. Notifier permission remains restricted.
- If excess USDC conversion lacks a configured OmniRouter route, it remains in escrow and its cyvlSDT stream cannot start until the route is available. Existing streams continue unmodified.

## Verification

Source-level cross-reference and deployment-script syntax only. **No tests, fork simulations, or contract deployments executed. Solidity compile unverified** because local npm dependency installation failed; do not treat this package as deployment-ready without compiling it in a provisioned Hardhat environment. Deploy-time static checks remain in deployment scripts; dynamic on-chain functions retain runtime validity conditions needed for safe execution.
