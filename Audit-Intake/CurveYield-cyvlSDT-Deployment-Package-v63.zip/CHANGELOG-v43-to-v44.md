# cyvlSDT v44 — compiler-confirmed v43 source correction

- The Merchant hardcoded USDC address checksum casing was corrected from `0xA0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` to `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48` (identical 20-byte address, Solidity-compliant checksum).
- v43 Locker rewrite and Staking-owned LP bribe distribution remain unchanged.
- Compiled on Github with Solidity 0.8.28, optimizer 200, viaIR, Cancun, OpenZeppelin v5.4.0.
- GitHub verified runtime sizes from successful build: Locker 16,257 B; Staking 14,002 B; Merchant 10,691 B. EIP-170 maximum 24,576 B.
- No tests/simulations/deployments executed.

Source version v44 is the compiled, updated replacement for the early v43 source deliverable.
