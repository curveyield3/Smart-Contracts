# v54 → v55: revenue vault replaced with BeefyVaultCurveYieldV8

- REMOVED old `contracts/CurveYieldVault.sol`, its legacy asynchronous interface files, and `contracts/CurveYieldRevenueStrategyV20.sol` (the legacy `CurveYieldRevenueStrategyV7`).
- ADDED `contracts/CurveYieldRevenueStrategyV8.sol` with the exact six functions of `IStrategyBoostHubV1` plus `emergencyWithdraw(uint256)` required by Beefy V8's emergency path. Retains revenue staking, compounding, OmniRouter conversions, owner rebinding, performance and caller fees; removes duplicate strategy withdrawal fee.
- Existing `contracts/BeefyVaultCurveYieldV8.sol` is reused **unchanged** as the revenue vault, alongside the separately deployed SDT/Yearn Beefy V8 vault.
- Updated core deployment, deployable manifest, verification, configuration, and ownership handoff for Beefy V8 construction and OZ4 direct ownership handoff.
- `StrategyCurveSDTYearnV9.sol` remains byte-identical to v54.

## Intentional behavior difference / warnings

1. Beefy V8 exposes synchronous withdrawal, not the former seven-day queued withdrawal. Revenue strategy uses fee-bearing immediate StakeDAO exits only. This changes user economics relative to the former vault's delayed no-fee option.
2. Revenue strategy values staked cyvlSDT net of StakeDAO's configured immediate fee. Its `withdraw(uint256)` unstake amount is grossed up to satisfy the vault's strict requested-amount condition; the vault withdrawal fee is charged only by Beefy V8.
3. Beefy V8's deposit pricing does not call the previous vault's strict/best-effort pre-deposit harvest hooks or price unharvested rewards. Unharvested staking rewards are not included in NAV until harvested, potentially redistributing preexisting yield toward new depositors. This requires an explicitly approved product/economic decision before deployment.
4. This is source-only; compilation, tests, forks and deployments were not run. Existing users of the original revenue vault cannot transfer their ERC-20 shares automatically to the new Beefy V8 vault.
