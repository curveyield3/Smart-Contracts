# CurveYield cyvlSDT Deployment Package v51

**Scope:** Restore the exact original SDT/Yearn V9 strategy. No modifications whatsoever to that Solidity source; no new Solidity tests, mainnet transactions, or deployments.

## Exact source restoration

- Original input ZIP: `CurveYield_SDT_Yearn_Beefy_v9 (1).zip`
- Original ZIP entry: `CurveYield_SDT_Yearn_Beefy_v9/contracts/StrategyCurveSDTYearnV9.sol`
- Restored package file: `contracts/StrategyCurveSDTYearnV9.sol`
- **Original and restored SHA-256:** `c280bd632a02776a21999f7a0f16d768405036646aad8e70ded6431652594b87`
- The v50-modified `contracts/StrategyCurveSDTYearnV10.sol` has been removed from the active contracts tree.
- Original V9's internal comments, interface declarations, constructors, selectors, economics, NAV calculations, conversion logic, guardian checks and byte-level formatting are unchanged. Its original mentions of `BeefyVaultV7FixedV2` and Guard V6 are intentionally retained as historical comments, not edited to mention V8.

## Deployment binding and preservation

- `contracts/BeefyVaultCurveYieldV8.sol` remains **unchanged** from v50.
- The original V9 strategy supplies the vault-facing functions used by Beefy V8 through its implemented external selectors, without needing `IStrategyBoostHubV1` inheritance or Solidity `override` annotations.
- Deployment now loads `StrategyCurveSDTYearnV9`, with original constructor `(predictedBeefyVault, factoryYearnV2Vault, curveGuardV8)`.
- The already-provided `BeefyVaultCurveYieldV8` vault is deployed separately against the original strategy's immutable `vault()` binding.
- Yearn CurveGlobal factory address, SDT/WETH Curve pool, gauge, and existing Curve Guard V8 address are left as in v50. Only the source identity, package version, deployer script and state artifact naming were updated.
- Existing cyvlSDT locker, staking, Boost Merchant, revenue vault/strategy, PoL Manager v22, and Guard V8 code remain unchanged.

## Deployable files

- `contracts/StrategyCurveSDTYearnV9.sol` — **exact original user-provided Solidity bytes**
- `contracts/BeefyVaultCurveYieldV8.sol` — existing renamed BoostHub vault, unchanged
- `config-sdt-yearn-v51.json` — strategy artifact set to `StrategyCurveSDTYearnV9`
- `deployment-v27/deploy-sdt-yearn-beefy-v51.js` — Yearn factory -> original V9 strategy -> Beefy V8 vault, with immutable binding checks and ownership configuration

The v50-only deploy script and v50 SDT/Yearn config were superseded and removed to prevent accidental use of `StrategyCurveSDTYearnV10` or stale state artifacts. The old v50 README/changelog are retained strictly as historical documents; **this v51 README governs the active package**.

Example commands for an already-authorized deployer (not executed in this packaging task):

```bash
npm ci
npm run compile:v51
RPC_URL=<ethereum-rpc> DEPLOYER_PRIVATE_KEY=<key> npm run deploy:sdt-yearn:v51
```

The deployment script will produce `deployment-output-v51/sdt-yearn-beefy-v51-ethereum.json` only when executed. If a prior v50 deployment was partially performed outside this session, reconcile its real chain transactions and recorded nonce/state before any v51 execution; this package does not automatically migrate that old state file.

## Verification evidence

The restored strategy has byte-for-byte equality with the strategy source stored in the user-provided V9 ZIP, and the SHA-256 above is reproduced from both byte strings. Package integrity and unchanged-contract hashes were checked locally. Solidity compilation, testing, and live deployment were not performed.
