# CurveYield cyvlSDT v36

Source and deployment scripts for the six-contract CurveYield cyvlSDT stack.

## v36 surgical change

- `CurveYieldvlSDTStaking` immediate withdrawal fee defaults to exactly **3.125%** (`31,250 ppm`).
- The owner-configurable maximum is exactly **3.5%** (`35,000 ppm`). The minimum remains 0%.
- Both `withdrawImmediate()` and `withdrawQueuedImmediate()` use the same `previewImmediateWithdrawal()` and exact fee scale. The fee continues to be paid in cyvlSDT to the existing treasury receiver; fee-free seven-day queued withdrawals are unchanged.
- A fractional basis point cannot be expressed in the existing integer-bps fee interface. The single relevant getter and setter are renamed to `immediateWithdrawFeePpm()` and `setImmediateWithdrawFeePpm(uint32)`; the denominator is `1_000_000`. Deployment scripts, interface and both configs are updated together.
- v35 production-config validators accidentally required metadata version 34 even though both released v35 configurations said version 35. v36 checks its own version 36 metadata, avoiding that existing deployment blocker.

No change to tiered SDT/USDC revenue sharing, independent reward streams, Merchant, Locker, DAO boost reserve, external router or Vault fees.

## Existing deployment procedure

Use the existing scripts: `npm ci`, `npm run compile:v36`, `npm run config:materialize:v36`, and subsequently the deploy/configure/verify/handoff scripts. No new workflows or tests are included.

**Compilation is not claimed until it succeeds in an environment with Hardhat dependencies available.**
