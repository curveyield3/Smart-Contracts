# PoL Manager v19 — One-Time Post-Deployment Position Binding

PoL Manager v19 is a surgical update to the supplied v18 PoL Manager. The **Curve pool, LP, gauge, Uniswap position manager and NFT ID are no longer constructor fields**. The Manager can deploy before any of them exists. The independent, unchanged `CurvePairOracleBoundsV6` guard continues handling all liquidity slippage checks; OmniRouter remains responsible for swaps.

## Constructor

`PoLManager(DeployConfig c)` requires only `owner`, `sdt`, `usdc`, `crv`, `cyvlSDT`, `omniRouter`, `yearnVaults[3]`, `eulerVaults[2]`, and `sdtYearnIndex` / `sdtEulerIndex`. Zero-address vaults are allowed and may be added later with the existing `setVault` function. The manager does not take a Curve pool, LP, Curve gauge, NFT manager, or token ID during deployment.

## One-time owner configuration

| Function | When to call | Permanent binding |
|---|---|---|
| `configureCurvePool(pool, lp)` | Once the 3-coin Curve pool and its LP token exist | `curvePool`, `curveLp`; must have SDT coin 0, cyvlSDT coin 1, and a distinct nonzero third coin |
| `configureCurveGauge(gauge)` | Whenever a real gauge exists **after** the pool has been bound | `curveGauge` |
| `configureUniswapPosition(positionManager, tokenId)` | Once the specific SDT/cyvlSDT NFT exists, **before** transferring it to PoL Manager | `uniNftManager`, `uniTokenId`, underlying token pair |

All three functions are **owner-only** and **one-time**: a second configuration is rejected. The position manager and NFT do not have to exist when the contract deploys. Curve and Uniswap can be configured in either order. The Curve gauge is optional and can be attached independently after the Curve pool.

After configuring the NFT position, transfer **only that NFT** with `safeTransferFrom` to PoL Manager. Its original `onERC721Received` restrictions still reject any other NFT. The NFT's original token-owed accounting remains in place. Its harvest remains manually opt-in via `setModuleEnabled(1, false, true)` after transfer. There is no automatic Uniswap allocation adapter.

`setLiquidityBounds(v6Guard)` and `setCurveSlippageBps(bps)` remain existing owner-settable operations; the guard itself deploys without the pool/NFT. Missing Curve/NFT positions remain disabled; direct vault operations remain available. Without configured guard, guarded liquidity operations revert.

The core deployer wires PoL Manager's `profitRecipient` to the Locker and the Locker's PoL deposit recipient to the **deployed** PoL Manager address, independently of the later pool/NFT binding. Setting `poLDeposit.shareBps` above zero is permitted after Manager deployment. The Locker simply transfers the designated SDT to the Manager; your keeper (authorized by `PoLManager.setOperator(keeper, true)`) later calls `allocateFunds(SDT, amount)`.

## Production configuration (v47)

In `config-production-v47.json`, `poLManager.curvePool`, `curveLp`, `curveGauge`, `uniNftManager`, and `uniTokenId` all start `null`. When these become available, set both `curvePool` and `curveLp` together, optionally the gauge, and set `uniNftManager` and `uniTokenId` together. Re-run the existing `configure:v47` entry point **while the signer is the owner**; it calls the same one-time setters and validates existing bindings rather than overwriting them. Alternatively, after transferring ownership to the Safe, call the corresponding setters once from the Safe. The configuration's optional position addresses do not block initial deployment or core verification.

## Preserved v18 features

Seven position slots (Curve, NFT, three Yearn, two Euler); independent position allocation and harvesting; five configurable SDT/cyvlSDT buy-rate thresholds and budgets; CRV compounding; owner-configured fees; no internal OmniRouter swap guards. The separate guard v6 is unchanged (300-second Uni TWAP, 2% Uni slippage, owner-configurable Curve bound). The original v18 source and its previously reported compilation measurement do **not** constitute verification of the modified v19 bytecode. No Solidity compilation, tests, fork simulation or deployment was performed for this revision.
