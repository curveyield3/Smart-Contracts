# CurveYield cyvlSDT Source + Deployment Package — v42

Source-only change to v41: the **maximum configured PoL share on new SDT deposits** is increased from **15% (1,500 bps) to 25% (2,500 bps)**. The default remains **0%** in both Ethereum mainnet configuration files.

## Exact scope

- `CurveYieldVlSDTLocker.MAX_POL_DEPOSIT_SHARE_BPS` is now `2_500`. `setPoLDepositShare()` enforces this cap for owner configuration. The existing deposit formula remains `floor(amount * poLDepositShareBps / 10_000)`.
- `deployment-v27/production-config-v27-v1.js` allows `poLDeposit.shareBps` in the inclusive range `0..2500`; `lpBribeRevenue.shareBps` remains capped at **1,500 bps (15%)**.
- Production verification reads `locker.MAX_POL_DEPOSIT_SHARE_BPS()` and expects `2500`.
- No modification to the PoL Manager v9 contract, its internal investment caps, the separate staking excess-tier PoL fee percentages, or other revenue sharing.

## Custody and allocations

As in v41, user deposits send the configured PoL SDT share directly to the PoL Manager; they do **not** call `allocateFunds()`. A separately authorized keeper can allocate the Manager's idle SDT later. The deposit's remaining SDT continues through the ordinary cyvlSDT mint or swap path.

Set a real `lockerRevenueDiversions.poLDeposit.recipient` and a nonzero desired `shareBps` in `config-mainnet-v42.json`/`config-production-v42.json` when ready. Default values are deliberately left unchanged.

This update changes only the source and deployment package. No Solidity compilation, tests, simulations, or deployments performed.
