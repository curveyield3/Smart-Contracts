# CurveYield cyvlSDT source package v55

**Current revenue vault:** `BeefyVaultCurveYieldV8` with `CurveYieldRevenueStrategyV8`.

**Separate SDT/Yearn investment vault:** another `BeefyVaultCurveYieldV8` deployed using `StrategyCurveSDTYearnV9` or the original v53 rebindable derivative (unchanged).

The old `CurveYieldVault` and asynchronous `CurveYieldRevenueStrategyV7` pair have been removed from active source, deployables, and core deployment flow. Historical READMEs are retained as immutable history only; see `CHANGELOG-v54-to-v55.md` for new behavior and deployment limitations. Both vaults share the same Beefy V8 implementation but are independent deployed instances.

The revenue strategy implements the Beefy vault's ordinary `withdraw(uint256)` and emergency `emergencyWithdraw(uint256)` strategy callbacks; both use the same liquidity exit because there is no Curve-guarded position in the revenue strategy.

The revenue staking exit fee is valued and settled in the replacement strategy to satisfy the vault's strict synchronous withdrawal API. Timelocked user withdrawals and pre-deposit reward-value protection of the former revenue vault are **not** preserved by the unmodified Beefy V8 vault. Verify economic acceptability before any deployment. No proxies introduced.
