# CurveYield cyvlSDT — v43

This is the updated v42 package with the v43 Locker/RevenueStaking/Merchant simplification.

**Contracts:** `contracts/CurveYieldVlSDTLocker.sol`, `contracts/CurveYieldvlSDTStaking.sol`, `contracts/CurveYieldVlSDTBoostMerchant.sol`, and interfaces.

**Deposit:** User transfers SDT; Locker transfers the up-to-25% configured PoL share to PoL Manager; Locker stakes remaining SDT as vlSDT and mints the same quantity of cyvlSDT. No user swap or PoL investment call. PoL keeper independently allocates idle SDT.

**Rewards:** Locker `claimAndForwardRevenue()` obtains both SDT/USDC distributor claims through the existing Stake DAO router and Aladdin rewards; `forwardRevenue()` sweeps unreserved SDT and USDC from all sources including PoL Manager, Merchant, and direct deposits. Both pass entire balances to Staking. Staking alone performs LP bribe diversion (max 15%) and base/excess-tier distributions.

**Boost:** The Merchant has direct access to the 85% boost allocation (net of previously delegated/listed/fill commitments), DAO 10% and admin 5% remain protected. DAO marketplace offer acceptance uses `marketplaceAcceptOffer(...,true)` rather than a parallel method and directs proceeds to `treasuryReceiver`. Merchant calls the same method with `false`.

**Redemption:** `setRedemptionRate(uint256)` configures SDT paid per cyvlSDT (1e18 = 1:1). `fundRedemptionLiquidity(amount)` locks owner-funded liquid SDT away from revenue sweeps, and `redeem(shares, receiver)` transfers the fixed-rate amount if available, extinguishes shares and adjusts the gross SDT principal benchmark. This is an **owner-prefunded liquid cash redemption** mechanism, not a claim on underlying vlSDT unstaking. It cannot redeem until funded.

For exact source changes and migration notes consult `CHANGELOG-v42-to-v43.md`.
