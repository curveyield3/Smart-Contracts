# CurveYield cyvlSDT v34 — source and deployment

This package contains **six** deployable Solidity contracts and the existing v20/v27 deployment orchestration, updated for v34. No tests were created or run. Read `CHANGELOG-v33-to-v34.md` before deploying.

## Entrypoints

- `npm run compile:v34` — compile Solidity once npm dependencies are available.
- `npm run config:materialize:v34` — copy/validate production deployment configuration.
- `npm run deploy:v34` — deploy only six core contracts; attaches to existing OmniRouter.
- `npm run configure:v34` — configure Locker, staking rewards, Merchant, Vault, and marketplace permission.
- `npm run verify:v34` — verify deployed wiring; optional OmniRouter routes are reported separately.
- `npm run handoff:propose:v34` and `npm run handoff:accept:v34` — existing owner handoff.

## Deployed OmniRouter / delayed three-coin StableSwap

- `omniRouter` is `0xa4a533025fef8d3446e7cb8a434824e1ee865b00` on Ethereum mainnet and is not re-deployed here.
- The **USDC→SDT** route and **SDT→cyvlSDT** route are NOT configured as part of this source package. Existing route lengths are zero at time of inspection.
- No StableSwap pool exists in the deployment config: `postDeploymentStablePool.address` and `.coinIndices` are null. The future three-coin pool's third token, address and indices must not be guessed.
- On initial deployment the Locker stakes SDT into vlSDT and mints cyvlSDT 1:1. Once a better SDT→cyvlSDT route exists, `Locker.deposit` buys cyvlSDT instead of minting if the trade yields strictly more shares. Its minOutput is `amount+1`, never below the alternative mint.
- After the StableSwap is deployed, the router owner must configure its route with the correct real pool/coin indices using existing OmniRouter `setRoute`/`setRouteConfig`. Fill `postDeploymentStablePool.address` later, rerun the existing deployment verification for pool metadata and route readiness. The deployment scripts do not send any router-owner transaction.
- Revenue Strategy uses the same OmniRouter for USDC→SDT and calls the Locker to receive cyvlSDT. USDC conversion remains unavailable until that route is live; SDT rewards can already be deposited 1:1.

## Staking/burning/boost policies

- `CurveYieldvlSDTStaking.sol` is the former revenue staking contract, renamed. No multiplied-vlBoost user staking contract remains.
- Only Merchant (module ID 1) controls commercial boost usage; Locker retains custody, authorization and existing expiry/cancel accounting.
- cyvlSDT has no permissionless burn/burnFrom. Emergency withdrawal still calls a Locker-only supply burn paired with 1:1 underlying redemption.
- Aladdin SDT rewards compound directly through Locker's existing donate routine **without new shares**.
- Merchant sells **only for USDC**; owner must configure posting and minimum fill rates and an SDT/USDC valuation before commercial activity.

## Operational status

The package is source-only. Solidity compilation is pending (npm dependency install failed due unavailable network), and no fork/live execution or security testing was run. Merchant owner rates are not supplied and both OmniRouter routes are not yet configured. These are outstanding readiness items, not preconditions for compiling or initially deploying the six contracts.
