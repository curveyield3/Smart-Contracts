# CurveYield cyvlSDT v43 — Locker simplification

## Implemented changes

1. Removed the Locker's entire SDT→cyvlSDT swap / quote / slippage / fallback path and OmniRouter constructor dependency. Deposits now always transfer the configured PoL share (up to 25%) then stake net SDT and mint net cyvlSDT 1:1.
2. Replaced asynchronous Locker emergency withdrawal request/complete records with a fixed-rate, **liquid** SDT redemption method `redeem(shares, receiver)`. Owner sets the rate via `setRedemptionRate(wad)` (default 1 SDT per share), and pre-funds a protected liquidity reserve with `fundRedemptionLiquidity(amount)`. This does not unstake vlSDT and cannot redeem more than its funded liquidity; it is a funded redemption mechanism, not an unlimited vault withdrawal.
3. Consolidated SDT/USDC distributor claims plus the Aladdin claim into `claimAndForwardRevenue()`, and added a permissionless `forwardRevenue()` for Merchant/PoL/direct receipts. Both forward unreserved full token balances using the same generic notification function to RevenueStaking; none of the reward splitting takes place in Locker. Aladdin claim failure is non-blocking; the Stake DAO Router claim remains atomic.
4. Moved the existing owner-configurable 0–15% LP bribe revenue diversion from Locker into `CurveYieldvlSDTStaking.notifyReward`, **ahead of** weekly base/excess revenue tier classification. All reward streams use the same calculation. Deployment & verification scripts now configure/check Staking's diversion recipient.
5. Removed generic boost-module IDs, registries, percentage and absolute reserves, loops, and reservation-draining. Direct Merchant boost capacity is the non-DAO/non-admin 85% entitlement, bounded by live vlBoost delegability. DAO 10%, admin 5%, and real delegation expiry accounting remain independent.
6. Removed the separate DAO-only Marketplace sale function. `marketplaceAcceptOffer(..., bool daoSale)` shares the execution path, sets `treasuryReceiver` for DAO proceeds, and otherwise sends Merchant proceeds through the generic Locker→Staking revenue path. `daoSale=true` requires Locker owner; `false` requires Merchant. Merchant interface passes `false`.
7. Removed compatibility-only `donateSDT`, `ADMIN`, Snapshot ERC1271 vote subsystem, PoL allocation proxy, redundant Merchant forwarding overloads, duplicated Aladdin operator setup, obsolete events, and unused declarations.
8. PoL transfers remain directly to Manager custody; keeper allocates later. PoL performance-fee SDT can be swept through `forwardRevenue()`. Redemption liquidity is explicitly excluded from that sweep.

## Source-level change

Locker: 48,406 bytes in v42 → approximately 24,200 bytes in v43 (measured locally; compiled size must be verified independently). Merchant and Staking interface/wiring updated.

## Important behavior changes

- The old asynchronous `requestEmergencyWithdrawal`/`completeEmergencyWithdrawal` path is **removed**. The replacement is an immediate cash redemption **only if the owner has prefunded enough liquid SDT**. The underlying vlSDT backing remains in the Locker; redeeming shares does not unwind underlying vlSDT.
- The previous owner-only DAO marketplace entry point is replaced with boolean mode on the existing accept-offer function; any callers must update ABI and call with `daoSale=true`.
- All `forwardRevenue` transfers report gross SDT/USDC to Staking, which now applies the LP bribe share.
- Snapshot/ERC1271 validation is no longer performed by the Locker. An external authorized voting solution is required if off-chain Snapshot votes are still desired.

## Remaining deployment prerequisites

- Update deploy callers for the 10-argument Locker constructor (removed OmniRouter argument).
- Set the bribe allocator address and LP percentage on Staking, not Locker.
- Authorize an external PoL keeper directly on PoL Manager, if needed.
- Create a liquid redemption reserve to enable `redeem`; no pre-existing SDT backing is assumed liquid.

## Verification status

Static source/package review only until an actual build result is obtained. No tests, simulations, or deployments requested or run.
