# Interface-to-implementation compatibility audit v1 (cyvlSDT source package v52)

Date: November 22, 2026. Scope: all six standalone interface source files, directly declared internal interfaces, deployed counterpart contracts independently checked with Ethereum reads. No source contract functionality was modified.

## Confirmed ABI correction

- `contracts/interfaces/ICurveYield.sol` / `ICurveYieldvlSDTStaking.immediateWithdrawFeePpm()` originally declared `returns (uint256)` but `contracts/CurveYieldvlSDTStaking.sol` declares `uint32 public immediateWithdrawFeePpm`, whose canonical ABI return type is `uint32`. Changed the standalone interface return to `uint32`. The selector and 32-byte EVM word encoding remain unchanged; this corrects the type declaration (the broader prior type was decodable for ordinary fee values).

## Verified component relationships

| Interface / caller | Matched against | Finding |
|---|---|---|
| `IStrategyBoostHubV1` / Beefy vault | `StrategyCurveSDTYearnV9` and `BeefyVaultCurveYieldV8` source | All six used selectors exist, with matching argument/return types: `vault`, `want`, `deposit`, `withdraw(uint256)`, `balanceOf`, `lockVaultProfit`. Original V9 does not need to inherit the interface to expose these selectors. |
| Inline `IBeefySDTVaultV6` in V9 | BeefyVaultCurveYieldV8 source | `totalSupply():uint256`, `withdrawalFeeBps():uint256`, `adminFeeReceiver():address` match. Historical V6 interface name is retained to preserve strategy bytes. |
| `ICurveYieldVaultStrategy` | `CurveYieldRevenueStrategyV20` and `CurveYieldVault` source | Full declared V20 async strategy surface is implemented; separate from synchronous Beefy V8 strategy. |
| `ICurveYieldVault` | `CurveYieldVault` source | `feeReceiver():address` matches public getter. |
| `ICurveYieldVlSDTToken`, `ICurveYieldvlSDTLocker`, `ICurveYieldvlSDTStaking` | Locker, token, and staking source | Used selectors match the local implementations, including public/generated getters and inherited ERC20 methods, except the corrected staking fee return type. |
| `IStakeDao.sol`: `IVlSDT`, `IVlBoost`, `IFeeDistributor`, `IStakeDaoRouter`, `IBoostMarketplace` | Verified deployed Ethereum target ABI / returned tuple shapes | Matched the relevant function signatures, including `getOffer`/`getListing` component order, `unstake`, `boost`, `execute`, fee-distributor `claim`. Router is a proxy; verified target exposes the `execute(bytes[])` ABI. |
| `ICurveYieldOmniRouter` and inline `IPoLRouter` | Deployed CurveYieldOmniRouter (`0xa4a533025fef8d3446e7cb8a434824e1ee865b00`) | Used five selectors match, including `swapExactInput` and `price_oracle`; PoL's additional `swap` and `estimate_exact_output` also match. |
| Inline `IPoLLiquidityBounds`, `ICurveLiquidityBoundsSDTV7` | Deployed CurvePairOracleBoundsV8 (`0xAB989D9Daa0279e123d453204545be556F2D3072`) | Quote selectors and output types match; historical V7 name in original V9 preserved. |
| Inline `ICurveEthereumVoteMarket`, `ICurveGaugeControllerForBribes` | Ethereum VoteMarket Platform and GaugeController verified ABI | Method selectors, output types and eight-field bounty struct order match. |
| Inline `ICurveSDTWETHV6` | SDT/WETH Curve pool `0xA19bf6fBf05624282cb6ed498f4761f22e084Edd` | Used pool selectors match; on-chain coins order was independently confirmed (WETH 0, SDT 1). |
| Inline `IAladdinVlSDTDelegation` / `IAladdinRewardHistory` | Aladdin delegation verified proxy implementation / live getter reads | Delegation boost/claim and reward-history getter shapes checked where available; proxy can be upgraded, so this is time-bound to the observed implementation. |
| Inline `IPoLNft` | Uniswap V3 NonfungiblePositionManager standard ABI | Declared position/liquidity signatures consistent with expected V3 API; no active NFT manager is yet bound on the observed old PoL deployment. Exact future configured address must be verified separately. |
| Inline `IPoL4626`, `IPoLYearn`, `IPoLGauge`, `IPoLCurveNG` | ERC4626/Yearn or Morpho V1/Curve integrations | Source ABI shapes are consistent with expected integrations, but actual later-configured target addresses must be inspected at deployment. |
| Inline `IYearnSDTLPV9` | Intended CurveGlobal Yearn V2 vault | The factory can create a vault for the verified SDT/WETH gauge, but no actual target vault existed at the previous live check; cannot claim deployment-specific ABI verified until its creation. |

## Limits and preservation

- This is a source/ABI/deployed-ABI reconciliation, **not** a transaction test or behavioral audit; actual calls may still revert for state, permission or accounting reasons.
- ERC-20 `uint32` and `uint256` view returns are ABI-encoded as 32-byte words; this was a canonical type mismatch, not an established runtime decoding breakage.
- All original V9 strategy bytes are exactly identical to uploaded source (SHA-256 `c280bd632a02776a21999f7a0f16d768405036646aad8e70ded6431652594b87`). `BeefyVaultCurveYieldV8.sol`, PoL Manager v22 and Guard V8 are not edited.
- **PoL v22 recovery behavior was not changed:** the former 90-day emergency migration has not been restored. Vault-share and Curve-LP restrictions on `rescueToken` still apply.
- No Solidity compile, tests, simulations, on-chain transactions or deployment were performed. The release package leaves the existing v51 deploy configuration/script untouched because it requires no interface change; v52 is the package revision, not a contract implementation revision.
