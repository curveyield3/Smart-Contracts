# v54 — v53 added restriction removal (no proxies)

Source basis: `/mnt/data/CurveYield-cyvlSDT-Deployment-Package-v53.zip`.

## Removed (new in v53)

- Balance/supply gates before rebinding token, locker, staking, strategy, vault, Yearn, marketplace and PoL references.
- Counter-based blockers: `pendingEmergencyWithdrawalCount`, `pendingWithdrawalCount`, `pendingStrategyWithdrawalCount`, and `outstandingListings` together with their increment/decrement code.
- Automatic `retireClosedListing` management added solely for the marketplace switch gate.
- Reverse-binding staticcalls and current-asset/old-position checks in new setters.
- Old-curve-LP, old-gauge and Uniswap NFT drain prerequisites in PoL reconfiguration and clear paths.
- `hasBounty` restriction and implementation-contract validation in bribe allocator rebinding.
- v53 added deployment verifier / acceptance checks restricting revenue-vault configurator state.

## Preserved intentionally

- Owner/configurator authorization for rebinding; unrestricted external callers must not be able to hijack contract references.
- Existing pre-v53 validation, slippage and economic guards on deposit/withdraw, other user paths and initial configuration.
- Token approval revocation/grant when switching PoL router, Curve pool/gauge, and Yearn vault; those operations execute the replacement, rather than gate it.
- Exact original `StrategyCurveSDTYearnV9.sol` bytes and all other untouched original V9 source files.
- No proxies, delegatecalls, external registry, or new infrastructure.

## Source compatibility correction

The new `StrategyCurveSDTYearnRebindable.sol` from v53 inherited OpenZeppelin 4 `Ownable2Step` without importing it and used `Ownable(initialOwner_)` (an OpenZeppelin 5-style constructor). The v54 derivative imports `Ownable2Step` and calls `_transferOwnership(initialOwner_)` instead. The exact original V9 is unchanged. Solidity compilation remains unverified unless an actual compiler/build result is obtained.

## Important behavior consequence

Rebinding now succeeds without position-drain verification. Ownership is still restricted, but these setters **do not migrate user balances, staking ledgers, Yearn shares, boost commitments, pending withdrawals or liabilities**. Rebinding while positions are funded can orphan assets or claims. The owner must coordinate any migration off-chain/on-chain. The code does not enforce such sequencing.

## Versioning

v54 is the next full-package revision after v53. v53 source and deployment script/configuration names are retained for backward deployment compatibility, and v54 changes only Solidity source, the two recently added handoff checks, and documentation/manifest.
