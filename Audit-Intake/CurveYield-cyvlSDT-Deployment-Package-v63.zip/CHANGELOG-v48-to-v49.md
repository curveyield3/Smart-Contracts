# Changelog v48 → v49

- PoL Manager source v20 → v22; V6 external bounds guard → V8; 75-bps independent Curve and Uniswap NFT quote slippage.
- Add `BeefyVaultCurveYieldV8` from exact BoostHub v63 `BeefyVaultV7FixedV2` source, with the single contract-identifier rename.
- Add unchanged `IStrategyBoostHubV1` and OpenZeppelin v4.9.6 alias while preserving OpenZeppelin v5 used by legacy contracts.
- Keep `CurveYieldVault` and its revenue-strategy deployment in place because it requires asynchronous redemption incompatible with Beefy V8.
- Do not generate missing factory-linked strategy/deployment without its source or verified external factory interface.
- No tests, compilation, simulation or deployment performed.
