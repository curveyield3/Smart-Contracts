# CurveYield cyvlSDT v35 → v36

## Approved change: immediate cyvlSDT staking withdrawal fees

| Parameter | v35 | v36 |
|---|---:|---:|
| Immediate withdrawal default | 0.5% (50 bps) | **3.125% (31,250 ppm)** |
| Owner-configurable maximum | 2.5% (250 bps) | **3.5% (35,000 ppm)** |
| Minimum | 0% | 0% |
| Fee recipient | DAO treasury | DAO treasury (unchanged) |
| Fee-free queued withdrawal | 7 days | 7 days (unchanged) |

`CurveYieldvlSDTStaking` now uses ppm fee precision to represent 3.125% exactly, through `immediateWithdrawFeePpm`, `setImmediateWithdrawFeePpm`, and a denominator of 1,000,000 in the single shared preview calculation. Both immediate-withdrawal entry points invoke that same preview.

Corresponding interface, deployment, verification and JSON configuration references were updated; no old integer-bps fee control remains. The existing v35 production configuration guards that incorrectly checked release 34 were aligned with release 36 to allow the existing deployment procedure to proceed.

No other reward, allocation or withdrawal behavior was intentionally changed.

No tests were added or run. Compilation remains unverified in this environment.
