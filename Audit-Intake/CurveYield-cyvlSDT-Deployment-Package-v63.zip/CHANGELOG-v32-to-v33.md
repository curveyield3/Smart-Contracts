# CurveYield cyvlSDT v32 → v33 — complete source change log

## Removed deployable contracts

None in v33 (the seven cyGOV contracts and ChildGauge removed in v31 remain absent). Nine existing deployable contracts remain. No new deployable contract, router, oracle, storage bridge, test or workflow was added.

## `contracts/CurveYieldVlSDTBoostMerchant.sol`

1. Deleted the `utilization()` read and quadratic utilization/price interpolation from `currentPricePerWeek`.
2. Replaced old per-token `minPricePerWeek`, `maxPricePerWeek` fields with `postPricePerWeek`, `minimumFillPricePerWeek`, `sdtWeiPerToken`, `paymentTokenUnit`; modified existing owner `setPaymentToken` to accept explicit configured rates and conversion value; it reads payment-token decimals. For SDT conversion it enforces exactly 1e18 SDT wei per token; non-SDT conversion is owner-maintained, not an oracle.
3. Added interface-only `IAladdinRewardHistory` and fixed Ethereum proxy address; added `aladdinLastEpochRate`, `aladdinMinimumPriceInSDT`, `aladdinLastEpochAprBps`, `aladdinAverageAprBps`, `priceInSDT`, `_checkPremium` to use the most recent fully checkpointed completed UNIX/Thursday week. Last-epoch reward per delegated boost is the economic floor; optional APR views do not control route selection.
4. `currentPricePerWeek` now returns fixed owner-configured post price and enforces the >=110% Aladdin floor; `acceptableFillPricePerWeek` separately enforces the owner's minimum fill threshold and includes marketplace fee.
5. Added `MAX_LEASE_SECONDS = 90 days`, `MAX_REQUEST_WEEKS = 12`, and conservative `MAX_MARKETPLACE_LISTING_WEEKS = 11`; implemented `_checkEndtime` and `_alignedEndtime` to ensure actual rounded expiries never exceed 90 days (regardless of nominal weeks). Replaced old 13-week limit in this Merchant.
6. `quoteLease` and `leaseBoost` retain direct-lease purpose but use the fixed posting price and current-time-based max duration checks; direct lease cannot target Aladdin's proxy route selector.
7. `createMarketplaceListing`, `_createMarketplaceListing`, `refreshMarketplaceListing` and `cancelMarketplaceListing`: fixed pricing, premium check after marketplace fee, existing Locker listing path, no duplicate listing ledger.
8. `fillProfitableOffer`, `_fillProfitableOffer`, `_acceptableOffer`: reject unacceptable or expired offers, apply owner-configured minimum fill price AND 110% Aladdin weekly reward floor net of marketplace fee, calculate actual rounded duration <= 90 days, then reuse `LOCKER.marketplaceAcceptOffer`.
9. Added `delegateAladdinBoost` / `_delegateAladdinBoost` Merchant decision functions; these invoke the EXISTING `LOCKER.delegateBoost(amount, alignedEndtime, address(ALADDIN))` rather than creating a new Locker delegation API, allocation ledger or commitment record. Caller must be owner/keeper.
10. Added `executeBestRoute` and `Route/RouteParams` for merchant-only order-vs-listing-vs-Aladdin selection. It accepts a keeper-supplied offer ID, checks it on-chain, optionally falls back to a listing, otherwise delegates to Aladdin. No new order-book index or log-scanning system is created.
11. Added `setPostListingIfNoAcceptableOffer` owner toggle and events for route selections, Aladdin delegations and compounded rewards. `claimAladdinRewardsAndCompound` forwards through Locker's existing compounding entry.
12. Reused Locker's existing module capacity read for all route types; no configurable route-allocation percentages or parallel boost inventory accounting introduced.

## `contracts/CurveYieldVlSDTLocker.sol`

1. **Removed the separate v32 owner-only `delegateAladdinBoost(amount,endtime)` entry point.** The Locker's *existing* `delegateBoost(amount,endtime,recipient)` is used for ALL Merchant-initiated delegation, including the new Aladdin route.
2. Inside the existing `delegateBoost`, after its original module capacity validation and commitment accounting: a recipient equal to the fixed `ALADDIN_DELEGATION` proxy selects an Aladdin `boost(amount,endtime,address(this))` call (restricted to `boostMerchant`); other recipients retain the original `VLBOOST.boost(address(this),amount,endtime,recipient)` behavior. For Aladdin, require exact week-aligned expiry to prevent divergent commitment expiries. The original `ModuleBoostCommitment` and `releaseModuleBoostCommitment` apply to both routes. Existing events and dedicated Aladdin delegation event remain.
3. **No new boost allocation, reserve, commitment ledger, owner-only DAO quota or duplicate module process was added.** Earlier in-progress `merchantDelegateAladdinBoost` duplicate was discarded before this release. Existing module capacity enforcement stays intact as custody protection for Merchant and Boost Staking.
4. Restricted the existing v32 `claimAladdinRewardsAndCompound` entry to `onlyMerchant` to keep execution routed via Merchant; reward claims still call Aladdin as Locker and use the pre-existing `_donateSDTHeld` routine shared by `donateSDT`, preserving one-to-one vlSDT staking, `totalDonatedSDT`, `SDTDonated`, and no cyvlSDT mint.
5. Kept the original v32 `setAladdinDelegationOperator(bool)` owner permission call; only the Locker can authorize Aladdin for its own vlBoost. No new permission infrastructure.

## `contracts/interfaces/ICurveYield.sol`

Removed any in-progress `merchantDelegateAladdinBoost` interface entry. Existing `delegateBoost` ABI is retained, along with existing `claimAladdinRewardsAndCompound` and `setAladdinDelegationOperator` declarations. No additional external Locker delegation API.

## Deployment/configuration updates

- Renamed configurations to `config-mainnet-v33.json`, `config-production-v33.json`, set `version=33`, `release="33"`; added `boostEconomics.postListingIfNoAcceptableOffer` default false. `merchantPaymentTokens` stays empty until the owner supplies actual per-token post price, acceptable fill price and SDT equivalent (no invented production pricing).
- Modified `deployment-v20/deploy-configure-v20.js` to use the Merchant's five-argument `setPaymentToken`; optionally set the passive listing-fallback toggle through existing configuration sequence. Kept the existing Locker module reserve setup and handoff process.
- Updated other inherited deployment/config/materialization/verification/handoff scripts from v32 to v33 paths, output naming and release validation without new workflows.
- Updated `package.json`, `package-lock.json` package metadata and `hardhat.config.js` paths/scripts for v33; Solidity compiler target still 0.8.28 with optimizer, viaIR and Cancun EVM.
- Added `README-v33.md`, this changelog, the exact source diff, a source manifest, and an archive-wide SHA-256 manifest. Kept the historical v31→v32 change log and patch; removed stale v32 manifest/README from v33 root.

## Known boundaries / verification

- Source wiring and JavaScript syntax checked; v33 production configuration materialized using existing script; no new tests or tests run. Not compiled or simulated, as npm dependencies were not installed and npm registry access failed.
- **Aladdin history is a backward-looking rate, not guaranteed future reward.** If the latest completed week lacks checkpointed data or total voting power, sell-rate checking reverts, while the Merchant can call its explicit Aladdin delegation route.
- Non-SDT payment tokens use an owner-maintained SDT conversion, not a trustless oracle. Owners must update this value before comparing off-SDT trades. The Merchant's configured `postPricePerWeek` and `minimumFillPricePerWeek` are separate ceilings/floors of intent, both required to exceed the reward benchmark at execution.
- A public EVM contract cannot iterate historical logs. No untrusted historical fill-average oracle was added; only actual on-chain active offer ID and Aladdin weekly reward reads are used.
