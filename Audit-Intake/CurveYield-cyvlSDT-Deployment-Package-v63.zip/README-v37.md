# CurveYield cyvlSDT Source + Deployment Package — v37

Version: **37**. Baseline: v36. Ethereum mainnet source release, not deployed.

## Scope

- Six existing deployable contracts: `CurveYieldVlSDTToken`, `CurveYieldVlSDTLocker`, `CurveYieldvlSDTStaking`, `CurveYieldVlSDTBoostMerchant`, `CurveYieldVault`, `CurveYieldRevenueStrategyV7` (source file `CurveYieldRevenueStrategyV20.sol`). No converter or multiplied-vlBoost staking contract.
- Owner-controlled Locker LP Bribe Revenue Share and PoL Deposit Share, each independently capped at 15%.
- Merchant is the only boost module; DAO boost reserve 10%. Aladdin SDT claims and the legacy `donateSDT()` contribution path are revenue, **never compounded into vlSDT**.
- Fee tier defaults: base 100% stakers; first excess 75/15/5/5 stakers/DAO/admin/PoL; second excess 60/20/10/10.
- Distinct seven-day streams for each receipt's base and each completed cyvlSDT excess conversion. Multiple receipts in one weekly epoch share one cumulative tier threshold.
- Normal vlSDT-equivalent SDT and USDC weekly base rates come from the latest fully checkpointed Stake DAO FeeDistributor epoch and `vlSDT.totalSupplyAt(epoch)`. PoL-diverted principal is included *virtually* in the benchmark through `Locker.baseSDTEquivalent()`, but NOT redeemable backing.
- One source of revenue classification: `CurveYieldvlSDTStaking.notifyReward`, callable only from the Locker. Merchant sends lease USDC through the Locker. Fee-distributor and Aladdin rewards also use the Locker's one forwarding path.

## Fees and recipients

`lockerRevenueDiversions.lpBribeRevenue` and `lockerRevenueDiversions.poLDeposit` each contain `shareBps` (0–1500) and `recipient` (nullable with a zero share). Deployment configuration and verification use the existing scripts. The PoL deposit transfer sends SDT to the configured recipient and never stakes that portion. Tier PoL revenue sends SDT or USDC to the *same configured PoL recipient*. If that address is unset, Staking accounts for it as pending until `forwardPendingPoLRevenue(token)` is called. Configure a recipient capable of accepting and managing both tokens before use.

## Economic behavior and constraints

The 1:1 backing is preserved by minting only against the *net* SDT actually staked. Reward benchmark principal tracks the **gross** SDT originally deposited to mint those shares, including the PoL diversion. This may exceed the available vlSDT and is **only a reward-rate benchmark**. Actual payout is limited to token receipts. LP bribe diversion reduces those receipts before tier classification; neither PoL virtual principal nor bribe allocation creates funds.

The three-token SDT/cyvlSDT StableSwap pool is **post-deployment**. Until a route exists, SDT deposits mint 1:1 after any PoL deduction. When a route is available, the Locker swaps only if the quoted return beats the net mint amount. Staker excess cyvlSDT conversions need an OmniRouter USDC->SDT route if source income is USDC; absent that route, conversions remain pending without blocking reward intake.

## Build/operate

Use existing `npm run compile:v37`, `config:materialize:v37`, `deploy:v37`, `configure:v37`, `verify:v37`, and existing handoff scripts. Deployment requires independent compilation. Trading rates and PoL recipients are configured separately; setup must be complete before production proceeds. Read `CHANGELOG-v36-to-v37.md` for details.

**Verification status:** source edits and JavaScript syntax reviewed, config and ZIP integrity checked. Solidity compilation not verified; no tests or blockchain transactions performed.
