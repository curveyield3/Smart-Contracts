# CurveYield cyvlSDT v46 — PoL Manager v18 + External Guard v6

## Scope

- Replaced bundled PoL Manager v9 source with the exact user-supplied `PoL_Manager_Contract_v18.sol` and its README.
- Added the exact user-supplied `CurvePairOracleBounds_v6.sol` and `UniV3TickMath_v6.sol` to `contracts/external_guard_v6/`; neither source is modified.
- Added `poLLiquidityBounds` to existing core `DEPLOYABLES`: the no-constructor, no-owner `CurvePairOracleBoundsV6` is deployed as an independent contract, recorded in deployment state, and checked in post-deployment verification. It is excluded from ownership handoff.
- Set Hardhat compilers to Solidity 0.8.28 (core and PoL Manager v18) and 0.8.30 (guard v6); preserved optimizer 200 runs, viaIR, Cancun settings. The v18 source is explicitly pinned to 0.8.28.
- Added `poLManager` v18 and v6 bounds metadata plus Curve LP slippage (default 200 bps) to mainnet and production configs. Existing `poLDeposit.recipient` remains the sole PoL Manager address; no duplicate address field is introduced.
- When a deployed v18 Manager is provided as `lockerRevenueDiversions.poLDeposit.recipient` and the deployer owns it, existing configuration calls `setLiquidityBounds(newGuard)`, `setCurveSlippageBps(configuredBps)`, and `setProfitRecipient(locker)` as needed. If a separate Safe owns the Manager, its owner makes the calls; verification reads those getters and refuses to report completed wiring until they match.
- Updated verification to v18's actual ABI: `usdc` is **private** in the v18 source and there is no `usdc()` getter. `sdt`, `omniRouter`, `liquidityBounds`, `curveSlippageBps`, and `profitRecipient` are checked.
- Aligned previously stale 42/45 config gates, artifact directory, release tags, deployment-output paths, and package scripts to v46.

## Deployment sequencing

1. Deploy core cyvlSDT contracts **and the v6 guard**. Guard has no constructor and can be deployed before pool/NFT existence.
2. Deploy **PoL Manager v18 separately** once the Curve SDT/cyvlSDT pool, LP token, and fixed Uni v3 NFT exist. Its `DeployConfig` requires those valid contract addresses and NFT position; they are not present in the current initial deployment config. Do not attempt deployment with fabricated addresses.
3. Set `lockerRevenueDiversions.poLDeposit.recipient` to the deployed v18 Manager. Run existing configure script; it attaches the guard and sets profit recipient, provided the wallet owns the Manager, or use the same calls from its owner Safe.
4. Authorize the user's keeper through PoL Manager's `setOperator(keeper, true)`. Keep direct Locker→Manager SDT PoL share transfers and keeper-initiated `allocateFunds()`; the Locker never invokes `allocateFunds()` on deposit.

**Important:** v6 guard's Curve bounds are marginal historical-oracle estimates, not finite-size LP quotes. Large liquidity adds/withdrawals may revert. A missing or zero guard address causes guarded operations to revert. The Manager does not implement duplicate swap slippage logic; OmniRouter retains ordinary swap protection.

## Validation status

No Solidity compilation, contract tests, fork simulations, or deployment have been performed in this edit. The v18 Manager was previously built by its source package; its v6 guard was not reported as compiled in that package. Source/version/script consistency checks are performed only.
