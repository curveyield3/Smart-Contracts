# CurveYield cyvlSDT v37 → v38

- Integrated `VoteMarketSingleGaugeBribeAllocator.sol` as seventh source/deployment contract. Replaces the incompatible Arbitrum-only v3 allocator; excludes superseded V2 campaign, hook and forecasting mechanisms.
- Ethereum VoteMarket V1 direct `createBounty`/`increaseBountyDuration`/`closeBounty` integration; one gauge, one extendable bounty, native refund to manager.
- Uses **deployed CurveYield OmniRouter `price_oracle(CRV,USDC)`** as the only CRV/USDC price source. Verified it returns gross historical token-out per whole token-in, scaled 1e18. No Chainlink, independent quote feed or forecasting reporter.
- Calculates maximum VoteMarket reward per vote from `CRV.rate()`, Curve GaugeController relative weight and gauge bias, 18-decimal Oracle output, USDC's six decimals and configurable minimum return (default 1.25×). Applies one native VoteMarket price cap; removes parallel ROI gating.
- Reuses OmniRouter swap routing and its native slippage guard for converting direct SDT receipts into USDC; USDC receipts require no deposit entry point.
- Deployment scripts now deploy/track/handoff the allocator; Locker LP bribe recipient automatically resolves to the deployed allocator address. Bribe share remains owner-configurable 0..15%; default 0. No invented gauge or swap routes.
- Updated v38 config reward-tier metadata to match v37 Solidity (75/15/5/5 first excess; 60/20/10/10 second excess). No staking/merchant/locker Solidity changes beyond the existing OmniRouter interface addition.
- Known pre-funding requirements: choose gauge, configure CRV→USDC OmniRouter oracle route, configure SDT→USDC route for SDT conversion, supply USDC, call `processEpoch` / `fundEpoch` before bounty extension expires.
- Source edits only. **No compilation, test execution, simulation, or deployment** performed.
