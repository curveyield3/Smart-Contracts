# v55 to v56

- BeefyVaultCurveYieldV8.sol: added optional revenue strategy live fee read, shareholder-only instant exit fee, ERC4626 preview updates, queued request/complete/early settlement, gross-principal queue quoting, and events.
- CurveYieldRevenueStrategyV8.sol: added direct staking live fee getter and pending staking queue, reserved-idle accounting, queue completion and early exit; instant gross-up and NAV now share the live fee source.
- config-mainnet-v47.json and config-production-v47.json: append ` cyvlSDT` to revenue vault name.
- `StrategyCurveSDTYearnV9.sol`, PoL, locker, staking, guard, and separate SDT/Yearn strategy deployment: unchanged.
- No proxies, tests, or broadcasts.
