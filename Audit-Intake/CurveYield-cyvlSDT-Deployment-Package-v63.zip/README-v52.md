# CurveYield cyvlSDT Deployment Package v52

This is the one-increment successor to v51. The only Solidity source adjustment is `contracts/interfaces/ICurveYield.sol`: `ICurveYieldvlSDTStaking.immediateWithdrawFeePpm()` returns `uint32` to match the actual getter exposed by `CurveYieldvlSDTStaking.sol`. See `INTERFACE_COMPATIBILITY_REPORT_v1.md` for scope, ABI-by-ABI evaluation and residual deployment-specific checks.

**Immutable source preservation:** `contracts/StrategyCurveSDTYearnV9.sol` remains byte-identical to the original supplied V9 (SHA-256 `c280bd632a02776a21999f7a0f16d768405036646aad8e70ded6431652594b87`); `contracts/BeefyVaultCurveYieldV8.sol` unchanged. Other contract implementations, PoL v22, and Guard V8 remain identical to v51.

The SDT/Yearn deployer remains `deployment-v27/deploy-sdt-yearn-beefy-v51.js` using `config-sdt-yearn-v51.json`. These are active and not stale: no deployment parameter change was required. `npm run compile:v52` is provided as the v52 release alias. Deployment script execution, Solidity compilation, tests, and chain writes were not performed.
