# CurveYield cyvlSDT source package v49 — PoL v22 / Guard V8 / Beefy Vault V8

## Changes against v48

- Replace the v20 PoL source with the **exact** PoL Manager v22 source from the supplied v4 Safe handoff.
- Replace the external V6 guard source with the **exact** CurvePairOracleBounds V8, retaining original UniV3TickMath V6 from the handoff. Update PoL references to the new source and guard, 75 bps independent Curve/NFT slippage configuration.
- **Add** `contracts/BeefyVaultCurveYieldV8.sol` by copying the BoostHub Contract Stack **v63** file `contracts/BeefyVaultV7FixedV2.sol` and replacing only the Solidity contract identifier (`BeefyVaultV7FixedV2` → `BeefyVaultCurveYieldV8`). All 4626 entrypoints, checkpoint APY, fees, valuation and withdrawal behavior are preserved exactly.
- Import the accompanying unchanged `contracts/interfaces/IStrategyBoostHubV1.sol`, and pin the separate `@openzeppelin-4/contracts@4.9.6` npm alias (the existing OpenZeppelin v5 dependency remains intact).

## Critical compatibility boundary: do not redeploy the revenue vault as Beefy V8 yet

`CurveYieldRevenueStrategyV7` (implemented in `CurveYieldRevenueStrategyV20.sol`) and the existing `CurveYieldVault.sol` form an asynchronous-withdrawal pair. The new **BeefyVaultCurveYieldV8** assumes the quite different `IStrategyBoostHubV1`: `withdraw(uint256)`, `lockVaultProfit(uint256)`, `balanceOf()`, and a predicted vault address known to the strategy before vault deployment. It also requires `_strategy.vault() == address(this)` **during its own constructor**. The original cyvlSDT revenue strategy only exposes `withdrawInstant(uint256)` plus timelocked request/complete paths and does not implement these methods. Replacing the existing revenue vault with Beefy V8 without a compatible new strategy would break withdrawals. Therefore the original `CurveYieldVault.sol` and its deployment route remain unchanged. The new Beefy V8 source is available for the separately requested additional strategy/vault pair when its compatible strategy source is provided.

## Missing additional strategy / Yearn Curve-factory deployment

The only extra `.md` attachment received was **`CurveYield_Automated_Security_Pipeline_Implementation_Plan_v9(2).md`**, which is an audit pipeline specification, *not* a vault strategy source. Neither the PoL handoff nor the BoostHub v63 archive provides a specialized constructor-bound strategy for a new Yearn Curve factory vault for Curve pool `0xA19bf6fBf05624282cb6ed498f4761f22e084Edd`. No guessed strategy, factory method, CREATE nonce, address, or deployment call is added. A Yearn-factory vault is distinct from the Beefy vault itself; exact factory version and instantiated vault/strategy binding must be established before writing executable deployment calls.

## Deployment and behavior

The existing legacy revenue-vault deployment paths are **preserved**, not silently switched to a contract they cannot call. The PoL manager and Guard V8 deployment script references are source-updated but **not** tied to the already-deployed v4 Safe CREATE2 proposal. The PoL v22 source intentionally lacks the v20 90-day owner-staged emergency migration mechanism; its owner-only Uniswap NFT withdrawal is present. The v4 handoff Safe transactions are historical and must not be replayed against mainnet without reviewing the live on-chain state (Guard V8 may already exist).

The new source has been checked for exact source fidelity with the only contract-identifier substitution; **no contracts were compiled, tested, simulated, deployed, or verified** as part of this package. The npm lockfile includes the OpenZeppelin 4.9.6 npm alias with its registry archive URL but without an integrity digest because registry access was unavailable. Before using `npm ci` or compiling in a trusted GitHub environment, regenerate the lockfile with the accessible registry and retain the same pinned version.
