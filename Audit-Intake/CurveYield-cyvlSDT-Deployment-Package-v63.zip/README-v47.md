# CurveYield cyvlSDT deployment package v47

## Change from v46

PoL Manager **v19** is now deployable together with the Locker, Staking, Merchant, Bribe Allocator and the unchanged `CurvePairOracleBoundsV6` guard **before the Curve pool, LP or Uniswap NFT has been deployed**. PoL Manager v19 is a minimal derivative of the user-provided v18 source: its Curve pool/LP, optional gauge, and fixed Uniswap v3 NFT have been moved out of `DeployConfig` into owner-only, one-time post-deployment setters.

### One-time setters after the positions exist

1. `PoLManager.configureCurvePool(pool, lp)` — bind valid Curve pool/LP once (coin 0 SDT; coin 1 cyvlSDT). The Curve gauge is not required yet.
2. `PoLManager.configureCurveGauge(gauge)` — optional; bind the gauge once after the pool is configured.
3. `PoLManager.configureUniswapPosition(positionManager, tokenId)` — bind the fixed SDT/cyvlSDT NFT once. Transfer that NFT to the PoL Manager afterward.

The v47 `config-mainnet-v47.json` and `config-production-v47.json` set all optional position values to `null`. Populate them as the pool/NFT exist; owner can call setters directly or have the existing configure script call them once. The scripts check bound values before attempting to set them. No component is fabricated or preset. The guard retains its original external oracle behavior and settings.

### Deployment and PoL revenue

`deploy:v47` deploys and records both `PoLManager` and `CurvePairOracleBoundsV6`. `configure:v47` wires `setLiquidityBounds(guard)`, `setCurveSlippageBps(configBps)`, `setProfitRecipient(locker)`, and `Locker.setPoLDepositShare(shareBps, deployedManager)`. The Manager no longer requires a separate, manually supplied address in `lockerRevenueDiversions.poLDeposit.recipient` (that config field remains null). After setting the Locker's nonzero PoL share, user deposits transfer that SDT to the PoL Manager without triggering allocation. Configure the keeper as an operator of PoL Manager; it invests idle funds with `allocateFunds` separately.

Ownership handoff includes PoL Manager's existing `proposeOwner` and `acceptOwner` flow. All other cyvlSDT contracts retain their previous deployment and handoff logic. Pool/NFT binding can be executed from the owner Safe later even if initial deployment/handoff has already completed.

### Settings and verification

Solidity 0.8.28 for PoL Manager v19; Solidity ^0.8.30 for untouched external guard v6; optimizer 200, viaIR and Cancun settings retained. No compilation, tests, live-fork simulation or onchain deployment has been performed for this v47 edit. Refer to `PoL_Manager_README_v19.md` and `CHANGELOG-v46-to-v47.md` for the exact interface, prerequisite and operational notes.
