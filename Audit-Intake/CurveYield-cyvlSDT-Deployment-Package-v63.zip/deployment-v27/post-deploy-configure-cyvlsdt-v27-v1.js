#!/usr/bin/env node
"use strict";

const path = require("path");
const {
  makeContext,
  DEPLOYABLES,
  codeExists,
  contract,
  saveState,
  readJson,
  send
} = require("../deployment-v20/lib-v20");
const { deployAndConfigure } = require("../deployment-v20/deploy-configure-v20");
const { validateProductionConfigObject } = require("./production-config-v27-v1");

function defaultConfigPath() {
  return path.resolve(__dirname, "..", "config-production-v47.json");
}

async function assertCompleteDeployment(ctx) {
  const missing = [];
  for (const [key] of DEPLOYABLES) {
    const entry = ctx.state.contracts[key];
    if (!entry?.address || !(await codeExists(ctx.provider, entry.address))) missing.push(key);
  }
  if (missing.length) {
    throw new Error(`post-deployment configuration requires all current core contracts; missing/no-code: ${missing.join(", ")}`);
  }
}

async function configurationStatus(ctx) {
  const c = ctx.config;
  const cyvlSdt = contract(ctx, "cyvlSdt");
  const locker = contract(ctx, "locker");
  const revenueStaking = contract(ctx, "revenueStaking");
  const boostMerchant = contract(ctx, "boostMerchant");
  const revenueVault = contract(ctx, "revenueVault");
  const revenueStrategy = contract(ctx, "revenueStrategy");
  const bribeAllocator = contract(ctx, "bribeAllocator");
  const same = (a, b) => a.toLowerCase() === b.toLowerCase();
  const rewardTokens = ctx.state.external?.feeDistributorRewardTokens?.all || [];
  const guard = contract(ctx, "poLLiquidityBounds");
  const guardAddress = await guard.getAddress();
  const guardPresent = await codeExists(ctx.provider, guardAddress)
    && Number(await guard.UNI_V3_TWAP_SECONDS()) === 300
    ; // Guard V8 accepts caller-configured Uniswap slippage; no fixed-slippage getter.
  const poL = contract(ctx, "poLManager");
  const poLRecipient = await poL.getAddress();
  const p = c.poLManager;
  const [polSdt, polOmniRouter, polBounds, polSlippage, polUniSlippage, polProfitReceiver, polCurve,
    polLP, polGauge, polNftManager, polTokenId] = await Promise.all([
      poL.sdt(), poL.omniRouter(), poL.liquidityBounds(), poL.curveSlippageBps(),
      poL.uniSlippageBps(), poL.profitRecipient(), poL.curvePool(), poL.curveLp(), poL.curveGauge(),
      poL.uniNftManager(), poL.uniTokenId()
    ]);
  const poLManagerWiring = same(polSdt,c.stakeDao.sdt)
    && same(polOmniRouter,c.omniRouter)
    && same(polBounds,guardAddress)
    && Number(polSlippage)===p.curveSlippageBps
    && Number(polUniSlippage)===p.uniSlippageBps
    && same(polProfitReceiver,await locker.getAddress())
    && (!p.curvePool||(same(polCurve,p.curvePool)&&same(polLP,p.curveLp)))
    && (!p.curveGauge||same(polGauge,p.curveGauge))
    && (!p.uniNftManager||(same(polNftManager,p.uniNftManager)&&polTokenId===BigInt(p.uniTokenId)));
  const checks = {
    poLBoundsDeployed: guardPresent,
    poLManagerWiring,
    cyvlSdtLocker: same(await cyvlSdt.locker(), await locker.getAddress()),
    lockerConfigured: await locker.systemConfigured(),
    lockerModules: same(await locker.revenueStaking(), await revenueStaking.getAddress())
      && same(await locker.boostMerchant(), await boostMerchant.getAddress()),
    rewardTokens: (await Promise.all([...rewardTokens, await cyvlSdt.getAddress()]
      .map(t => revenueStaking.isRewardToken(t)))).every(Boolean),
    rateSources: same(await revenueStaking.SDT_DISTRIBUTOR(), c.stakeDao.vlSdtFeeDistributorSdt)
      && same(await revenueStaking.USDC_DISTRIBUTOR(), c.stakeDao.vlSdtFeeDistributorUsdc)
      && same(await revenueStaking.VLSDT(), c.stakeDao.vlSdt),
    revenueNotifier: same(await revenueStaking.LOCKER(), await locker.getAddress()),
    lockerRevenueDiversions: Number(await revenueStaking.lpBribeRevenueShareBps()) === c.lockerRevenueDiversions.lpBribeRevenue.shareBps
      && same(await revenueStaking.lpBribeContract(), await bribeAllocator.getAddress())
      && Number(await locker.poLDepositShareBps()) === c.lockerRevenueDiversions.poLDeposit.shareBps
      && same(await locker.cyvlSdtPoLContract(), poLRecipient),
    bribeAllocatorWiring: same(await bribeAllocator.OMNI_ROUTER(), c.omniRouter)
      && same(await bribeAllocator.VOTEMARKET(), c.bribeAllocator.voteMarket)
      && same(await bribeAllocator.gauge(), c.bribeAllocator.gauge || require("ethers").ZeroAddress)
      && (await bribeAllocator.minimumReturnWad()) === BigInt(c.bribeAllocator.minimumReturnWad),
    revenueWithdrawalFee: Number(await revenueStaking.immediateWithdrawFeePpm()) === c.revenueStakingConfig.immediateWithdrawFeePpm,
    revenueVaultStrategy: same(await revenueVault.strategy(), await revenueStrategy.getAddress())
      && same(await revenueVault.want(), await cyvlSdt.getAddress())
      && same(await revenueStrategy.vault(), await revenueVault.getAddress()),
    omniRouterWiring: same(await revenueStrategy.OMNI_ROUTER(), c.omniRouter)
      && same(await revenueStrategy.LOCKER(), await locker.getAddress())
  };
  // Trading rates are owner-configured after deploy; treat absence as disabled,
  // NOT as a blocker for the initial six-contract deployment/ownership handoff.
  const merchantUsdcSaleRates = (await boostMerchant.postPricePerWeek()) > 0n
    && (await boostMerchant.minimumFillPricePerWeek()) > 0n
    && (await boostMerchant.sdtWeiPerUsdc()) > 0n;
  // Price routes are not deployed/configured at this phase. Report but never block
  // the initial contract deployment or 1:1 cyvlSDT minting path.
  const omni = new (require("ethers").Contract)(c.omniRouter, [
    "function routeLength(address,address) view returns (uint256)"
  ], ctx.provider);
  const optionalRoutes = {
    crvToUsdcOracle: Number(await omni.routeLength("0xD533a949740bb3306d119CC777fa900bA034cd52", c.usdc)),
    sdtToUsdcBribes: Number(await omni.routeLength(c.stakeDao.sdt, c.usdc)),
    usdcToSdt: Number(await omni.routeLength(c.usdc, c.stakeDao.sdt)),
    sdtToCyvlSdt: Number(await omni.routeLength(c.stakeDao.sdt, await cyvlSdt.getAddress()))
  };
  // The 3-coin SDT/cyvlSDT StableSwap is intentionally created AFTER initial
  // deployment. If supplied later, verify its actual coins here, not on-chain.
  let stablePool = { configured: false, reason: "pool not deployed/configured yet" };
  if (c.postDeploymentStablePool?.address) {
    const poolAddress = c.postDeploymentStablePool.address;
    if (!await codeExists(ctx.provider, poolAddress)) {
      throw new Error(`configured post-deployment StableSwap has no code: ${poolAddress}`);
    }
    const ethers = require("ethers");
    async function readThreeCoins(signature) {
      const pool = new ethers.Contract(poolAddress, [`function ${signature} view returns (address)`], ctx.provider);
      return Promise.all([0, 1, 2].map(i => pool.coins(i)));
    }
    let coins;
    try { coins = await readThreeCoins("coins(uint256)"); }
    catch { coins = await readThreeCoins("coins(int128)"); }
    const expected = [c.stakeDao.sdt.toLowerCase(), (await cyvlSdt.getAddress()).toLowerCase()];
    const lower = coins.map(x => x.toLowerCase());
    if (!expected.every(x => lower.includes(x))) {
      throw new Error(`3-coin StableSwap does not contain both SDT and cyvlSDT: ${coins.join(",")}`);
    }
    if (new Set(lower).size !== 3 || lower.some(x => x === ethers.ZeroAddress.toLowerCase())) {
      throw new Error("post-deployment StableSwap must have three distinct nonzero coins");
    }
    stablePool = { configured: optionalRoutes.sdtToCyvlSdt > 0, address: poolAddress, coins };
  }
  return { fullyActive: Object.values(checks).every(Boolean), checks, merchantUsdcSaleRates, optionalRoutes, stablePool };

}

async function configureSuite(options = {}) {
  const configPath = path.resolve(options.configPath || process.argv[2] || defaultConfigPath());
  const rawConfig = readJson(configPath);
  validateProductionConfigObject(rawConfig);
  const tag = options.tag || process.env.DEPLOYMENT_TAG || "v55-live";

  const initial = await makeContext({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    confirmations: options.confirmations,
    stateFile: options.stateFile
  });
  if (!["deployed", "configured", "production-configured"].includes(initial.state.phase)) {
    throw new Error(`invalid phase for post-deployment configuration: ${initial.state.phase}`);
  }
  await assertCompleteDeployment(initial);
  const beforeAddresses = Object.fromEntries(DEPLOYABLES.map(([key]) => [key, initial.state.contracts[key].address]));
  const beforeDeployTxs = initial.state.transactions.filter(tx => String(tx.label).startsWith("deploy:")).length;

  const configured = await deployAndConfigure({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    confirmations: options.confirmations,
    stateFile: initial.stateFile
  });

  for (const key of Object.keys(beforeAddresses)) {
    if (configured.state.contracts[key]?.address !== beforeAddresses[key]) {
      throw new Error(`configuration changed deployment address for ${key}`);
    }
  }
  const afterDeployTxs = configured.state.transactions.filter(tx => String(tx.label).startsWith("deploy:")).length;
  if (afterDeployTxs !== beforeDeployTxs) {
    throw new Error("post-deployment configuration unexpectedly deployed a contract");
  }

  const status = await configurationStatus(configured);
  if (!status.fullyActive) throw new Error(`v47 configuration incomplete: ${JSON.stringify(status)}`);
  configured.state.phase = "production-configured";
  configured.state.productionConfigurationStatus = status;
  saveState(configured.stateFile, configured.state);
  console.log(JSON.stringify(status, null, 2));
  return configured;
}

if (require.main === module) {
  configureSuite().catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { assertCompleteDeployment, configurationStatus, configureSuite };
