#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

function readJson(file) { return JSON.parse(fs.readFileSync(file, "utf8")); }
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2) + "\n"); }

function validateProductionConfigObject(config) {
  const blockers = [];
  if (config.version !== 47 || config.release !== "47" || config.chainId !== 1) {
    blockers.push("v47 Ethereum mainnet config required");
  }
  for (const [name, limit] of [["lpBribeRevenue", 1500], ["poLDeposit", 2500]]) {
    const cfg = config.lockerRevenueDiversions?.[name];
    if (!cfg || !Number.isInteger(cfg.shareBps) || cfg.shareBps < 0 || cfg.shareBps > limit) {
      blockers.push(`${name}.shareBps must be integer 0..${limit}`);
    } else if (cfg.recipient && !/^0x[0-9a-fA-F]{40}$/.test(cfg.recipient)) {
      blockers.push(`${name}.recipient invalid`);
    }
  }
  // Position addresses are optional during deployment and individually bindable once afterward.
  const p = config.poLManager;
  if (!p || p.sourceVersion !== 22 || !String(p.deployment || "").startsWith("with-core")
      || p.liquidityBounds?.contract !== "CurvePairOracleBoundsV8"
      || p.liquidityBounds?.sourceVersion !== 8 || p.liquidityBounds?.deployWithCore !== true
      || !Number.isInteger(p.curveSlippageBps) || p.curveSlippageBps < 0 || p.curveSlippageBps >= 10000
      || !Number.isInteger(p.uniSlippageBps) || p.uniSlippageBps < 0 || p.uniSlippageBps >= 10000
      || !/^0x[0-9a-fA-F]{40}$/.test(p.crv || "")
      || !Number.isInteger(p.sdtYearnIndex) || p.sdtYearnIndex < 0 || p.sdtYearnIndex > 2
      || !Number.isInteger(p.sdtEulerIndex) || p.sdtEulerIndex < 0 || p.sdtEulerIndex > 1
      || !Array.isArray(p.yearnVaults) || p.yearnVaults.length !== 3
      || !Array.isArray(p.eulerVaults) || p.eulerVaults.length !== 2
      || [...(p.yearnVaults || []), ...(p.eulerVaults || [])].some(v => v != null && !/^0x[0-9a-fA-F]{40}$/.test(v))
      || (Boolean(p.curvePool) !== Boolean(p.curveLp))
      || (p.curveGauge && !p.curvePool)
      || (Boolean(p.uniNftManager) !== (p.uniTokenId != null))
      || (p.uniTokenId != null && (!Number.isSafeInteger(p.uniTokenId) || p.uniTokenId <= 0))
      || [p.curvePool,p.curveLp,p.curveGauge,p.uniNftManager].some(v => v != null && !/^0x[0-9a-fA-F]{40}$/.test(v))) {
    blockers.push("PoL v22 / Guard V8 require both Curve and Uniswap slippage bps; optional Curve pool/LP, gauge and Uni NFT must be paired and valid when supplied");
  }
  if (config.lockerRevenueDiversions?.poLDeposit?.recipient) {
    blockers.push("poLDeposit.recipient must be null: the core deploys and wires its own PoL Manager");
  }
  const b = config.bribeAllocator;
  if (!b || !/^0x[0-9a-fA-F]{40}$/.test(b.voteMarket || "")) {
    blockers.push("bribeAllocator.voteMarket must be a contract address");
  }
  if (b?.gauge != null && !/^0x[0-9a-fA-F]{40}$/.test(b.gauge)) {
    blockers.push("bribeAllocator.gauge must be a gauge address or null");
  }
  if (!b || !/^\d+$/.test(String(b.minimumReturnWad ?? "")) || BigInt(b.minimumReturnWad) < 10n ** 18n) {
    blockers.push("bribeAllocator.minimumReturnWad must be at least 1e18");
  }
  if (config.lockerRevenueDiversions?.lpBribeRevenue?.recipient) {
    blockers.push("lpBribeRevenue.recipient must be null: v43 deploys and wires its own allocator");
  }
  if (blockers.length) throw new Error(`Invalid v47 configuration: ${blockers.join("; ")}`);
  return true;
}

function materializeProductionConfig({ basePath, outputPath }) {
  const config = readJson(basePath);
  validateProductionConfigObject(config);
  writeJson(outputPath, config);
  return config;
}

if (require.main === module) {
  const root = path.resolve(__dirname, "..");
  const basePath = path.resolve(process.argv[2] || path.join(root, "config-mainnet-v47.json"));
  const outputPath = path.resolve(process.argv[3] || path.join(root, "config-production-v47.json"));
  try {
    materializeProductionConfig({ basePath, outputPath });
    console.log(`v47 production configuration written: ${outputPath}`);
  } catch (error) {
    console.error(error.message || error);
    process.exitCode = 1;
  }
}

module.exports = { readJson, writeJson, validateProductionConfigObject, materializeProductionConfig };
