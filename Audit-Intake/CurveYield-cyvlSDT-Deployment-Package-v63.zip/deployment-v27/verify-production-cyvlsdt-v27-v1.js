#!/usr/bin/env node
"use strict";

const path = require("path");
const {
  ethers,
  makeContext,
  saveState,
  readJson,
} = require("../deployment-v20/lib-v20");
const { verifyDeployment } = require("../deployment-v20/verify-deployment-v20");
const { validateProductionConfigObject } = require("./production-config-v27-v1");
const { assertCompleteDeployment, configurationStatus } = require("./post-deploy-configure-cyvlsdt-v27-v1");

function defaultConfigPath() {
  return path.resolve(__dirname, "..", "config-production-v47.json");
}

async function verifyProduction(options = {}) {
  const configPath = path.resolve(options.configPath || process.argv[2] || defaultConfigPath());
  const rawConfig = readJson(configPath);
  validateProductionConfigObject(rawConfig);
  const tag = options.tag || process.env.DEPLOYMENT_TAG || "v55-live";

  const ctx = await makeContext({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    confirmations: 0,
    allowWalletMismatch: true
  });
  await assertCompleteDeployment(ctx);

  const finalPhase = ["ownership-proposed", "ownership-accepted", "final-verified"].includes(ctx.state.phase);
  const expectedOwner = options.expectedOwner || process.env.EXPECTED_OWNER || (finalPhase ? ctx.config.finalOwner : ctx.wallet.address);
  const expectedAdmin = options.expectedAdmin || process.env.EXPECTED_ADMIN || (finalPhase ? ctx.config.finalAdmin : ctx.wallet.address);

  await verifyDeployment({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    expectedOwner,
    expectedAdmin
  });

  const status = await configurationStatus(ctx);
  if (!status.fullyActive) {
    throw new Error(`production configuration is not fully active: ${JSON.stringify(status)}`);
  }
  const ownerIsFinal = ethers.getAddress(expectedOwner) === ctx.config.finalOwner;
  ctx.state.phase = ownerIsFinal ? "final-verified" : "production-verified";
  ctx.state.productionVerification = {
    verifiedAtBlock: await ctx.provider.getBlockNumber(),
    expectedOwner: ethers.getAddress(expectedOwner),
    expectedAdmin: ethers.getAddress(expectedAdmin),
    status
  };
  saveState(ctx.stateFile, ctx.state);
  console.log(`V47 production verification PASS; phase=${ctx.state.phase}; state=${ctx.stateFile}`);
  return ctx;
}

if (require.main === module) {
  verifyProduction().catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { verifyProduction };
