#!/usr/bin/env node
"use strict";

const path = require("path");
const {
  makeContext,
  contract,
  send,
  OWNABLE_CONTRACTS,
  saveState,
  readJson,
  ethers
} = require("../deployment-v20/lib-v20");
const { validateProductionConfigObject } = require("./production-config-v27-v1");
const { verifyProduction } = require("./verify-production-cyvlsdt-v27-v1");

function defaultConfigPath() {
  return path.resolve(__dirname, "..", "config-production-v47.json");
}

async function acceptHandoff(options = {}) {
  const configPath = path.resolve(options.configPath || process.argv[2] || defaultConfigPath());
  const rawConfig = readJson(configPath);
  validateProductionConfigObject(rawConfig);
  const tag = options.tag || process.env.DEPLOYMENT_TAG || "v55-live";

  const ctx = await makeContext({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    confirmations: options.confirmations,
    allowWalletMismatch: true
  });
  if (ethers.getAddress(ctx.wallet.address) !== ctx.config.finalOwner) {
    throw new Error(`acceptance wallet must be finalOwner ${ctx.config.finalOwner}`);
  }
  if (!["ownership-proposed", "ownership-accepted", "final-verified"].includes(ctx.state.phase)) {
    throw new Error(`ownership acceptance requires ownership-proposed phase, got ${ctx.state.phase}`);
  }

  for (const [key] of OWNABLE_CONTRACTS) {
    const target = contract(ctx, key);
    const owner = ethers.getAddress(await target.owner());
    if (owner === ctx.config.finalOwner) continue;
    if (key === "revenueVault") {
      throw new Error("Revenue Beefy V8 must have been transferred in the proposal stage");
    }
    const pendingOwner = ethers.getAddress(await target.pendingOwner());
    if (pendingOwner !== ctx.config.finalOwner) {
      throw new Error(`${key}.pendingOwner=${pendingOwner}, expected ${ctx.config.finalOwner}`);
    }
    const method = key === "poLManager" ? "acceptOwner" : "acceptOwnership";
    await send(ctx, `handoff:${key}.${method}`, target, method, []);
  }

  ctx.state.phase = "ownership-accepted";
  saveState(ctx.stateFile, ctx.state);

  await verifyProduction({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    expectedOwner: ctx.config.finalOwner,
    expectedAdmin: ctx.config.finalAdmin
  });
  console.log("V47 ownership acceptance and final production verification PASS.");
  return ctx;
}

if (require.main === module) {
  acceptHandoff().catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { acceptHandoff };
