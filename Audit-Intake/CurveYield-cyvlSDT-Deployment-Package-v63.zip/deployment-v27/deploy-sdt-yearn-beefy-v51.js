#!/usr/bin/env node
"use strict";

// Additional SDT/Curve/Yearn + BeefyVaultCurveYieldV8 deployment.
// Separate from the v47 core deploy: Yearn's CurveGlobal factory is an external
// mainnet dependency and must emit the new V2 Yearn vault before our strategy
// can bind it immutably in its constructor.
const fs = require("fs");
const path = require("path");
const { ethers } = require("ethers");
const { loadArtifact } = require("../deployment-v20/lib-v20");

const ROOT = path.resolve(__dirname, "..");
const ZERO = ethers.ZeroAddress;
const SDT = "0x73968b9a57c6E53d41345FD57a6E6ae27d6CDB2F";
const WETH = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2";
const DEFAULT_CONFIG = path.join(ROOT, "config-sdt-yearn-v51.json");
const DEFAULT_STATE = path.join(ROOT, "deployment-output-v51", "sdt-yearn-beefy-v51-ethereum.json");

const factoryABI = [
  "function latestStandardVaultFromGauge(address gauge) view returns (address)",
  "function canCreateVaultPermissionlessly(address gauge) view returns (bool)",
  "function createNewVaultsAndStrategies(address gauge) returns (address vault,address convexStrategy,address curveStrategy,address convexFraxStrategy)",
  "event NewAutomatedVault(uint256 indexed category,address indexed lpToken,address gauge,address indexed vault,address convexStrategy,address curveStrategy,address convexFraxStrategy)"
];
const vaultABI = [
  "function token() view returns (address)",
  "function decimals() view returns (uint256)",
  "function pricePerShare() view returns (uint256)"
];
const localVaultABI = [
  "function strategy() view returns (address)",
  "function want() view returns (address)",
  "function withdrawalFeeBps() view returns (uint256)",
  "function depositFeeBps() view returns (uint256)",
  "function adminFeeReceiver() view returns (address)",
  "function owner() view returns (address)",
  "function setDepositFeeBps(uint256 feeBps)",
  "function transferOwnership(address newOwner)"
];

function configuredAddress(c, key) {
  const address = c[key];
  if (typeof address !== "string" || !ethers.isAddress(address) || address === ZERO) {
    throw new Error(`config ${key} must be a nonzero Ethereum address`);
  }
  return ethers.getAddress(address);
}
function same(a, b) { return ethers.getAddress(a) === ethers.getAddress(b); }
function saveState(file, state) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2) + "\n", { mode: 0o600 });
  fs.renameSync(tmp, file);
}
async function deployed(provider, address) { return (await provider.getCode(address)) !== "0x"; }
async function success(tx, confirmations, description) {
  const r = await tx.wait(confirmations);
  if (!r || r.status !== 1) throw new Error(`${description} failed; tx=${tx.hash}`);
  return r;
}

async function deploySdtYearnBeefy(options = {}) {
  const cfgPath = path.resolve(options.configPath || process.argv[2] || DEFAULT_CONFIG);
  const c = JSON.parse(fs.readFileSync(cfgPath, "utf8"));
  if (c.version !== 51 || c.chainId !== 1 || c.network !== "ethereum-mainnet") {
    throw new Error("The additional SDT/Yearn deployment requires v51 Ethereum-mainnet config");
  }
  if (c.vaultContract !== "BeefyVaultCurveYieldV8" || c.strategyContract !== "StrategyCurveSDTYearnV9") {
    throw new Error("Unexpected vault or strategy artifact identity");
  }
  if (c.yearnVaultReuse !== "use-existing-if-factory-reports-one") {
    throw new Error("Unexpected Yearn factory duplicate policy");
  }
  if (!Number.isInteger(c.withdrawalFeeBps) || c.withdrawalFeeBps < 0 || c.withdrawalFeeBps > 10000
      || !Number.isInteger(c.depositFeeBps) || c.depositFeeBps < 0 || c.depositFeeBps > 100
      || !Number.isInteger(c.confirmations) || c.confirmations < 1
      || !c.vaultName || !c.vaultSymbol) {
    throw new Error("Invalid vault fee, confirmation, or ERC20 name/symbol configuration");
  }
  const pool = configuredAddress(c, "curvePool");
  const gauge = configuredAddress(c, "curveGauge");
  const curveGuard = configuredAddress(c, "curveGuardV8");
  const yearnFactory = configuredAddress(c, "yearnCurveFactory");
  const vaultOwner = configuredAddress(c, "vaultOwner");
  const adminFeeReceiver = configuredAddress(c, "adminFeeReceiver");
  const rpcUrl = options.rpcUrl || process.env.RPC_URL;
  const privateKey = options.privateKey || process.env.DEPLOYER_PRIVATE_KEY;
  if (!rpcUrl || !privateKey) throw new Error("RPC_URL and DEPLOYER_PRIVATE_KEY are required");
  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const network = await provider.getNetwork();
  if (network.chainId !== 1n) throw new Error(`Unexpected chain ID ${network.chainId}`);
  const signer = new ethers.Wallet(privateKey, provider);
  for (const [name, addr] of [["Curve SDT/WETH LP",pool],["Curve gauge",gauge],
                               ["Yearn CurveGlobal factory",yearnFactory],["Curve V8 guard",curveGuard]]) {
    if (!await deployed(provider, addr)) throw new Error(`${name} missing code at ${addr}`);
  }

  // Source-bound dependency preflight: Twocrypto-NG pool = LP token, WETH index 0,
  // SDT index 1; the Curve gauge must stake this LP token. No new Curve pool is created.
  const lp = new ethers.Contract(pool, ["function coins(uint256) view returns (address)"], provider);
  const g = new ethers.Contract(gauge, ["function lp_token() view returns (address)"], provider);
  if (!same(await lp.coins(0), WETH) || !same(await lp.coins(1), SDT)
      || !same(await g.lp_token(), pool)) throw new Error("Pool/gauge assets differ from strategy immutables");
  const guard = new ethers.Contract(curveGuard, [
    "function quoteDeposit(address,uint8,uint256,uint16) view returns (uint256 estimate,uint256 minOut)",
    "function quoteWithdraw(address,uint8,uint256,uint16) view returns (uint256 estimate,uint256 minOut)"
  ], provider);
  const depQuote = await guard.quoteDeposit(pool, 1, ethers.parseUnits("1",18), 200);
  const wdQuote = await guard.quoteWithdraw(pool, 1, ethers.parseUnits("1",18), 200);
  if (depQuote.minOut === 0n || wdQuote.minOut === 0n) throw new Error("V8 guard returned zero on sample SDT/LP quotes");

  const statePath = path.resolve(options.stateFile || process.env.SDT_YEARN_V51_STATE || DEFAULT_STATE);
  const state = fs.existsSync(statePath) ? JSON.parse(fs.readFileSync(statePath,"utf8")) : {
    packageVersion:51,chainId:1, pool, gauge,curveGuard,yearnFactory,deployer:signer.address,
    vaultContract:c.vaultContract,strategyContract:c.strategyContract
  };
  for (const [key, expected] of [["pool",pool],["gauge",gauge],["curveGuard",curveGuard],
                                  ["yearnFactory",yearnFactory],["deployer",signer.address]]) {
    if (!same(state[key],expected)) throw new Error(`State file ${key} conflicts with deployment config`);
  }
  const factory = new ethers.Contract(yearnFactory, factoryABI, signer);
  let yearnVault = await factory.latestStandardVaultFromGauge(gauge);
  if (yearnVault === ZERO) {
    if (state.yearnVault) {
      throw new Error("Saved Yearn vault not visible from authoritative factory; do not deploy a duplicate");
    }
    if (!await factory.canCreateVaultPermissionlessly(gauge)) {
      throw new Error(`CurveGlobal cannot permissionlessly create a vault for gauge ${gauge}`);
    }
    const receipt = await success(await factory.createNewVaultsAndStrategies(gauge), c.confirmations,
                                  "Yearn CurveGlobal vault creation");
    const events = [];
    for (const log of receipt.logs) {
      if (!same(log.address,yearnFactory)) continue;
      try {
        const parsed = factory.interface.parseLog(log);
        if (parsed && parsed.name === "NewAutomatedVault" && same(parsed.args.lpToken,pool)
            && same(parsed.args.gauge,gauge)) events.push(parsed);
      } catch { /* another event from the same factory */ }
    }
    if (events.length !== 1) throw new Error("Yearn factory transaction lacks exactly one matching NewAutomatedVault event");
    yearnVault = events[0].args.vault;
    state.yearnFactoryTx = receipt.hash;
    state.yearnVault = yearnVault;
    saveState(statePath,state);
  }
  if (state.yearnVault && !same(state.yearnVault,yearnVault)) {
    throw new Error("Yearn factory vault changed from the previously recorded address");
  }
  const yv = new ethers.Contract(yearnVault,vaultABI,provider);
  if (!await deployed(provider,yearnVault) || !same(await yv.token(),pool)) {
    throw new Error("Yearn factory vault does not hold the requested Curve LP token");
  }
  if ((await yv.decimals()) > 30n || (await yv.pricePerShare()) === 0n) {
    throw new Error("Yearn V2 share valuation unavailable or invalid");
  }
  state.yearnVault = yearnVault;
  saveState(statePath,state);

  // Beefy constructor reads _strategy.vault() against its own address;
  // we must first deploy StrategyCurveSDTYearnV9 pointing to the wallet's
  // *next* CREATE address. Reserve an explicit contiguous nonce pair.
  if (!state.strategyAddress) {
    const nonce = await provider.getTransactionCount(signer.address,"pending");
    const expectedBeefy = ethers.getCreateAddress({from:signer.address,nonce:nonce+1});
    const stratArtifact = loadArtifact(c.strategyContract);
    const strat = await new ethers.ContractFactory(stratArtifact.abi,stratArtifact.bytecode,signer)
      .deploy(expectedBeefy,yearnVault,curveGuard,{nonce});
    const stratReceipt = await success(strat.deploymentTransaction(),c.confirmations,"SDT Yearn strategy deployment");
    const actual = await strat.getAddress();
    if (stratReceipt.contractAddress && !same(stratReceipt.contractAddress,actual)) {
      throw new Error("Strategy receipt contract address mismatch");
    }
    if (!same(await strat.vault(),expectedBeefy) || !same(await strat.yearn(),yearnVault)
        || !same(await strat.want(),SDT)) throw new Error("Strategy constructor bindings differ from config");
    state.strategyAddress = actual;
    state.beefyVaultAddress = expectedBeefy;
    state.beefyVaultNonce = nonce+1;
    state.strategyTx = stratReceipt.hash;
    saveState(statePath,state);
  }
  if (!await deployed(provider,state.strategyAddress)) throw new Error("Recorded strategy has no code");
  const strategy = new ethers.Contract(state.strategyAddress,[
    "function vault() view returns(address)",
    "function yearn() view returns(address)",
    "function curveLiquidityGuard() view returns(address)",
    "function want() view returns(address)"
  ],provider);
  if (!same(await strategy.vault(),state.beefyVaultAddress)
      || !same(await strategy.yearn(),yearnVault)
      || !same(await strategy.curveLiquidityGuard(),curveGuard)
      || !same(await strategy.want(),SDT)) {
    throw new Error("Recorded strategy differs from requested immutable bindings");
  }

  if (!await deployed(provider,state.beefyVaultAddress)) {
    const nextNonce = await provider.getTransactionCount(signer.address,"pending");
    if (nextNonce !== state.beefyVaultNonce) {
      throw new Error(`Reserved Beefy vault CREATE nonce ${state.beefyVaultNonce} unavailable (pending=${nextNonce}); do not deploy a misbound vault`);
    }
    const beefyArtifact = loadArtifact(c.vaultContract);
    const beefy = await new ethers.ContractFactory(beefyArtifact.abi,beefyArtifact.bytecode,signer)
      .deploy(state.strategyAddress,c.vaultName,c.vaultSymbol,c.withdrawalFeeBps,adminFeeReceiver,
              {nonce:state.beefyVaultNonce});
    const receipt = await success(beefy.deploymentTransaction(),c.confirmations,"Beefy V8 vault deployment");
    if (!same(await beefy.getAddress(),state.beefyVaultAddress)) {
      throw new Error("Beefy V8 vault deployed to an unexpected address");
    }
    state.beefyVaultTx = receipt.hash;
    saveState(statePath,state);
  }
  const beefy = new ethers.Contract(state.beefyVaultAddress,localVaultABI,signer);
  if (!same(await beefy.strategy(),state.strategyAddress) || !same(await beefy.want(),SDT)
      || !same(await beefy.adminFeeReceiver(),adminFeeReceiver)
      || Number(await beefy.withdrawalFeeBps()) !== c.withdrawalFeeBps) {
    throw new Error("Beefy V8 deployed configuration mismatch");
  }
  if (Number(await beefy.depositFeeBps()) !== c.depositFeeBps) {
    if (!same(await beefy.owner(),signer.address)) throw new Error("Only deploying owner can set initial deposit fee");
    await success(await beefy.setDepositFeeBps(c.depositFeeBps),c.confirmations,"Beefy deposit fee");
  }
  if (!same(await beefy.owner(),vaultOwner)) {
    if (!same(await beefy.owner(),signer.address)) throw new Error("Unexpected owner; cannot transfer vault ownership");
    await success(await beefy.transferOwnership(vaultOwner),c.confirmations,"Beefy ownership handoff");
  }
  if (!same(await beefy.owner(),vaultOwner)
      || Number(await beefy.depositFeeBps()) !== c.depositFeeBps) {
    throw new Error("Beefy V8 final on-chain owner or deposit fee mismatch");
  }
  state.status = "deployed-and-configured";
  state.vaultOwner = vaultOwner;
  state.adminFeeReceiver = adminFeeReceiver;
  state.withdrawalFeeBps = c.withdrawalFeeBps;
  state.depositFeeBps = c.depositFeeBps;
  saveState(statePath,state);
  console.log(JSON.stringify({status:state.status,yearnVault,
    strategy:state.strategyAddress,beefyVault:state.beefyVaultAddress,
    vaultOwner,adminFeeReceiver,stateFile:statePath},null,2));
  return state;
}

if (require.main === module) deploySdtYearnBeefy().catch(error=>{
  console.error(error);
  process.exitCode=1;
});
module.exports = { deploySdtYearnBeefy };
