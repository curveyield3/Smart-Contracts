#!/usr/bin/env node
"use strict";

const path = require("path");
const {
  makeContext,
  contract,
  send,
  OWNABLE_CONTRACTS,
  saveState,
  readJson
} = require("../deployment-v20/lib-v20");
const { validateProductionConfigObject } = require("./production-config-v27-v1");
const { verifyProduction } = require("./verify-production-cyvlsdt-v27-v1");

function defaultConfigPath() {
  return path.resolve(__dirname, "..", "config-production-v47.json");
}

async function proposeHandoff(options = {}) {
  const configPath = path.resolve(options.configPath || process.argv[2] || defaultConfigPath());
  const rawConfig = readJson(configPath);
  validateProductionConfigObject(rawConfig);
  const tag = options.tag || process.env.DEPLOYMENT_TAG || "v55-live";

  const ctx = await makeContext({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    confirmations: options.confirmations
  });
  if (ctx.state.phase !== "production-verified") {
    throw new Error(`ownership handoff requires production-verified phase, got ${ctx.state.phase}`);
  }

  await verifyProduction({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag,
    expectedOwner: ctx.wallet.address,
    expectedAdmin: ctx.wallet.address
  });

  const literal = `TRANSFER_TO_${ctx.config.finalOwner}`;
  if (process.env.CONFIRM_FINAL_HANDOFF !== literal) {
    throw new Error(`Set CONFIRM_FINAL_HANDOFF=${literal} to authorize ownership handoff`);
  }

  const revenueStaking = contract(ctx, "revenueStaking");
  if ((await revenueStaking.admin()).toLowerCase() !== ctx.config.finalAdmin.toLowerCase()) {
    await send(ctx, "handoff:revenueStaking.setAdmin", revenueStaking, "setAdmin", [ctx.config.finalAdmin]);
  }

  for (const [key] of OWNABLE_CONTRACTS) {
    const target = contract(ctx, key);
    const owner = (await target.owner()).toLowerCase();
    if (owner === ctx.config.finalOwner.toLowerCase()) continue;
    // Beefy V8 uses OZ4 Ownable (one-step transfer); every other listed contract
    // retains its original two-step owner acceptance route.
    if (key === "revenueVault") {
      await send(ctx, `handoff:${key}.transferOwnership`, target, "transferOwnership", [ctx.config.finalOwner]);
      continue;
    }
    const pendingOwner = (await target.pendingOwner()).toLowerCase();
    if (pendingOwner !== ctx.config.finalOwner.toLowerCase()) {
      const method = key === "poLManager" ? "proposeOwner" : "transferOwnership";
      await send(ctx, `handoff:${key}.${method}`, target, method, [ctx.config.finalOwner]);
    }
  }

  ctx.state.phase = "ownership-proposed";
  saveState(ctx.stateFile, ctx.state);
  console.log(`ownership handoff proposed to ${ctx.config.finalOwner}; final owner must run accept-handoff-cyvlsdt-v27-v1.js`);
  return ctx;
}

if (require.main === module) {
  proposeHandoff().catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { proposeHandoff };
