#!/usr/bin/env node
"use strict";

const path = require("path");
const {
  makeContext,
  deployOne,
  assertExternalDependencies,
  saveState,
  readJson
} = require("../deployment-v20/lib-v20");
const { validateProductionConfigObject } = require("./production-config-v27-v1");
const { DEPLOYABLES } = require("../deployment-v20/lib-v20");
const EXPECTED_KEYS = DEPLOYABLES.map(([key]) => key);

function defaultConfigPath() {
  return path.resolve(__dirname, "..", "config-production-v47.json");
}

async function deploySuite(options = {}) {
  const configPath = path.resolve(options.configPath || process.argv[2] || defaultConfigPath());
  validateProductionConfigObject(readJson(configPath));

  const ctx = await makeContext({
    configPath,
    rpcUrl: options.rpcUrl || process.env.RPC_URL,
    privateKey: options.privateKey || process.env.DEPLOYER_PRIVATE_KEY,
    tag: options.tag || process.env.DEPLOYMENT_TAG || "v55-live",
    confirmations: options.confirmations,
    stateFile: options.stateFile
  });
  const c = ctx.config;
  const deployer = ctx.wallet.address;
  const treasury = c.feeReceivers.treasury;

  if (!["new", "deployed"].includes(ctx.state.phase)) {
    throw new Error(
      `deploy-only script refuses state phase ${ctx.state.phase}; expected new or deployed`
    );
  }

  const feeDistributorRewardTokens = await assertExternalDependencies(ctx.provider, c);
  ctx.state.external = { ...c.stakeDao, feeDistributorRewardTokens };
  saveState(ctx.stateFile, ctx.state);

  const cyvlSdt = await deployOne(ctx, "cyvlSdt", "CurveYieldVlSDTToken", [deployer]);
  const locker = await deployOne(ctx, "locker", "CurveYieldVlSDTLocker", [
    deployer,
    treasury,
    c.stakeDao.sdt,
    c.stakeDao.vlSdt,
    c.stakeDao.vlBoost,
    c.stakeDao.router,
    c.stakeDao.vlSdtFeeDistributorUsdc,
    c.stakeDao.vlSdtFeeDistributorSdt,
    c.stakeDao.boostMarketplace,
    await cyvlSdt.getAddress()
  ]);
  const revenueStaking = await deployOne(ctx, "revenueStaking", "CurveYieldvlSDTStaking", [
    deployer,
    deployer,
    treasury,
    await cyvlSdt.getAddress(),
    c.stakeDao.sdt,
    c.usdc,
    await locker.getAddress(),
    c.stakeDao.vlSdt,
    c.stakeDao.vlSdtFeeDistributorSdt,
    c.stakeDao.vlSdtFeeDistributorUsdc,
    c.omniRouter
  ]);
  const boostMerchant = await deployOne(ctx, "boostMerchant", "CurveYieldVlSDTBoostMerchant", [
    deployer,
    await locker.getAddress(),
    c.stakeDao.boostMarketplace
  ]);
  // Beefy V8 constructor requires strategy.vault() to equal its own address.
  // The strategy must be deployed first with the exact next CREATE address.
  const { ethers } = require("ethers");
  const strategyExisting = ctx.state.contracts.revenueStrategy?.address || c.existingContracts?.revenueStrategy;
  const vaultExisting = ctx.state.contracts.revenueVault?.address || c.existingContracts?.revenueVault;
  const existingStrategyDeployed = !!strategyExisting
    && (await ctx.provider.getCode(strategyExisting)) !== "0x";
  const existingVaultDeployed = !!vaultExisting
    && (await ctx.provider.getCode(vaultExisting)) !== "0x";
  const pendingNonce = await ctx.provider.getTransactionCount(ctx.wallet.address, "pending");
  let predictedVault;
  if (existingVaultDeployed) {
    predictedVault = vaultExisting;
  } else if (existingStrategyDeployed) {
    const boundStrategy = new ethers.Contract(strategyExisting,
      ["function vault() view returns (address)"], ctx.provider);
    predictedVault = await boundStrategy.vault();
    const nextCreate = ethers.getCreateAddress({from: ctx.wallet.address, nonce: pendingNonce});
    if (predictedVault.toLowerCase() !== nextCreate.toLowerCase()) {
      throw new Error(`Revenue strategy already bound to ${predictedVault}; next CREATE would be ${nextCreate}`);
    }
  } else {
    predictedVault = ethers.getCreateAddress({from: ctx.wallet.address, nonce: pendingNonce + 1});
  }
  const revenueStrategy = await deployOne(ctx, "revenueStrategy", "CurveYieldRevenueStrategyV8", [
    deployer,
    predictedVault,
    await cyvlSdt.getAddress(),
    c.stakeDao.sdt,
    await revenueStaking.getAddress(),
    await locker.getAddress(),
    c.omniRouter,
    c.revenueVault.performanceFeeBps,
    c.revenueVault.callFeeBps
  ]);
  const targetVault = await revenueStrategy.vault();
  if (targetVault.toLowerCase() !== predictedVault.toLowerCase()) {
    throw new Error(`Revenue strategy expected vault ${targetVault}; predicted ${predictedVault}`);
  }
  const revenueVault = await deployOne(ctx, "revenueVault", "BeefyVaultCurveYieldV8cyvlSDT", [
    await revenueStrategy.getAddress(),
    c.revenueVault.name,
    c.revenueVault.symbol,
    c.revenueVault.withdrawalFeeBps,
    treasury
  ]);
  if ((await revenueVault.getAddress()).toLowerCase() !== targetVault.toLowerCase()) {
    throw new Error("Revenue Beefy V8 vault address differs from strategy's bound address");
  }

  await deployOne(ctx, "bribeAllocator", "VoteMarketSingleGaugeBribeAllocator", [
    deployer, c.omniRouter, c.bribeAllocator.voteMarket
  ]);

  // Guard V8 and PoL Manager v22 deploy before any Curve pool or NFT exists.
  await deployOne(ctx, "poLLiquidityBounds", "CurvePairOracleBoundsV8", []);
  const p = c.poLManager;
  const zero = "0x0000000000000000000000000000000000000000";
  await deployOne(ctx, "poLManager", "PoLManager", [{
    owner: deployer,
    yearnVaults: p.yearnVaults.map(v => v || zero),
    sdtYearnIndex: p.sdtYearnIndex,
    eulerVaults: p.eulerVaults.map(v => v || zero),
    sdtEulerIndex: p.sdtEulerIndex,
    crv: p.crv,
    cyvlSDT: await cyvlSdt.getAddress(),
    sdt: c.stakeDao.sdt,
    usdc: c.usdc,
    omniRouter: c.omniRouter
  }]);

  const missing = EXPECTED_KEYS.filter(key => !ctx.state.contracts[key]?.address);
  if (missing.length) throw new Error(`core deployment incomplete: ${missing.join(", ")}`);
  ctx.state.phase = "deployed";
  ctx.state.releaseCandidate = "CurveYield-cyvlSDT-v47";
  ctx.state.deploymentPackage = "v47";
  saveState(ctx.stateFile, ctx.state);
  console.log(`V47 deployment complete: ${EXPECTED_KEYS.length} contracts recorded; state=${ctx.stateFile}`);
  return ctx;
}

if (require.main === module) {
  deploySuite().catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { EXPECTED_KEYS, deploySuite };
