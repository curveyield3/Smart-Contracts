# Changelog: v56 to v57

## Requested renaming

- cyvlSDT **Solidity contract** is now `BeefyVaultCurveYieldV8cyvlSDT` in `contracts/BeefyVaultCurveYieldV8cyvlSDT.sol`. This is the v56 queued-withdrawal + live staking-fee implementation with only its contract identifier changed.
- Its ERC-20 name is `Compounding CurveYield vlSDT`, symbol `cyvlSDTcv`, configured in both production and mainnet JSON.
- Core deployment and artifact/ownership lookup select `BeefyVaultCurveYieldV8cyvlSDT` for `revenueVault`.
- `BeefyVaultCurveYieldV8` in `contracts/BeefyVaultCurveYieldV8.sol` is restored **byte-for-byte from v55** for the independent SDT/Yearn deployments; their contracts/configs are unchanged.
- No changes to `CurveYieldRevenueStrategyV8.sol`, `StrategyCurveSDTYearnV9.sol`, or `StrategyCurveSDTYearnRebindable.sol`.

## Compatibility

- Both Beefy vaults still use the same `IStrategyBoostHubV1` strategy interface, share-mint/burn functions, and constructor argument types.
- Solidity contract names affect which compilation artifacts deployment scripts load, not the ERC-20 `name()` and `symbol()` stored from constructor inputs.
- Existing deployed contract names/metadata cannot be changed by changing this source package.

## Verification

- Source equality/integrity checks, ZIP integrity, JSON validity and JavaScript parsing performed for the updated deployment script.
- No Solidity compilation, testing, simulation or deployment performed.
