# cyvlSDT v45 — vlSDT-backed two-step emergency redemption

- Replaced the v44 owner-prefunded SDT redemption reserve with a genuine vlSDT unstake: `requestEmergencyWithdrawal(shares)` pulls and burns cyvlSDT, adjusts gross principal, and calls Stake DAO `VLSDT.unstake(shares)`.
- The Stake DAO native unstake request ID identifies the user's minimal Locker accounting record (requester, shares, snapshotted early-rate). No second request-ID counter, no separate cooldown/penalty engine.
- `completeEmergencyWithdrawal(id,receiver,false)` uses native `VLSDT.withdraw` after the protocol cooldown, transfers its full 1:1 SDT principal directly to the user, and pays NO Stake DAO penalty.
- `completeEmergencyWithdrawal(id,receiver,true)` uses native `VLSDT.withdrawEarly`, pays the fixed snapshotted early rate, reverting if the native net proceeds would be insufficient. Early-withdrawn surplus, if any, is ordinary SDT revenue and can be swept via the existing generic revenue path.
- Configurable `redemptionRateWad` controls only early exits, defaults to 0.75e18 in line with Stake DAO's current maximum 25% penalty; cap at 1e18. Any updates only affect new requests.
- Restored owner-only irreversible `disableEmergencyWithdrawForever()`; this disables all new requests while allowing outstanding burned-share claims to settle (otherwise user principal would be stranded).
- Removed owner-funded redemption-liquidity state, dedicated funding method, its reserve subtraction, and the v44 single-step `redeem` method.
- Added the missing `withdrawEarly` interface method to `IVlSDT`; no changes to Stake DAO's external contracts.
- Potential blocker for individual exits: active vlBoost delegated-out balance reduces Stake DAO's underlying usable unstakable vlSDT; request fails atomically if unavailable.
- No tests or simulations were performed.
