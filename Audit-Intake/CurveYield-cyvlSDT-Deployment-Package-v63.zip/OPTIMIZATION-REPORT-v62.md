# cyvlSDT optimization report — v62

**Baseline:** v61, source package `CurveYield-cyvlSDT-Deployment-Package-v61.zip`.  
**Candidate:** v62, merchant + cyvlSDT-specific revenue vault + revenue strategy only.  
**Compiler configuration:** Hardhat, solc 0.8.28 for merchant/strategy and selected 0.8.28/0.8.30 for vault per project settings; viaIR=true, optimizer runs=200, evmVersion=cancun. Precise artifact compiler version remains unconfirmed without a build.  
**No tests, fork simulations or deployment performed.**

## Implemented merchant (M1-M4)

- M1: standing unlimited USDC allowance for Locker established in constructor. `setLocker()` revokes prior spender allowance and grants maximum to new spender. Removed per-lease approval/reset.
- M2: one marketplace offer snapshot per acceptance attempt; no nested repeated `getOffer` calls.
- M3: `executeBestRoute` performs one capacity check for all three branches; standalone direct entrypoints still independently validate boost limits.
- M4: reuse marketplace fee and minimum Aladdin price in an offer's profitability and fill-threshold checks, retaining the independent premium rule for the configured minimum rate and the original Aladdin fail-closed semantics.

## Implemented revenue vault (V1-V6)

- V1: single live staking fee read for exact-net `previewWithdraw()` gross rounding loop.
- V2: cache share supply for deposit and withdrawal calculations, retaining post-investment NAV measurement.
- V3: reuse already-read idle balance and share supply in queued withdrawal requests.
- V4: keep APY's 12-hour best-effort self-call and gas budget; cache checkpoint eligibility without changing public APY interfaces.
- V5: share exact fee-distribution helper across queued and ordinary exits (same constructor fee, same retained live fee, same rounding).
- V6: pass already-read post-fee idle balance to `_earn()` instead of reading balance again; retain actual post-strategy NAV calculation and deposit protection.
- V7 was **evaluated but not applied**. Custom errors would change observable revert payloads. No compiler bytecode measurement justified breaking existing integration compatibility in this release. All existing revert strings preserved.

## Implemented revenue strategy (S1-S7)

- S1: unlimited approvals for WANT to revenue staking, SDT to locker, USDC to OmniRouter; rotate prior approvals on all relevant owner rebindings including WANT replacement. No harvest/deposit recurring approval writes.
- S2: collect guarded USDC conversion result and all directly held SDT into one `_depositHeldSDT()` per harvest, rather than several deposits.
- S3: locally calculate the same floor-rounded live instant-withdraw capacity using one backend fee lookup; preserve gross-up and maximum-active checks.
- S4: avoid `reservedWithdrawalAssets` SSTORE when zero idle is reserved/released.
- S5: cache bounded reward-token count and avoid unnecessary conversion calls for unknown rewards.
- S6: single USDC conversion helper and one SDT deposit helper, replacing redundant token-dispatch logic.
- S7: unify `completeWithdrawal` and `withdrawPendingInstant` into one internal settlement path without removing direct-call guards, backend request ids, distinct events or readiness check.

## Constraints and risks

- Unlimited approvals expose the approved spenders to indefinite allowances; owner replacements revoke the old authorization before granting the new.
- The strategy's existing ability to rebind staking while old queued requests remain unresolved can strand those requests; this prior architecture issue is not changed by gas work and should be separately resolved before migration.
- The vault's existing net NAV versus gross queued-withdrawal price difference is **not** changed by gas work; the economic design remains unverified here and should not be assumed production-safe solely based on compilation.
- No externally callable function signatures were changed according to static source comparisons. No public events or storage declarations intentionally changed. All unaffected Solidity files are byte-identical to v61.
- Source changes are implemented, but gas savings, runtime deployed bytes, bytecode headroom, deployment gas, and full semantic equivalence are **UNKNOWN** without a real v61/v62 compiler build and permitted comparable EVM traces. Do not interpret this as a deployment-ready security signoff.

## Source bytes (UTF-8 file size, *not* runtime code size)

| Solidity contract | v61 bytes | v62 bytes | Difference (v62-v61) |
|---|---:|---:|---:|
| `contracts/BeefyVaultCurveYieldV8cyvlSDT.sol` | 32,899 | 33,414 | +515 |
| `contracts/CurveYieldRevenueStrategyV8.sol` | 17,163 | 18,120 | +957 |
| `contracts/CurveYieldVlSDTBoostMerchant.sol` | 19,485 | 20,943 | +1,458 |

**Changed Solidity files:** 3/ 17.  **JS syntax checks:** 11 deployment JS files plus Hardhat config.  **ZIP:** verified on assembly.
