# CurveYield cyvlSDT v35

Source and deployment scripts for the six-contract CurveYield cyvlSDT system. The v35 changes are recorded in `CHANGELOG-v34-to-v35.md`.

Revenue model: Each token's normal vlSDT base benchmark uses the last fully checkpointed Stake DAO reward epoch at first income receipt of a given Thursday-to-Thursday accounting week. Cumulative SDT and USDC receipts per week allocate base first, then marginal 75/20/5 and 60/30/10 excess tiers. Base SDT and USDC rewards stream independently, with a fresh seven-day stream per notification. Staker excess conversions each launch their own cyvlSDT seven-day stream. DAO vlBoost reserve is 10%.

Workflow: `npm ci`, `npm run compile:v35`, `npm run config:materialize:v35`, then the existing deploy/configure/verify/handoff scripts. Never deploy without successful compilation and contract-read readiness checks. The future three-token StableSwap is an optional post-deployment configuration. OmniRouter USDC→SDT is required for **excess USDC conversion**, not for deployment or collection of USDC revenue.

No tests were added or executed. The compile step was not successful in the local runtime because the package installation is incomplete.
