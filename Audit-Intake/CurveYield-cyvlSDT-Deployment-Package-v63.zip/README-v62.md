# CurveYield cyvlSDT Deployment Package — v62

Based **only** on approved v61. Exactly three Solidity contracts changed: `CurveYieldVlSDTBoostMerchant.sol`, `BeefyVaultCurveYieldV8cyvlSDT.sol`, `CurveYieldRevenueStrategyV8.sol`. The standard/Yearn Beefy vault and both SDT/Yearn strategy contracts are unchanged. Locker minting and staking improvements from v60/v61 are preserved.

Requested gas-first updates: Merchant M1-M4, cyvlSDT revenue vault V1-V6 (V7 evaluated and held for revert-data compatibility), and revenue strategy S1-S7. See `OPTIMIZATION-REPORT-v62.md` for detailed scope, caveats, and `SOURCE-DIFF-v61-to-v62.patch` for exact changes.

**No Solidity compilation, EVM gas trace, tests, simulation or live deployment verified for v62.** Do not use this source package as a security-certified production release.
