# CurveYield cyvlSDT Source + Deployment Package — v40

Version **40**. Based on v39 PoL Manager v9 compatibility and v38 allocator. Source-only, not compiled, tested, simulated, or deployed.

## PoL deposit flow

A user deposits SDT once. The Locker immediately sends the configured 0–15% PoL share to the PoL Manager and attempts `allocateFunds(SDT, share)` using `try/catch`. A failed **investment** leaves the PoL funds idle at the Manager; the user's remaining SDT is still used to obtain/mint cyvlSDT. `PoLAllocationDeferred` identifies failures for later optional recovery. There is **no second normal-deposit transaction**.

PoL principal stays in PoL custody and cannot be included in the Locker's `forwardMarketplaceRevenue(SDT)` sweep. Performance fees, separately sent by PoL to the Locker as SDT, remain sweepable and follow the existing bribe share and staking tiers. Do not mistakenly sweep before completing a user deposit; the Locker's `nonReentrant` deposit prevents such reentry.

Configure PoL Manager v9 with the deployed Locker as an authorized operator and its `profitRecipient` (as detailed in `README-v39.md`). If allocation reverts, an authorized operator can use PoL v9 `allocateFunds` or the Locker's existing owner-only `allocatePoLFunds` to invest accumulated idle balances; this exception path is not needed on normal deposits. PoL v9 is included unchanged.

`config-mainnet-v40.json` and `config-production-v40.json` provide the existing Ethereum deployment placeholders. They do not invent a PoL deployment address or parameters. See `CHANGELOG-v39-to-v40.md` for details, earlier changelogs for the original architecture.

**No Solidity compilation, tests or deployments performed.**
