# PoL Manager v20 — One-Time Binding + Timelocked Emergency Migration

PoL Manager v20 retains v19 one-time position binding and adds a 90-day timelocked emergency migration. The **Curve pool, LP, gauge, Uniswap position manager and NFT ID are no longer constructor fields**. The Manager can deploy before any of them exists. The independent, unchanged `CurvePairOracleBoundsV6` guard continues handling all liquidity slippage checks; OmniRouter remains responsible for swaps.

## Constructor

`PoLManager(DeployConfig c)` requires only `owner`, `sdt`, `usdc`, `crv`, `cyvlSDT`, `omniRouter`, `yearnVaults[3]`, `eulerVaults[2]`, and `sdtYearnIndex` / `sdtEulerIndex`. Zero-address vaults are allowed and may be added later with the existing `setVault` function. The manager does not take a Curve pool, LP, Curve gauge, NFT manager, or token ID during deployment.

## One-time owner configuration

| Function | When to call | Permanent binding |
|---|---|---|
| `configureCurvePool(pool, lp)` | Once the 3-coin Curve pool and its LP token exist | `curvePool`, `curveLp`; must have SDT coin 0, cyvlSDT coin 1, and a distinct nonzero third coin |
| `configureCurveGauge(gauge)` | Whenever a real gauge exists **after** the pool has been bound | `curveGauge` |
| `configureUniswapPosition(positionManager, tokenId)` | Once the specific SDT/cyvlSDT NFT exists, **before** transferring it to PoL Manager | `uniNftManager`, `uniTokenId`, underlying token pair |

All three functions are **owner-only** and **one-time**: a second configuration is rejected. The position manager and NFT do not have to exist when the contract deploys. Curve and Uniswap can be configured in either order. The Curve gauge is optional and can be attached independently after the Curve pool.

After configuring the NFT position, transfer **only that NFT** with `safeTransferFrom` to PoL Manager. Its original `onERC721Received` restrictions still reject any other NFT. The NFT's original token-owed accounting remains in place. Its harvest remains manually opt-in via `setModuleEnabled(1, false, true)` after transfer. There is no automatic Uniswap allocation adapter.

`setLiquidityBounds(v6Guard)` and `setCurveSlippageBps(bps)` remain existing owner-settable operations; the guard itself deploys without the pool/NFT. Missing Curve/NFT positions remain disabled; direct vault operations remain available. Without configured guard, guarded liquidity operations revert.

The core deployer wires PoL Manager's `profitRecipient` to the Locker and the Locker's PoL deposit recipient to the **deployed** PoL Manager address, independently of the later pool/NFT binding. Setting `poLDeposit.shareBps` above zero is permitted after Manager deployment. The Locker simply transfers the designated SDT to the Manager; your keeper (authorized by `PoLManager.setOperator(keeper, true)`) later calls `allocateFunds(SDT, amount)`.

## Production configuration (v47)

In `config-production-v47.json`, `poLManager.curvePool`, `curveLp`, `curveGauge`, `uniNftManager`, and `uniTokenId` all start `null`. When these become available, set both `curvePool` and `curveLp` together, optionally the gauge, and set `uniNftManager` and `uniTokenId` together. Re-run the existing `configure:v47` entry point **while the signer is the owner**; it calls the same one-time setters and validates existing bindings rather than overwriting them. Alternatively, after transferring ownership to the Safe, call the corresponding setters once from the Safe. The configuration's optional position addresses do not block initial deployment or core verification.

## Preserved v18 features

Seven position slots (Curve, NFT, three Yearn, two Euler); independent position allocation and harvesting; five configurable SDT/cyvlSDT buy-rate thresholds and budgets; CRV compounding; owner-configured fees; no internal OmniRouter swap guards. The separate guard v6 is unchanged (300-second Uni TWAP, 2% Uni slippage, owner-configurable Curve bound). The original v18 source and its previously reported compilation measurement do **not** constitute verification of the modified v19 bytecode. No Solidity compilation, tests, fork simulation or deployment was performed for this revision.


## v20 emergency migration (v48 package)

`withdrawUniNFT(address)` has been REMOVED from the public ABI. An internal `_withdrawUniNFT(address)` is reachable **only** from `executeEmergencyMigration`, and transfers the configured NFT only when the Manager is its current owner.

1. `startEmergencyMigration(recipient, expiresAt)` (owner-only) schedules a new migration. The recipient is fixed permanently for this request. `expiresAt` must be strictly later than `block.timestamp + 90 days`. Exactly one pending migration may exist. No token list is specified at this stage.
2. After `emergencyMigrationRequest.executableAt` and no later than `.expiresAt`, the owner calls `executeEmergencyMigration(address[] tokens)`. The complete raw ERC-20 balance of each specified address is transferred to the recipient **without** _free() or vault/LP exclusions; then the fixed Uniswap v3 NFT, if owned, is transferred automatically. The array has no length cap or token whitelist; practical transaction gas still applies. A nonempty array is required unless a bound NFT is actually transferred.
3. Execution is atomic. If any requested ERC-20 transfer or the NFT transfer fails, the transaction reverts and the pending request, asset balances, and NFT remain unchanged. The owner can retry with a corrected token array until expiration; success deletes the request. Duplicate token addresses are harmless (the later pass sees zero balance).
4. `cancelEmergencyMigration()` can be called by the owner or guardian while pending, activated, or expired, before a successful execution. Cancellation clears the request; a new one requires a fresh 90-day delay. The guardian cannot initiate or execute.
5. No new ERC-20 rescue authority is added to `rescueToken()`; the separate normal rescue remains unchanged. Vault-share emergency transfers clear the affected slot's accruedFeeShares and highWatermarkPPS because its claim has left Manager custody. NFT transfers clear the initial and pending Uni fee-reserve counters.

**Limitations:** This operation only moves tokens and NFTs already in PoL Manager custody. It cannot unstake assets trapped in a broken external gauge or force paused ERC-4626 vaults to redeem. `expiresAt` is chosen by the owner rather than a preset duration. All attempted ERC-20 tokens must expose standard `balanceOf` and `transfer` behavior; noncompliant tokens can be removed from a retry list. After successful one-shot execution, further evacuations need a new request and a new 90-day delay.
