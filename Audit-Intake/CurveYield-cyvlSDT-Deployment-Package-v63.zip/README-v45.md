# cyvlSDT v45 Source Package

Current release. See earlier READMEs and `CHANGELOG-v44-to-v45.md` for evolution.

## Emergency exit — actual vlSDT unwind

1. User approves cyvlSDT for Locker and calls `requestEmergencyWithdrawal(shares)`. Locker burns the shares and calls `VLSDT.unstake(shares)`, returning the real Stake DAO request ID (which is also the key for `emergencyWithdrawals(id)`). Requires sufficient unstakable, undelegated vlSDT at that moment.
2. After Stake DAO's configured unstake delay (56 days on Ethereum at the time of verification), user calls `completeEmergencyWithdrawal(id,recipient,false)` for **full 1:1 SDT without early penalty**. This sends the SDT directly from Stake DAO to the recipient.
3. Alternatively before expiry, user can call `completeEmergencyWithdrawal(id,recipient,true)` to pay the Stake DAO native time-decaying early penalty and receive the locked fixed-rate SDT amount. The rate is snapshotted at request, defaults to 0.75e18, configurable for future requests from 0 to 1e18. A native penalty increase or early-exit pause can cause the early path to revert; the delayed path remains available.

The owner's `disableEmergencyWithdrawForever()` irreversibly prevents *new requests*. Already-created requests can still complete to avoid confiscating already-burned users' cyvlSDT. No prefunded SDT reserve or parallel accounting engine remains. Extra SDT left after early payout enters the existing generic staking-revenue sweep; no Locker-side split logic is added.

Compiler target: solc 0.8.28, optimizer 200, viaIR, Cancun, OpenZeppelin 5.4.0.
