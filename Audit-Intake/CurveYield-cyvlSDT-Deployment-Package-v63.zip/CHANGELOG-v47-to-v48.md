# v47 to v48

- PoL Manager v20 adds `startEmergencyMigration`, `cancelEmergencyMigration`, and `executeEmergencyMigration` with a fixed 90-day wait and caller-set expiry.
- Recipient fixed during queue, never taken as an execution parameter. No token whitelist or array size limit; full balances transferred.
- Guardian can cancel but cannot start/execute. Cancellable before unlock, after unlock, and after expiration. Atomic reverts preserve the queued request for retry.
- Bound Uniswap NFT transferred by private `_withdrawUniNFT` only during successful emergency migration; standalone public `withdrawUniNFT` removed.
- Migrated vault share positions clear old fee-share reservations and high-watermark checkpoints. Existing normal `rescueToken` unchanged.
- Deployment mappings, compiler override and config PoL source version updated to v20.
