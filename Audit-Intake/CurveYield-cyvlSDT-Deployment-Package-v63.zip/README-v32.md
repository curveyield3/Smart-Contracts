# CurveYield cyvlSDT v32 — Aladdin vlSDT delegation and shared donation-based compounding

This is the **v31 cyGOV-free source package**, upgraded in v32 to allow the `CurveYieldVlSDTLocker` (the contract that actually holds vlSDT) to delegate some of its existing DAO boost allocation to the Aladdin vlSDT delegation proxy, claim its SDT yield, and stake those rewards using the **same internal routine as the existing `donateSDT` path**. No cyvlSDT shares are issued for compounded rewards.

## Scope and invariant

- **Nine deployable Solidity contracts**, unchanged from v31. No new deployable contracts, routers or staking vaults.
- Existing v31 deletion of cyGOV contracts, converters, Governance Staking and ChildGauge remains intact.
- `donateSDT` and Aladdin claim both use `_donateSDTHeld(amount, donor)`: grant exact SDT allowance to vlSDT, stake SDT for `address(this)`, revoke allowance, verify one-to-one vlSDT receipt, increment `totalDonatedSDT`, emit `SDTDonated`.
- **No call to `CYVLSDT.mint`** in the reward claim route. Only ordinary `deposit` mints new shares.
- The existing `claimVlSDTRewards` continues forwarding the Stake DAO fee-distributor rewards to Revenue Staking; that is separate and unchanged.
- Rewards are compounded using actual SDT balance delta from Aladdin's claim. Zero-amount weekly claims are permitted and return zero.

## External integration constants — Ethereum mainnet

- Aladdin `VlSDTDelegation` proxy: `0x322c76e1205dE5ee4146e40644563B482B1CDA43` (call target, **not** the implementation address)
- vlBoost: `0xaB05ca46d1c78CAbB051efFE35099714Cad2AddA` (already an existing Locker constructor argument)
- SDT: `0x73968b9a57c6E53d41345FD57a6E6ae27d6CDB2F` (already an existing Locker constructor argument)
- Aladdin stakeDAO locker proxy receives the underlying boost **internally**; the Locker itself is the reward-share beneficiary and payout address.

## Operational sequence — after v32 deployment and configuration

1. The **Locker owner**, once, calls `locker.setAladdinDelegationOperator(true)`. This causes **the Locker itself** to authorize the fixed Aladdin proxy through vlBoost `setOperator`. This is deliberately an explicit owner action; production configuration does not silently grant delegation authority.
2. Read `locker.daoDelegableBoost()` and vlBoost `delegableBalance(lockerAddress)` for the eligible amount. Do not assume a positive amount simply because the Locker holds vlSDT. The DAO boost allocation is 20% of vlSDT less preexisting DAO commitments and releases.
3. The Locker owner calls `locker.delegateAladdinBoost(amount, endtime)`. `endtime` is floored to the UNIX weekly boundary before validation and DAO commitment recording; Aladdin applies the same rounding. The Locker is both the vlBoost delegator and the Aladdin reward-share beneficiary. Delegation does **not** move vlSDT principal.
4. Once previously completed weekly epochs can be claimed, any keeper calls `locker.claimAladdinRewardsAndCompound()`. Aladdin transfers SDT directly to the Locker, and the Locker passes those new SDT units through the existing donation stake routine. No extra cyvlSDT shares are minted.
5. For each delegation, after its normalized endtime, call the **existing** `releaseDaoBoostCommitment(commitmentId)` to release its accounting reservation. There is no duplicate release queue or new boost allocation system.

The two owner calls are **not automatically executed** by the deployment scripts. Production deployments must consider Aladdin proxy/operator trust and the existing DAO boost capacity. The boost expiry cannot exceed the existing Locker `MAX_BOOST_DURATION_WEEKS` policy.

## Source and deployment commands

Node.js, npm and Ethereum RPC are needed; npm dependencies are pinned by `package-lock.json` but not vendored:

```bash
npm ci
npm run compile:v32
npm run config:materialize:v32
# Manually review config-production-v32.json and external dependencies
export RPC_URL='https://<YOUR_ETHEREUM_RPC>'
export DEPLOYER_PRIVATE_KEY='<DEPLOYER_KEY>'
npm run deploy:v32
npm run configure:v32
npm run verify:v32
```

For owner handoff, the inherited commands are `handoff:propose:v32` and `handoff:accept:v32` and require the existing explicit approval procedure.

**No live transactions or tests were run while building v32. Solidity compilation was unavailable locally** because `solc`, Hardhat and OpenZeppelin dependencies were not installed and network package retrieval was not available. The package is a reviewable source deliverable, not a compiled/deployed attestation.

See `CHANGELOG-v31-to-v32.md`, `SOURCE-DIFF-v31-to-v32.patch`, `Source-Manifest-v32.sha256`, `PACKAGE-SHA256SUMS-v32.txt` and inherited v31 history in the upstream package.
