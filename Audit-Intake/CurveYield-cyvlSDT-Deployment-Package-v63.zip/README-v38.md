# CurveYield cyvlSDT Source + Deployment Package — v38

Version **38**. Baseline: v37. Ethereum mainnet source package; not compiled, tested, or deployed.

## Integrated Ethereum VoteMarket Bribe Allocator

`VoteMarketSingleGaugeBribeAllocator.sol` replaces the Arbitrum V2 standalone v3 allocator. It is a seventh deployable source contract alongside v37's six contracts. The v38 deployment scripts deploy it and set the Locker's `lpBribeContract` to that newly deployed address (even if `lpBribeRevenueShareBps == 0`). The Locker's existing revenue-share mechanics and all other v37 Solidity logic are unchanged.

- **One gauge, one upgradeable Ethereum VoteMarket bounty.** Uses Ethereum VoteMarket `createBounty` (two periods), `increaseBountyDuration` (+1 period, +new USDC), `updateBountyPeriod`, and `closeBounty`. Unclaimed USDC is returned directly to the allocator as bounty manager; no V2 `LeftoverDistributorHook` or cross-chain bridge.
- **Price:** read existing CurveYield OmniRouter `price_oracle(CRV, USDC)`. The returned gross historical route price means *whole USDC per whole CRV, scaled to 1e18*. No Chainlink contract, standalone oracle, price-feed reporter, or fallback.
- **CRV emission economics:** read CRV token `rate()` in CRV wei/second, Curve GaugeController's current `gauge_relative_weight_write(gauge, epoch)` and `points_weight(gauge, epoch).bias`. No separate forecast publishing or ROI approval. The cap is submitted to VoteMarket's native `maxRewardPerVote` and enforced there.
- **Target return:** owner-configurable `minimumReturnWad`, default `1.25e18` (1.25×); price per vote is *divided* by this multiple. Single gauge has no blacklists, so eligible weight matches the gauge bias directly.
- **Swap:** direct SDT/USDC receipts need no deposit function. SDT is converted into USDC through existing OmniRouter `guardedMinOut` plus `swapExactInput`. USDC revenue is spent on the campaign without a separate per-epoch funding cap. `processEpoch()` converts SDT if its swap route exists, then funds once per current epoch; `convertSDT()` and `fundEpoch()` can also be called separately. Each new funding epoch adds the available USDC to the same bounty as one extra period.
- **Close/refund:** any caller can call `closeExpiredBounty()` when the bounty expires. Native VoteMarket refunds to manager; closing syncs correctly even if someone called VoteMarket's public `closeBounty()` first. Changing gauge requires the previous bounty to be closed.
- **Owner controls:** `setGauge`, `setMinimumReturnWad`, `setPaused`, two-step ownership transfer, and paused-only `recoverToken`. No duplicated multi-chain market manager, emission quotes, hook administration, token rotation, source token registry, swap oracle adapters, parallel campaign records, independent campaign settlement, or additional ROI guard.

### Price cap units

```text
epoch = VoteMarket.getCurrentPeriod() // current Thursday epoch
weekly_gauge_CRV_wei = CRV.rate() * 604800 * gaugeRelativeWeight / 1e18
weekly_gauge_USDC_raw = weekly_gauge_CRV_wei * OmniRouter.price_oracle(CRV,USDC) / 1e30
break_even_per_vote = weekly_gauge_USDC_raw * 1e18 / eligibleGaugeBias
maxRewardPerVote = break_even_per_vote * 1e18 / minimumReturnWad
```

`maxRewardPerVote` is measured in raw 6-decimal USDC per whole 18-decimal veCRV vote in the native VoteMarket fixed-point convention. Gauge weight/voting bias and emissions use the **currently observable** epoch to estimate the next epoch; future votes, relative weights, inflation, or prices may change. This mechanism imposes an on-chain bribe price cap; it is not a guarantee of realized CRV emissions, acquired votes, or ROI.

## Integration and outstanding operations

- `config-mainnet-v38.json` / `config-production-v38.json` specify the verified Ethereum Curve VoteMarket (`0x0000000895cB182E6f983eb4D8b4E0Aa0B31Ae4c`), `gauge: null` (not provided yet), and `minimumReturnWad: "1250000000000000000"`.
- The owner must select the real gauge address before funding; update `bribeAllocator.gauge` in deployment config or call `setGauge()` after deployment. No gauge address has been invented.
- The existing mainnet OmniRouter (`0xa4a533025fef8d3446e7cb8a434824e1ee865b00`) must have a **CRV→USDC route configured** for the price calculation. Live inspection showed `routeLength(CRV, USDC) == 0` at review time. Its **SDT→USDC route** was also absent; that route is required for converting incoming SDT. Route configuration belongs to the already-deployed OmniRouter and has NOT been fabricated or changed by this package.
- `lockerRevenueDiversions.lpBribeRevenue.shareBps` remains independently configurable from 0 to 1500; its config `recipient` remains null because the scripts resolve it to the deployed `bribeAllocator` automatically. Default share stays **0** until explicitly chosen. `poLDeposit` configuration remains independent.
- The historical v37 `revenueStakingConfig.excessTier1/2` metadata was corrected in v38 configs to reflect **75/15/5/5** and **60/20/10/10**; no changes were made to Staking source.
- Use existing v38-named scripts (`npm run deploy:v38`, `configure:v38`, etc.) *only after separately compiling and approving deployment*. We have **not executed** them.

## Verification boundary

Static source/package review only. Solidity has **not** been compiled, tested, simulated, or deployed. The new v38 deployment script and source have not been execution-verified. Prior v37 code is retained unchanged outside the OmniRouter interface, deployment scripts, and configuration.
