# v61 → v62 — Merchant, revenue vault and strategy optimizations

- M1: standing unlimited USDC allowance for Locker established in constructor. `setLocker()` revokes prior spender allowance and grants maximum to new spender. Removed per-lease approval/reset.
- M2: one marketplace offer snapshot per acceptance attempt; no nested repeated `getOffer` calls.
- M3: `executeBestRoute` performs one capacity check for all three branches; standalone direct entrypoints still independently validate boost limits.
- M4: reuse marketplace fee and minimum Aladdin price in an offer's profitability and fill-threshold checks, retaining the independent premium rule for the configured minimum rate and the original Aladdin fail-closed semantics.

## Implemented revenue vault (V1-V6)

- V1: single live staking fee read for exact-net `previewWithdraw()` gross rounding loop.
- V2: cache share supply for deposit and withdrawal calculations, retaining post-investment NAV measurement.
- V3: reuse already-read idle balance and share supply in queued withdrawal requests.
- V4: keep APY's 12-hour best-effort self-call and gas budget; cache checkpoint eligibility without changing public APY interfaces.
- V5: share exact fee-distribution helper across queued and ordinary exits (same constructor fee, same retained live fee, same rounding).
- V6: pass already-read post-fee idle balance to `_earn()` instead of reading balance again; retain actual post-strategy NAV calculation and deposit protection.
- V7 was **evaluated but not applied**. Custom errors would change observable revert payloads. No compiler bytecode measurement justified breaking existing integration compatibility in this release. All existing revert strings preserved.

## Implemented revenue strategy (S1-S7)

- S1: unlimited approvals for WANT to revenue staking, SDT to locker, USDC to OmniRouter; rotate prior approvals on all relevant owner rebindings including WANT replacement. No harvest/deposit recurring approval writes.
- S2: collect guarded USDC conversion result and all directly held SDT into one `_depositHeldSDT()` per harvest, rather than several deposits.
- S3: locally calculate the same floor-rounded live instant-withdraw capacity using one backend fee lookup; preserve gross-up and maximum-active checks.
- S4: avoid `reservedWithdrawalAssets` SSTORE when zero idle is reserved/released.
- S5: cache bounded reward-token count and avoid unnecessary conversion calls for unknown rewards.
- S6: single USDC conversion helper and one SDT deposit helper, replacing redundant token-dispatch logic.
- S7: unify `completeWithdrawal` and `withdrawPendingInstant` into one internal settlement path without removing direct-call guards, backend request ids, distinct events or readiness check.

