# CurveYield cyvlSDT — v41 to v42

## Increased SDT deposit PoL diversion ceiling

- Change only the Locker PoL deposit maximum from `1_500` to `2_500` basis points (**15% → 25%**). `poLDepositShareBps` remains owner-configurable from 0 through the maximum, with the configured default kept at zero.
- Update production configuration validation to accept `poLDeposit.shareBps <= 2500` and retain the separate `lpBribeRevenue` maximum of `1500`.
- Add a deployment verification assertion of the on-chain PoL deposit cap.
- Preserve all other operating parameters: current `deposit()` still transfers SDT to the PoL Manager, does not automatically call `allocateFunds()`, and leaves subsequent investment to an authorized keeper. Existing PoL fees, DAO/admin revenue split, and PoL Manager v9 limits are unchanged.
- Bump version, deployment paths, README, and source manifest to v42.

No Solidity compilation, tests, simulations, or deployments performed.
