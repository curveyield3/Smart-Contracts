# CurveYield cyvlSDT Source + Deployment Package — v39

Version **39**. Baseline: v38. Mainnet source package, not compiled, tested, simulated, or deployed.

## PoL Manager v9 integration

The existing cyvlSDT Locker `setPoLDepositShare` sends up to 15% of user SDT deposits to the configured PoL contract **without staking those tokens into vlSDT**. v39 includes the uploaded `PoL_Manager_Contract_v9.sol` unchanged and adds the minimal owner-only Locker method `allocatePoLFunds(address token,uint256 amount)` that calls **`PoLManager.allocateFunds(address,uint256)`** to invest idle SDT/USDC. The PoL Manager's own `setAllocations` and `setModuleEnabled` control investments. This function is deliberately separate from user deposits to prevent allocation gas or temporarily unavailable positions from blocking minting.

When PoL Manager harvests, it converts its performance fees to **SDT** and transfers them to the configured `profitRecipient`. Set that recipient to the Locker. The existing `Locker.forwardMarketplaceRevenue(SDT)` function then forwards idle SDT through the existing LP-bribe share and Staking reward classification; it needs a separate transaction because ordinary ERC-20 transfers have no callback. PoL tier allocations from Staking (SDT and USDC) also go to the configured PoL Manager.

The PoL Manager contract itself is not deployed by the generic cyvlSDT deploy script because its deployment requires real pool/NFT/gauge/vault constructor settings that have not been provided. The **existing** `lockerRevenueDiversions.poLDeposit.recipient` config is the single PoL Manager address. The existing post-deployment script configures PoL `setOperator(locker,true)` and `setProfitRecipient(locker)` if the active deployer owns PoL; a different owner/Safe must do this independently. The verification script checks the actual PoL SDT, USDC, OmniRouter, operator and profit-recipient settings whenever a recipient is configured.

Read `CHANGELOG-v38-to-v39.md` for the complete integration procedure, gas/availability separation and operational prerequisites. Earlier architecture and change logs remain included. No Ethereum PoL contract address was fabricated; initially recipient is null and the diversion percentage is zero.

## Tooling boundaries

The package carries `v39` configs, metadata, the existing core deployment/configuration/verification/handoff scripts, and a source manifest. It does not add a PoL deployment pipeline, a new fee queue, or any tests. No Solidity compilation or simulation was performed.
