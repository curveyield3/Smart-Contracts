# CurveYield cyvlSDT — deployment package v60

This replaces v59 and removes **only the locker emergency withdrawal system**. The v59 1:1 gross minting and direct SDT allocation to PoL are preserved. Other contracts and user staking/Beefy queued-withdrawal behavior remain untouched.

The locker no longer contains a cyvlSDT redemption/unstake path. The cyvlSDT token no longer exposes the locker-only burn endpoint. This is a breaking ABI change and should only be adopted for a fresh deployment or after resolving all outstanding legacy emergency withdrawal claims.

See `CHANGELOG-v59-to-v60.md` and `SOURCE-DIFF-v59-to-v60.patch`. Historic READMEs in this package describe previous versions; use v60 documents for current behavior. Compilation, gas savings and EVM validation are not claimed.
