# CurveYield cyvlSDT Source + Deployment Package — v41

Source-only update to v40: no PoL investment call on user deposits.

## SDT deposit and PoL custody

The Locker transfers the configured 0–15% PoL share in SDT directly to the configured PoL Manager, then processes only the remaining SDT for cyvlSDT minting/optional swap. Deposits **do not call** the PoL Manager's `allocateFunds()`. This avoids unnecessary gas and avoids blocking deposits due to failed PoL investment operations. The PoL share transfer itself must succeed.

Once deposited, SDT belongs to the PoL Manager and is outside any Locker sweep. An external keeper may later call `PoLManager.allocateFunds(SDT, amount)` for any amount up to the Manager's available free SDT balance. This may aggregate receipts from multiple user deposits. The PoL Manager owner must authorize the keeper using `setOperator(keeper, true)`. Allocation remains subject to the Manager's pause state, enabled allocations, configured routes and investments. If no keeper calls, funds remain idle at PoL. The optional Locker owner-only `allocatePoLFunds` remains as a manual alternative, not a requirement.

PoL performance fees are paid in SDT to the Locker when `profitRecipient` is set to the Locker. Those SDT receipts can still be forwarded through `Locker.forwardMarketplaceRevenue(SDT)` and the existing LP bribe/Staking revenue path.

## Deployment

Use `config-mainnet-v41.json` / `config-production-v41.json`. The PoL Manager v9 remains included unchanged and requires its actual constructor parameters to deploy. The config has null recipient and zero PoL diversion by default; enter the real deployed PoL address and desired share before enabling diversion. Existing post-deployment wiring may grant the Locker operator permission for manual allocation; the external keeper must be authorized separately by the PoL Manager owner.

Historical README/changelog files from prior versions are retained as history; this v41 README supersedes v40's automatic-allocation instructions.

No Solidity compilation, tests, simulations, or deployment performed.
