# CurveYield cyvlSDT deployment package v63 — v62 to v63

## Scope

Based on the exact v62 source archive. Changes are limited to:
- `contracts/BeefyVaultCurveYieldV8.sol` (standard SDT/Yearn vault),
- `contracts/StrategyCurveSDTYearnRebindable.sol`,
- `contracts/StrategyCurveSDTYearnV9.sol`,
- package version metadata and this documentation.

No changes to cyvlSDT locker, staking, merchant, revenue vault/strategy, PoL, bribe allocator, external oracle guard, interfaces, or deployment scripts.

## Vault: YV1–YV5

- **YV1**: `withdraw(assets, receiver, owner)` uses one `_previewWithdrawWithNav` result for share sizing and subsequent gross asset calculation; keeps the original floor and ceiling rounding rules, validations, and final-exit requirement.
- **YV2**: `_depositAssets` snapshots total supply before `safeTransferFrom` / `_earn`, then uses it after investing. Existing nonReentrant entrypoints ensure no independent share-minting path intervenes.
- **YV3**: `_withdrawShares` retains the pre-burn supply and derives remaining supply after the burn for fee and final-holder checks, instead of re-reading `totalSupply()`.
- **YV4**: `getPricePerFullShare` avoids reading `totalSupply()` twice. Exact withdrawals reuse the same pre-burn NAV, while post-strategy state-changing asset-balance checks remain fresh.
- **YV5**: bounded APY ring traversal/index advancement replaces modulo operations with single conditional subtraction/wrap, using the existing fixed 10-slot ring bounds. No changes to 12-hour checkpoint cadence or APY math.

## Yearn strategies: YS1–YS5

- **YS1**: Both strategy variants reuse a single Yearn `pricePerShare()` response within each `_redeemRequiredSDT` iteration, rather than re-reading it for sizing the Yearn share withdrawal.
- **YS2**: Both variants reuse the local `yearnShareUnit`, already-read shares and LP balances within the same iteration. Reads after a state-changing withdrawal remain fresh.
- **YS3**: The existing deposit-event accounting already uses only one before-and-after Yearn share balance pair. The actual minted-share delta is preserved; substituting the external return value would change the accounting evidence. No further source change is justified.
- **YS4**: Both variants consolidate the repeated guarded quote-and-dust-check into a private helper, keeping the **two distinct guard quotes** (available LP versus actual LP burn) and the original `GUARD_SDT_DUST` revert. The final-exit dust branch, which intentionally differs, remains unchanged.
- **YS5**: The archived v51 deployment script still selects `StrategyCurveSDTYearnV9`, while the v53 deployment selects `StrategyCurveSDTYearnRebindable`. Both remain in the package and both retain their names, constructor signatures, external ABI and deployment paths. **V9 source byte-identity with the original historical archive is not preserved in this new v63 package**, because YS1/YS2/YS4 changes were applied to both strategies; the original remains available in v62.

## Boundaries and verification

No fee economics, Curve guard minimums, Yearn redemption retries, approval permissions, access-control roles, ERC-4626 external selectors, emergency withdrawal permissions, share accounting units, or final-holder payment rules were intentionally changed.

The replacement of duplicate valuation reads assumes the same transaction's preceding local ERC-20 share/allowance bookkeeping does not alter the external strategy NAV. The v62 and v63 sources need production-profile compilation and comparable execution-gas measurement; this package does **not** claim compiled success or measured gas improvements. Tests, live forks, and deployments were not executed.
