# cyvlSDT package v49 → v50

1. Imported provided `StrategyCurveSDTYearnV9.sol` as **`contracts/StrategyCurveSDTYearnV10.sol`**, replaced its old Beefy V7 dependency with explicit `IStrategyBoostHubV1` implementation for **BeefyVaultCurveYieldV8**, changed only vault-facing contract/interface annotations and their required override bindings; preserved economic code.
2. Added `deployment-v27/deploy-sdt-yearn-beefy-v50.js`, deploying/reusing a CurveGlobal factory **Yearn V2 vault** for the SDT/WETH LP gauge, then the adapted SDT strategy, then a second **BeefyVaultCurveYieldV8** at an exact nonce-predicted CREATE address, plus owner/fee setup and state receipts.
3. Added `config-sdt-yearn-v50.json` with live-sourced pool, gauge, Yearn Curve LP factory, Guard V8, CurveYield Safe owner, admin fee receiver and 50-bps immutable vault withdrawal fee.
4. Added `compile:v50` and `deploy:sdt-yearn:v50` npm scripts, bumped root package/lockfile name and version to v50, and added `README-v50.md` and manifest.
5. **Unchanged:** `contracts/BeefyVaultCurveYieldV8.sol` (v49 BoostHub v63 exact source), cyvlSDT legacy asynchronous vault/strategy, locker, token, staking, Boost Merchant, PoL Manager v22, Guard V8, and old v47 core deployment workflow. No new test, audit workflow or on-chain action.
