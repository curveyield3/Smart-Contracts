# cyvlSDT v44 Source Package

Current release. See `README-v43.md` and `CHANGELOG-v42-to-v43.md` for feature changes.

The entire v44 Locker/Staking/Merchant stack compiles via the isolated GitHub workflow.

- Locker: 16,257 bytes deployed / 8,319 below EIP-170 limit
- Staking: 14,002 bytes deployed / 10,574 below limit
- Merchant: 10,691 bytes deployed / 13,885 below limit

Settings: Solidity 0.8.28, optimizer 200 runs, viaIR, Cancun EVM, OpenZeppelin 5.4.0.

User deposit stakes net SDT and sends PoL principal directly to its Manager. All unreserved SDT and USDC revenue from Stake DAO, Aladdin, Merchant, and PoL can be claimed/forwarded through one Locker path to Staking, which owns both LP-bribe splitting and reward tiers.

The new `redeem(shares,receiver)` uses an owner-funded liquid SDT reserve at an owner-set rate; it does not unstake vlSDT.

No contract tests, simulations, or deployments have been performed.
