# v59 → v60 — Locker emergency withdrawal system removal

Based strictly on v59 (1:1 cyvlSDT mint and direct SDT-to-PoL routing).

- Removed the locker’s `setRedemptionRate`, `requestEmergencyWithdrawal`, `completeEmergencyWithdrawal`, and `disableEmergencyWithdrawForever` entry points.
- Removed their redemption rate, pending request ledger, permanent-disable flag, custom errors and events, and `WAD` constant used exclusively by that subsystem.
- Removed obsolete locker-only `burnForEmergencyWithdrawal` from the cyvlSDT token and `ICurveYieldVlSDTToken` interface. The cyvlSDT token remains mintable only by the owner-configured locker and has no locker-mediated redemption/burn path.
- Retained `grossSDTPrincipalForBase`, `baseSDTEquivalent`, and `BasePrincipalUpdated`. **These are required by `CurveYieldvlSDTStaking.notifyReward` to calculate the base reward benchmark.**
- Deposit behavior remains: deposit `N` SDT → mint `N` cyvlSDT; transfer `floor(N×PoL BPS/10000)` SDT to PoL and stake the remainder as vlSDT.
- Retained unlimited token approvals and rebind rotation, boost allocation and marketplace behavior, distributor claims and forwarding, ownership and role logic.
- Beefy vault/strategy emergency selectors and revenue staking’s *regular* withdrawal paths were deliberately not changed; they are separate subsystems and not locker emergency redemption.

**Critical economic consequence:** This removes the sole direct cyvlSDT → SDT redemption mechanism implemented in the locker. Minted cyvlSDT represents a nonredeemable staking/boost/revenue participation token through this contract. Prior to production use, independently verify that this is intended. Existing pending emergency withdrawals cannot be migrated to a new locker simply by rebinding contracts; this change is intended for fresh deployment without outstanding withdrawal requests.

**Verification:** Static source and reference checks performed. Solidity compilation, EVM execution, and integration tests have not been performed.
