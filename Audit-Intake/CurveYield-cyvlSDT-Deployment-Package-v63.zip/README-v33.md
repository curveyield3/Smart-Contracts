# CurveYield cyvlSDT v33 — merchant-managed boost decisions and Aladdin delegation

## Core design

This v33 source package replaces the merchant's utilization-squared sale-price curve with owner-configured posting and minimum-fill rates. Both sale routes must deliver at least **110% of Aladdin's most recently completed, checkpointed weekly SDT-per-vlBoost reward rate**. Marketplace sale fees are deducted before the comparison. Maximum realized boost lease duration is **90 days**, checked after any week-boundary alignment.

**The Merchant owns ALL new economic routing and allocation decisions. The Locker never chooses between marketplace and Aladdin, never stores a route-specific allocation percentage, and has no new allocation ledger.** The Locker keeps its PREEXISTING module reservation/commitment security accounting, which continues protecting the vlSDT position against over-delegation by any module.

The Locker's preexisting `delegateBoost(amount, endtime, recipient)` is the ONLY merchant-authorized delegation entry point for both direct boost grants and Aladdin. When `recipient == ALADDIN_DELEGATION`, only the configured merchant can select this route. The Locker then invokes Aladdin's proxy `boost(amount, endtime, address(this))`. This is essential because the Locker holds vlSDT and must be the actual `msg.sender` delegator and reward-share beneficiary. The same module accounting/release path applies to both routes. **There is no `merchantDelegateAladdinBoost` function, no separate Aladdin commitment accounting, and no new external allocation system in the Locker.**

Claims use `Merchant.claimAladdinRewardsAndCompound() -> Locker.claimAladdinRewardsAndCompound() -> _donateSDTHeld()`, the same private no-share-mint stake routine as `donateSDT`. It increases locked SDT per outstanding cyvlSDT without minting new shares.

## Key merchant ABI

- `setPaymentToken(token,enabled,postPricePerWeek,minimumFillPricePerWeek,sdtWeiPerToken)` — owner only; token prices are raw token base units per 1e18 boost per 7 days. The conversion is SDT wei for one whole payment token. SDT itself MUST have a conversion rate of 1e18. Owner must update non-SDT conversions to reflect exchange rates. No external oracle was added.
- `setPostListingIfNoAcceptableOffer(bool)` — owner chooses listing rather than Aladdin fallback when no qualifying offer is supplied.
- `aladdinLastEpochRate()` — returns completed Thursday/UNIX-week epoch and SDT wei per 1e18 vlBoost per week.
- `aladdinLastEpochAprBps()`, `aladdinAverageAprBps(weeksBack)` — read-only APR indicators; historical lookback 1–12 completed weeks; **only last epoch** sets the executable sale-rate floor.
- `aladdinMinimumPriceInSDT()` — last epoch's rate multiplied by 1.10.
- `currentPricePerWeek(token)`, `acceptableFillPricePerWeek(token)` — fail closed if configured thresholds violate the Aladdin floor. Marketplace paths include the actual marketplace fee in the premium check.
- `leaseBoost()` — direct boost lease with 90-day cap and owner-configured posting price; cannot pass Aladdin proxy as a buyer recipient.
- `createMarketplaceListing()`, `refreshMarketplaceListing()`, `cancelMarketplaceListing()` — offers to sell boost; maximum posted duration 11 whole weeks to stay below 90 days even when the marketplace rounds expiry up.
- `fillProfitableOffer()` — accepts an existing marketplace buyer offer only when its post-fee price exceeds BOTH the owner-configured minimum fill price AND 110% of Aladdin's recent rate; rejects offers whose actual rounded duration exceeds 90 days.
- `delegateAladdinBoost(amount,endtime)` — only owner/keeper; the Merchant instructs Locker's EXISTING `delegateBoost` call with the fixed Aladdin proxy route selector; there is no direct Merchant-to-Aladdin delegation.
- `executeBestRoute(params)` — owner/keeper selection: qualifying supplied marketplace buy offer first; otherwise post a configured listing if enabled; otherwise delegate to Aladdin. Keeper supplies a candidate order ID; no on-chain historical log scanner or unbounded order-book crawler was introduced.
- `claimAladdinRewardsAndCompound()` — permissionless Merchant-facing harvest; Locker limits callable reward-compounding entry to the configured Merchant. No new shares.

## Operational requirements

1. `Locker.configureSystem` registers Merchant as boost module ID 1 and Boost Staking as module ID 2; existing module capacities remain active. Owner's DAO reserve is not silently moved to Merchant. If desired, use the pre-existing DAO-release and module-reserve functions through the existing ownership configuration—no new mechanism.
2. Locker owner explicitly calls `setAladdinDelegationOperator(true)` once, after approving Aladdin's externally upgradeable proxy trust boundary. This call must originate from Locker, not Merchant/owner wallet.
3. Configure at least one payment token through `boostEconomics.merchantPaymentTokens` or the owner's Merchant `setPaymentToken` call. The example configuration defaults to an empty array to avoid inventing prices. Enable `postListingIfNoAcceptableOffer` only if fallback listing is desired.
4. Check that Aladdin's last completed reward epoch has been checkpointed. Sale functions deliberately revert when Aladdin history is stale; direct delegation remains callable independently.
5. Choose endtimes that normalize to Thursday 00:00 UTC UNIX-week boundaries and fit the 90-day max. One complete eligible epoch should be spanned if positive Aladdin rewards are expected. Claims process up to 50 weekly epochs per external call.
6. Configure the existing Marketplace's vlBoost operator permission for the Locker as already required by marketplace participation; Aladdin has a separate explicit operator permission.

## Integrity and verification

- Nine deployable Solidity source contracts, no newly deployed contracts, no new test files or test workflows.
- No cyGOV usage restored. Removed v30 cyGOV sources remain excluded.
- Source diff: `SOURCE-DIFF-v32-to-v33.patch`. Changes: `CHANGELOG-v32-to-v33.md`. Exact SHA-256 manifests included.
- **Not claimed compiled or live-tested.** The package pins Solidity 0.8.28 and dependencies via npm lockfile, but the working environment lacks downloaded npm dependencies and the package registry was not reachable. Static source/import checks and JS syntax checks only. No tests, simulations or deployments were executed.

## Reproduction (external deploy/compile environment)

```sh
npm ci
npm run compile:v33
npm run config:materialize:v33
# inspect config-production-v33.json and configure nonempty merchantPaymentTokens
npm run deploy:v33
npm run configure:v33
npm run verify:v33
```

The existing handoff commands remain `handoff:propose:v33` and `handoff:accept:v33` under the pre-existing authorization process. This ZIP is an audit/source package, not authorization to deploy.
