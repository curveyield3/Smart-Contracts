# v57 → v58 — approved locker-only optimizations

1. **One-time SDT approval for StakeDAO `VLSDT`.** Constructor grants `type(uint256).max` allowance; `deposit` no longer issues exact approval and subsequent zero-reset.
2. **One-time SDT and USDC approval for the configured revenue staking.** `configureSystem` grants max allowances for both reward tokens. `_notifyStaking` now only notifies revenue staking, using these approvals.
3. **Allowance rotation on `setRevenueStaking(next)`.** If the spender changes, clear allowances for the previous nonzero spender, update the pointer, approve max for both tokens to the new nonzero spender; preserve owner role, event and ability to set the pointer to zero. Setting the same address emits the existing event without needless approvals.
4. **Optimization #2:** `merchantDelegableBoost` samples vlSDT balance and delegable boost only once each; keeps marketplace filled, committed, DAO/admin and merchant accounting intact. Public helper functions are unchanged.
5. **Optimization #4:** `deposit` calculates `floor(amount * shareBps / 10000)` using `(amount/10000)*shareBps + ((amount%10000)*shareBps)/10000`, safe at full uint256 range under the existing `shareBps <= 2500` limit; no fee or rounding change.

**No other locker optimizations, Solidity source changes, economics, deployment or tests.** Standing unlimited allowances increase token exposure if a spender is malicious or compromised. Solidity compile/runtime gas verification not completed due missing dependencies and network-disabled local toolchain.
