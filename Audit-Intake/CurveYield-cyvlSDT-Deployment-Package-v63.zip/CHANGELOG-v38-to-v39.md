# CurveYield cyvlSDT v39 — PoL Manager v9 Compatibility

Source-only integration; v38 preserved as predecessor. No Solidity compilation, tests, simulation, or deployment.

## Minimal Locker changes

- Added an inline `ICurveYieldPoLManager` interface with the **actual** PoL v9 selector `allocateFunds(address token,uint256 amount) returns (uint256[7])` (not `allocate_funds`).
- Added owner-only `Locker.allocatePoLFunds(address token,uint256 amount)` to call PoL's existing `allocateFunds` for already-delivered idle **SDT or USDC**, and return its seven per-position allocation amounts. The Locker uses its existing configured `cyvlSdtPoLContract` address; no duplicated PoL address/config is introduced.
- The call is **separate from user deposits**: the 0–15% configured SDT PoL deposit share still transfers directly to PoL v9 without staking it as vlSDT, and PoL investment is triggered by a separate owner transaction. This prevents expensive PoL investment, paused PoL, missing routes, or incomplete allocations from blocking user deposits.
- No PoL Manager source was changed (v9 is included byte-for-byte as supplied). No new token accounting, approval, bridge, performance fee receiver, or manager-side oracle was added.

## Performance-fee income (already supported)

- PoL Manager v9 uses `profitRecipient` and `_pay` to **transfer SDT** performance fees via standard ERC-20 transfer. Ordinary SDT transfers do not invoke a Locker callback; therefore, the receipt does not automatically notify Staking.
- Configure the PoL Manager's `profitRecipient` to the Locker address (`PoLManager.setProfitRecipient(locker)`). After a PoL harvest, call the Locker's **existing** public `forwardMarketplaceRevenue(SDT_ADDRESS)`: it sweeps idle SDT, diverts the configured 0–15% LP bribe share, then notifies Staking with the balance. This uses existing Staking base/excess, DAO/admin/PoL tiers and independent seven-day streams. Marketplace/PoL performance SDT held at the same time is combined in that sweep.
- No new fee callback, reward balance shadow ledger, or dedicated PoL fee forwarding function is required. The legacy `MarketplaceRevenueForwarded` event will cover the sweep; this event label does not prove PoL provenance.
- Independently, the Staking contract already sends the PoL tier share of **both SDT and USDC** to the Locker's configured PoL recipient. PoL Manager v9 accepts both as idle assets when configured with those exact token addresses.

## Authorization and post-deployment wiring

The PoL Manager must be deployed/configured separately with its real **Curve pool, original fixed Uniswap V3 NFT, Yearn/Euler vaults, SDT, USDC and existing OmniRouter**. Those required constructor values are **not available in the v38 cyvlSDT configuration** and are not invented. The v39 package includes the original, standalone PoL Manager v9 source, but does not attempt to deploy it automatically or add unrelated infrastructure.

1. Deploy PoL v9 separately with Ethereum mainnet SDT and USDC and the existing OmniRouter.
2. In `config-mainnet-v39.json` and `config-production-v39.json`, set `lockerRevenueDiversions.poLDeposit.recipient` to the deployed PoL Manager address, and independently choose `poLDeposit.shareBps` (0..1500). Recipient may be set while share is zero so Staking can deliver PoL fee allocations.
3. PoL owner must call `PoLManager.setOperator(locker, true)`, permitting the Locker to call PoL `allocateFunds`, and `PoLManager.setProfitRecipient(locker)`, sending future SDT performance fees back to the Locker. The existing post-deploy configuration script now makes these two calls automatically **only if** the deployment wallet is the PoL owner. For a Safe-owned PoL Manager, do these calls using that Safe. Verification will fail until they are done when a recipient is configured.
4. When PoL idle SDT/USDC is ready for investment, the Locker owner can call `Locker.allocatePoLFunds(token, amount)`. The PoL Manager must not be paused, must have `allocationsSet == true`, and must have at least one enabled nonzero-weight position; supported swap routes and vaults also have to exist.
5. After any PoL harvest that transfers SDT to the Locker, call `Locker.forwardMarketplaceRevenue(SDT)` to account for it as ordinary staking revenue. (The call is permissionless; a keeper can invoke it.)

`post-deploy-configure-cyvlsdt-v27-v1.js` now verifies all five relevant PoL links: SDT address, USDC address, OmniRouter address, Locker operator authorization, and Locker as profit recipient, whenever a PoL recipient is present. Default `poLDeposit.recipient = null` / `poLDeposit.shareBps = 0` remains a valid initial deployment state.

## Known boundaries

- No ERC-20 receiver callback exists. PoL profit fees require an explicit sweep; do **not** assume sending SDT automatically opens a reward stream.
- The PoL's `allocateFunds` is owner/operator-only; an external user cannot call it through the Locker. In v39 only the Locker **owner** can invoke the wrapper. A PoL-approved keeper can alternatively invoke PoL Manager directly.
- The original PoL v9 source reports runtime size of 24,346 bytes at optimizer runs 1 and only 230 bytes EIP-170 headroom. This package does not modify it and does not independently verify compilation or code size.
- Neither PoL funding nor SDT performance fee transfers mint or back additional cyvlSDT.
- Source-level compatibility and deployment wiring were reviewed; full integration, actual constructor configuration and production behavior remain **unverified without deployment/compilation**.
