# CurveYield cyvlSDT Source Package v54

This version removes **v53-added blocking rebinding checks** without introducing proxies. Contract-address setters remain owner/configurator-controlled, and previously existing economic/user-path guards remain intact.

See `CHANGELOG-v53-to-v54.md`, `SOURCE-DIFF-v53-to-v54.patch`, and `REPLACEMENT_ARCHITECTURE_REPORT_v2.md` for exact changes and migration risks. The v53 architecture report is superseded.

Deployment scripts and configs named v53 remain bundled unchanged except for removing the new configurator verifier/acceptance restrictions. The immutable original `StrategyCurveSDTYearnV9.sol` source is preserved byte-for-byte.

**Not yet compiled, tested or deployed.**
