# CurveYield v51 → v52

- Fixed one confirmed interface ABI type mismatch: `ICurveYieldvlSDTStaking.immediateWithdrawFeePpm` `uint256` → `uint32` in `contracts/interfaces/ICurveYield.sol`.
- Added `INTERFACE_COMPATIBILITY_REPORT_v1.md` with the actual interface-to-contract/source/live-ABI reconciliation and unverified deployment-dependent targets.
- Updated package/npm metadata and added `compile:v52` alias. Kept v51 deployment scripts/configuration source unchanged.
- Verified original V9 strategy source is byte-exact (SHA-256 `c280bd632a02776a21999f7a0f16d768405036646aad8e70ded6431652594b87`); no vault, strategy, Locker, PoL Manager or Guard implementation modifications.
- No new/modified/executed tests, compilation, chain simulation, broadcast or deployment.
