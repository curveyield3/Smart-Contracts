# CurvePairOracleBounds v6

## Changes from v5

- **Added ordinary three-token StableSwap-NG LP quotes**, including pools with Curve-managed ERC-4626 or external rate oracles.
- Uses `price_oracle(0)` and `price_oracle(1)`, `A()`, `get_virtual_price()`, and all three `stored_rates()` values.
- Reconstructs the oracle-implied relative reserves using the 3-coin StableSwap invariant; does not read live pool balances.
- Existing `quoteDeposit(address,uint8,uint256,uint16)` and `quoteWithdraw(address,uint8,uint256,uint16)` interfaces automatically recognize the actual coin count and support indices 0, 1, or 2.
- Rejects nested metapools (both `BASE_POOL()` and `base_pool()` variants), pools with unsupported numbers of invariant coins, and three-token pools missing required TWAP/rate interfaces with `NotSupported(pool)`.
- Retains v5 2-coin StableSwap (including managed rate oracles), 2-coin CurveTwocrypto-Optimized, and Uniswap v3 NFT position/deposit/percentage-withdrawal quote functions.
- Read-only. No fee, ownership, swap execution, token custody, or deployment constructor inputs.

## Mathematical method

For normalized historical balances `u[i] = xp[i]/D`, amplification `Ann = 3*A`, `q = D^3/(27*xp[0]*xp[1]*xp[2])`, and historical normalized prices `p[0] = 1`, `p[1] = price_oracle(0)`, `p[2] = price_oracle(1)`, the pool's marginal StableSwap conversion is:

    dD/dxp[i] = (Ann + q/u[i]) / (Ann - 1 + 4*q)

Set `t=q/u[0]`, `d[0]=t`, `d[i]=p[i]*(Ann+t)-Ann`. The solver finds the positive scalar t satisfying both:

    q = (Ann - 1) / (Ann * sum(1/d[i]) - 1)
    q^4 = d[0]*d[1]*d[2]/27

It computes the marginal derivative, adjusts each token via `stored_rates()[i]`, and divides/multiplies by virtual price to estimate LP minting or single-token redemption. User-supplied slippage bps determine the output haircut.

**Rates of 1.0** are treated as ordinary unit normalization; this contract does not infer or configure external oracles. Rates come directly from the Curve pool itself.

## Grounded comparison: Ethereum fxUSD/rUSD/btcUSD

Pool: `0x52bF165abd26106D810733CC29FAfF68b96DECe8`. Reference block `0x19344f6` (Ethereum). A=500, `price_oracle(0)=0.996902833178208373`, `price_oracle(1)=0.998276696734309612`; all three `stored_rates` returned 1.0. VP ~1.0795980565.

| Coin | Operation | v6 model output | Curve benchmark | Relative error |
|---|---|---:|---:|---:|
| fxUSD | Deposit 1 coin -> LP | 0.9280495813 | 0.9279898545 | +0.00644% |
| rUSD | Deposit 1 coin -> LP | 0.9251752569 | 0.9251415099 | +0.00365% |
| btcUSD | Deposit 1 coin -> LP | 0.9264502704 | 0.9263996428 | +0.00546% |
| fxUSD | Burn 1 LP -> coin | 1.0775286365 | 1.0774591532 | +0.00645% |
| rUSD | Burn 1 LP -> coin | 1.0808762907 | 1.0808368353 | +0.00365% |
| btcUSD | Burn 1 LP -> coin | 1.0793887507 | 1.0793297654 | +0.00546% |

The Curve quote functions were used only **off-chain to benchmark accuracy**; the delivered contract never reads Curve spot balances or spot LP mint/burn quotations. The published numbers do not imply a universal <2% guarantee, especially when a single-sided operation is large relative to liquidity.

Previously inspected rate-adjusted 2-coin NG examples:
- `0x15e4ff94B70a8F146b4e4aFD069014d126035752` (sfrxUSD/scrvUSD): two non-unit rates.
- `0x57064F49Ad7123C92560882a45518374ad982e85` (crvUSD/sUSDe): one non-unit rate.

## Source files

- `CurvePairOracleBounds_v6.sol`
- `UniV3TickMath_v6.sol`

## Status

- Versioned Solidity source complete and packaged.
- Model arithmetic independently compared against on-chain Curve benchmark calls.
- **Solidity compiler and full deployed-contract execution have not been verified.** Do not interpret this as a compiled/deployed/audited build.
- No live deployment performed; Fraxtal v3 remains unchanged.
- No test contracts, test files, workflows, or infrastructure have been added.
