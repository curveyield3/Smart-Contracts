// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ICurveYieldOmniRouter} from "./interfaces/ICurveYieldOmniRouter.sol";

/// @notice Curve V1 GaugeController used by the Ethereum VoteMarket platform.
interface ICurveGaugeControllerForBribes {
    function gauge_types(address gauge) external view returns (int128);
    function gauge_relative_weight_write(address gauge, uint256 epoch) external returns (uint256);
    function gauge_relative_weight(address gauge, uint256 epoch) external view returns (uint256);
    function points_weight(address gauge, uint256 epoch) external view returns (uint256 bias, uint256 slope);
}

interface ICurveCRVInflationRate {
    function rate() external view returns (uint256);
}

/// @notice Ethereum VoteMarket V1, as deployed for Curve; not Arbitrum V2's Campaign API.
interface ICurveEthereumVoteMarket {
    struct Bounty {
        address gauge;
        address manager;
        address rewardToken;
        uint8 numberOfPeriods;
        uint256 endTimestamp;
        uint256 maxRewardPerVote;
        uint256 totalRewardAmount;
        address[] blacklist;
    }

    function gaugeController() external view returns (address);
    function getCurrentPeriod() external view returns (uint256);
    function getBounty(uint256 bountyId) external view returns (Bounty memory);
    function getPeriodsLeft(uint256 bountyId) external view returns (uint256);
    function updateBountyPeriod(uint256 bountyId) external;
    function createBounty(
        address gauge,
        address manager,
        address rewardToken,
        uint8 numberOfPeriods,
        uint256 maxRewardPerVote,
        uint256 totalRewardAmount,
        address[] calldata blacklist,
        bool upgradeable
    ) external returns (uint256 bountyId);
    function increaseBountyDuration(
        uint256 bountyId,
        uint8 additionalPeriods,
        uint256 additionalReward,
        uint256 newMaxRewardPerVote
    ) external;
    function closeBounty(uint256 bountyId) external;
}

/// @title VoteMarketSingleGaugeBribeAllocator
/// @notice One Ethereum gauge and one continuously extended USDC bounty.
/// @dev Receives SDT/USDC directly from cyvlSDT Locker. Uses OmniRouter for SDT conversion
///      and for the CRV/USDC historical price; VoteMarket itself applies maxRewardPerVote.
///      Current GaugeController weights and CRV inflation are an estimate of NEXT week's
///      emissions, not a guaranteed realized return. No parallel forecast or return gate.
contract VoteMarketSingleGaugeBribeAllocator is Ownable2Step, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 public constant WAD = 1e18;
    uint256 public constant WEEK = 7 days;
    uint256 public constant ETHEREUM_CHAIN_ID = 1;
    uint8 public constant INITIAL_BOUNTY_PERIODS = 2;

    address public constant USDC_TOKEN = 0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48;
    address public constant SDT_TOKEN = 0x73968b9a57c6E53d41345FD57a6E6ae27d6CDB2F;
    IERC20 public immutable USDC;
    IERC20 public immutable SDT;
    address public constant CRV = 0xD533a949740bb3306d119CC777fa900bA034cd52;

    ICurveYieldOmniRouter public OMNI_ROUTER;
    ICurveEthereumVoteMarket public VOTEMARKET;
    ICurveGaugeControllerForBribes public GAUGE_CONTROLLER;

    address public gauge;
    uint256 public minimumReturnWad = 1_250_000_000_000_000_000; // 1.25x
    uint256 public bountyId;
    bool public hasBounty;
    uint256 public lastFundingEpoch;
    bool public hasFundedEpoch;
    bool public paused;

    error InvalidConfiguration();
    error Paused();
    error BountyStillActive();
    error NoBounty();
    error BountyNotExpired();
    error BountyExpired();
    error InsufficientEmissionValue();
    error MissingOmniRouterRoute();
    error UnexpectedTokenTransfer();

    event GaugeChanged(address indexed gauge);
    event OmniRouterRebound(address indexed previous,address indexed next);
    event VoteMarketRebound(address indexed previous,address indexed next);
    event MinimumReturnChanged(uint256 minimumReturnWad);
    event PausedChanged(bool paused);
    event SDTConverted(uint256 inputSDT, uint256 outputUSDC);
    event BountyCreated(uint256 indexed bountyId, uint256 amountUSDC, uint256 maxRewardPerVote);
    event BountyExtended(uint256 indexed bountyId, uint256 amountUSDC, uint256 maxRewardPerVote);
    event BountyClosed(uint256 indexed bountyId, uint256 refundedUSDC);

    constructor(address initialOwner, address omniRouter, address voteMarket) Ownable(initialOwner) {
        if (block.chainid != ETHEREUM_CHAIN_ID || initialOwner == address(0)
            || omniRouter.code.length == 0 || voteMarket.code.length == 0) revert InvalidConfiguration();
        USDC = IERC20(USDC_TOKEN);
        SDT = IERC20(SDT_TOKEN);
        OMNI_ROUTER = ICurveYieldOmniRouter(omniRouter);
        VOTEMARKET = ICurveEthereumVoteMarket(voteMarket);
        address controller = VOTEMARKET.gaugeController();
        if (controller.code.length == 0) revert InvalidConfiguration();
        GAUGE_CONTROLLER = ICurveGaugeControllerForBribes(controller);
    }

    modifier whenActive() {
        if (paused) revert Paused();
        _;
    }

    function setOmniRouter(address next) external onlyOwner {
        emit OmniRouterRebound(address(OMNI_ROUTER), next);
        OMNI_ROUTER = ICurveYieldOmniRouter(next);
    }

    function setVoteMarket(address next) external onlyOwner {
        address controller = ICurveEthereumVoteMarket(next).gaugeController();
        emit VoteMarketRebound(address(VOTEMARKET), next);
        VOTEMARKET = ICurveEthereumVoteMarket(next);
        GAUGE_CONTROLLER = ICurveGaugeControllerForBribes(controller);
        gauge = address(0);
    }

    function setPaused(bool value) external onlyOwner {
        paused = value;
        emit PausedChanged(value);
    }

    /// @notice Changing gauge is only permitted after any previous bounty has been closed.
    function setGauge(address nextGauge) external onlyOwner {
        if (hasBounty) revert BountyStillActive();
        if (nextGauge != address(0) && GAUGE_CONTROLLER.gauge_types(nextGauge) < 0)
            revert InvalidConfiguration();
        gauge = nextGauge;
        emit GaugeChanged(nextGauge);
    }

    function setMinimumReturnWad(uint256 nextMinimumReturnWad) external onlyOwner {
        if (nextMinimumReturnWad < WAD) revert InvalidConfiguration();
        minimumReturnWad = nextMinimumReturnWad;
        emit MinimumReturnChanged(nextMinimumReturnWad);
    }

    /// @notice CRV emission value attributable to one unit of *gauge-eligible* voting bias.
    /// @dev Uses the current epoch as the observable proxy for the upcoming voting epoch.
    ///      The marketplace creates its bounty starting next epoch. USDC has six decimals.
    ///      price_oracle returns whole USDC per whole CRV scaled by 1e18 (gross, no swap fee).
    function previewMaxRewardPerVote() external view returns (uint256) {
        uint256 epoch = VOTEMARKET.getCurrentPeriod();
        return _maximumPerVote(epoch, GAUGE_CONTROLLER.gauge_relative_weight(gauge, epoch));
    }

    function _maximumPerVote(uint256 epoch, uint256 relativeWeight) internal view returns (uint256) {
        if (gauge == address(0) || relativeWeight == 0) revert InsufficientEmissionValue();
        (uint256 eligibleBias,) = GAUGE_CONTROLLER.points_weight(gauge, epoch);
        if (eligibleBias == 0) revert InsufficientEmissionValue();
        if (OMNI_ROUTER.routeLength(CRV, address(USDC)) == 0) revert MissingOmniRouterRoute();
        uint256 crvPriceUsdc18 = OMNI_ROUTER.price_oracle(CRV, address(USDC));
        if (crvPriceUsdc18 == 0) revert InsufficientEmissionValue();

        // CRV rate is wei of CRV per second. Curve weights are 1e18, veCRV bias is 1e18.
        uint256 weeklyGaugeCrvWei = Math.mulDiv(ICurveCRVInflationRate(CRV).rate() * WEEK, relativeWeight, WAD);
        // Convert wei CRV to raw USDC (6 decimals) via 1e18-denominated price.
        uint256 weeklyGaugeUsdc = Math.mulDiv(weeklyGaugeCrvWei, crvPriceUsdc18, 1e30);
        // VoteMarket defines rewardPerVote as 1e18 * raw reward units / raw gauge bias.
        uint256 capAtBreakEven = Math.mulDiv(weeklyGaugeUsdc, WAD, eligibleBias);
        uint256 cap = Math.mulDiv(capAtBreakEven, WAD, minimumReturnWad);
        if (cap == 0) revert InsufficientEmissionValue();
        return cap;
    }

    /// @notice Convert Locker-supplied SDT to USDC through the existing guarded OmniRouter.
    /// @dev No Chainlink feeds, separate price oracles, or independently managed swap routes.
    function convertSDT() public nonReentrant whenActive returns (uint256 receivedUSDC) {
        uint256 amount = SDT.balanceOf(address(this));
        if (amount == 0) return 0;
        if (OMNI_ROUTER.routeLength(address(SDT), address(USDC)) == 0) revert MissingOmniRouterRoute();
        uint256 beforeBalance = USDC.balanceOf(address(this));
        SDT.forceApprove(address(OMNI_ROUTER), amount);
        OMNI_ROUTER.swapExactInput(
            address(SDT), address(USDC), amount,
            OMNI_ROUTER.guardedMinOut(address(SDT), address(USDC), amount),
            address(this), block.timestamp
        );
        SDT.forceApprove(address(OMNI_ROUTER), 0);
        receivedUSDC = USDC.balanceOf(address(this)) - beforeBalance;
        if (receivedUSDC == 0) revert UnexpectedTokenTransfer();
        emit SDTConverted(amount, receivedUSDC);
    }

    /// @notice Add all available USDC to the same bounty once per funding epoch.
    /// @dev Native VoteMarket maxRewardPerVote is the ONLY price/enforcement gate.
    ///      No extra epoch cap, emission reporter, independent profitability check or hook.
    function fundEpoch() public nonReentrant whenActive returns (bool funded) {
        if (gauge == address(0)) return false;
        uint256 epoch = VOTEMARKET.getCurrentPeriod();
        if (hasFundedEpoch && lastFundingEpoch == epoch) return false;
        uint256 amount = USDC.balanceOf(address(this));
        if (amount == 0) return false;
        uint256 relativeWeight = GAUGE_CONTROLLER.gauge_relative_weight_write(gauge, epoch);
        uint256 maxPerVote = _maximumPerVote(epoch, relativeWeight);

        USDC.forceApprove(address(VOTEMARKET), amount);
        if (!hasBounty) {
            address[] memory noBlacklist = new address[](0);
            uint256 id = VOTEMARKET.createBounty(
                gauge, address(this), address(USDC), INITIAL_BOUNTY_PERIODS,
                maxPerVote, amount, noBlacklist, true
            );
            ICurveEthereumVoteMarket.Bounty memory created = VOTEMARKET.getBounty(id);
            if (created.manager != address(this) || created.gauge != gauge
                || created.rewardToken != address(USDC)) revert InvalidConfiguration();
            bountyId = id;
            hasBounty = true;
            emit BountyCreated(id, amount, maxPerVote);
        } else {
            // If extension was missed until expiration, close explicitly before creating another.
            VOTEMARKET.updateBountyPeriod(bountyId);
            if (VOTEMARKET.getPeriodsLeft(bountyId) < 1) revert BountyExpired();
            VOTEMARKET.increaseBountyDuration(bountyId, 1, amount, maxPerVote);
            emit BountyExtended(bountyId, amount, maxPerVote);
        }
        USDC.forceApprove(address(VOTEMARKET), 0);
        lastFundingEpoch = epoch;
        hasFundedEpoch = true;
        return true;
    }

    /// @notice Permissionless one-call maintenance. Retains SDT until a router swap route exists.
    /// @dev Use fundEpoch() separately if a configured SDT swap route is temporarily unavailable.
    function processEpoch() external whenActive returns (bool funded) {
        if (SDT.balanceOf(address(this)) != 0 && OMNI_ROUTER.routeLength(address(SDT), address(USDC)) != 0) {
            convertSDT();
        }
        return fundEpoch();
    }

    /// @notice Recover any unclaimed bounty funds to this contract once it has expired.
    /// @dev VoteMarket refunds directly to its recorded bounty manager, without a hook.
    function closeExpiredBounty() external nonReentrant returns (uint256 refundUSDC) {
        if (!hasBounty) revert NoBounty();
        // Apply pending native extensions before checking the actual end timestamp.
        VOTEMARKET.updateBountyPeriod(bountyId);
        ICurveEthereumVoteMarket.Bounty memory b = VOTEMARKET.getBounty(bountyId);
        // Anyone may call VoteMarket.closeBounty directly. In that case the
        // native platform has already returned the USDC to this manager.
        if (b.manager == address(0)) {
            emit BountyClosed(bountyId, 0);
            hasBounty = false;
            return 0;
        }
        if (b.manager != address(this)) revert InvalidConfiguration();
        if (VOTEMARKET.getCurrentPeriod() < b.endTimestamp) revert BountyNotExpired();
        uint256 previous = USDC.balanceOf(address(this));
        VOTEMARKET.closeBounty(bountyId);
        refundUSDC = USDC.balanceOf(address(this)) - previous;
        emit BountyClosed(bountyId, refundUSDC);
        hasBounty = false;
    }

    /// @notice Owner-only rescue while paused; active bounty funds stay in VoteMarket custody.
    function recoverToken(address token, address to, uint256 amount) external onlyOwner nonReentrant {
        if (!paused || to == address(0)) revert InvalidConfiguration();
        IERC20(token).safeTransfer(to, amount);
    }
}
