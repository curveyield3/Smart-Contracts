// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable, Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {IVlSDT, IVlBoost, IFeeDistributor, IStakeDaoRouter, IBoostMarketplace} from "./interfaces/IStakeDao.sol";
import {ICurveYieldVlSDTToken, ICurveYieldvlSDTStaking} from "./interfaces/ICurveYield.sol";

interface IAladdinVlSDTDelegation {
    function boost(uint256 amount, uint256 endtime, address rewardShareRecipient) external;
    function claim(address user, address rewardRecipient) external returns (uint256 claimedSDT);
}

/// @notice Single vlSDT custodian: stake SDT, protect DAO/admin boost, and forward unreserved revenue.
/// @dev Reward-tier splitting and LP-bribe diversion are exclusively performed by RevenueStaking.
contract CurveYieldVlSDTLocker is Ownable2Step, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 public constant BPS = 10_000;
    uint16 public constant MAX_POL_DEPOSIT_SHARE_BPS = 2_500;
    uint256 public constant DAO_BOOST_BPS = 1_000;
    uint256 public constant ADMIN_BOOST_BPS = 500;
    uint256 public constant WEEK = 7 days;
    uint256 public constant MAX_BOOST_DURATION_WEEKS = 13;
    address public constant ALADDIN_DELEGATION = 0x322c76e1205dE5ee4146e40644563B482B1CDA43;
    uint8 private constant CLAIM_DISTRIBUTORS_MODULE = 0x0c;
    uint8 private constant SWEEP_TOKENS_MODULE = 0x07;
    bytes4 private constant CLAIM_DISTRIBUTORS_SELECTOR = 0xb38aab9d;
    bytes4 private constant SWEEP_TOKENS_SELECTOR = 0x780469bb;

    IERC20 public immutable SDT;
    IERC20 public immutable USDC_REWARD_TOKEN;
    IVlSDT public immutable VLSDT;
    IVlBoost public immutable VLBOOST;
    IStakeDaoRouter public immutable STAKE_DAO_ROUTER;
    IFeeDistributor public immutable VLSDT_FEE_DISTRIBUTOR_USDC;
    IFeeDistributor public immutable VLSDT_FEE_DISTRIBUTOR_SDT;
    IBoostMarketplace public BOOST_MARKETPLACE;
    ICurveYieldVlSDTToken public CYVLSDT;

    address public treasuryReceiver;
    address public cyvlSdtPoLContract;
    uint16 public poLDepositShareBps;
    address public revenueStaking;
    address public boostMerchant;
    bool public systemConfigured;
    uint256 public grossSDTPrincipalForBase;

    struct BoostCommitment { uint128 amount; uint64 endtime; bool active; }
    uint256 public daoCommittedBoost;
    uint256 public adminCommittedBoost;
    uint256 public merchantCommittedBoost;
    uint256 public nextDaoBoostCommitmentId = 1;
    uint256 public nextAdminBoostCommitmentId = 1;
    uint256 public nextMerchantBoostCommitmentId = 1;
    mapping(uint256 => BoostCommitment) public daoBoostCommitments;
    mapping(uint256 => BoostCommitment) public adminBoostCommitments;
    mapping(uint256 => BoostCommitment) public merchantBoostCommitments;

    error ZeroAddress();
    error ZeroAmount();
    error NotConfigured();
    error AlreadyConfigured();
    error OnlyBoostMerchant();
    error OnlyAdmin();
    error InvalidBoostDuration();
    error InsufficientBoostCapacity();
    error CommitmentNotExpired();
    error InvalidCommitment();
    error InvalidPoLShare();
    error InvalidRevenueToken();
    error InvalidStakeAmount();
    error InvalidFeeDistributor();
    error ValueTooLarge();
    error OnlyDaoOwner();

    event SystemConfigured(address indexed staking, address indexed merchant);
    event RevenueStakingRebound(address indexed previous, address indexed next);
    event BoostMerchantRebound(address indexed previous, address indexed next);
    event CyvlSDTRebound(address indexed previous, address indexed next);
    event BoostMarketplaceRebound(address indexed previous, address indexed next);
    event TreasuryReceiverSet(address indexed prior, address indexed next);
    event PoLDepositShareSet(uint16 shareBps, address indexed recipient);
    event PoLDepositSent(uint256 amount);
    event Deposited(address indexed caller, address indexed receiver, uint256 minted);
    event BasePrincipalUpdated(uint256 value);
    event RevenueForwarded(address indexed token, uint256 amount);
    event RevenueClaimed(uint256 usdc, uint256 sdt);
    event AladdinBoostDelegated(uint256 indexed commitmentId, uint256 amount, uint256 endtime);
    event BoostDelegated(address indexed operator, address indexed recipient, uint256 amount, uint256 endtime);
    event MarketplaceOperatorSet(bool approved);
    event BoostCommitmentCreated(uint8 indexed lane, uint256 indexed id, uint256 amount, uint256 endtime);
    event BoostCommitmentReleased(uint8 indexed lane, uint256 indexed id, uint256 amount);
    event DaoMarketplaceRevenue(address indexed token, uint256 amount);

    constructor(
        address initialOwner_, address initialTreasuryReceiver_, address sdt_, address vlSdt_,
        address vlBoost_, address stakeDaoRouter_, address vlSdtFeeDistributorUsdc_,
        address vlSdtFeeDistributorSdt_, address boostMarketplace_, address cyvlSdt_
    ) Ownable(initialOwner_) {
        if (initialOwner_ == address(0) || initialTreasuryReceiver_ == address(0)
            || sdt_ == address(0) || vlSdt_ == address(0) || vlBoost_ == address(0)
            || stakeDaoRouter_ == address(0) || vlSdtFeeDistributorUsdc_ == address(0)
            || vlSdtFeeDistributorSdt_ == address(0) || boostMarketplace_ == address(0)
            || cyvlSdt_ == address(0)) revert ZeroAddress();
        address usdcRewardToken = IFeeDistributor(vlSdtFeeDistributorUsdc_).REWARD_TOKEN();
        if (usdcRewardToken == address(0) || IFeeDistributor(vlSdtFeeDistributorSdt_).REWARD_TOKEN() != sdt_)
            revert InvalidFeeDistributor();
        treasuryReceiver = initialTreasuryReceiver_;
        SDT = IERC20(sdt_);
        USDC_REWARD_TOKEN = IERC20(usdcRewardToken);
        VLSDT = IVlSDT(vlSdt_);
        VLBOOST = IVlBoost(vlBoost_);
        STAKE_DAO_ROUTER = IStakeDaoRouter(stakeDaoRouter_);
        VLSDT_FEE_DISTRIBUTOR_USDC = IFeeDistributor(vlSdtFeeDistributorUsdc_);
        VLSDT_FEE_DISTRIBUTOR_SDT = IFeeDistributor(vlSdtFeeDistributorSdt_);
        BOOST_MARKETPLACE = IBoostMarketplace(boostMarketplace_);
        CYVLSDT = ICurveYieldVlSDTToken(cyvlSdt_);
        // The immutable Stake DAO spender only needs approval once, not on each deposit.
        SDT.forceApprove(vlSdt_, type(uint256).max);
        emit TreasuryReceiverSet(address(0), initialTreasuryReceiver_);
    }

    modifier configured() { if (!systemConfigured) revert NotConfigured(); _; }
    modifier onlyMerchant() { if (msg.sender != boostMerchant) revert OnlyBoostMerchant(); _; }
    modifier onlyAdmin() {
        if (!systemConfigured) revert NotConfigured();
        if (msg.sender != ICurveYieldvlSDTStaking(revenueStaking).admin()) revert OnlyAdmin();
        _;
    }

    function configureSystem(address revenueStaking_, address boostMerchant_) external onlyOwner {
        if (systemConfigured) revert AlreadyConfigured();
        if (revenueStaking_ == address(0) || boostMerchant_ == address(0)) revert ZeroAddress();
        revenueStaking = revenueStaking_;
        boostMerchant = boostMerchant_;
        // The revenue contract pulls the exact forwarded reward amount each time.
        SDT.forceApprove(revenueStaking_, type(uint256).max);
        USDC_REWARD_TOKEN.forceApprove(revenueStaking_, type(uint256).max);
        systemConfigured = true;
        emit SystemConfigured(revenueStaking_, boostMerchant_);
    }

    /// @notice Change the revenue staking address.
    function setRevenueStaking(address next) external onlyOwner {
        address previous = revenueStaking;
        if (previous != next) {
            if (previous != address(0)) {
                SDT.forceApprove(previous, 0);
                USDC_REWARD_TOKEN.forceApprove(previous, 0);
            }
            revenueStaking = next;
            if (next != address(0)) {
                SDT.forceApprove(next, type(uint256).max);
                USDC_REWARD_TOKEN.forceApprove(next, type(uint256).max);
            }
        }
        emit RevenueStakingRebound(previous, next);
    }

    /// @notice Change the boost merchant address.
    function setBoostMerchant(address next) external onlyOwner {
        emit BoostMerchantRebound(boostMerchant, next);
        boostMerchant = next;
    }

    /// @notice Change the cyvlSDT token address.
    function setCyvlSDT(address next) external onlyOwner {
        emit CyvlSDTRebound(address(CYVLSDT), next);
        CYVLSDT = ICurveYieldVlSDTToken(next);
    }

    /// @notice Change the external boost marketplace address.
    function setBoostMarketplace(address next) external onlyOwner {
        address old = address(BOOST_MARKETPLACE);
        bool wasApproved = VLBOOST.isOperator(address(this), old);
        if (wasApproved) VLBOOST.setOperator(old, false);
        BOOST_MARKETPLACE = IBoostMarketplace(next);
        if (wasApproved) VLBOOST.setOperator(next, true);
        emit BoostMarketplaceRebound(old, next);
    }

    function setTreasuryReceiver(address next) external onlyOwner {
        if (next == address(0)) revert ZeroAddress();
        emit TreasuryReceiverSet(treasuryReceiver, next);
        treasuryReceiver = next;
    }

    function setPoLDepositShare(uint16 shareBps, address recipient) external onlyOwner {
        if (shareBps > MAX_POL_DEPOSIT_SHARE_BPS) revert InvalidPoLShare();
        if (shareBps != 0 && recipient == address(0)) revert ZeroAddress();
        poLDepositShareBps = shareBps;
        cyvlSdtPoLContract = recipient;
        emit PoLDepositShareSet(shareBps, recipient);
    }

    /// @notice Deposit SDT: send PoL allocation as SDT, stake the remainder, mint 1 cyvlSDT per SDT.
    /// @dev The PoL principal is virtual benchmark principal, not redeemable vlSDT backing.
    function deposit(uint256 amount, address receiver) external configured nonReentrant returns (uint256 minted) {
        if (amount == 0) revert ZeroAmount();
        if (receiver == address(0)) revert ZeroAddress();
        SDT.safeTransferFrom(msg.sender, address(this), amount);
        // Floor(amount * shareBps / BPS) without overflowing a uint256 product.
        // shareBps <= 2,500: the quotient and remainder products both fit.
        uint256 shareBps = poLDepositShareBps;
        uint256 pol = (amount / BPS) * shareBps + ((amount % BPS) * shareBps) / BPS;
        if (pol != 0) {
            SDT.safeTransfer(cyvlSdtPoLContract, pol);
            emit PoLDepositSent(pol);
        }
        uint256 net = amount - pol;
        if (net == 0) revert InvalidStakeAmount();
        uint256 beforeBalance = VLSDT.balanceOf(address(this));
        VLSDT.stake(net, address(this));
        if (VLSDT.balanceOf(address(this)) - beforeBalance != net) revert InvalidStakeAmount();
        minted = amount;
        grossSDTPrincipalForBase += amount;
        emit BasePrincipalUpdated(grossSDTPrincipalForBase);
        CYVLSDT.mint(receiver, minted);
        emit Deposited(msg.sender, receiver, minted);
    }

    function baseSDTEquivalent(uint256 shares) external view returns (uint256) {
        uint256 supply = CYVLSDT.totalSupply();
        return supply == 0 ? 0 : Math.mulDiv(shares, grossSDTPrincipalForBase, supply);
    }

    /// @notice One claim operation for the SDT and USDC distributors and Aladdin.
    /// @dev A reverting Aladdin claim cannot block forwarding existing distributor/PoL income.
    function claimAndForwardRevenue() external configured nonReentrant returns (uint256 usdcSent, uint256 sdtSent) {
        address[] memory distributors = new address[](2);
        distributors[0] = address(VLSDT_FEE_DISTRIBUTOR_USDC);
        distributors[1] = address(VLSDT_FEE_DISTRIBUTOR_SDT);
        address[] memory tokens = new address[](2);
        tokens[0] = address(USDC_REWARD_TOKEN);
        tokens[1] = address(SDT);
        bytes[] memory calls = new bytes[](2);
        calls[0] = bytes.concat(bytes1(CLAIM_DISTRIBUTORS_MODULE), abi.encodeWithSelector(CLAIM_DISTRIBUTORS_SELECTOR, distributors));
        calls[1] = bytes.concat(bytes1(SWEEP_TOKENS_MODULE), abi.encodeWithSelector(SWEEP_TOKENS_SELECTOR, tokens));
        STAKE_DAO_ROUTER.execute(calls);
        try IAladdinVlSDTDelegation(ALADDIN_DELEGATION).claim(address(this), address(this)) returns (uint256) {} catch {}
        (usdcSent, sdtSent) = _forwardHeldRevenue();
        emit RevenueClaimed(usdcSent, sdtSent);
    }

    /// @notice Forward any SDT/USDC received from Merchant, Aladdin, PoL or direct transfers.
    function forwardRevenue() external configured nonReentrant returns (uint256 usdcSent, uint256 sdtSent) {
        return _forwardHeldRevenue();
    }

    /// @dev Merchant's pre-existing direct-lease interface; now uses the exact same generic forwarding path.
    function forwardMerchantRevenue(uint256 amount) external configured onlyMerchant nonReentrant {
        if (amount == 0) revert ZeroAmount();
        USDC_REWARD_TOKEN.safeTransferFrom(msg.sender, address(this), amount);
        _forwardHeldRevenue();
    }

    function _forwardHeldRevenue() private returns (uint256 usdc, uint256 sdt) {
        usdc = USDC_REWARD_TOKEN.balanceOf(address(this));
        sdt = SDT.balanceOf(address(this));
        if (usdc != 0) _notifyStaking(address(USDC_REWARD_TOKEN), usdc);
        if (sdt != 0) _notifyStaking(address(SDT), sdt);
    }

    function _notifyStaking(address token, uint256 amount) private {
        ICurveYieldvlSDTStaking(revenueStaking).notifyReward(token, amount);
        emit RevenueForwarded(token, amount);
    }

    function setMarketplaceOperator(bool approved) external onlyOwner {
        VLBOOST.setOperator(address(BOOST_MARKETPLACE), approved);
        emit MarketplaceOperatorSet(approved);
    }

    function _boostCapacity(uint256 bps) private view returns (uint256) {
        return Math.mulDiv(VLSDT.balanceOf(address(this)), bps, BPS);
    }
    function daoBoostAllocation() public view returns (uint256) { return _boostCapacity(DAO_BOOST_BPS); }
    function adminBoostAllocation() public view returns (uint256) { return _boostCapacity(ADMIN_BOOST_BPS); }
    function merchantBoostAllocation() public view returns (uint256) {
        return _boostCapacity(BPS - DAO_BOOST_BPS - ADMIN_BOOST_BPS);
    }
    function daoDelegableBoost() public view returns (uint256) {
        return _delegable(daoBoostAllocation(), daoCommittedBoost);
    }
    function adminDelegableBoost() public view returns (uint256) {
        return _delegable(adminBoostAllocation(), adminCommittedBoost);
    }
    function marketplaceCommittedBoost() public view returns (uint256) {
        return BOOST_MARKETPLACE.committedBalance(address(this));
    }
    function marketplaceFilledBoost() public view returns (uint256) {
        uint256 total = VLSDT.balanceOf(address(this));
        uint256 rawFree = VLBOOST.delegableBalance(address(this));
        uint256 delegated = total > rawFree ? total - rawFree : 0;
        uint256 recorded = daoCommittedBoost + adminCommittedBoost + merchantCommittedBoost;
        return delegated > recorded ? delegated - recorded : 0;
    }
    function merchantBoostUsed() public view returns (uint256) {
        return merchantCommittedBoost + marketplaceFilledBoost() + marketplaceCommittedBoost();
    }
    function merchantDelegableBoost() public view returns (uint256) {
        // One balance snapshot and one delegable snapshot, rather than two of each.
        uint256 total = VLSDT.balanceOf(address(this));
        uint256 free = VLBOOST.delegableBalance(address(this));
        uint256 cap = Math.mulDiv(total, BPS - DAO_BOOST_BPS - ADMIN_BOOST_BPS, BPS);
        uint256 delegated = total > free ? total - free : 0;
        uint256 recorded = daoCommittedBoost + adminCommittedBoost + merchantCommittedBoost;
        uint256 marketplaceFilled = delegated > recorded ? delegated - recorded : 0;
        uint256 used = merchantCommittedBoost + marketplaceFilled + marketplaceCommittedBoost();
        if (used >= cap) return 0;
        uint256 available = cap - used;
        return available < free ? available : free;
    }
    function _delegable(uint256 cap, uint256 used) private view returns (uint256) {
        if (used >= cap) return 0;
        uint256 left = cap - used;
        uint256 free = VLBOOST.delegableBalance(address(this));
        return left < free ? left : free;
    }
    function admin() public view returns (address) {
        return systemConfigured ? ICurveYieldvlSDTStaking(revenueStaking).admin() : address(0);
    }

    function _validateEndtime(uint256 endtime) private view {
        uint256 ceiling = Math.ceilDiv(block.timestamp + MAX_BOOST_DURATION_WEEKS * WEEK, WEEK) * WEEK;
        if (endtime <= block.timestamp || endtime > ceiling) revert InvalidBoostDuration();
    }

    function _record(mapping(uint256 => BoostCommitment) storage records, uint256 id, uint256 amount, uint256 endtime) private {
        if (amount > type(uint128).max || endtime > type(uint64).max) revert ValueTooLarge();
        records[id] = BoostCommitment(uint128(amount), uint64(endtime), true);
    }

    function _release(mapping(uint256 => BoostCommitment) storage records, uint256 id, uint8 lane) private returns (uint256 amount) {
        BoostCommitment storage c = records[id];
        if (!c.active) revert InvalidCommitment();
        if (block.timestamp < c.endtime) revert CommitmentNotExpired();
        c.active = false;
        amount = c.amount;
        emit BoostCommitmentReleased(lane, id, amount);
    }

    function delegateBoost(uint256 amount, uint256 endtime, address recipient)
        external configured onlyMerchant nonReentrant returns (uint256 id) {
        if (amount == 0) revert ZeroAmount();
        if (recipient == address(0)) revert ZeroAddress();
        _validateEndtime(endtime);
        if (amount > merchantDelegableBoost()) revert InsufficientBoostCapacity();
        id = nextMerchantBoostCommitmentId++;
        _record(merchantBoostCommitments, id, amount, endtime);
        merchantCommittedBoost += amount;
        if (recipient == ALADDIN_DELEGATION) {
            if (endtime % WEEK != 0) revert InvalidBoostDuration();
            if (!VLBOOST.isOperator(address(this), ALADDIN_DELEGATION))
                VLBOOST.setOperator(ALADDIN_DELEGATION, true);
            IAladdinVlSDTDelegation(ALADDIN_DELEGATION).boost(amount, endtime, address(this));
            emit AladdinBoostDelegated(id, amount, endtime);
        } else {
            VLBOOST.boost(address(this), amount, endtime, recipient);
        }
        emit BoostCommitmentCreated(1, id, amount, endtime);
        emit BoostDelegated(msg.sender, recipient, amount, endtime);
    }

    function delegateDaoBoost(uint256 amount, uint256 endtime, address recipient)
        external onlyOwner nonReentrant returns (uint256 id) {
        if (amount == 0) revert ZeroAmount();
        if (recipient == address(0)) revert ZeroAddress();
        _validateEndtime(endtime);
        if (amount > daoDelegableBoost()) revert InsufficientBoostCapacity();
        id = nextDaoBoostCommitmentId++;
        _record(daoBoostCommitments, id, amount, endtime);
        daoCommittedBoost += amount;
        VLBOOST.boost(address(this), amount, endtime, recipient);
        emit BoostCommitmentCreated(2, id, amount, endtime);
    }

    function delegateAdminBoost(uint256 amount, uint256 endtime, address recipient)
        external onlyAdmin nonReentrant returns (uint256 id) {
        if (amount == 0) revert ZeroAmount();
        if (recipient == address(0)) revert ZeroAddress();
        _validateEndtime(endtime);
        if (amount > adminDelegableBoost()) revert InsufficientBoostCapacity();
        id = nextAdminBoostCommitmentId++;
        _record(adminBoostCommitments, id, amount, endtime);
        adminCommittedBoost += amount;
        VLBOOST.boost(address(this), amount, endtime, recipient);
        emit BoostCommitmentCreated(3, id, amount, endtime);
    }

    function releaseMerchantBoostCommitment(uint256 id) external {
        merchantCommittedBoost -= _release(merchantBoostCommitments, id, 1);
    }
    function releaseDaoBoostCommitment(uint256 id) external {
        daoCommittedBoost -= _release(daoBoostCommitments, id, 2);
    }
    function releaseAdminBoostCommitment(uint256 id) external {
        adminCommittedBoost -= _release(adminBoostCommitments, id, 3);
    }

    function marketplaceCreateListing(uint256 amount, uint256 pricePerWeek, uint256 minDuration,
        uint256 maxDuration, address paymentToken, uint256 expiry)
        external configured onlyMerchant returns (uint256 listingId) {
        if (amount == 0) revert ZeroAmount();
        if (minDuration == 0 || maxDuration < minDuration || maxDuration > MAX_BOOST_DURATION_WEEKS)
            revert InvalidBoostDuration();
        if (amount > merchantDelegableBoost()) revert InsufficientBoostCapacity();
        listingId = BOOST_MARKETPLACE.createListing(amount, pricePerWeek, minDuration, maxDuration, paymentToken, expiry);
    }

    function marketplaceUpdateListing(uint256 listingId, uint256 newAmount, uint256 newPricePerWeek)
        external configured onlyMerchant {
        BOOST_MARKETPLACE.updateListing(listingId, newAmount, newPricePerWeek);
        if (merchantBoostUsed() > merchantBoostAllocation()) revert InsufficientBoostCapacity();
    }

    function marketplaceCancelListing(uint256 listingId) external configured onlyMerchant {
        BOOST_MARKETPLACE.cancelListing(listingId);
    }

    /// @notice DAO mode uses the same marketplace code path; only custody recipient/cap differ.
    /// @dev Merchant may call false; owner may call true. No separate DAO sale function.
    function marketplaceAcceptOffer(uint256 offerId, uint256 amount, uint256 minTotalPayment,
        uint256 maxEffectiveDuration, bool daoSale)
        external configured nonReentrant returns (uint256 revenue) {
        if (amount == 0) revert ZeroAmount();
        if (daoSale) {
            if (msg.sender != owner()) revert OnlyDaoOwner();
            if (amount > daoDelegableBoost()) revert InsufficientBoostCapacity();
        } else {
            if (msg.sender != boostMerchant) revert OnlyBoostMerchant();
            if (amount > merchantDelegableBoost()) revert InsufficientBoostCapacity();
        }
        IBoostMarketplace.BuyOffer memory offer = BOOST_MARKETPLACE.getOffer(offerId);
        if (offer.duration == 0 || offer.duration > MAX_BOOST_DURATION_WEEKS) revert InvalidBoostDuration();
        if (!daoSale && offer.paymentToken != address(USDC_REWARD_TOKEN) && offer.paymentToken != address(SDT))
            revert InvalidRevenueToken();
        uint256 beforeBalance = IERC20(offer.paymentToken).balanceOf(address(this));
        BOOST_MARKETPLACE.acceptOffer(offerId, amount, minTotalPayment, maxEffectiveDuration);
        revenue = IERC20(offer.paymentToken).balanceOf(address(this)) - beforeBalance;
        if (daoSale) {
            uint256 endtime = Math.ceilDiv(block.timestamp + uint256(offer.duration) * WEEK, WEEK) * WEEK;
            uint256 id = nextDaoBoostCommitmentId++;
            _record(daoBoostCommitments, id, amount, endtime);
            daoCommittedBoost += amount;
            if (revenue != 0) IERC20(offer.paymentToken).safeTransfer(treasuryReceiver, revenue);
            emit DaoMarketplaceRevenue(offer.paymentToken, revenue);
            emit BoostCommitmentCreated(2, id, amount, endtime);
        } else {
            _forwardHeldRevenue();
        }
    }
}
