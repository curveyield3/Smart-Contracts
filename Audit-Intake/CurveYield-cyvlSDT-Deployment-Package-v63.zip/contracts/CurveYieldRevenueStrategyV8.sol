// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable, Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ICurveYieldvlSDTStaking} from "./interfaces/ICurveYield.sol";
import {IStrategyBoostHubV1} from "./interfaces/IStrategyBoostHubV1.sol";
import {ICurveYieldOmniRouter} from "./interfaces/ICurveYieldOmniRouter.sol";
import {ICurveYieldvlSDTLocker} from "./interfaces/ICurveYield.sol";

interface IRevenueBeefyVault {
    function adminFeeReceiver() external view returns (address);
}

/// @notice cyvlSDT revenue-staking strategy for the shared BeefyVaultCurveYieldV8 vault.
contract CurveYieldRevenueStrategyV8 is
    IStrategyBoostHubV1,
    Ownable2Step,
    Pausable,
    ReentrancyGuard
{
    using SafeERC20 for IERC20;

    uint256 internal constant BPS = 10_000;
    uint256 public constant MAX_PERFORMANCE_FEE_BPS = 900;
    uint256 public constant MAX_CALL_FEE_BPS = 100;
    uint256 public constant MAX_TOTAL_HARVEST_FEE_BPS = 1_000;

    address public override vault;
    IERC20 public WANT;
    IERC20 public immutable SDT;
    ICurveYieldvlSDTStaking public REVENUE_STAKING;

    address public constant USDC = 0xA0b86991c6218b36c1d19d4a2e9eb0ce3606eb48;
    ICurveYieldOmniRouter public OMNI_ROUTER;
    ICurveYieldvlSDTLocker public LOCKER;

    uint16 public immutable performanceFeeBps;
    uint16 public immutable callFeeBps;

    struct PendingStrategyWithdrawal {
        uint256 grossAmount;
        uint256 reservedIdle;
        uint256 stakingRequestId;
        uint64 unlockTime;
    }
    uint256 public nextStrategyWithdrawalId = 1;
    uint256 public reservedWithdrawalAssets;
    mapping(uint256 => PendingStrategyWithdrawal) public pendingStrategyWithdrawals;

    error ZeroAddress();
    error ZeroAmount();
    error NotVault();
    error NotSelf();
    error InvalidFee();
    error InsufficientWithdrawable(uint256 requested, uint256 available);
    error InvalidWithdrawalRequest();
    error WithdrawalNotReady(uint256 unlockTime);

    event Deposit(uint256 amount);
    event Withdraw(uint256 requested, uint256 grossUnstaked, uint256 sent);
    event StrategyWithdrawalRequested(uint256 indexed id, uint256 amount, uint256 reservedIdle, uint256 stakingId, uint256 unlockTime);
    event StrategyWithdrawalCompleted(uint256 indexed id, uint256 amount);
    event StrategyWithdrawalExitedImmediately(uint256 indexed id, uint256 amount);
    event Harvest(address indexed caller, uint256 grossWant, uint256 callerFee, uint256 performanceFee);
    event WantRebound(address indexed previous,address indexed next);
    event VaultRebound(address indexed previous,address indexed next);
    event RevenueStakingRebound(address indexed previous,address indexed next);
    event LockerRebound(address indexed previous,address indexed next);
    event OmniRouterRebound(address indexed previous,address indexed next);

    constructor(
        address initialOwner_,
        address vault_,
        address want_,
        address sdt_,
        address revenueStaking_,
        address locker_,
        address omniRouter_,
        uint16 performanceFeeBps_,
        uint16 callFeeBps_
    ) Ownable(initialOwner_) {
        if (
            initialOwner_ == address(0) || vault_ == address(0) || want_ == address(0)
                || sdt_ == address(0)
                || revenueStaking_ == address(0) || locker_ == address(0) || omniRouter_ == address(0)
        ) revert ZeroAddress();
        if (
            performanceFeeBps_ > MAX_PERFORMANCE_FEE_BPS
                || callFeeBps_ > MAX_CALL_FEE_BPS
                || uint256(performanceFeeBps_) + uint256(callFeeBps_) > MAX_TOTAL_HARVEST_FEE_BPS
        ) revert InvalidFee();
        vault = vault_;
        WANT = IERC20(want_);
        SDT = IERC20(sdt_);
        REVENUE_STAKING = ICurveYieldvlSDTStaking(revenueStaking_);
        LOCKER = ICurveYieldvlSDTLocker(locker_);
        OMNI_ROUTER = ICurveYieldOmniRouter(omniRouter_);
        performanceFeeBps = performanceFeeBps_;
        callFeeBps = callFeeBps_;
        WANT.forceApprove(revenueStaking_, type(uint256).max);
        SDT.forceApprove(locker_, type(uint256).max);
        IERC20(USDC).forceApprove(omniRouter_, type(uint256).max);
    }

    modifier onlyVault() {
        if (msg.sender != vault) revert NotVault();
        _;
    }

    modifier onlySelf() {
        if (msg.sender != address(this)) revert NotSelf();
        _;
    }

    /// @notice Rebind this strategy's asset reference.
    function setWant(address next) external onlyOwner {
        if (next == address(0)) revert ZeroAddress();
        address previous = address(WANT);
        if (previous != next) {
            WANT.forceApprove(address(REVENUE_STAKING), 0);
            IERC20(next).forceApprove(address(REVENUE_STAKING), type(uint256).max);
        }
        emit WantRebound(previous, next);
        WANT = IERC20(next);
    }

    function setVault(address next) external onlyOwner {
        emit VaultRebound(vault, next);
        vault = next;
    }

    function setRevenueStaking(address next) external onlyOwner {
        if (next == address(0)) revert ZeroAddress();
        address previous = address(REVENUE_STAKING);
        if (previous != next) {
            WANT.forceApprove(previous, 0);
            WANT.forceApprove(next, type(uint256).max);
        }
        emit RevenueStakingRebound(previous, next);
        REVENUE_STAKING = ICurveYieldvlSDTStaking(next);
    }

    function setLocker(address next) external onlyOwner {
        if (next == address(0)) revert ZeroAddress();
        address previous = address(LOCKER);
        if (previous != next) {
            SDT.forceApprove(previous, 0);
            SDT.forceApprove(next, type(uint256).max);
        }
        emit LockerRebound(previous, next);
        LOCKER = ICurveYieldvlSDTLocker(next);
    }

    function setOmniRouter(address next) external onlyOwner {
        if (next == address(0)) revert ZeroAddress();
        address previous = address(OMNI_ROUTER);
        if (previous != next) {
            IERC20(USDC).forceApprove(previous, 0);
            IERC20(USDC).forceApprove(next, type(uint256).max);
        }
        emit OmniRouterRebound(previous, next);
        OMNI_ROUTER = ICurveYieldOmniRouter(next);
    }

    function want() external view override returns (address) {
        return address(WANT);
    }

    /// @notice Beefy V8 transfers cyvlSDT to the strategy before calling deposit().
    function deposit() external override onlyVault whenNotPaused {
        _depositIdle();
    }

    /// @notice Withdraw the exact amount requested by Beefy V8, including unreserved idle cyvlSDT.
    /// @dev Both strategy NAV and gross-up read the current staking exit fee;
    ///      only the vault charges its separate shareholder-retained fee.
    function withdraw(uint256 amount) external override onlyVault nonReentrant {
        _withdraw(amount);
    }

    /// @dev Beefy V8 emergencyWithdraw() dispatches this selector. The revenue strategy
    ///      has no Curve output guard to bypass, so settle through the same principal path.
    function emergencyWithdraw(uint256 amount) external onlyVault nonReentrant {
        _withdraw(amount);
    }

    function _withdraw(uint256 amount) internal {
        if (amount == 0) return;
        uint256 idle = _unreservedIdle();
        uint256 unstaked;
        if (idle < amount) {
            uint256 needed = amount - idle;
            uint256 active = REVENUE_STAKING.activeBalance(address(this));
            uint256 fee = immediateWithdrawFeePpm();
            // Same floor rounding as the staking contract's previewImmediateWithdrawal.
            // One backend fee read replaces separate preview and fee external calls.
            uint256 maxNet = fee >= 1_000_000 ? 0 : active - Math.mulDiv(active, fee, 1_000_000);
            if (needed > maxNet) revert InsufficientWithdrawable(needed, maxNet);
            // No fee when the configured staking fee is zero; otherwise round up
            // the staked amount so the vault receives its requested net amount.
            unstaked = Math.mulDiv(needed, 1_000_000, 1_000_000 - fee, Math.Rounding.Ceil);
            if (unstaked > active) unstaked = active;
            REVENUE_STAKING.withdrawImmediate(unstaked, address(this));
        }
        WANT.safeTransfer(vault, amount);
        emit Withdraw(amount, unstaked, amount);
    }

    /// @notice Gross principal currently available through a seven-day fee-free
    ///         staking queue, excluding other users' pending queue reservations.
    function grossBalanceOf() external view returns (uint256) {
        return _unreservedIdle() + REVENUE_STAKING.activeBalance(address(this));
    }

    /// @notice Read the exact live rate used for the staking backend's instant withdrawals.
    function immediateWithdrawFeePpm() public view returns (uint256) {
        return uint256(REVENUE_STAKING.immediateWithdrawFeePpm());
    }

    /// @notice Reserve idle cyvlSDT and queue only the staked remainder, free of the instant fee.
    function requestWithdrawal(uint256 amount)
        external onlyVault nonReentrant returns (uint256 requestId, uint256 unlockTime)
    {
        if (amount == 0) revert ZeroAmount();
        uint256 idle = _unreservedIdle();
        uint256 reservedIdle = idle < amount ? idle : amount;
        uint256 remaining = amount - reservedIdle;
        uint256 stakingId;
        if (remaining != 0) {
            stakingId = REVENUE_STAKING.requestWithdrawal(remaining);
            (address owner_, uint128 staked, uint64 unlockedAt, bool completed) =
                REVENUE_STAKING.withdrawalRequests(stakingId);
            if (owner_ != address(this) || staked != remaining || completed) revert InvalidWithdrawalRequest();
            unlockTime = unlockedAt;
        } else {
            unlockTime = block.timestamp + REVENUE_STAKING.WITHDRAWAL_DELAY();
        }
        if (reservedIdle != 0) reservedWithdrawalAssets += reservedIdle;
        requestId = nextStrategyWithdrawalId++;
        pendingStrategyWithdrawals[requestId] = PendingStrategyWithdrawal(
            amount, reservedIdle, stakingId, uint64(unlockTime)
        );
        emit StrategyWithdrawalRequested(requestId, amount, reservedIdle, stakingId, unlockTime);
    }

    /// @notice Return the queued full-principal amount to the vault after cooldown.
    function completeWithdrawal(uint256 requestId)
        external onlyVault nonReentrant returns (uint256 received)
    {
        return _settleQueuedWithdrawal(requestId, false);
    }

    /// @notice Settle an outstanding queued request immediately using staking's live fee.
    function withdrawPendingInstant(uint256 requestId)
        external onlyVault nonReentrant returns (uint256 received)
    {
        return _settleQueuedWithdrawal(requestId, true);
    }

    /// @dev One settlement path for queued and immediate exits. Always delete the
    ///      consumed request before making external calls; preserve event identity.
    function _settleQueuedWithdrawal(uint256 requestId, bool immediate)
        private returns (uint256 received)
    {
        PendingStrategyWithdrawal memory p = pendingStrategyWithdrawals[requestId];
        if (p.grossAmount == 0) revert InvalidWithdrawalRequest();
        if (!immediate && block.timestamp < p.unlockTime) revert WithdrawalNotReady(p.unlockTime);
        delete pendingStrategyWithdrawals[requestId];
        if (p.reservedIdle != 0) reservedWithdrawalAssets -= p.reservedIdle;
        received = p.reservedIdle;
        if (p.stakingRequestId != 0) {
            if (immediate) {
                received += REVENUE_STAKING.withdrawQueuedImmediate(p.stakingRequestId, address(this));
            } else {
                received += REVENUE_STAKING.completeQueuedWithdrawal(p.stakingRequestId, address(this));
            }
        }
        if (received != 0) WANT.safeTransfer(vault, received);
        if (immediate) emit StrategyWithdrawalExitedImmediately(requestId, received);
        else emit StrategyWithdrawalCompleted(requestId, received);
    }

    function _unreservedIdle() internal view returns (uint256) {
        return WANT.balanceOf(address(this)) - reservedWithdrawalAssets;
    }

    /// @notice Beefy V8 reinvests the portion of its withdrawal fee retained for shareholders.
    /// @dev Retained cyvlSDT stays idle and is included in balanceOf(); no duplicate fee is taken.
    function lockVaultProfit(uint256) external override onlyVault {}

    function harvest() external nonReentrant whenNotPaused returns (uint256 grossWant) {
        grossWant = _harvest(msg.sender);
    }

    function harvest(address callFeeRecipient) external nonReentrant whenNotPaused returns (uint256 grossWant) {
        if (callFeeRecipient == address(0)) revert ZeroAddress();
        grossWant = _harvest(callFeeRecipient);
    }

    function balanceOf() public view override returns (uint256) {
        // Price active stake at its currently instant-withdrawable net value.
        // Exclude reserved idle and queued principal: those belong to burned shares.
        return _unreservedIdle()
            + REVENUE_STAKING.previewImmediateWithdrawal(REVENUE_STAKING.activeBalance(address(this)));
    }

    function estimatedTokenAprBps() external pure returns (uint256) {
        return 0;
    }

    /// @notice Conservatively value rewards before they are actually harvested.
    /// @dev Does not require a not-yet-configured USDC->SDT or SDT->cyvlSDT route.
    ///      Unavailable USDC pricing contributes zero rather than blocking vault deposits.
    function estimatedUnharvestedWant() external view returns (uint256 estimatedWant) {
        uint256 count = REVENUE_STAKING.rewardTokenCount();
        bool sdtObserved;
        for (uint256 i; i < count; ++i) {
            address token = REVENUE_STAKING.rewardTokens(i);
            if (token == address(0)) continue;
            uint256 held = token == address(WANT) ? 0 : IERC20(token).balanceOf(address(this));
            uint256 amount = REVENUE_STAKING.earned(address(this), token) + held;
            if (amount == 0) continue;
            if (token == address(WANT) || token == address(SDT)) {
                // The Locker issues 1 cyvlSDT per input SDT, even when it diverts a PoL share.
                estimatedWant += amount;
                if (token == address(SDT)) sdtObserved = true;
            } else if (token == USDC) {
                try OMNI_ROUTER.guardedMinOut(USDC, address(SDT), amount) returns (uint256 quotedSdt) {
                    estimatedWant += quotedSdt;
                } catch {}
            }
        }
        if (!sdtObserved) {
            uint256 heldSdt = SDT.balanceOf(address(this));
            estimatedWant += heldSdt;
        }
    }

    function panic() external onlyOwner nonReentrant {
        _pause();
        uint256 active = REVENUE_STAKING.activeBalance(address(this));
        if (active != 0) REVENUE_STAKING.withdrawImmediate(active, address(this));
    }

    function pause() external onlyOwner {
        _pause();
    }

    function unpause() external onlyOwner {
        _unpause();
        _depositIdle();
    }

    function _harvest(address callFeeRecipient) internal returns (uint256 grossWant) {
        uint256 beforeWant = WANT.balanceOf(address(this));
        REVENUE_STAKING.claimRewardsSelf();

        uint256 count = REVENUE_STAKING.rewardTokenCount();
        bool convertUSDC;
        for (uint256 i; i < count; ++i) {
            address token = REVENUE_STAKING.rewardTokens(i);
            if (token == USDC && token != address(WANT)) convertUSDC = true;
            // SDT and unknown assets remain untouched until the single conversion below.
        }
        if (convertUSDC) _convertHeldUSDC();
        // Deposit SDT received directly and from the guarded USDC swap exactly once.
        _depositHeldSDT();

        uint256 afterWant = WANT.balanceOf(address(this));
        grossWant = afterWant - beforeWant;
        uint256 callerFee;
        uint256 performanceFee;
        if (grossWant != 0) {
            if (callFeeRecipient != address(0) && callFeeBps != 0) {
                callerFee = Math.mulDiv(grossWant, callFeeBps, BPS);
                if (callerFee != 0) WANT.safeTransfer(callFeeRecipient, callerFee);
            }
            if (performanceFeeBps != 0) {
                performanceFee = Math.mulDiv(grossWant, performanceFeeBps, BPS);
                if (performanceFee != 0) WANT.safeTransfer(IRevenueBeefyVault(vault).adminFeeReceiver(), performanceFee);
            }
        }
        _depositIdle();
        emit Harvest(callFeeRecipient, grossWant, callerFee, performanceFee);
    }

    function _convertHeldUSDC() internal {
        uint256 amount = IERC20(USDC).balanceOf(address(this));
        if (amount == 0) return;
        uint256 guarded;
        try OMNI_ROUTER.guardedMinOut(USDC, address(SDT), amount) returns (uint256 minimum) {
            guarded = minimum;
        } catch { return; } // Missing route is non-blocking and leaves USDC liquid.
        if (guarded == 0) return;
        try OMNI_ROUTER.swapExactInput(
            USDC, address(SDT), amount, guarded, address(this), block.timestamp
        ) returns (uint256) {} catch { return; }
    }

    function _depositHeldSDT() internal {
        uint256 amount = SDT.balanceOf(address(this));
        if (amount == 0) return;
        LOCKER.deposit(amount, address(this));
    }

    function _depositIdle() internal {
        uint256 amount = _unreservedIdle();
        if (amount == 0) return;
        REVENUE_STAKING.stake(amount);
        emit Deposit(amount);
    }



}
