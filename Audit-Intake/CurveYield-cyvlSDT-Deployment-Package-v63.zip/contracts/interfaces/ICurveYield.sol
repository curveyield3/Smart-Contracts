// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

interface ICurveYieldVlSDTToken {
    function mint(address receiver, uint256 amount) external;
    function balanceOf(address account) external view returns (uint256);
    function totalSupply() external view returns (uint256);
}

interface ICurveYieldvlSDTStaking {
    function admin() external view returns (address);
    function notifyReward(address token, uint256 amount) external;
    function stake(uint256 amount) external;
    function immediateWithdrawFeePpm() external view returns (uint32);
    function previewImmediateWithdrawal(uint256 amount) external view returns (uint256 received);
    function withdrawImmediate(uint256 amount, address receiver) external returns (uint256 received);
    function requestWithdrawal(uint256 amount) external returns (uint256 id);
    function completeQueuedWithdrawal(uint256 id, address receiver) external returns (uint256 amount);
    function withdrawQueuedImmediate(uint256 id, address receiver) external returns (uint256 received);
    function WITHDRAWAL_DELAY() external view returns (uint256);
    function queuedBalance(address user) external view returns (uint256);
    function withdrawalRequests(uint256 id)
        external
        view
        returns (address owner, uint128 amount, uint64 unlockTime, bool completed);
    function claimRewardsSelf() external;
    function activeBalance(address user) external view returns (uint256);
    function rewardTokenCount() external view returns (uint256);
    function rewardTokens(uint256 index) external view returns (address);
    function earned(address user, address token) external view returns (uint256);
    function isRewardToken(address token) external view returns (bool);
}

interface ICurveYieldvlSDTLocker {
    function deposit(uint256 amount, address receiver) external returns (uint256 minted);
    function poLDepositShareBps() external view returns (uint16);
    function cyvlSdtPoLContract() external view returns (address);
    function baseSDTEquivalent(uint256 shares) external view returns (uint256);
    function forwardMerchantRevenue(uint256 amount) external;
    function claimAndForwardRevenue() external returns (uint256 usdcSent, uint256 sdtSent);
    function delegateBoost(uint256 amount, uint256 endtime, address recipient) external returns (uint256 commitmentId);
    function releaseMerchantBoostCommitment(uint256 id) external;
    function merchantDelegableBoost() external view returns (uint256);
    function daoBoostAllocation() external view returns (uint256);
    function daoDelegableBoost() external view returns (uint256);
    function adminBoostAllocation() external view returns (uint256);
    function adminDelegableBoost() external view returns (uint256);
    function marketplaceCreateListing(uint256 amount, uint256 pricePerWeek, uint256 minDuration,
        uint256 maxDuration, address paymentToken, uint256 expiry) external returns (uint256 listingId);
    function marketplaceUpdateListing(uint256 listingId, uint256 newAmount, uint256 newPricePerWeek) external;
    function marketplaceCancelListing(uint256 listingId) external;
    function marketplaceAcceptOffer(uint256 offerId, uint256 fillAmount, uint256 minTotalPayment,
        uint256 maxEffectiveDuration, bool daoSale) external returns (uint256 revenueAmount);
}
