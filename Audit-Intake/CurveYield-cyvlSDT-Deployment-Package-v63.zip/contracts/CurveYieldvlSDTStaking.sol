// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable, Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {ICurveYieldOmniRouter} from "./interfaces/ICurveYieldOmniRouter.sol";

interface IStakingEpochDistributor {
    function tokensPerEpoch(uint256 epoch) external view returns (uint256);
    function lastTokenTime() external view returns (uint256);
}
interface IStakingVlSDT {
    function totalSupplyAt(uint256 epoch) external view returns (uint256);
}
interface IStakingLocker {
    function deposit(uint256 amount, address receiver) external returns (uint256 minted);
    function baseSDTEquivalent(uint256 shares) external view returns (uint256);
    function cyvlSdtPoLContract() external view returns (address);
}


contract CurveYieldvlSDTStaking is Ownable2Step, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint16 public constant MAX_LP_BRIBE_REVENUE_SHARE_BPS = 1_500;
    uint256 public constant STREAM_DURATION = 7 days;
    uint256 public constant WEEK = 7 days;
    uint256 public constant WITHDRAWAL_DELAY = 7 days;
    uint256 public constant MAX_IMMEDIATE_WITHDRAW_FEE_PPM = 35_000;
    uint256 public constant FEE_PPM = 1_000_000;
    uint256 public constant FIRST_EXCESS_TREASURY_BPS = 1_500;
    uint256 public constant FIRST_EXCESS_ADMIN_BPS = 500;
    uint256 public constant FIRST_EXCESS_POL_BPS = 500;
    uint256 public constant SECOND_EXCESS_TREASURY_BPS = 2_000;
    uint256 public constant SECOND_EXCESS_ADMIN_BPS = 1_000;
    uint256 public constant SECOND_EXCESS_POL_BPS = 1_000;
    uint256 public constant BPS = 10_000;
    uint256 public constant PRECISION = 1e27;
    uint256 public constant MAX_REWARD_TOKENS = 8;

    struct Stream {
        uint256 amount;
        uint64 start;
        uint64 end;
    }

    struct RewardData {
        uint256 rewardPerActiveStored;
        uint256 scaledRemainder;
        uint64 lastUpdate;
        uint64 streamHead;
        Stream[] streams;
    }

    struct WithdrawalRequest {
        address owner;
        uint128 amount;
        uint64 unlockTime;
        bool completed;
    }

    IERC20 public CYVLSDT;
    IERC20 public immutable SDT;
    IERC20 public immutable USDC;
    IStakingVlSDT public immutable VLSDT;
    IStakingEpochDistributor public immutable SDT_DISTRIBUTOR;
    IStakingEpochDistributor public immutable USDC_DISTRIBUTOR;
    ICurveYieldOmniRouter public OMNI_ROUTER;
    address public LOCKER;
    address public treasuryReceiver;
    address public lpBribeContract;
    uint16 public lpBribeRevenueShareBps;
    address public admin;
    uint32 public immediateWithdrawFeePpm = 31_250; // 3.125%; max 3.5%

    address[] public rewardTokens;
    mapping(address => bool) public isRewardToken;
    mapping(address => RewardData) internal _rewardData;

    uint256 public totalActiveStake;
    uint256 public totalQueuedStake;
    mapping(address => uint256) public activeBalance;
    mapping(address => uint256) public queuedBalance;
    mapping(address => mapping(address => uint256)) public userRewardPerTokenPaid;
    mapping(address => mapping(address => uint256)) public accruedRewards;

    // Cumulative weekly income avoids granting the same base entitlement twice.
    // The last fully checkpointed source epoch is frozen on the FIRST receipt of each week.
    struct EpochAccounting {
        bool initialized;
        uint256 benchmark;
        uint256 received;
        uint256 baseAllocated;
        uint256 firstExcessAllocated;
        uint256 eligibleFirstExcess;
        uint256 eligibleSecondExcess;
        uint256 treasuryAllocated;
        uint256 adminAllocated;
        uint256 poLAllocated;
        uint256 benchmarkSourceEpoch;
    }
    mapping(address => mapping(uint256 => EpochAccounting)) public epochAccounting;

    // One conversion record per receipt, ensuring independent cyvlSDT streams after conversion.
    struct PendingConversion {
        address token;
        uint256 amount;
        bool converted;
    }
    PendingConversion[] public pendingConversions;
    // PoL rewards can be accounted before the PoL recipient is deployed/configured.
    // They remain escrowed in their original token until explicitly forwarded.
    mapping(address => uint256) public pendingPoLRevenue;

    uint256 public nextWithdrawalId = 1;
    mapping(uint256 => WithdrawalRequest) public withdrawalRequests;

    error ZeroAddress();
    error ZeroAmount();
    error RewardTokenAlreadyAdded();
    error RewardTokenLimit();
    error NotNotifier();
    error UnsupportedRewardToken();
    error InsufficientStake();
    error InvalidWithdrawalRequest();
    error WithdrawalNotReady();
    error ValueTooLarge();
    error NonExactRewardTransfer(uint256 expected, uint256 received);
    error NoPendingExcess();
    error InvalidConversion();
    error ConversionRouteUnavailable();
    error InvalidUnderlyingToken();
    error OnlyAdmin();
    error InvalidImmediateWithdrawFee();
    error InvalidRevenueShare();

    event RewardTokenAdded(address indexed token);
    event Staked(address indexed user, uint256 amount);
    event ImmediateWithdrawal(address indexed user, address indexed receiver, uint256 amount, uint256 fee);
    event WithdrawalRequested(uint256 indexed id, address indexed user, uint256 amount, uint256 unlockTime);
    event QueuedWithdrawalCompleted(uint256 indexed id, address indexed user, address indexed receiver, uint256 amount);
    event QueuedWithdrawalExitedImmediately(
        uint256 indexed id, address indexed user, address indexed receiver, uint256 amount, uint256 fee
    );
    event RewardStreamStarted(address indexed token, uint256 amount, uint256 startTime, uint256 endTime);
    event EpochIncomeApplied(address indexed token, uint256 indexed epoch, uint256 sourceEpoch,
        uint256 received, uint256 base, uint256 firstExcess, uint256 secondExcess,
        uint256 treasury, uint256 admin, uint256 poL, uint256 stakerExcess);
    event ExcessQueued(uint256 indexed id, address indexed token, uint256 amount);
    event ExcessConverted(uint256 indexed id, uint256 amountIn, uint256 cyvlSdtOut);
    event RewardClaimed(address indexed user, address indexed token, address indexed receiver, uint256 amount);
    event ImmediateTreasuryReward(address indexed token, uint256 amount);
    event ImmediateAdminReward(address indexed token, address indexed receiver, uint256 amount);
    event PoLRevenueForwarded(address indexed token, address indexed recipient, uint256 amount);
    event PoLRevenueEscrowed(address indexed token, uint256 amount);
    event TreasuryReceiverSet(address indexed oldReceiver, address indexed newReceiver);
    event AdminSet(address indexed oldAdmin, address indexed newAdmin);
    event ImmediateWithdrawFeeSet(uint256 oldFeePpm, uint256 newFeePpm);
    event LpBribeRevenueShareSet(uint16 shareBps, address indexed bribeContract);
    event LpBribeRevenueSent(address indexed token, uint256 amount);
    event LockerRebound(address indexed previous, address indexed next);
    event CyvlSDTRebound(address indexed previous, address indexed next);
    event OmniRouterRebound(address indexed previous, address indexed next);

    constructor(
        address initialOwner_,
        address initialAdmin_,
        address initialTreasuryReceiver_,
        address cyvlSdt_,
        address sdt_,
        address usdc_,
        address locker_,
        address vlSdt_,
        address sdtDistributor_,
        address usdcDistributor_,
        address omniRouter_
    ) Ownable(initialOwner_) {
        if (
            initialOwner_ == address(0) || initialAdmin_ == address(0)
                || initialTreasuryReceiver_ == address(0)
                || cyvlSdt_ == address(0) || sdt_ == address(0) || usdc_ == address(0)
                || locker_ == address(0) || vlSdt_ == address(0)
                || sdtDistributor_ == address(0) || usdcDistributor_ == address(0)
                || omniRouter_ == address(0)
        ) revert ZeroAddress();
        treasuryReceiver = initialTreasuryReceiver_;
        admin = initialAdmin_;
        CYVLSDT = IERC20(cyvlSdt_);
        SDT = IERC20(sdt_);
        USDC = IERC20(usdc_);
        LOCKER = locker_;
        VLSDT = IStakingVlSDT(vlSdt_);
        SDT_DISTRIBUTOR = IStakingEpochDistributor(sdtDistributor_);
        USDC_DISTRIBUTOR = IStakingEpochDistributor(usdcDistributor_);
        OMNI_ROUTER = ICurveYieldOmniRouter(omniRouter_);
        // These approvals are set once, not on every excess conversion.
        USDC.forceApprove(omniRouter_, type(uint256).max);
        SDT.forceApprove(locker_, type(uint256).max);
        emit TreasuryReceiverSet(address(0), initialTreasuryReceiver_);
        emit AdminSet(address(0), initialAdmin_);
    }

    modifier onlyAdmin() {
        if (msg.sender != admin) revert OnlyAdmin();
        _;
    }

    /// @notice Change the locker address.
    function setLocker(address next) external onlyOwner {
        address previous = LOCKER;
        if (previous != next) {
            SDT.forceApprove(previous, 0);
            if (next != address(0)) SDT.forceApprove(next, type(uint256).max);
            LOCKER = next;
        }
        emit LockerRebound(previous, next);
    }

    /// @notice Change the staking token; existing user stake accounting stays in this contract.
    function setCyvlSDT(address next) external onlyOwner {
        emit CyvlSDTRebound(address(CYVLSDT), next);
        CYVLSDT = IERC20(next);
    }

    function setOmniRouter(address next) external onlyOwner {
        address previous = address(OMNI_ROUTER);
        if (previous != next) {
            USDC.forceApprove(previous, 0);
            if (next != address(0)) USDC.forceApprove(next, type(uint256).max);
            OMNI_ROUTER = ICurveYieldOmniRouter(next);
        }
        emit OmniRouterRebound(previous, next);
    }

    /// @notice The sole pre-tier LP-bribe diversion; Locker only delivers gross rewards.
    function setLpBribeRevenueShare(uint16 shareBps, address bribeContract) external onlyOwner {
        if (shareBps > MAX_LP_BRIBE_REVENUE_SHARE_BPS) revert InvalidRevenueShare();
        if (shareBps != 0 && bribeContract == address(0)) revert ZeroAddress();
        lpBribeRevenueShareBps = shareBps;
        lpBribeContract = bribeContract;
        emit LpBribeRevenueShareSet(shareBps, bribeContract);
    }

    function setTreasuryReceiver(address newReceiver) external onlyOwner {
        if (newReceiver == address(0)) revert ZeroAddress();
        emit TreasuryReceiverSet(treasuryReceiver, newReceiver);
        treasuryReceiver = newReceiver;
    }

    function setAdmin(address newAdmin) external onlyAdmin {
        if (newAdmin == address(0)) revert ZeroAddress();
        emit AdminSet(admin, newAdmin);
        admin = newAdmin;
    }

    function setImmediateWithdrawFeePpm(uint32 newFeePpm) external onlyOwner {
        if (newFeePpm > MAX_IMMEDIATE_WITHDRAW_FEE_PPM) revert InvalidImmediateWithdrawFee();
        emit ImmediateWithdrawFeeSet(immediateWithdrawFeePpm, newFeePpm);
        immediateWithdrawFeePpm = newFeePpm;
    }

    function previewImmediateWithdrawal(uint256 amount) public view returns (uint256 received) {
        received = amount - Math.mulDiv(amount, immediateWithdrawFeePpm, FEE_PPM);
    }

    function addRewardToken(address token) external onlyOwner {
        if (token == address(0)) revert ZeroAddress();
        if (isRewardToken[token]) revert RewardTokenAlreadyAdded();
        if (rewardTokens.length >= MAX_REWARD_TOKENS) revert RewardTokenLimit();
        isRewardToken[token] = true;
        rewardTokens.push(token);
        _rewardData[token].lastUpdate = uint64(block.timestamp);
        emit RewardTokenAdded(token);
    }

    function rewardTokenCount() external view returns (uint256) {
        return rewardTokens.length;
    }

    function streamCount(address token) external view returns (uint256) {
        return _rewardData[token].streams.length;
    }

    function getStream(address token, uint256 index) external view returns (Stream memory) {
        return _rewardData[token].streams[index];
    }

    function pendingConversionCount() external view returns (uint256) {
        return pendingConversions.length;
    }

    function stake(uint256 amount) external nonReentrant {
        if (amount == 0) revert ZeroAmount();
        _checkpointAll(msg.sender);
        CYVLSDT.safeTransferFrom(msg.sender, address(this), amount);
        activeBalance[msg.sender] += amount;
        totalActiveStake += amount;
        emit Staked(msg.sender, amount);
    }

    function withdrawImmediate(uint256 amount, address receiver)
        external
        nonReentrant
        returns (uint256 received)
    {
        if (amount == 0) revert ZeroAmount();
        if (receiver == address(0)) revert ZeroAddress();
        _checkpointAll(msg.sender);
        uint256 staked = activeBalance[msg.sender];
        if (staked < amount) revert InsufficientStake();

        activeBalance[msg.sender] = staked - amount;
        totalActiveStake -= amount;
        received = previewImmediateWithdrawal(amount);
        uint256 fee = amount - received;
        if (fee != 0) CYVLSDT.safeTransfer(treasuryReceiver, fee);
        CYVLSDT.safeTransfer(receiver, received);
        emit ImmediateWithdrawal(msg.sender, receiver, amount, fee);
    }

    function requestWithdrawal(uint256 amount) external nonReentrant returns (uint256 id) {
        if (amount == 0) revert ZeroAmount();
        _checkpointAll(msg.sender);
        uint256 staked = activeBalance[msg.sender];
        if (staked < amount) revert InsufficientStake();

        activeBalance[msg.sender] = staked - amount;
        totalActiveStake -= amount;
        queuedBalance[msg.sender] += amount;
        totalQueuedStake += amount;

        if (amount > type(uint128).max) revert ValueTooLarge();
        id = nextWithdrawalId++;
        uint64 unlockTime = uint64(block.timestamp + WITHDRAWAL_DELAY);
        withdrawalRequests[id] = WithdrawalRequest(msg.sender, uint128(amount), unlockTime, false);
        emit WithdrawalRequested(id, msg.sender, amount, unlockTime);
    }

    function completeQueuedWithdrawal(uint256 id, address receiver)
        external
        nonReentrant
        returns (uint256 amount)
    {
        if (receiver == address(0)) revert ZeroAddress();
        WithdrawalRequest storage request = withdrawalRequests[id];
        if (request.owner != msg.sender || request.completed || request.amount == 0) {
            revert InvalidWithdrawalRequest();
        }
        if (block.timestamp < request.unlockTime) revert WithdrawalNotReady();

        // Active stake was removed at request time; only global streaming needs a checkpoint.
        _checkpointAll(address(0));
        request.completed = true;
        amount = request.amount;
        queuedBalance[msg.sender] -= amount;
        totalQueuedStake -= amount;
        CYVLSDT.safeTransfer(receiver, amount);
        emit QueuedWithdrawalCompleted(id, msg.sender, receiver, amount);
    }

    /// @notice Cancels a queued withdrawal and exits it immediately using the current immediate-withdraw fee.
    /// @dev A zero configured immediate fee naturally produces a full-value instant exit.
    function withdrawQueuedImmediate(uint256 id, address receiver)
        external
        nonReentrant
        returns (uint256 received)
    {
        if (receiver == address(0)) revert ZeroAddress();
        WithdrawalRequest storage request = withdrawalRequests[id];
        if (request.owner != msg.sender || request.completed || request.amount == 0) {
            revert InvalidWithdrawalRequest();
        }

        // Preserve treasury processing without rewriting unchanged user accruals.
        _checkpointAll(address(0));
        request.completed = true;
        uint256 amount = request.amount;
        queuedBalance[msg.sender] -= amount;
        totalQueuedStake -= amount;

        received = previewImmediateWithdrawal(amount);
        uint256 fee = amount - received;
        if (fee != 0) CYVLSDT.safeTransfer(treasuryReceiver, fee);
        CYVLSDT.safeTransfer(receiver, received);
        emit QueuedWithdrawalExitedImmediately(id, msg.sender, receiver, amount, fee);
    }

    /// @notice Accept post-bribe revenue from the Locker, split by weekly totals.
    /// @dev Each notification is a separate base stream; excess is separately converted to cyvlSDT.
    function notifyReward(address token, uint256 amount) external nonReentrant {
        if (msg.sender != LOCKER) revert NotNotifier();
        if (token != address(SDT) && token != address(USDC)) revert InvalidUnderlyingToken();
        if (amount == 0) revert ZeroAmount();

        uint256 prior = IERC20(token).balanceOf(address(this));
        IERC20(token).safeTransferFrom(msg.sender, address(this), amount);
        uint256 credited = IERC20(token).balanceOf(address(this)) - prior;
        if (credited != amount) revert NonExactRewardTransfer(amount, credited);

        // Apply the LP-bribe share exactly once, before weekly base/excess tier accounting.
        uint256 bribeAmount = Math.mulDiv(amount, lpBribeRevenueShareBps, BPS);
        if (bribeAmount != 0) {
            IERC20(token).safeTransfer(lpBribeContract, bribeAmount);
            emit LpBribeRevenueSent(token, bribeAmount);
            amount -= bribeAmount;
            if (amount == 0) return;
        }

        // Even a receipt with zero active stakers counts toward the weekly gross
        // tier thresholds. The preexisting no-staker treasury policy remains.
        bool noActiveStake = totalActiveStake == 0;
        uint256 epoch = (block.timestamp / WEEK) * WEEK;
        EpochAccounting storage e = epochAccounting[token][epoch];
        if (!e.initialized) {
            e.initialized = true;
            IStakingEpochDistributor d = token == address(SDT) ? SDT_DISTRIBUTOR : USDC_DISTRIBUTOR;
            // The source can be stale when SDT distributions are irregular; use
            // the most recent fully checkpointed epoch, never a partial current epoch.
            uint256 checkpointEnd = (d.lastTokenTime() / WEEK) * WEEK;
            if (checkpointEnd >= WEEK) {
                uint256 sourceEpoch = checkpointEnd - WEEK;
                e.benchmarkSourceEpoch = sourceEpoch;
                uint256 supply = VLSDT.totalSupplyAt(sourceEpoch);
                if (supply != 0) {
                    // Treat gross SDT principal (including SDT sent to PoL on mint)
                    // as if it had been staked directly into vlSDT for base yield.
                    uint256 sdtEquivalent = IStakingLocker(LOCKER).baseSDTEquivalent(totalActiveStake);
                    e.benchmark = Math.mulDiv(sdtEquivalent, d.tokensPerEpoch(sourceEpoch), supply);
                }
            }
        }

        uint256 oldBase = e.baseAllocated;
        uint256 oldFirst = e.firstExcessAllocated;
        uint256 oldReceived = e.received;
        uint256 received = oldReceived + amount;
        uint256 base = Math.min(received, e.benchmark);
        uint256 first = Math.min(received - base, e.benchmark / 2);
        uint256 second = received - base - first;
        uint256 baseDelta = base - oldBase;
        uint256 firstDelta = first - oldFirst;
        uint256 secondDelta = second - (oldReceived - oldBase - oldFirst);
        e.received = received;
        if (baseDelta != 0) e.baseAllocated = base;
        if (firstDelta != 0) e.firstExcessAllocated = first;
        if (noActiveStake) {
            // This income already consumes any remaining weekly base/tier allowance.
            // Because there are no stakers, forward it fully to treasury instead
            // of placing it in user streams or the normal excess-fee calculation.
            IERC20(token).safeTransfer(treasuryReceiver, amount);
            emit ImmediateTreasuryReward(token, amount);
            emit EpochIncomeApplied(token, epoch, e.benchmarkSourceEpoch, amount,
                0, 0, 0, amount, 0, 0, 0);
            return;
        }
        uint256 firstEligible = e.eligibleFirstExcess + firstDelta;
        uint256 secondEligible = e.eligibleSecondExcess + secondDelta;
        if (firstDelta != 0) e.eligibleFirstExcess = firstEligible;
        if (secondDelta != 0) e.eligibleSecondExcess = secondEligible;
        uint256 treasuryTarget = Math.mulDiv(firstEligible, FIRST_EXCESS_TREASURY_BPS, BPS)
            + Math.mulDiv(secondEligible, SECOND_EXCESS_TREASURY_BPS, BPS);
        // Admin and PoL tier percentages are identical; calculate their target once.
        uint256 adminAndPoLTarget = Math.mulDiv(firstEligible, FIRST_EXCESS_ADMIN_BPS, BPS)
            + Math.mulDiv(secondEligible, SECOND_EXCESS_ADMIN_BPS, BPS);
        uint256 treasuryDelta = treasuryTarget - e.treasuryAllocated;
        uint256 adminDelta = adminAndPoLTarget - e.adminAllocated;
        uint256 poLDelta = adminAndPoLTarget - e.poLAllocated;
        uint256 stakerExcess = amount - baseDelta - treasuryDelta - adminDelta - poLDelta;
        if (treasuryDelta != 0) e.treasuryAllocated = treasuryTarget;
        if (adminDelta != 0) e.adminAllocated = adminAndPoLTarget;
        if (poLDelta != 0) e.poLAllocated = adminAndPoLTarget;

        if (baseDelta != 0) _startIndependentStream(token, baseDelta);
        if (treasuryDelta != 0) {
            IERC20(token).safeTransfer(treasuryReceiver, treasuryDelta);
            emit ImmediateTreasuryReward(token, treasuryDelta);
        }
        if (adminDelta != 0) {
            IERC20(token).safeTransfer(admin, adminDelta);
            emit ImmediateAdminReward(token, admin, adminDelta);
        }
        if (poLDelta != 0) {
            address recipient = IStakingLocker(LOCKER).cyvlSdtPoLContract();
            if (recipient == address(0)) {
                pendingPoLRevenue[token] += poLDelta;
                emit PoLRevenueEscrowed(token, poLDelta);
            } else {
                IERC20(token).safeTransfer(recipient, poLDelta);
                emit PoLRevenueForwarded(token, recipient, poLDelta);
            }
        }
        if (stakerExcess != 0) {
            uint256 id = pendingConversions.length;
            pendingConversions.push(PendingConversion(token, stakerExcess, false));
            emit ExcessQueued(id, token, stakerExcess);
        }
        emit EpochIncomeApplied(token, epoch, e.benchmarkSourceEpoch, amount,
            baseDelta, firstDelta, secondDelta, treasuryDelta, adminDelta, poLDelta, stakerExcess);
    }

    /// @notice Forwards previously accrued PoL fees once the existing Locker PoL recipient is set.
    function forwardPendingPoLRevenue(address token) external nonReentrant returns (uint256 amount) {
        if (token != address(SDT) && token != address(USDC)) revert InvalidUnderlyingToken();
        address recipient = IStakingLocker(LOCKER).cyvlSdtPoLContract();
        if (recipient == address(0)) revert ZeroAddress();
        amount = pendingPoLRevenue[token];
        if (amount == 0) return 0;
        pendingPoLRevenue[token] = 0;
        IERC20(token).safeTransfer(recipient, amount);
        emit PoLRevenueForwarded(token, recipient, amount);
    }

    /// @notice Converts ONE receipt's staker-excess allocation into ONE new cyvlSDT stream.
    /// @dev If USDC->SDT has no route yet, funds remain pending; Merchant receipts never revert.
    function convertExcess(uint256 id) external nonReentrant returns (uint256 cyvlSdtOut) {
        if (id >= pendingConversions.length) revert InvalidConversion();
        PendingConversion storage c = pendingConversions[id];
        if (c.converted || c.amount == 0) revert NoPendingExcess();
        uint256 amount = c.amount;
        address token = c.token;
        c.converted = true;
        uint256 sdtOut = amount;
        if (token == address(USDC)) {
            ICurveYieldOmniRouter router = OMNI_ROUTER;
            if (router.routeLength(address(USDC), address(SDT)) == 0)
                revert ConversionRouteUnavailable();
            sdtOut = router.swapExactInput(address(USDC), address(SDT), amount, 1,
                address(this), block.timestamp);
        }
        uint256 beforeAmount = CYVLSDT.balanceOf(address(this));
        IStakingLocker(LOCKER).deposit(sdtOut, address(this));
        cyvlSdtOut = CYVLSDT.balanceOf(address(this)) - beforeAmount;
        if (cyvlSdtOut == 0) revert ZeroAmount();
        _startIndependentStream(address(CYVLSDT), cyvlSdtOut);
        emit ExcessConverted(id, amount, cyvlSdtOut);
    }

    /// @notice Safe public generic-reward claim: every reward token can only be paid to the caller.
    function claimRewardsSelf() external nonReentrant {
        // Snapshot the small (at most eight-token) list once for both passes.
        address[] memory tokens = rewardTokens;
        uint256 count = tokens.length;
        for (uint256 i; i < count; ++i) {
            address token = tokens[i];
            _checkpointReward(token);
            _checkpointUser(msg.sender, token);
        }
        // Keep all checkpointing ahead of token transfers, as in v60.
        for (uint256 i; i < count; ++i) {
            address token = tokens[i];
            uint256 amount = accruedRewards[msg.sender][token];
            if (amount == 0) continue;
            accruedRewards[msg.sender][token] = 0;
            IERC20(token).safeTransfer(msg.sender, amount);
            emit RewardClaimed(msg.sender, token, msg.sender, amount);
        }
    }

    function earned(address user, address token) external view returns (uint256) {
        if (!isRewardToken[token]) return 0;
        uint256 rewardPerToken = _previewRewardPerToken(token);
        return accruedRewards[user][token]
            + Math.mulDiv(activeBalance[user], rewardPerToken - userRewardPerTokenPaid[user][token], PRECISION);
    }

    function _checkpointAll(address account) internal {
        uint256 count = rewardTokens.length;
        for (uint256 i; i < count; ++i) {
            address token = rewardTokens[i];
            _checkpointReward(token);
            if (account != address(0)) _checkpointUser(account, token);
        }
    }

    function _checkpointUser(address account, address token) internal {
        RewardData storage data = _rewardData[token];
        uint256 paid = userRewardPerTokenPaid[account][token];
        uint256 current = data.rewardPerActiveStored;
        if (current != paid) {
            uint256 balance = activeBalance[account];
            if (balance != 0) {
                uint256 newlyEarned = Math.mulDiv(balance, current - paid, PRECISION);
                if (newlyEarned != 0) accruedRewards[account][token] += newlyEarned;
            }
            userRewardPerTokenPaid[account][token] = current;
        }
    }

    function _checkpointReward(address token) internal {
        RewardData storage data = _rewardData[token];
        uint256 from = data.lastUpdate;
        uint256 to = block.timestamp;
        if (from == 0) {
            data.lastUpdate = uint64(to);
            return;
        }
        if (to == from) return;

        uint256 head = data.streamHead;
        uint256 count = data.streams.length;
        if (head == count) {
            data.lastUpdate = uint64(to);
            return;
        }
        uint256 gross;
        uint256 nextHead = head;
        for (uint256 i = head; i < count; ++i) {
            Stream storage stream = data.streams[i];
            uint256 start = stream.start;
            if (start >= to) break;
            uint256 end = stream.end;
            if (end <= to) nextHead = i + 1;
            if (end <= from) continue;
            uint256 streamAmount = stream.amount;
            gross += _vested(streamAmount, start, end, to)
                - _vested(streamAmount, start, end, from);
        }
        if (gross != 0) {
            uint256 active = totalActiveStake;
            if (active == 0) {
                // No beneficiaries while the stream was vesting; direct it to treasury.
                IERC20(token).safeTransfer(treasuryReceiver, gross);
            } else {
                uint256 previousRemainder = data.scaledRemainder;
                uint256 scaled = gross * PRECISION + previousRemainder;
                uint256 delta = scaled / active;
                uint256 remainder = scaled % active;
                if (remainder != previousRemainder) data.scaledRemainder = remainder;
                if (delta != 0) data.rewardPerActiveStored += delta;
            }
        }
        data.lastUpdate = uint64(to);
        if (nextHead != head) data.streamHead = uint64(nextHead);
    }

    function _previewRewardPerToken(address token) internal view returns (uint256 rewardPerToken) {
        RewardData storage data = _rewardData[token];
        rewardPerToken = data.rewardPerActiveStored;
        if (data.lastUpdate == 0 || data.lastUpdate == block.timestamp || totalActiveStake == 0) {
            return rewardPerToken;
        }
        uint256 gross = _streamedBetween(data, data.lastUpdate, block.timestamp);
        if (gross == 0) return rewardPerToken;
        return rewardPerToken + (gross * PRECISION + data.scaledRemainder) / totalActiveStake;
    }

    function _streamedBetween(RewardData storage data, uint256 from, uint256 to)
        internal
        view
        returns (uint256 gross)
    {
        uint256 count = data.streams.length;
        for (uint256 i = data.streamHead; i < count; ++i) {
            Stream storage stream = data.streams[i];
            uint256 start = stream.start;
            if (start >= to) break;
            uint256 end = stream.end;
            if (end <= from) continue;
            uint256 amount = stream.amount;
            gross += _vested(amount, start, end, to)
                - _vested(amount, start, end, from);
        }
    }

    function _startIndependentStream(address token, uint256 amount) internal {
        if (amount == 0) return;
        if (!isRewardToken[token]) revert UnsupportedRewardToken();
        _checkpointReward(token);
        uint64 start = uint64(block.timestamp);
        uint64 end = uint64(block.timestamp + STREAM_DURATION);
        _rewardData[token].streams.push(Stream(amount, start, end));
        emit RewardStreamStarted(token, amount, start, end);
    }

    function _vested(uint256 amount, uint256 start, uint256 end, uint256 timestamp)
        internal
        pure
        returns (uint256)
    {
        if (timestamp <= start) return 0;
        if (timestamp >= end) return amount;
        return Math.mulDiv(amount, timestamp - start, end - start);
    }
}
